# Kites Studio — HD-2D look-dev, round 1

One scene, built twice, to compare two tech directions. The scene is **Windferry Hamlet**: a cozy hillside hamlet by a
stream at golden hour, with a blue-hour/night preset and rain. The point of round 1 is to answer one question —
does the look make you go *wow* and feel cozy, while being unmistakably HD-2D and *its own* thing?

| Build | Stack | Run | Evidence | Review |
|---|---|---|---|---|
| **Web** | three.js (WebGL2) + Vite | `cd web && npm install && npm run dev` → <http://127.0.0.1:5180/> | `review/web/round-2/` | `review/web-review-1.md` |
| **Godot** | Godot 4.7 Forward+ | `godot --path godot` | `review/godot/round-2/` | `review/godot-review-1.md` |

Both builds generate their pixel textures, foliage, particles and sky in code at load; the only imported art is the
shared hero sprite. Nothing is loaded from the reference games.

## Controls (identical in both)

| Key | Action |
|---|---|
| `1` | Golden hour (default) |
| `2` | Blue hour / night |
| `R` | Rain on/off (wet ground, puddles, rain rings on the pond) |
| `F` / `G` / `B` | Volumetrics / depth of field / bloom |
| `H` | Hide the HUD |
| drag / wheel | Limited pan along the strip / small zoom |

Godot adds `Q` (quality) and `P` (screenshot to `godot/shots/`). Web takes `?q=low|med|high` (default `high`).

## Measured performance (Apple M1 Pro, GPU idle)

| Build | Setting | Result |
|---|---|---|
| Web | `?q=high`, 2464×1260 internal | **~90 fps** (p95 frame 17.1 ms) |
| Godot | balanced, 2560×1440, MetalFX 0.8 | **70.3–70.8 fps** (14.1 ms), 3 consecutive runs |

Benchmark with the other build closed: the same Godot config measures anywhere from 27 to 71 fps while a browser tab
renders the web build, which is why earlier numbers in the round-1 reviews disagree.

## What is in the scene

- **Tiered diorama** with a narrow FOV and a tilted, lens-shifted camera: bokeh foreground grass and flowers, a sharp
  focal tier (path, stone bridge, the hero, campfire, lanterns), a raised terrace of three houses with distinct roofs,
  big pixel-cluster trees, hazy ridges and a band of sky with drifting pixel clouds.
- **Water**: stream → waterfall → lily pond with a real mirror reflection, ripples, Fresnel, sun/moon glints, rain rings.
- **Light**: low golden sun with shadows, shadowed god rays, lantern and window scattering, height fog with aerial
  perspective, mist on the water, bloom, filmic tonemap with warm highlights and cool shadows, vignette, light CA + grain.
- **Life**: one gusting wind field drives grass, flowers, reeds, canopies, laundry, bunting, smoke, leaves, dust and the
  kite; butterflies, a bird flock, hopping birds, fireflies, a turning water wheel / windmill.
- **Hero**: the shared 2-head-tall pixel sprite (`assets/character/hero.png`, 47×65), lit by the scene with rim light,
  cast shadow and a contact shadow. Static by design in round 1.

## Layout

- `docs/ART_BRIEF.md` — the brief both builds were held to (requirements, scene concept, Octopath developer notes,
  technique guidance, review protocol). `docs/REVIEWER_TASK.md` — the reviewer brief.
- `refs/` — reference material: frames from the two Bilibili videos, Steam screenshots of The Last Night and LONG GONE,
  and the full source of the "The Last Night tribute" three.js scene that inspired the pipeline.
- `assets/character/` — the shared hero sprite plus its .aseprite source and an auto-pixelised AI source.
- `review/` — independent reviews and their captures. The `.png` captures are local evidence and are not committed.
- `web/`, `godot/` — the two builds, each with its own README (techniques, identity notes, known limits).

## Status

Round 1 of an iterative look-dev. Both builds run, are measured, and have been through one independent review plus a
fix pass; the round-2 reviews are pending.
