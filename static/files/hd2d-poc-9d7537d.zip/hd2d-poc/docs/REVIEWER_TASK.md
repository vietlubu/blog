# Reviewer task template (round 1)

You are the art-direction + tech reviewer for ONE track (`web` or `godot`) of the HD-2D look-dev.
You do not write production code in the build. You may write throwaway capture scripts under `review/<track>/`.

1. Read `docs/ART_BRIEF.md` (requirements, Octopath notes, review protocol) and the builder's `<track>/README.md`.
2. Look at the references side by side: `refs/hi/town_day.jpg`, `refs/hi/town_night.jpg`, `refs/hi/town_autumn.jpg`,
   `refs/town_sheet.jpg`, `refs/lastnight_sheet.jpg`, `refs/longgone_sheet.jpg`, `refs/hi/tribute_*.jpg`, `refs/tribute_sheet.jpg`.
3. Run the build yourself (do not trust the builder's screenshots):
   - web: `cd web && npm install && npm run dev` → http://127.0.0.1:5180/ ; capture with the Chrome DevTools MCP
     (`xd://mcp__chrome_devtools_*`, read each doc first; screenshots with `filePath`), check console errors, measure FPS.
   - godot: `godot --path godot -- --shot=<abs.png> --shot-delay=<sec> [--preset=night]`; motion via
     `godot --path godot --write-movie /tmp/<x>.avi --fixed-fps 30 --quit-after 150` + ffmpeg frame extraction; check stdout/stderr for errors.
   Capture: golden-hour full frame, 2× crop around the hero, night preset, foreground/background DOF regions, water reflection region,
   and 4+ frames over ~4 s (or a GIF) to judge motion. Save under `review/<track>/review-<n>/`.
4. Judge against the references, not against "it renders". Be specific and visual: point to regions, compare to a named reference frame.
   Check the hard requirements one by one (life, volumetrics, reflections, camera/DOF, 2-head hero lit by the scene, performance).
   Check pixel-art fidelity (consistent texel density, no blurry/mip-mapped pixel textures, no diagonal pixel grids, no shimmering),
   readability of the hero, composition of the default framing, palette/grading, and whether the scene has its OWN HD-2D identity.
   Also read the implementation (shaders, scene setup) and flag tech that is fragile, wasteful, or will not scale to a game.
5. When something is weak, research how others solved it (web search; cite links) and give the concrete technique.
6. Write `review/<track>-review-<n>.md`: verdict (one paragraph), score table (brief's categories, 1–10), then prioritized change
   requests **P0 (must fix before the owner sees it) / P1 / P2**, each with: evidence (screenshot path + region), what is wrong vs which
   reference, the concrete fix. Keep it actionable; ≤ 15 requests, P0 first.
7. Final message: the verdict, the score table, and the P0 list.
