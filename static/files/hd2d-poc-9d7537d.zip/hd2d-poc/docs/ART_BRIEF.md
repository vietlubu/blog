# HD-2D Round 1 — Art & Tech Brief (shared by the Web and Godot builds)

## Goal of round 1
Build ONE living, refined HD-2D diorama scene that proves the game's look can make a viewer go "wow"
and feel cozy. The owner will open each build tomorrow and judge only the real-time scene:
does it reproduce the **liveliness and refinement** of the references while having **its own HD-2D identity**?

No gameplay. The character does not need to move (static sprite; a subtle idle breathe/blink is optional).

## Hard requirements (acceptance checklist)
1. **Static + dynamic life**: houses, flowers, grass and trees swaying in a wind field (with gusts),
   falling leaves and/or rain, birds and butterflies. Plus small touches: chimney smoke, water ripples, dust motes.
2. **Volumetric light + subtle, believable reflections**: shadowed god rays (sun through canopy / between houses),
   local light scattering (lanterns, windows), water that reflects the scene, wet/glossy highlights where plausible.
3. **Camera angle + depth of field**: diorama/tilt-shift framing, narrow FOV, focus on the hero, bokeh foreground and background.
4. **A pixel-art character, ~2 heads tall** (head ≈ half of total height), placed in the scene and lit by the scene.
   Shared sprite: `assets/character/hero.png` (transparent PNG, pivot = bottom-center, feet on the last opaque row,
   facing down-right in front 3/4 view). Copy it into your project. Both builds use the same sprite so they can be compared.
   Final sprite: **47×65 px** (art 42×64, head = top 32 rows → exactly 2 heads tall; feet on the bottom row, feet centred at x≈24).
   Derive the world-space height from the PNG size × texel density; never hardcode it.
5. Runs smoothly (target 60 fps at ~1440p on an Apple Silicon Mac; provide a quality switch if needed).

## References (all local — look at them before designing)
| # | Ref | Local path | Take from it |
|---|-----|-----------|--------------|
| 1 | Octopath Traveler (HD-2D origin) | notes below | pixel textures + normal/spec maps reacting to dynamic light, tilt-shift DOF, narrow FOV, chibi scale, tiered level, post stack |
| 2 | The Last Night (Steam shots) | `refs/steam/612400_*.jpg`, sheet `refs/lastnight_sheet.jpg` | pixel art in true 3D light: fog shafts, rim-lit silhouettes, glow, wet reflections, cinematic grading |
| 3 | LONG GONE (Steam shots) | `refs/steam/1977610_*.jpg`, sheet `refs/longgone_sheet.jpg` | daylight pixel-art in 3D: overgrown foliage density, warm sun shafts in dusty air, painterly skies, depth haze |
| 4 | "The Last Night tribute" by Opus (three.js, full source) | code: `refs/the-last-night-tribute/` (read `README.md`, `src/render/pipeline.js`, `src/render/shaders.js`, `src/world/sprites.js`, `src/core/textures.js`); video frames `refs/tribute/`, `refs/tribute_sheet.jpg`, `refs/hi/tribute_*.jpg`; full video `~/Downloads/the-last-night-tribute.mp4` | proven techniques: procedural pixel textures + per-texel normals from height, planar reflection, half-res ray-marched volumetric fog with shadowed spot shafts, sprite volume normals + rim light, gather bokeh DOF, bloom mip chain, ACES grading |
| 5 | **Cozy miniature town** (the owner's main inspiration) | frames `refs/town/`, sheet `refs/town_sheet.jpg`, hi-res `refs/hi/town_*.jpg`; full video `~/Downloads/hd2d.mp4` | horizontal diorama layout, cozy palette, blocky pixel-cluster tree canopies, chibi billboard characters, campfire/crystal light, fireflies, chimney smoke, pond reflections, heavy tilt-shift DOF, seasons & time of day |

### Octopath Traveler — what the developers said (UNREAL FEST EAST 2018, Acquire; 4Gamer report
<https://business.4gamer.net/article/1810/18101801/>; also Unreal spotlight
<https://www.unrealengine.com/spotlights/octopath-traveler-s-hd-2d-art-style-and-story-make-for-a-jrpg-dream-come-true>)
- Concept: "what if late-SNES dot art had kept evolving as dot art instead of becoming 3DCG".
- Dot-art textures get **normal + specular maps**, so dynamic lights and shadows change the pixels in real time.
- **Tilt-shift lens look**: DOF + lens post effects → miniature feel. Early builds with everything crisp and evenly lit felt
  "old-gen"; what people want is the **memory-corrected** look: air, depth, DOF, beautiful effects, *but not overdone*.
- **Narrow FOV, gentle perspective** (a normal 3D FOV felt too wide vs 2D games).
- **Scale**: houses shrunk to fit **2-head chibi characters** (FF6 style); characters at house-scale do not read as 2D.
- **Tiered (hina-dan) level design**: back of the map higher, so the tilted camera sees dense content instead of sky.
- Master material features: **world-space UVs** (pixels never rotate diagonally, seams vanish), circular **alpha cut-out**
  of foreground objects around the character, top-facing snow/sand projection, **gradient tinting to break 16×16 repetition**,
  **wind sway shader** with gust strength.
- Post: Color grading, Bloom, Bokeh DOF, **lens flares only at specific spots** (very high threshold; sun glints on water,
  sunset sun), ambient cubemap, vignette, chromatic aberration in dramatic moments.

## Scene concept (same for both builds)
**"Windferry Hamlet" — a cozy hillside hamlet by a stream, late-summer golden hour turning to dusk.**
A horizontal diorama strip (read left→right like the town reference), seen from a tilted, narrow-FOV camera.

Tiers, front to back:
- **T0 foreground (out of focus)**: tall grass tufts, wildflowers, a fence post, a leafy branch entering a top corner to frame the shot.
- **T1 focal tier (sharp)**: dirt/cobble path along a small stream; a small arched stone (or wooden) bridge; **the hero stands on the
  path near the bridge**; flower beds, a bench, a lantern post, crates/barrels, a laundry line.
- **T2 (slightly higher)**: 2–4 cozy timber-and-plaster houses with distinct roofs (slate / clay tile / thatch), chimneys with smoke,
  warm-lit windows, flower boxes; optionally a water wheel turning on the stream.
- **T3 background (higher terrain, soft blur)**: one or two big old trees with blocky pixel-cluster canopies that the sun shines
  through, hillside with more roofs / a windmill, forest edge.
- **T4 far**: hills/mountains in aerial haze, painterly pixel clouds drifting, sky gradient.
- **Water**: the stream widens into a pond with lily pads and reeds; it reflects houses, sky, lanterns; ripples, sun glints.

Mood & light (default preset "Golden hour"): low warm sun from behind/side → long shadows, shafts through the canopy and between houses,
dust/pollen glittering in the shafts, mist over water, warm rim on the hero and foliage edges, cool blue-violet ambient in shadow,
windows and 1–3 lanterns just starting to glow. Provide at least a second preset **"Blue hour / night"** (lanterns, lit windows, moon,
fireflies, stronger volumetrics) — the owner's references are about light, and the cozy-town video's day/night range impressed them.
Rain is optional (a toggle that makes surfaces wet is a strong reflection showcase if time allows).

Life: one shared wind field drives grass, flowers, reeds, tree canopies, laundry, banners and smoke; falling leaves drift with it;
butterflies flutter around flowers; a bird flock crosses the sky now and then and 1–2 birds hop on a roof/ground; fireflies in shade/at night.
Optional signature touch: a kite flying above the hill (the studio is "Kites Studio").

## "Own HD-2D identity" — required
Do not clone reference 5. Make deliberate style choices and **write them down** (3–6 bullets) in your build's README:
e.g. palette & hue-shifted ramps, texel density, how foliage is built, how light is graded, what makes it feel *yours*.
Keep HD-2D fundamentals: crisp pixel art at the focal plane, real 3D light/shadow/fog/reflection on it, tilt-shift depth.

## Technical guidance (both builds)
- **Texel density**: one consistent density for environment textures and sprites (suggestion 1 texel = 1/32 world unit →
  a 64-texel-tall hero ≈ 2 units, door ≈ 2.5 units, small house ≈ 5–7 units to the ridge). Nearest-neighbour sampling, no blurry mips.
- **Assets**: everything original. Generate pixel textures procedurally in code (like ref 4) and/or draw them. Pixel Maker MCP
  (`xd://mcp__pixel_maker_*`, workspace id `fe5abdc9a597f45aa8513475f5195a23`) can generate props/tiles if you want hand-drawn-looking
  pixel art (AI output often has an irregular pixel grid — verify at integer zoom). The live Aseprite MCP is single-instance and
  reserved for the hero-sprite cleanup; don't use it from the builds.
  Per-texel normal maps (from a height map) for bricks, roof tiles, bark, cobbles, planks.
- **Sprites in 3D**: Y-axis billboard (or fixed facing) quads with alpha-tested cut-out; volume normals from the blurred alpha
  silhouette; receive and cast shadows; rim light from lights behind; small contact shadow.
- **Foliage**: blocky pixel-cluster canopies (voxel-ish clumps or layered cards) + instanced grass/flowers; vertex wind with gusts.
- **Volumetrics**: shadowed sun shafts (ray-marched fog sampling the shadow map, half-res + bilateral upsample) and local light
  scattering; height fog + aerial perspective; mist over the water.
- **Reflections**: planar mirror (or SSR) for water with ripple-normal distortion and Fresnel; subtle spec on wet stones/windows.
- **DOF**: tilt-shift — focus on the hero; strong near-foreground and background bokeh; keep the focal band crisp.
- **Post**: HDR → bloom (soft, high threshold) → filmic tonemap (ACES/AgX) → grading (warm highlights, cool lifted shadows) →
  vignette, very light chromatic aberration at the edges, light grain. Lens glints only on sun-on-water / brightest lamps. No CRT gimmicks.
- **Camera**: narrow FOV (~20–30° vertical), pitch ~15–25° down; slow "breathing" drift to show parallax; optional limited
  drag-to-pan along the strip and a small zoom range. Default framing must already be the money shot.
- **Controls** (keep consistent across builds): `1` golden hour, `2` blue hour/night, `R` rain (if implemented),
  `F` fog/volumetrics on/off, `G` DOF on/off, `B` bloom on/off, `H` hide HUD, `P` save screenshot (Godot). HUD minimal and fades out.

## Deliverables
- **Web** → `web/` (three.js + Vite, WebGL2). `cd web && npm install && npm run dev` serves on **http://127.0.0.1:5180/**;
  `npm run build` produces a static `web/dist/`.
- **Godot** → `godot/` (Godot 4.7, binary `godot` on PATH, Forward+). `godot --path godot` runs the scene.
  Must support a capture mode for reviewers: `godot --path godot -- --shot=<abs.png> --shot-delay=<sec> [--preset=night]` saves a
  screenshot and quits. Motion can be recorded with Godot Movie Maker (`--write-movie <file.avi> --fixed-fps 30 --quit-after <frames>`).
- Each build: `README.md` (run, controls, techniques, **style identity bullets**, known limits).
- Evidence: screenshots in `review/<web|godot>/round-<n>/` (hero shot golden hour, crop around hero, night preset, plus a few
  frames over time proving motion).

## Review protocol (reviewers)
Run the build yourself, capture stills + motion, compare side by side with the references above. Score 1–10 and justify:
composition & tiered depth · pixel-art fidelity & texel consistency · lighting & volumetrics · reflections · DOF & camera ·
life/animation · palette & grading · character integration (2-head scale, lit by scene) · own HD-2D identity · performance/stability · code quality.
Write `review/<track>-review-<n>.md`: verdict, scores, then **prioritized change requests (P0/P1/P2)**, each with evidence
(screenshot + region), the concrete fix/technique, and links when you researched something online.
