# Windferry Hamlet — HD-2D round 1 (Godot 4.7, Forward+)

A cozy hillside hamlet by a stream at golden hour, built as one real-time HD-2D diorama.
Everything (textures, sprites' normal maps, foliage, clouds, birds, kite) is generated at startup
from code — there are no imported assets except the shared hero sprite, which is loaded raw.

## Run

```bash
godot --path godot                                   # windowed, 2560x1440 px (1280x720 pt on Retina)
godot --path godot -- --high                         # screenshot quality tier (also: press Q)
godot --path godot -- --shot=/abs/out.png --shot-delay=8 [--preset=night] [--rain] [--high]
godot --path godot -- --bench                        # prints average FPS over seconds 6–16, then quits
godot --path godot --write-movie /tmp/wf.avi --fixed-fps 30 --quit-after 360 -- --nohud
```

A fresh clone needs no editor import step: scripts, shaders and the scene load directly and
`assets/hero.png` is read with `Image.load_from_file`. The hero size is derived from the PNG
(`width/32 × height/32` units, pivot bottom-centre), so replacing `assets/hero.png` just works.

## Controls

| Key | Action |
| --- | --- |
| `1` / `2` | golden hour / blue hour–night (cross-fades over ~2.5 s) |
| `R` | rain on/off (wet roughness, rain streaks, ripple rings on the pond) |
| `F` / `G` / `B` | volumetrics / depth of field / bloom |
| `Q` | quality: balanced (default) ↔ high |
| `H` | hide HUD (it also fades by itself after 6 s) |
| `P` | save a screenshot to `godot/shots/` |
| drag / wheel | limited pan along the strip / small zoom |

## How it is built

- **One texel density everywhere: 32 texels per world unit.** Hero (47×65 px) → 1.47×2.03 units,
  leaf cards 64 px → 2 units, grass tufts 24×32 px → 0.75×1 unit. Every architectural surface
  is pixel art evaluated *per world texel* in `shaders/surface.gdshader` (plaster, rubble stone, barrel clay tiles,
  slate, thatch, planks, beams, bark, cobbles, glass) with UVs in world units, so pixels never
  stretch or rotate and adjacent boxes share one grid. Each texel's value is quantised to a 4-tone
  hue-shifted ramp; a per-texel height gives a per-texel normal (cotangent frame, no mesh tangents).
  A large soft tint gradient breaks repetition (the Octopath "gradient tinting" trick).
- **Ground** (`terrain.gdshader`): grass / dirt path / cobbles / wet bank / pond bed resolved per
  texel from a 2 px-per-unit mask with hash-dithered borders; 5-tone grass ramp with 1×2 "blade"
  strokes and single-texel wildflowers; animated caustics on the pond bed.
- **Tiers**: T0 out-of-focus tufts, reeds and a fence; T1 cobbled path, arched stone bridge, hero, lanterns,
  bench, barrels/crates; T2 behind a mossy retaining wall (culvert + cascade, stairs) with three
  timber-and-plaster houses (thatch / clay tile / slate), shutters, flower boxes, chimneys, lit windows,
  laundry and a kite banner; T3 big old tree, hill cottages, windmill, forest edge; T4 layered hazy ridges + pixel clouds.
- **Foliage**: canopies are clusters of 2-unit leaf cards (voronoi leaf-cluster pixel atlas) placed on
  ellipsoid lobes with outward per-vertex normals and depth AO, so they shade as round volumes,
  cast dappled alpha-scissor shadows and transmit light (backlight). Grass/flowers/reeds are a MultiMesh.
- **One wind field** (`shaders/common.gdshaderinc`, mirrored in `life.gd`): travelling gust fronts along
  `wind_dir` drive grass, flowers, reeds, canopies, laundry, banner, falling leaves (custom particle shader),
  water ripple strength ("cat's paws"), chimney smoke drift, butterflies, kite and windmill speed.
- **Light**: low warm sun (directional, PSSM shadows), cool lavender ambient, ACES filmic tonemap.
  Volumetric fog follows Godot's "volumetric lighting" recipe (ambient inject 0) plus a world FogVolume whose
  density grows with camera distance — the focal tier stays clear and deep-valued while sun shafts
  appear through the canopy and between houses. Lanterns and windows are omni lights with volumetric
  energy for local scattering; mist hugs the pond (ellipsoid FogVolume with a drifting fog shader).
- **Water** (`water.gdshader`): planar mirror via a SubViewport camera reflected about the water plane
  (geometry under the plane is discarded in that pass); ripple normals snapped to the 32-texel grid
  distort reflection and depth-tinted refraction; Fresnel; sparse texel sun/moon glints that bloom;
  shoreline foam, cascade rings, rain rings.
- **Hero sprite** (`sprite.gdshader`): volume normals from the blurred alpha silhouette, wrap diffuse,
  a rim term from every light that sits behind/beside the sprite, alpha-scissor shadow casting/receiving,
  a soft contact-shadow decal. Birds, songbirds, butterflies, kite use the same shader.
- **Camera / post**: 21° vertical FOV, 12.5° pitch, slow breathing drift; Godot bokeh DOF (circle) refocused on
  the hero every frame with a narrow focal band (tilt-shift miniature read); bloom; a canvas pass for split-tone
  grade (cool shadows / warm highlights), vignette, edge-weighted chromatic aberration and fine grain.
- **Presets**: every look parameter is a blend between golden hour and blue hour (sun→moon, sky, fog colour/density,
  window/lantern energy, fireflies) plus a rain blend, so `1`/`2`/`R` cross-fade instead of popping.

## Own HD-2D identity

- **"Texel-true world"**: not just textures — water ripples, glints, ground transitions and foliage all snap to the
  same 32-texel world grid, so even moving light breaks into pixel-sized shards.
- **Hue-shifted 4-tone ramps per material** (mauve-violet shadows on warm stone, teal-green shadow grass, rust-orange tile)
  and *continuous* light on top — the palette is quantised, the lighting never is.
- **Leaf-cluster canopies** built from pixel voronoi clumps on lit volumes, chunkier and rounder than the reference
  town's cube voxels, closer to a storybook gouache read.
- **Clear focal band, hazy world**: fog density is a function of distance from the lens, so the hero tier stays crisp
  and saturated like a lit stage while god rays live behind it.
- **Kites Studio signature**: a kite flies over the right meadow and the hamlet banner carries a kite emblem.

## Performance (Apple M1 Pro, 2560×1440)

Measured with `--bench` on an **idle GPU** (`review/godot/round-2/fps.txt`), three consecutive runs:
**balanced 70.3–70.8 fps (14.1–14.2 ms)**, draws 120–251. Target was 60 fps at ~1440p, so balanced clears it.

Every earlier number (round-1's 49 fps, the 36 fps a first run prints while shaders compile) is GPU-contention or
warm-up noise: with a Chrome tab rendering the web build the *same* configuration measured anywhere between 27 and
71 fps. Benchmark with the browser closed.

Balanced drops MSAA (SMAA instead), SSAO, uses 2 shadow splits, 96×64 froxels and a 30 Hz 0.36-scale mirror, and
renders 3D at 0.8 with MetalFX spatial. `Q`/`--high` is meant for screenshots. `--scale=<x>` overrides the 3D scale.

## Round-2 changes (after `review/godot-review-1.md`)

The round-1 builder hit an account rate limit mid-pass; these edits are the orchestrator's, on top of its round-2 work.
Evidence: `review/godot/round-2/`.

- Pond reflection fixed (the double `pow(refl, 2.2)` decode is gone), water-edge reeds moved to a layer the mirror
  camera sees, camera reframed with a sky band, wall broken into segments, thinner far haze.
- **God-ray cost cut**: the slice stack was 20 full-quad additive layers, ~9 ms of frame time at 1440p. It is now 10
  slices with smaller quads and `density` 0.0035 → 0.0075; hiding the stack now moves frame time by ~1.5 fps instead of ~9.
  The lower slice count also removed the blown-out amber smear over the top-left of the golden-hour frame.
- **Night pond glint tamed**: `glint` 10 → 5 and `glint_lo` → 0.995 at night. The broad lobe was turning the whole pond
  into one white blob that bloomed; it is now a few sparkles.

## Research links

- Octopath developers' talk (4Gamer report): <https://business.4gamer.net/article/1810/18101801/>
- Godot — Volumetric fog and fog volumes (volumetric lighting recipe): <https://docs.godotengine.org/en/stable/tutorials/3d/volumetric_fog.html>
- Godot — Fog Volumes arrive in Godot 4.0: <https://godotengine.org/article/fog-volumes-arrive-in-godot-4>
- Godot — CameraAttributesPractical (DOF): <https://docs.godotengine.org/en/stable/classes/class_cameraattributespractical.html>
- Godot — Creating movies (Movie Maker): <https://docs.godotengine.org/en/stable/tutorials/animation/creating_movies.html>
- Planar reflection in Godot 4 (reference implementations): <https://godotengine.org/asset-library/asset/4102>, <https://github.com/JyarlJung/GodotWaterShader>
- Normal mapping without precomputed tangents (cotangent frame): <http://www.thetenthplanet.de/archives/1180>
- Techniques studied (not copied) from the local "The Last Night tribute" source: sprite rim lighting, per-texel normals from height.

## Known limits

- Godot's built-in DOF is a gather bokeh driven by distance; near-foreground blur is softer than a dedicated
  scatter bokeh, and very bright bokeh discs are not shaped like the tribute's.
- The mirror camera has no oblique clip plane in Godot 4.7; geometry below the water is discarded in the terrain and
  surface shaders instead (other materials, e.g. reeds, are simply not drawn in the mirror).
- Volumetric shafts come from Godot's froxel fog; they are softer and lower-frequency than a dedicated half-res ray march.
- The hero is static (no idle animation); the camera only drifts and does not follow anything.
