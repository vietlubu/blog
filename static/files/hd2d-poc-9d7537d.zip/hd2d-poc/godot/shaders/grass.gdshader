// Instanced grass / flower / reed tufts (MultiMesh). INSTANCE_CUSTOM.x = atlas cell, .y = phase.
shader_type spatial;
render_mode cull_disabled, world_vertex_coords;
#include "res://shaders/common.gdshaderinc"

uniform sampler2D atlas : source_color, filter_nearest;
uniform float cells = 8.0;
uniform float sway = 1.0;

varying float hf;
varying float wy;

void vertex() {
	hf = 1.0 - UV.y;
	vec3 root = MODEL_MATRIX[3].xyz;
	float ph = INSTANCE_CUSTOM.y * 6.2831;
	vec2 w = wind_offset(root.xz, TIME, ph) * sway * hf * hf * max(VERTEX.y - root.y, 0.0);
	VERTEX.xz += w;
	VERTEX.y -= dot(w, w) * 0.35;
	wy = VERTEX.y;
	UV.x = (UV.x + INSTANCE_CUSTOM.x) / cells;
	NORMAL = normalize(vec3(0.0, 1.0, 0.0) + NORMAL * 0.3);
}

void fragment() {
	if (CAMERA_POSITION_WORLD.y < water_level && wy < water_level) {
		discard; // planar reflection pass: nothing below the mirror plane
	}
	vec4 c = texture(atlas, UV);
	ALBEDO = c.rgb * COLOR.rgb * mix(0.6, 1.0, hf);
	ALPHA = c.a;
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	BACKLIGHT = vec3(0.3, 0.38, 0.12);
	ROUGHNESS = mix(0.8, 0.2, wetness);
	SPECULAR = 0.2;
}
