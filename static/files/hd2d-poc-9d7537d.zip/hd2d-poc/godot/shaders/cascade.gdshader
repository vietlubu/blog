// Little cascade from the culvert: scrolling pixel streaks, foam at the lip.
shader_type spatial;
render_mode blend_mix, cull_disabled, depth_draw_never;
#include "res://shaders/common.gdshaderinc"

uniform vec3 water : source_color = vec3(0.5, 0.7, 0.75);

void fragment() {
	vec2 t = floor(UV * vec2(48.0, 32.0));
	float s = hash12(vec2(t.x, floor(t.y * 0.25 - TIME * 10.0 + hash12(vec2(t.x, 1.0)) * 9.0)));
	float foam = step(0.62, s) + step(0.8, UV.y) * step(0.5, hash12(t + floor(TIME * 12.0)));
	ALBEDO = mix(water * 0.6, vec3(0.95), clamp(foam, 0.0, 1.0));
	ROUGHNESS = 0.2;
	ALPHA = clamp(0.55 + foam, 0.0, 0.95) * smoothstep(0.0, 0.08, UV.x) * smoothstep(1.0, 0.92, UV.x);
}
