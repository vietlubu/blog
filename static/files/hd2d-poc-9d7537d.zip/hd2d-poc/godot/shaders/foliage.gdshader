// Canopy / branch leaf cards: pixel-cluster atlas, outward (spherical) normals baked per vertex,
// wind sway weighted by UV2.x, translucency so backlit leaves glow at golden hour.
shader_type spatial;
render_mode cull_disabled, world_vertex_coords;
#include "res://shaders/common.gdshaderinc"

uniform sampler2D atlas : source_color, filter_nearest;
uniform float sway = 0.35;
uniform vec3 tint : source_color = vec3(1.0);
uniform vec3 translucent : source_color = vec3(0.35, 0.45, 0.12);

void vertex() {
	vec2 w = wind_offset(VERTEX.xz, TIME, UV2.y) * sway * UV2.x;
	w += vec2(sin(TIME * 3.1 + UV2.y * 7.0), cos(TIME * 2.7 + UV2.y * 5.0)) * 0.03 * UV2.x * (0.4 + wind_gust(VERTEX.xz, TIME));
	VERTEX.xz += w;
	VERTEX.y -= dot(w, w) * 0.3;
}

void fragment() {
	vec4 c = texture(atlas, UV);
	ALBEDO = c.rgb * COLOR.rgb * tint;
	ALPHA = c.a;
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	BACKLIGHT = translucent;
	ROUGHNESS = 0.7;
	SPECULAR = 0.25;
}
