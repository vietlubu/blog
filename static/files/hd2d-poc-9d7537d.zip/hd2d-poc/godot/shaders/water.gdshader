// Pond + stream: planar mirror reflection (SubViewport camera) distorted by texel-quantised ripple
// normals, depth-tinted refraction, Fresnel, sun glints (GGX), wind "cat's paws", rain rings.
shader_type spatial;
render_mode blend_mix, depth_draw_always, cull_back, specular_schlick_ggx;
#include "res://shaders/common.gdshaderinc"

uniform sampler2D reflection_tex : filter_linear, repeat_disable;
uniform sampler2D screen_tex : hint_screen_texture, filter_linear, repeat_disable;
uniform sampler2D depth_tex : hint_depth_texture, filter_nearest, repeat_disable;
uniform vec3 shallow : source_color = vec3(0.55, 0.7, 0.55);
uniform vec3 deep : source_color = vec3(0.04, 0.1, 0.12);
uniform float refl_strength = 0.92;
uniform float distort = 0.018;
uniform vec2 cascade_pos = vec2(-4.0, -4.3);
uniform vec3 sun_dir = vec3(0.0, 0.5, -0.8);
uniform vec3 sun_col : source_color = vec3(1.0, 0.7, 0.4);
uniform float glint = 18.0;
uniform float glint_lo = 0.94;

varying vec3 wpos;

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

float wave(vec2 p, float t) {
	float h = sin(dot(p, vec2(0.9, 0.4)) * 2.2 - t * 1.4) * 0.5
		+ sin(dot(p, vec2(-0.3, 1.0)) * 3.1 - t * 1.9) * 0.3
		+ (vnoise(p * 2.5 + vec2(t * 0.4, t * 0.25)) - 0.5) * 0.8
		+ (vnoise(p * 6.0 - vec2(t * 0.6, -t * 0.3)) - 0.5) * 0.35;
	return h * 0.03;
}

// expanding rain rings, one random drop per 0.6-unit cell
vec2 rings(vec2 p, float t) {
	vec2 g = vec2(0.0);
	vec2 c = floor(p / 0.6);
	for (int j = 0; j <= 1; j++) {
		for (int i = 0; i <= 1; i++) {
			vec2 cell = c + vec2(float(i), float(j));
			vec2 h = hash22(cell);
			float ph = fract(t * (0.8 + h.x * 0.6) + h.y);
			vec2 ctr = (cell + h) * 0.6;
			vec2 dv = p - ctr;
			float d = length(dv);
			float r = ph * 0.45;
			float ring = exp(-pow((d - r) * 28.0, 2.0)) * (1.0 - ph);
			g += dv / max(d, 1e-3) * ring;
		}
	}
	return g * 1.5;
}

void fragment() {
	vec2 p = wpos.xz;
	vec2 q = (floor(p * 32.0) + 0.5) / 32.0; // ripples snap to the world texel grid
	float t = TIME;
	float amp = 0.7 + wind_gust(q, t) * 1.8 * wind_strength;
	float e = 1.0 / 32.0;
	float h0 = wave(q, t);
	vec2 g = vec2(wave(q + vec2(e, 0.0), t) - h0, wave(q + vec2(0.0, e), t) - h0) * 32.0 * amp;
	float dc = length(p - cascade_pos);
	g += vec2(sin(dc * 14.0 - t * 7.0)) * normalize(p - cascade_pos + 1e-3) * 0.25 * smoothstep(2.5, 0.3, dc);
	g += rings(q, t) * rain;
	vec3 nw = normalize(vec3(-g.x, 1.0, -g.y));
	NORMAL = normalize((VIEW_MATRIX * vec4(nw, 0.0)).xyz);

	float zr = texture(depth_tex, SCREEN_UV).r;
	vec4 vp = INV_PROJECTION_MATRIX * vec4(SCREEN_UV * 2.0 - 1.0, zr, 1.0);
	vp.xyz /= vp.w;
	float depth = max(0.0, VERTEX.z - vp.z);
	vec2 off = nw.xz * distort * clamp(depth * 3.0, 0.0, 1.0);
	vec3 refr = textureLod(screen_tex, SCREEN_UV + off * 0.5, 0.0).rgb;
	float absorb = 1.0 - exp(-depth * 2.6);
	refr = mix(refr * shallow * 0.8, deep * (1.0 - night * 0.7), absorb);

	// mirror RT is HDR linear (use_hdr_2d): sample as-is. Distortion stretched vertically so lights streak.
	vec3 refl = texture(reflection_tex, vec2(1.0 - SCREEN_UV.x, SCREEN_UV.y) + vec2(-off.x * 1.2, off.y * 4.0)).rgb;
	vec3 V = normalize(-VERTEX);
	float ndv = clamp(dot(NORMAL, V), 0.0, 1.0);
	float fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
	float k = clamp(mix(0.7, 1.0, fres) * refl_strength, 0.0, 1.0) * smoothstep(0.0, 0.1, depth);

	float fn = hash12(floor(p * 16.0) + floor(t * 3.0));
	float foam = step(depth + (fn - 0.5) * 0.08, 0.035);
	foam = max(foam, step(fn, smoothstep(1.6, 0.2, dc) * 0.8));
	ALBEDO = vec3(0.85, 0.9, 0.88) * foam;
	// pixel glints: steepened texel normals reflecting the sun/moon -> sparse sparkles that bloom
	vec3 vw = normalize(CAMERA_POSITION_WORLD - wpos);
	vec3 ng = normalize(vec3(-g.x * 4.0, 1.0, -g.y * 4.0));
	float spark = smoothstep(glint_lo, 1.0, dot(reflect(-vw, ng), sun_dir)) * step(0.55, hash12(floor(p * 32.0) + floor(t * 6.0)));
	EMISSION = mix(refr, refl, k) * (1.0 - foam) + sun_col * spark * glint * (1.0 - foam);
	ROUGHNESS = mix(0.05, 0.6, foam);
	SPECULAR = 0.6;
	ALPHA = 1.0;
}
