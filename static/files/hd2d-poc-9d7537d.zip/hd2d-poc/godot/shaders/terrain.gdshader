// Ground: grass / dirt path / cobbles / wet banks / pond bed, evaluated per world texel (32 / unit)
// so pixels never rotate or stretch, with organic dithered borders from a low-res mask.
shader_type spatial;
#include "res://shaders/common.gdshaderinc"

uniform sampler2D mask : filter_linear, repeat_disable; // r dirt path, g cobbles, a flower density
uniform vec4 bounds = vec4(-60.0, -70.0, 120.0, 94.0);
uniform float texel = 32.0;
uniform vec3 g0 : source_color;
uniform vec3 g1 : source_color;
uniform vec3 g2 : source_color;
uniform vec3 g3 : source_color;
uniform vec3 g4 : source_color;
uniform vec3 d0 : source_color;
uniform vec3 d1 : source_color;
uniform vec3 d2 : source_color;
uniform vec3 d3 : source_color;
uniform vec3 s0 : source_color;
uniform vec3 s1 : source_color;
uniform vec3 s2 : source_color;
uniform vec3 s3 : source_color;
uniform vec3 mud : source_color;

varying vec3 wpos;
varying vec3 wnrm;

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wnrm = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

// Cobble: returns ramp value; g = height gradient (stone domes, mortar flat).
float cob(vec2 t, out vec2 g) {
	vec2 c = t / 7.0;
	vec2 ci = floor(c);
	vec2 cf = fract(c);
	float f1 = 8.0;
	float f2 = 8.0;
	vec2 best = vec2(0.0);
	vec2 boff = vec2(0.0);
	for (int j = -1; j <= 1; j++) {
		for (int i = -1; i <= 1; i++) {
			vec2 gg = vec2(float(i), float(j));
			vec2 r = gg + hash22(ci + gg) * 0.8 + 0.1 - cf;
			float d = dot(r, r);
			if (d < f1) { f2 = f1; f1 = d; best = ci + gg; boff = r; } else if (d < f2) { f2 = d; }
		}
	}
	float edge = (sqrt(f2) - sqrt(f1)) * 7.0;
	g = edge < 1.1 ? vec2(0.0) : normalize(boff + 1e-4) * (1.0 - clamp(edge / 3.0, 0.0, 1.0)) * 0.9;
	return edge < 1.1 ? 0.03 : 0.3 + hash12(best) * 0.35 + clamp(dot(boff, vec2(0.7)), -1.0, 1.0) * 0.22;
}

// One ground texel: colour, roughness and an analytic height gradient (per-texel normal).
vec3 ground(vec2 t, out vec2 g, out float r) {
	vec2 tc = (t + 0.5) / texel;
	vec4 m = texture(mask, (tc - bounds.xy) / bounds.zw);
	float d = hash12(t + 17.0) - 0.5;
	vec2 jit = hash22(t + 5.0) - 0.5;
	float dn = vnoise(tc * 2.7) - 0.5;
	float y = wpos.y + d * 0.06;
	r = 0.92;
	g = jit * 0.35;
	bool wet_zone = wpos.z > -7.0; // the valley floor on the right is below the water plane but dry
	if (wet_zone && y < water_level - 0.08) { // pond bed
		float v = 0.3 + vnoise(tc * 1.5) * 0.4 + d * 0.3;
		r = 0.4;
		if (hash12(t * 0.37 + 2.0) > 0.93) { g = jit * 1.4; return s1; }
		return mud * (0.6 + v * 0.8);
	}
	if (wet_zone && y < water_level + 0.22) { // wet bank
		float v = 0.35 + vnoise(tc * 2.0) * 0.4 + d * 0.3;
		r = 0.3;
		if (hash12(t * 0.53 + 9.0) > 0.86) { g = jit * 1.4; return ramp4(v + 0.15, s0, s1, s2, s3) * 0.8; }
		return ramp4(v - 0.1, d0 * 0.7, d1 * 0.7, d2 * 0.75, d3 * 0.8);
	}
	float path = m.r + d * 0.22 + dn * 0.38;
	float cb = m.g + d * 0.18 + dn * 0.2;
	float steep = 1.0 - smoothstep(0.72, 0.86, wnrm.y);
	if (cb > 0.5) {
		r = 0.7;
		return ramp4(cob(t, g) + dn * 0.15, s0, s1, s2, s3);
	}
	if (path > 0.5 || steep + d * 0.6 > 0.6) {
		float v = 0.42 + vnoise(tc * 1.7) * 0.3 + d * 0.32 - (path < 0.62 ? 0.12 : 0.0);
		g *= 0.6;
		if (hash12(t * 0.71 + 5.0) > 0.95) { v = 0.85; g = vec2(-0.3, -0.6); }
		if (hash12((t - vec2(0.0, 1.0)) * 0.71 + 5.0) > 0.95) { v = 0.08; }
		return ramp4(v, d0, d1, d2, d3);
	}
	// grass: soft patches + 1x2 blade strokes, 5-tone ramp, tiny flowers
	float n = vnoise(tc * 0.23) * 0.45 + vnoise(tc * 0.9 + 4.0) * 0.25;
	float blade = hash12(vec2(t.x, floor(t.y * 0.5)));
	float v = n + blade * 0.38 - 0.06 - (path > 0.36 ? 0.1 : 0.0);
	if (hash12(t * 1.7 + 3.0) > 0.994 - m.a * 0.05) {
		float k = hash12(t + 41.0);
		g = vec2(0.0, -0.5);
		return k < 0.35 ? vec3(0.95, 0.92, 0.85) : (k < 0.6 ? vec3(0.95, 0.75, 0.2) : (k < 0.8 ? vec3(0.9, 0.35, 0.45) : vec3(0.55, 0.45, 0.85)));
	}
	float i = clamp(floor(v * 5.0), 0.0, 4.0);
	return i < 0.5 ? g0 : (i < 1.5 ? g1 : (i < 2.5 ? g2 : (i < 3.5 ? g3 : g4)));
}

void fragment() {
	if (CAMERA_POSITION_WORLD.y < water_level && wpos.y < water_level) {
		discard;
	}
	vec2 t = floor(wpos.xz * texel);
	vec2 g;
	float r;
	vec3 col = ground(t, g, r);
	col *= 0.9 + vnoise(wpos.xz * 0.07) * 0.2;
	// sunlit caustics on the pond bed
	if (wpos.y < water_level - 0.05) {
		vec2 q = floor(wpos.xz * 16.0) / 16.0;
		float c = abs(sin(q.x * 3.1 + TIME * 0.9 + sin(q.y * 2.3 + TIME * 0.7) * 1.5) + sin(q.y * 3.7 - TIME * 0.8 + sin(q.x * 1.9) * 1.2));
		col *= 1.0 + smoothstep(1.55, 1.95, c) * 0.6 * (1.0 - night);
	}
	float wet = wetness * smoothstep(0.3, 0.9, wnrm.y);
	ALBEDO = col * (1.0 - wet * 0.3);
	ROUGHNESS = mix(r, 0.12, wet);
	SPECULAR = 0.4;
	vec3 nw = normalize(wnrm - vec3(g.x, 0.0, g.y) * 0.45);
	NORMAL = normalize((VIEW_MATRIX * vec4(nw, 0.0)).xyz);
}
