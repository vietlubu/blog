// Shared helpers: hashes, value noise, and THE wind field (one field drives every swaying thing).
global uniform vec2 wind_dir;
global uniform float wind_strength;
global uniform float wetness;
global uniform float water_level;
global uniform float night;
global uniform float rain;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
vec2 hash22(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.xx + p3.yz) * p3.zy);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = hash12(i);
	float b = hash12(i + vec2(1.0, 0.0));
	float c = hash12(i + vec2(0.0, 1.0));
	float d = hash12(i + vec2(1.0, 1.0));
	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(vec2 p) {
	return vnoise(p) * 0.55 + vnoise(p * 2.03 + 7.1) * 0.3 + vnoise(p * 4.1 + 3.3) * 0.15;
}

// Gust fronts travel along wind_dir; 0..1. Mirrored in scripts/wind.gd for script-driven life.
float wind_gust(vec2 p, float t) {
	float s = dot(p, wind_dir);
	float g = 0.5 + 0.5 * sin(s * 0.21 - t * 1.6 + 0.6 * sin(t * 0.23));
	g *= 0.55 + 0.45 * sin(s * 0.063 - t * 0.47 + 2.0);
	return g * g;
}
// Horizontal sway offset (world units) for unit sway weight.
vec2 wind_offset(vec2 p, float t, float phase) {
	float g = wind_gust(p, t);
	float flutter = sin(t * 2.6 + phase + p.x * 0.9 + p.y * 0.6) * 0.6 + sin(t * 5.3 + phase * 2.1) * 0.25;
	float push = 0.35 + 0.9 * g;
	return wind_dir * wind_strength * (push + flutter * (0.3 + 0.7 * g)) * 0.5;
}

// 4-step ramp lookup: pixel-art palettes are quantised, lighting is not.
vec3 ramp4(float v, vec3 c0, vec3 c1, vec3 c2, vec3 c3) {
	float i = clamp(floor(v * 4.0), 0.0, 3.0);
	return i < 0.5 ? c0 : (i < 1.5 ? c1 : (i < 2.5 ? c2 : c3));
}
