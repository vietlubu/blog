// Painterly gradient sky with sun / moon disc, glow and twinkling stars at night.
shader_type sky;
render_mode use_debanding;
#include "res://shaders/common.gdshaderinc"

uniform vec3 zenith : source_color = vec3(0.35, 0.5, 0.75);
uniform vec3 horizon : source_color = vec3(1.0, 0.75, 0.5);
uniform vec3 below : source_color = vec3(0.4, 0.35, 0.35);
uniform vec3 sun_glow : source_color = vec3(1.0, 0.6, 0.3);
uniform float disc = 0.9996;

void sky() {
	vec3 d = EYEDIR;
	float h = d.y;
	vec3 col = mix(horizon, zenith, smoothstep(-0.02, 0.6, h));
	col = mix(col, below, smoothstep(0.0, -0.25, h));
	if (LIGHT0_ENABLED) {
		float sd = dot(d, LIGHT0_DIRECTION);
		col += sun_glow * (pow(max(sd, 0.0), 5.0) * 0.45 + pow(max(sd, 0.0), 60.0) * 1.2);
		col += LIGHT0_COLOR * smoothstep(disc, disc + 0.00025, sd) * 6.0;
	}
	if (!AT_CUBEMAP_PASS && night > 0.01) {
		vec2 sp = floor(d.xz / (d.y + 0.35) * 260.0);
		float s = step(0.996, hash12(sp)) * smoothstep(0.05, 0.35, h);
		col += vec3(0.8, 0.85, 1.0) * s * night * (0.6 + hash12(sp + 3.0) * 1.4);
	}
	COLOR = col;
}
