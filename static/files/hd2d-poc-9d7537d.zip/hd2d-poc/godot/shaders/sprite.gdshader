// Pixel sprites in 3D light: volume normals from the blurred alpha silhouette, wrap diffuse,
// directional rim light (lights behind the sprite outline it), casts/receives shadows.
shader_type spatial;
render_mode cull_disabled;
#include "res://shaders/common.gdshaderinc"

uniform sampler2D tex : source_color, filter_nearest;
uniform sampler2D ntex : filter_nearest;
uniform float frames = 1.0;
uniform float rim_strength = 0.9;
uniform float wrap = 0.5;
uniform float glow = 0.0;
instance uniform float frame = 0.0;
instance uniform vec4 tint = vec4(1.0);

void fragment() {
	vec2 uv = vec2((UV.x + floor(frame)) / frames, UV.y);
	vec4 c = texture(tex, uv);
	ALBEDO = c.rgb * tint.rgb;
	ALPHA = c.a;
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	vec3 n = texture(ntex, uv).rgb * 2.0 - 1.0;
	NORMAL = normalize(mat3(VIEW_MATRIX) * mat3(MODEL_MATRIX) * n);
	if (!FRONT_FACING) { NORMAL.xz = -NORMAL.xz; }
	ROUGHNESS = 0.9;
	SPECULAR = 0.1;
	EMISSION = c.rgb * glow;
}

void light() {
	float ndl = dot(NORMAL, LIGHT);
	DIFFUSE_LIGHT += clamp((ndl + wrap) / (1.0 + wrap), 0.0, 1.0) * ATTENUATION * LIGHT_COLOR / PI;
	float edge = clamp(length(NORMAL.xy) * 1.15, 0.0, 1.0);
	float dir = max(dot(normalize(NORMAL.xy + 1e-4), normalize(LIGHT.xy + 1e-4)), 0.0);
	float back = clamp(-LIGHT.z, 0.0, 1.0);
	// thin rim: only the outer 1-2 texels of the silhouette, capped so it never turns the sprite into a lamp
	float rim = min(pow(edge, 6.0) * dir * (0.3 + 0.7 * back) * rim_strength, 0.6);
	SPECULAR_LIGHT += rim * ATTENUATION * LIGHT_COLOR / PI * mix(vec3(1.0), ALBEDO, 0.35);
}
