// Local volumetric fog. Density grows with distance from the camera so the focal band stays clear
// and deep-valued while the canopy / background tiers carry the haze and the shadowed sun shafts.
shader_type fog;
#include "res://shaders/common.gdshaderinc"

uniform float density = 0.05; // far (or uniform) density
uniform float near_density = 0.0;
uniform vec3 cam_pos = vec3(0.0, 12.0, 34.0);
uniform float near_d = 40.0;
uniform float far_d = 70.0;
uniform vec3 albedo : source_color = vec3(1.0);
uniform float base_y = 0.0;
uniform float falloff = 0.5;
uniform float wisp = 0.5;
uniform float scale = 0.25;
uniform bool use_sdf = true;
uniform bool by_distance = false;
uniform float end_d = 90.0;

void fog() {
	vec3 p = WORLD_POSITION;
	float n = fbm(p.xz * scale + vec2(TIME * 0.05, TIME * 0.02) + p.y * 0.1);
	float h = exp(-max(p.y - base_y, 0.0) * falloff);
	float dist = distance(p, cam_pos);
	// mid-distance haze band only: beyond end_d the depth fog's aerial perspective takes over,
	// so the far ridges in the valley window stay readable instead of drowning in volumetric haze
	float d = by_distance ? mix(near_density, density, smoothstep(near_d, far_d, dist)) * smoothstep(end_d + 20.0, end_d, dist) : density;
	DENSITY = d * h * mix(1.0, smoothstep(0.25, 0.75, n) * 2.0, wisp) * (use_sdf ? clamp(-SDF * 1.5, 0.0, 1.0) : 1.0);
	ALBEDO = albedo;
}
