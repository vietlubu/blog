// Crisp god rays: a stack of camera-facing additive slices through the canopy / house-gap volume.
// Every slice fragment samples the real directional shadow map in light(), so leaf-card holes and
// the gaps between houses become sharp dappled blades (t3ssel8r / David Holland slice technique).
shader_type spatial;
render_mode blend_add, depth_draw_never, cull_disabled, fog_disabled;
#include "res://shaders/common.gdshaderinc"

uniform sampler2D depth_tex : hint_depth_texture, filter_nearest, repeat_disable;
uniform float strength = 1.0;   // preset fade: (1 - night) * (1 - 0.75 rain)
uniform float density = 0.05;   // per-slice in-scatter
uniform float y_lo = 1.5;
uniform float y_hi = 10.5;
uniform vec3 box_center = vec3(0.0);
uniform vec3 box_half = vec3(10.0);
uniform vec3 tint : source_color = vec3(1.0, 0.85, 0.62);

varying vec3 wpos;
varying float fade;

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec3 d = abs(wpos - box_center) / box_half;
	fade = smoothstep(1.0, 0.7, d.x) * smoothstep(1.0, 0.6, d.z);
	fade *= smoothstep(y_lo, y_lo + 1.5, wpos.y) * smoothstep(y_hi, y_hi - 3.0, wpos.y);
	// soft intersection with opaque geometry
	float zr = texture(depth_tex, SCREEN_UV).r;
	vec4 vp = INV_PROJECTION_MATRIX * vec4(SCREEN_UV * 2.0 - 1.0, zr, 1.0);
	vp.xyz /= vp.w;
	fade *= clamp((VERTEX.z - vp.z) * 0.8, 0.0, 1.0);
	fade *= strength;
	if (fade < 0.002) {
		discard;
	}
	ALBEDO = vec3(0.0);
	SPECULAR = 0.0;
	ROUGHNESS = 1.0;
	AO = 0.0;
	AO_LIGHT_AFFECT = 0.0;
}

void light() {
	if (LIGHT_IS_DIRECTIONAL) {
		float c = dot(-LIGHT, VIEW);
		float g = 0.55;
		float hg = (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * c, 1.5);
		float flick = 0.85 + 0.3 * wind_gust(wpos.xz, TIME);
		SPECULAR_LIGHT += LIGHT_COLOR * tint * ATTENUATION * density * hg * fade * flick;
	}
}
