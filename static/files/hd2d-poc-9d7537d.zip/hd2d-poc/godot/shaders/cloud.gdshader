// Far painterly pixel clouds / hill silhouettes: unshaded, tinted per preset, fogged by depth fog.
shader_type spatial;
render_mode unshaded, cull_disabled;
#include "res://shaders/common.gdshaderinc"

uniform sampler2D tex : source_color, filter_nearest;
uniform vec3 lit : source_color = vec3(1.0, 0.85, 0.7);
uniform vec3 shade : source_color = vec3(0.6, 0.55, 0.7);
uniform float energy = 1.0;

void fragment() {
	vec4 c = texture(tex, UV);
	ALBEDO = mix(shade, lit, c.r) * energy;
	ALPHA = c.a;
	ALPHA_SCISSOR_THRESHOLD = 0.5;
}
