extends RefCounted
## Procedural pixel-art images, all original, generated at startup (no imported assets).

const GRASS := ["#17302f", "#24503a", "#3f7536", "#6f9c3a", "#b0c656"]
const LEAF := ["#142a2c", "#1f4535", "#336b39", "#5a9440", "#97bf4e", "#d4dd78"]


static func tex(img: Image) -> ImageTexture:
	return ImageTexture.create_from_image(img)


static func h2(x: int, y: int, s: int) -> float:
	var n := (x * 374761393 + y * 668265263 + s * 2147483647) & 0x7fffffff
	n = ((n ^ (n >> 13)) * 1274126177) & 0x7fffffff
	return float(n & 0xffff) / 65535.0


static func ramp(cols: Array, v: float) -> Color:
	return Color.html(cols[clampi(int(v * cols.size()), 0, cols.size() - 1)])


## Leaf clumps: jittered-grid voronoi leaf clusters inside a ragged blob, 8 variants (512x64):
## different radii, single / twin lobes and see-through gaps so canopies do not tile into fish scales.
static func leaf_atlas(seed_: int, cols: Array = LEAF) -> ImageTexture:
	var img := Image.create(512, 64, false, Image.FORMAT_RGBA8)
	var cs := 6.0
	for k in 8:
		var ph := float(k) * 1.7 + seed_
		var base_r := 20.0 + float(k % 4) * 2.2
		var twin := k >= 5
		var holes := 0.18 + 0.06 * float(k % 3)
		for y in 64:
			for x in 64:
				var p := Vector2(x + 0.5, y + 0.5)
				var d := p - Vector2(32, 33)
				var ang := atan2(d.y, d.x)
				var rr := base_r + 3.5 * sin(ang * 5.0 + ph) + 2.5 * sin(ang * 9.0 + ph * 2.0) + h2(x, y, seed_ + k) * 2.5
				var inside := Vector2(d.x, d.y * 1.1).length() <= rr
				if twin:
					var d2 := p - Vector2(32 + (14 if k % 2 == 0 else -14), 22)
					inside = Vector2(d.x * 1.25, d.y * 1.3).length() <= rr * 0.85 or d2.length() <= rr * 0.55
				if not inside:
					continue
				var gx := int(floor(p.x / cs))
				var gy := int(floor(p.y / cs))
				var f1 := 1e9
				var f2 := 1e9
				var off := Vector2.ZERO
				var cell := Vector2i.ZERO
				for j in range(-1, 2):
					for i in range(-1, 2):
						var c := Vector2i(gx + i, gy + j)
						var q := (Vector2(c) + Vector2(0.15 + 0.7 * h2(c.x, c.y, seed_ * 3 + k), 0.15 + 0.7 * h2(c.y, c.x, seed_ * 5 + k))) * cs
						var dd := p.distance_squared_to(q)
						if dd < f1:
							f2 = f1
							f1 = dd
							off = p - q
							cell = c
						elif dd < f2:
							f2 = dd
				var edge := sqrt(f2) - sqrt(f1)
				# hole between some clusters lets light through
				if edge < 0.9 and h2(cell.x, cell.y, seed_ + 77) < holes:
					continue
				var v := 0.55 - (off.x + off.y) * 0.055 - d.y / 64.0 * 0.55 + (h2(cell.x, cell.y, seed_ + 9) - 0.5) * 0.3
				if edge < 1.0:
					v -= 0.35
				img.set_pixel(k * 64 + x, y, ramp(cols, v))
	return tex(img)


static func _blade(img: Image, ox: int, H: int, x0: float, h: int, lean: float, cols: Array, wide: bool) -> void:
	for y in h:
		var f := float(y) / maxf(1.0, h - 1.0)
		var x := int(round(x0 + lean * f * f))
		var c := ramp(cols, 0.1 + f * 0.85)
		img.set_pixel(clampi(ox + x, ox, ox + 23), H - 1 - y, c)
		if wide and f < 0.35:
			img.set_pixel(clampi(ox + x + 1, ox, ox + 23), H - 1 - y, ramp(cols, f * 0.6))


static func _dot(img: Image, x: int, y: int, c: Color) -> void:
	if x >= 0 and y >= 0 and x < img.get_width() and y < img.get_height():
		img.set_pixel(x, y, c)


## 8 tuft cells of 24x32: 0-1 grass, 2 tall grass, 3 seed heads, 4 daisies, 5 poppies, 6 lavender, 7 reeds.
static func tuft_atlas() -> ImageTexture:
	var H := 32
	var img := Image.create(24 * 8, H, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var dry := ["#3a4a2a", "#6b7034", "#a59a48", "#d6c36a", "#efe2a0"]
	for cell in 8:
		var ox := cell * 24
		var n := 13 if cell < 2 else 10
		var hmax := 13 if cell < 2 else 24
		if cell == 7:
			n = 7
			hmax = 31
		for b in n:
			var x0 := rng.randf_range(3.0, 20.0)
			var h := rng.randi_range(int(hmax * 0.45), hmax)
			var lean := rng.randf_range(-5.0, 5.0)
			var cols: Array = dry if (cell == 3 and b % 2 == 0) else GRASS
			_blade(img, ox, H, x0, h, lean, cols, cell != 7)
		match cell:
			3:
				for s in 6:
					var x := ox + rng.randi_range(3, 20)
					var y := H - rng.randi_range(16, 24)
					for k in 3:
						_dot(img, x + (k % 2), y + k, Color.html(dry[3 + (k % 2)]))
			4:
				for s in 6:
					var x := ox + rng.randi_range(3, 20)
					var y := H - rng.randi_range(10, 21)
					for k in range(y + 2, H - 2):
						_dot(img, x, k, Color.html(GRASS[1]))
					for o in [Vector2i(-1, 0), Vector2i(1, 0), Vector2i(0, -1), Vector2i(0, 1)]:
						_dot(img, x + o.x, y + o.y, Color.html("#f4f0e6"))
					_dot(img, x, y, Color.html("#f2b632"))
			5:
				for s in 6:
					var x := ox + rng.randi_range(3, 19)
					var y := H - rng.randi_range(10, 22)
					for k in range(y + 2, H - 2):
						_dot(img, x, k, Color.html(GRASS[2]))
					var red := Color.html("#d8322e") if s % 3 != 0 else Color.html("#f2c230")
					for o in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(-1, 1), Vector2i(2, 1)]:
						_dot(img, x + o.x, y + o.y, red)
					_dot(img, x, y + 1, Color.html("#3a1420") if s % 3 != 0 else Color.html("#b07a10"))
			6:
				for s in 5:
					var x := ox + rng.randi_range(4, 19)
					var y := H - rng.randi_range(14, 24)
					for k in range(y + 5, H - 2):
						_dot(img, x, k, Color.html(GRASS[2]))
					for k in 6:
						_dot(img, x + (k % 2), y + k, Color.html("#8a6ad0" if k % 2 == 0 else "#b89cf0"))
			7:
				for s in 3:
					var x := ox + rng.randi_range(5, 18)
					var y := rng.randi_range(1, 6)
					for k in 5:
						_dot(img, x, y + k, Color.html("#5a3420" if k > 0 else "#8a5a34"))
						_dot(img, x + 1, y + k, Color.html("#3a2016"))
	return tex(img)


## Painterly pixel cloud (r = lit factor, a = coverage), 3 variants of 128x64.
static func cloud_atlas() -> ImageTexture:
	var img := Image.create(384, 64, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 99
	for k in 3:
		var puffs := []
		for i in 9:
			var x := rng.randf_range(24, 104)
			var r := rng.randf_range(10, 22) * (1.0 - absf(x - 64) / 90.0)
			puffs.append(Vector3(x, 48 - r * rng.randf_range(0.5, 0.9), r))
		for y in 64:
			for x in 128:
				var best := -1.0
				var lit := 0.0
				for pf in puffs:
					var d := Vector2(x - pf.x, (y - pf.y) * 1.25)
					var inside: float = pf.z - d.length()
					if inside > best:
						best = inside
						lit = clamp(0.5 - d.y / pf.z * 0.7 - d.x / pf.z * 0.2, 0.0, 1.0)
				if best < 0.0 or y > 52:
					continue
				var dth := 0.12 if (x + y) % 2 == 0 else -0.12
				var q := floorf(clampf(lit + dth, 0.0, 0.999) * 3.0) / 2.0
				img.set_pixel(k * 128 + x, y, Color(q, 0, 0, 1))
	return tex(img)


## Volume normal map from the alpha silhouette (blurred), object space, encoded 0..1.
static func silhouette_normals(src: Image, radius: int = 3, bulge: float = 0.35) -> ImageTexture:
	var w := src.get_width()
	var h := src.get_height()
	var a := PackedFloat32Array()
	a.resize(w * h)
	for y in h:
		for x in w:
			a[y * w + x] = 1.0 if src.get_pixel(x, y).a > 0.5 else 0.0
	for pass_i in 2:
		var b := PackedFloat32Array()
		b.resize(w * h)
		for y in h:
			for x in w:
				var s := 0.0
				var n := 0
				for k in range(-radius, radius + 1):
					var xx := clampi(x + k, 0, w - 1) if pass_i == 0 else x
					var yy := y if pass_i == 0 else clampi(y + k, 0, h - 1)
					s += a[yy * w + xx]
					n += 1
				b[y * w + x] = s / n
		a = b
	var out := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		for x in w:
			var gx := a[y * w + clampi(x + 1, 0, w - 1)] - a[y * w + clampi(x - 1, 0, w - 1)]
			var gy := a[clampi(y + 1, 0, h - 1) * w + x] - a[clampi(y - 1, 0, h - 1) * w + x]
			var cx := (float(x) / w - 0.5) * 2.0
			var n := Vector3(-gx * 2.2 + cx * bulge, gy * 2.2 + 0.15, 1.0).normalized()
			out.set_pixel(x, y, Color(n.x * 0.5 + 0.5, n.y * 0.5 + 0.5, n.z * 0.5 + 0.5, 1.0))
	return tex(out)


static func _paint(img: Image, rows: Array, palette: Dictionary, ox: int = 0, oy: int = 0) -> void:
	for y in rows.size():
		var row: String = rows[y]
		for x in row.length():
			var ch := row[x]
			if palette.has(ch):
				img.set_pixel(ox + x, oy + y, Color.html(palette[ch]))


## Bird, 2 frames 18x10 (wings up / down), drawn at 1x so it shares the 32 texel/unit grid.
static func bird_frames() -> Image:
	var img := Image.create(36, 10, false, Image.FORMAT_RGBA8)
	var pal := {"k": "#2a2430", "w": "#4a4050", "b": "#e8dcc4", "o": "#f0a040"}
	_paint(img, [
		"k...............k.",
		"kk.............kk.",
		".kkk.........kkk..",
		"..kkkw.....wkkk...",
		"....kkkkkkkkk.....",
		".....kkbbbkk.kk...",
		"......kkbbkkkko...",
		"........kk........",
		"..................",
		".................."], pal, 0, 0)
	_paint(img, [
		"..................",
		"..................",
		"..................",
		"......kkkkkk.kk...",
		"...wkkkbbbbkkkko..",
		"..kkk..kbbk..kkk..",
		".kk.....kk.....kk.",
		"kk..............kk",
		"k................k",
		".................."], pal, 18, 0)
	return img


## Small hopping songbird, 2 frames 10x8 (stand / peck).
static func songbird_frames() -> Image:
	var img := Image.create(20, 8, false, Image.FORMAT_RGBA8)
	var pal := {"k": "#2b2026", "b": "#7a4a30", "r": "#d0603a", "c": "#efe0c4", "y": "#f0b030"}
	_paint(img, [
		"..........",
		"......kk..",
		".....kbbky",
		"bb..kbrrk.",
		".bbkbrccr.",
		"..bbbccc..",
		"....k.k...",
		"....k.k..."], pal, 0, 0)
	_paint(img, [
		"..........",
		"..........",
		"bb........",
		".bbkkbb...",
		"..bbrrcbk.",
		"...bccckby",
		"....k.k...",
		"....k.k..."], pal, 10, 0)
	return img


## Butterfly, 2 frames 9x7 (open / folded); white so instances tint it.
static func butterfly_frames() -> Image:
	var img := Image.create(18, 7, false, Image.FORMAT_RGBA8)
	var pal := {"w": "#ffffff", "s": "#c8c0d8", "k": "#2a2030"}
	_paint(img, [
		"ww.....ww",
		"wwws.swww",
		".wwwkwww.",
		"..swkws..",
		".wws.sww.",
		".ww...ww.",
		"........."], pal, 0, 0)
	_paint(img, [
		".........",
		"...w.w...",
		"...wkw...",
		"...wkw...",
		"...sks...",
		"....k....",
		"........."], pal, 9, 0)
	return img


## Falling leaf variants, 4 x (6x6).
static func leaf_particles() -> ImageTexture:
	var img := Image.create(24, 6, false, Image.FORMAT_RGBA8)
	var sets := [["#2f6a36", "#6fa443"], ["#a8b43a", "#e0d060"], ["#c86a28", "#f0a040"], ["#8a3a24", "#d06a3a"]]
	for k in 4:
		_paint(img, [
			"....dd",
			"..dlld",
			".dlld.",
			"dlld..",
			"dld...",
			"d....."], {"d": sets[k][0], "l": sets[k][1]}, k * 6, 0)
	return tex(img)


## Lily pads (2 variants 20x14, foreshortened ellipse with a notch; second has a flower).
static func lily_atlas() -> ImageTexture:
	var img := Image.create(40, 14, false, Image.FORMAT_RGBA8)
	for k in 2:
		for y in 14:
			for x in 20:
				var d := Vector2((x - 9.5) / 9.5, (y - 6.5) / 6.5)
				if d.length() > 1.0:
					continue
				if d.x > 0.0 and abs(d.y) < d.x * 0.35:
					continue
				var v := 0.5 - d.y * 0.25 - d.x * 0.15 + (h2(x, y, k) - 0.5) * 0.2
				if d.length() > 0.85:
					v -= 0.3
				img.set_pixel(k * 20 + x, y, ramp(["#1c3c2c", "#2f6a3a", "#4f9444", "#86c058"], v))
		if k == 1:
			for o in [Vector2i(0, 0), Vector2i(-1, 1), Vector2i(1, 1), Vector2i(0, 1), Vector2i(-2, 2), Vector2i(2, 2), Vector2i(0, 2)]:
				img.set_pixel(20 + 7 + o.x, 4 + o.y, Color.html("#f4a6c8" if o.y < 2 else "#e070a0"))
			img.set_pixel(27, 5, Color.html("#f8e070"))
	return tex(img)


## Diamond kite with the studio's two-tone panels (16x20) + tail bow.
static func kite_image() -> ImageTexture:
	var img := Image.create(16, 22, false, Image.FORMAT_RGBA8)
	for y in 20:
		var hw := (y if y < 7 else int((20 - y) * 7.0 / 13.0))
		for x in range(8 - hw, 8 + hw):
			var left := x < 8
			var top := y < 7
			var c := "#e24a3a" if left == top else "#f4d35e"
			if x == 8 - hw or x == 7 + hw:
				c = "#5a2a24"
			if x == 7 or x == 8 or y == 7:
				c = "#6a3a2a"
			img.set_pixel(x, y, Color.html(c))
	return tex(img)


## Cloth swatches 4 x (16x20): laundry shirt, striped towel, sheet, banner with a kite emblem.
static func cloth_atlas() -> ImageTexture:
	var img := Image.create(64, 20, false, Image.FORMAT_RGBA8)
	for y in 20:
		for x in 16:
			var n := (h2(x, y, 5) - 0.5) * 0.12
			img.set_pixel(x, y, Color.html("#5a7ab8").lightened(n + (0.12 if y < 2 else 0.0)))
			img.set_pixel(16 + x, y, Color.html("#e8ddc8" if (y / 3) % 2 == 0 else "#d2563e").lightened(n))
			img.set_pixel(32 + x, y, Color.html("#f2ecdc").darkened(0.06 + n))
			var c := Color.html("#3a5a8a")
			if x < 1 or x > 14 or y < 1:
				c = Color.html("#f0c050")
			var dx: int = abs(x - 8)
			var dy: int = abs(y - 9)
			if dx + dy * 0.7 < 4.5:
				c = Color.html("#f4d35e" if x < 8 else "#e24a3a")
			if y > 13 and x == 8 + (y % 2):
				c = Color.html("#f0c050")
			img.set_pixel(48 + x, y, c)
	# laundry shirt silhouette: cut sleeves
	for y in range(8, 20):
		for x in [0, 1, 14, 15]:
			img.set_pixel(x, y, Color(0, 0, 0, 0))
	return tex(img)


## Pixel smoke puff 16x16 with quantised alpha.
static func puff_image() -> ImageTexture:
	var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for y in 16:
		for x in 16:
			var d := Vector2(x - 7.5, y - 7.5).length() / 7.5 + (h2(x, y, 3) - 0.5) * 0.25
			if d > 1.0:
				continue
			var a: float = floor((1.0 - d) * 3.0 + 0.6) / 3.0
			var lit: float = 0.82 + (7.5 - y) / 7.5 * 0.12 - (x - 7.5) / 7.5 * 0.05
			img.set_pixel(x, y, Color(lit, lit, lit * 1.02, clamp(a, 0.0, 1.0)))
	return tex(img)


## Soft round sprite for glows (fireflies, lantern halos); not pixel art on purpose.
static func dot_image(size: int = 16) -> ImageTexture:
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	for y in size:
		for x in size:
			var d := Vector2(x + 0.5 - size * 0.5, y + 0.5 - size * 0.5).length() / (size * 0.5)
			var a: float = clamp(1.0 - d, 0.0, 1.0)
			img.set_pixel(x, y, Color(1, 1, 1, a * a))
	return tex(img)
