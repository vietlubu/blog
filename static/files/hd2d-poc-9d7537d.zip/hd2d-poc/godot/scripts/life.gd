extends Node3D
## Actors and script-driven life: hero sprite, bird flock, hopping songbirds, butterflies, kite,
## windmill, chimney smoke steering. Everything that drifts reads the same wind field as the shaders.

const Pix := preload("res://scripts/pixtex.gd")
const SPRITE := preload("res://shaders/sprite.gdshader")
const TEXEL := 32.0
const WIND_DIR := Vector2(0.92, 0.38)

var world: Node3D
var cam: Camera3D
var t := 0.0
var wind := 1.0
var hero: MeshInstance3D
var hero_shadow: MeshInstance3D
var sun_dir := Vector3(0, 1, 0) # set by main._apply (sun or moon, pointing to the light)
var flock: Array[MeshInstance3D] = []
var flock_t0 := 1.5
var songbirds: Array[Dictionary] = []
var butterflies: Array[Dictionary] = []
var kite: MeshInstance3D
var kite_tail: Array[MeshInstance3D] = []
var kite_line: MeshInstance3D
var kite_anchor := Vector3(6.6, 4.0, -6.4) # tied to the laundry pole on T2
var rng := RandomNumberGenerator.new()


static func gust(p: Vector2, tt: float) -> float:
	var s := p.dot(WIND_DIR)
	var g := 0.5 + 0.5 * sin(s * 0.21 - tt * 1.6 + 0.6 * sin(tt * 0.23))
	g *= 0.55 + 0.45 * sin(s * 0.063 - tt * 0.47 + 2.0)
	return g * g


func _sprite(img: Image, frames: int, scale_: float = 1.0, shadows: bool = true) -> MeshInstance3D:
	var q := QuadMesh.new()
	q.size = Vector2(img.get_width() / float(frames), img.get_height()) / TEXEL * scale_
	q.center_offset = Vector3(0, q.size.y * 0.5, 0)
	var mt := ShaderMaterial.new()
	mt.shader = SPRITE
	mt.set_shader_parameter("tex", ImageTexture.create_from_image(img))
	mt.set_shader_parameter("ntex", Pix.silhouette_normals(img, 2 if img.get_height() < 20 else 3))
	mt.set_shader_parameter("frames", float(frames))
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = mt
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi


func setup(w: Node3D, camera: Camera3D) -> void:
	world = w
	cam = camera
	rng.seed = 77
	# hero: size derived from the PNG (any size) at 32 texels / unit, pivot bottom-centre
	var img := Image.load_from_file(ProjectSettings.globalize_path("res://assets/hero.png"))
	# visible quad never casts (a camera-facing billboard would shadow itself); a sun-facing proxy casts instead
	hero = _sprite(img, 1, 1.0, false)
	hero.name = "Hero"
	hero.layers = 16
	var hp: Vector3 = world.HERO_POS
	hero.position = Vector3(hp.x, world.ground_y(hp.x, hp.z), hp.z)
	hero_shadow = _sprite(img, 1, 1.0, true)
	hero_shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY
	hero_shadow.layers = 16
	var dm := material_for_contact()
	var dec := Decal.new()
	dec.texture_albedo = dm
	dec.size = Vector3(img.get_width() / TEXEL * 1.1, 0.6, img.get_width() / TEXEL * 0.55)
	dec.modulate = Color(0.05, 0.04, 0.08, 0.75)
	dec.position = hero.position + Vector3(0, 0.1, 0)
	dec.cull_mask = 0xFFFFF & ~16 # do not darken the hero's own boots
	add_child(dec)
	# bird flock: first pass right away, then every 15 s, routed across the valley window
	var bimg := Pix.bird_frames()
	for i in 7:
		var b := _sprite(bimg, 2, 1.0, false)
		b.visible = false
		flock.append(b)
	# hopping songbirds: two on the path, one on a roof ridge
	var simg := Pix.songbird_frames()
	var spots := [Vector3(4.2, 0, 1.9), Vector3(-0.6, 0, 2.4)]
	if world.roof_spots.size() > 1:
		spots.append(world.roof_spots[1])
	for i in spots.size():
		var s := _sprite(simg, 2)
		var p: Vector3 = spots[i]
		var on_roof := i == 2
		if not on_roof:
			p.y = world.ground_y(p.x, p.z)
		s.position = p
		songbirds.append({"node": s, "home": p, "from": p, "to": p, "hop": 1.0, "wait": rng.randf_range(0.5, 2.0), "roof": on_roof, "face": 1.0})
	# butterflies around the flower beds
	var fimg := Pix.butterfly_frames()
	var homes := [Vector3(-0.4, 0, 2.0), Vector3(3.6, 0, -0.4), Vector3(5.8, 0, 1.6), Vector3(-1.6, 0, -2.8), Vector3(-8.5, 0, -3.2), Vector3(9.6, 0, 0.4)]
	var tints := [Color(1.0, 0.55, 0.12), Color(1.0, 0.88, 0.2), Color(0.35, 0.6, 1.0), Color(1.0, 0.45, 0.25), Color(1.0, 0.88, 0.2), Color(0.35, 0.6, 1.0)]
	for i in homes.size():
		var f := _sprite(fimg, 2, 1.0, false)
		f.set_instance_shader_parameter("tint", tints[i])
		var h: Vector3 = homes[i]
		h.y = world.ground_y(h.x, h.z) + 0.7
		butterflies.append({"node": f, "home": h, "ph": rng.randf() * TAU, "rate": rng.randf_range(10.0, 14.0), "cycle": rng.randf_range(8.0, 11.0)})
	# kite above the right hill, tail of bows, string to the hill
	var kimg := Pix.kite_image().get_image()
	kite = _sprite(kimg, 1, 1.0, false)
	var tail_img := Image.create(6, 5, false, Image.FORMAT_RGBA8)
	for o in [Vector2i(0, 0), Vector2i(0, 4), Vector2i(1, 1), Vector2i(1, 3), Vector2i(0, 1), Vector2i(0, 3), Vector2i(0, 2), Vector2i(1, 2),
			Vector2i(5, 0), Vector2i(5, 4), Vector2i(4, 1), Vector2i(4, 3), Vector2i(5, 1), Vector2i(5, 3), Vector2i(5, 2), Vector2i(4, 2)]:
		tail_img.set_pixel(o.x, o.y, Color.html("#f4d35e"))
	tail_img.set_pixel(2, 2, Color.html("#e24a3a"))
	tail_img.set_pixel(3, 2, Color.html("#e24a3a"))
	for i in 7:
		kite_tail.append(_sprite(tail_img, 1, 1.0, false))
	kite_line = MeshInstance3D.new()
	kite_line.mesh = ImmediateMesh.new()
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(0.95, 0.9, 0.8, 0.6)
	lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	kite_line.material_override = lm
	kite_line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(kite_line)


func material_for_contact() -> Texture2D:
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 1))
	g.set_color(1, Color(1, 1, 1, 0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(0.5, 0.0)
	gt.width = 64
	gt.height = 64
	return gt


func _face_camera(n: Node3D) -> void:
	var d := cam.global_position - n.global_position
	n.rotation.y = atan2(d.x, d.z)


func tick(delta: float, wind_strength: float) -> void:
	t += delta
	wind = wind_strength
	_face_camera(hero)
	var ld := Vector3(sun_dir.x, 0.0, sun_dir.z)
	if ld.length() > 0.01:
		ld = ld.normalized()
		hero_shadow.position = hero.position - ld * 0.25
		hero_shadow.rotation.y = atan2(ld.x, ld.z)
	var clouds: Node3D = world.get_node("Clouds")
	for c in clouds.get_children():
		c.position.x = fposmod(c.position.x + delta * 0.5 * wind + 40.0, 140.0) - 40.0
	_flock()
	_songbirds(delta)
	_butterflies()
	_kite()
	var g := gust(Vector2(0, -10), t)
	if world.windmill_sails:
		world.windmill_sails.rotate_z(-delta * (0.35 + g * 0.6) * wind)
	for s in world.smoke:
		var sp: Vector3 = s.global_position
		var gg := gust(Vector2(sp.x, sp.z), t)
		var pm: ParticleProcessMaterial = s.process_material
		pm.gravity = Vector3(WIND_DIR.x, 0, WIND_DIR.y) * (0.6 + gg * 1.3) * wind + Vector3(0, 0.04, 0)
	for i in world.lily_nodes.size():
		var l: Node3D = world.lily_nodes[i]
		l.position.y = world.WATER_Y + 0.012 + sin(t * 1.3 + i) * 0.006


func _flock() -> void:
	var period := 15.0
	var lt := fmod(t - flock_t0, period)
	var cross := t > flock_t0 and lt < 12.0
	var lead := Vector3(-18.0 + lt * 4.5, 7.8 + sin(lt * 0.5) * 0.4, -8.0)
	for i in flock.size():
		var b := flock[i]
		b.visible = cross
		if not cross:
			continue
		var row := (i + 1) / 2
		var side := -1.0 if i % 2 == 1 else 1.0
		var off := Vector3(-row * 1.3, side * row * 0.45 + sin(t * 1.7 + i) * 0.15, side * row * 0.9)
		b.position = lead + off
		var flap := fmod(t * 7.0 + i * 0.37, 2.0)
		var glide := sin(t * 0.9 + i) > 0.6
		b.set_instance_shader_parameter("frame", 0.0 if glide else floor(flap))
		_face_camera(b)


func _songbirds(delta: float) -> void:
	for sb in songbirds:
		var n: MeshInstance3D = sb.node
		if sb.hop < 1.0:
			sb.hop = min(1.0, sb.hop + delta / 0.32)
			var p: Vector3 = sb.from.lerp(sb.to, sb.hop)
			p.y += sin(sb.hop * PI) * 0.28
			n.position = p
			n.set_instance_shader_parameter("frame", 0.0)
		else:
			sb.wait -= delta
			var peck: bool = fmod(t * 3.0 + sb.home.x, 4.0) > 3.4 and not sb.roof
			n.set_instance_shader_parameter("frame", 1.0 if peck else 0.0)
			if sb.wait <= 0.0:
				sb.from = n.position
				var to: Vector3 = sb.home + Vector3(rng.randf_range(-0.9, 0.9), 0, 0 if sb.roof else rng.randf_range(-0.5, 0.5))
				if not sb.roof:
					to.y = world.ground_y(to.x, to.z)
				sb.to = to
				sb.face = 1.0 if to.x > sb.from.x else -1.0
				sb.hop = 0.0
				sb.wait = rng.randf_range(0.4, 2.6)
		_face_camera(n)
		n.scale.x = sb.face


func _butterflies() -> void:
	for bf in butterflies:
		var n: MeshInstance3D = bf.node
		var ph: float = bf.ph
		var h: Vector3 = bf.home
		var cyc: float = bf.cycle
		var g := gust(Vector2(h.x, h.z), t)
		# figure-eight flight (1:2 Lissajous), then settle on the flowers with slow wing beats
		var a := t * 0.9 + ph
		var fly := h + Vector3(sin(a) * 1.1, sin(t * 1.3 + ph) * 0.25 + sin(t * 3.1 + ph) * 0.06, sin(2.0 * a) * 0.45)
		fly += Vector3(WIND_DIR.x, 0, WIND_DIR.y) * g * 0.5 * wind
		var lt := fmod(t + ph * 2.0, cyc)
		var rest_w := smoothstep(cyc - 3.2, cyc - 2.6, lt) * (1.0 - smoothstep(cyc - 0.4, cyc, lt))
		var rest := Vector3(h.x + sin(ph) * 0.4, h.y - 0.5, h.z)
		n.position = fly.lerp(rest, rest_w)
		var beat: float = floor(fmod(t * 1.6, 2.0)) if rest_w > 0.9 else floor(fmod(t * bf.rate, 2.0))
		n.set_instance_shader_parameter("frame", beat)
		_face_camera(n)


func _kite() -> void:
	var g := gust(Vector2(kite_anchor.x, kite_anchor.z), t)
	var p := Vector3(11.0 + sin(t * 0.37) * 0.6 + g * 0.8 * wind, 7.3 + sin(t * 0.53) * 0.3 + g * 0.3, -11.0)
	kite.position = p
	_face_camera(kite)
	# no roll: the kite's pixel grid stays upright
	var prev := p
	for i in kite_tail.size():
		var k := kite_tail[i]
		var target := prev + Vector3(-0.2 - g * 0.15, -0.38, 0) + Vector3(0, 0, 0)
		target.x += sin(t * 3.0 - i * 0.7) * 0.12
		k.position = target
		_face_camera(k)
		prev = target
	var im: ImmediateMesh = kite_line.mesh
	im.clear_surfaces()
	im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
	for i in 13:
		var f := i / 12.0
		var q := kite_anchor.lerp(p, f)
		q.y -= sin(f * PI) * 1.4
		im.surface_add_vertex(q)
	im.surface_end()
