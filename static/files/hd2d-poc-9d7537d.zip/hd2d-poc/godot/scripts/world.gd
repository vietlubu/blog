extends Node3D
## Builds "Windferry Hamlet": tiered terrain, stream + pond, houses, bridge, props, trees, foliage, particles.
## Units: 1 unit = 32 texels everywhere (sprites, cards, procedural surfaces).

const Builder := preload("res://scripts/builder.gd")
const Pix := preload("res://scripts/pixtex.gd")
const SURF := preload("res://shaders/surface.gdshader")
const TERRAIN := preload("res://shaders/terrain.gdshader")
const WATER := preload("res://shaders/water.gdshader")
const FOLIAGE := preload("res://shaders/foliage.gdshader")
const GRASS := preload("res://shaders/grass.gdshader")
const CLOTH := preload("res://shaders/cloth.gdshader")
const CLOUD := preload("res://shaders/cloud.gdshader")
const CASCADE := preload("res://shaders/cascade.gdshader")
const LEAVES := preload("res://shaders/leaves.gdshader")
const LEAFDRAW := preload("res://shaders/leafdraw.gdshader")
const SHAFTS := preload("res://shaders/shafts.gdshader")

const TEXEL := 32.0
const WATER_Y := -0.25
const X0 := -64.0
const Z0 := -78.0
const XW := 128.0
const ZD := 106.0
const STEP := 0.5
const POND := Vector4(-6.6, 3.5, 3.8, 2.0) # cx, cz, rx, rz: left of the bridge so it mirrors lantern, house A, tree
const STREAM := [Vector2(-4.0, -5.0), Vector2(-4.0, -1.0), Vector2(-4.2, 1.6), Vector2(-5.6, 3.2)]
const HERO_POS := Vector3(1.6, 0.0, 1.1)

var noise := FastNoiseLite.new()
var heights := PackedFloat32Array()
var nx := 0
var nz := 0
var mask_img: Image
var cam_fwd := Vector3(0, -0.33, -0.94)

# handles for presets / life
var glass_mats: Array[ShaderMaterial] = []
var lamp_mats: Array[ShaderMaterial] = []
var window_lights: Array[OmniLight3D] = []
var lantern_lights: Array[OmniLight3D] = []
var smoke: Array[GPUParticles3D] = []
var fireflies: GPUParticles3D
var dust: GPUParticles3D
var rain_fx: GPUParticles3D
var leaves: Array[GPUParticles3D] = []
var cloud_mat: ShaderMaterial
var hill_mats: Array[StandardMaterial3D] = []
var cam_pos := Vector3(0, 15, 38)
var water_mat: ShaderMaterial
var shafts: ShaderMaterial
var windmill_sails: Node3D
var lily_nodes: Array[Node3D] = []
var footprints: Array[Rect2] = []
var flower_spots: Array[Vector3] = []
var roof_spots: Array[Vector3] = []
var m := {}


func _ss(a: float, b: float, x: float) -> float:
	var t: float = clamp((x - a) / (b - a), 0.0, 1.0)
	return t * t * (3.0 - 2.0 * t)


func _seg_dist(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var t: float = clamp((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
	return p.distance_to(a + ab * t)


func stream_dist(x: float, z: float) -> float:
	var p := Vector2(x, z)
	var d := 1e9
	for i in STREAM.size() - 1:
		d = min(d, _seg_dist(p, STREAM[i], STREAM[i + 1]))
	return d


func pond_e(x: float, z: float) -> float:
	return Vector2((x - POND.x) / POND.z, (z - POND.y) / POND.w).length() + noise.get_noise_2d(x * 3.0, z * 3.0) * 0.08


func path_z(x: float) -> float:
	return 0.7 + 0.55 * sin(x * 0.16 + 0.4)


func height(x: float, z: float) -> float:
	var n := noise.get_noise_2d(x, z)
	var h := 1.6 * _ss(-4.8, -5.15, z)
	# T3: the hill keeps climbing on the left (big tree, windmill) but falls away into a valley on the right,
	# opening a window onto layered hazy ridges for the kite and the flock.
	var rv := _ss(3.0, 12.0, x)
	h += _ss(-15.0, -20.0, z) * 1.3 * (1.0 - rv * 0.5) + max(0.0, -z - 19.0) * lerpf(0.42, -0.6, rv)
	h += n * (0.12 + 0.9 * _ss(-14.0, -32.0, z))
	h += _ss(12.0, 22.0, z) * 0.6 # front lip rises a bit toward the lens
	# left and right ends of T1 rise gently so the strip reads as a diorama
	h += _ss(-22.0, -36.0, x) * 1.2 * _ss(-6.0, 4.0, z) + _ss(24.0, 36.0, x) * 1.0
	if z > -4.8:
		var c := 1.0 - _ss(1.05, 1.9, stream_dist(x, z))
		h = lerp(h, -0.8, c)
	var pc := 1.0 - _ss(0.72, 1.12, pond_e(x, z))
	h = lerp(h, -0.95, pc)
	return h


func ground_y(x: float, z: float) -> float:
	var fx: float = clamp((x - X0) / STEP, 0.0, nx - 1.001)
	var fz: float = clamp((z - Z0) / STEP, 0.0, nz - 1.001)
	var ix := int(fx)
	var iz := int(fz)
	var tx := fx - ix
	var tz := fz - iz
	var a := heights[iz * nx + ix]
	var b := heights[iz * nx + ix + 1]
	var c := heights[(iz + 1) * nx + ix]
	var d := heights[(iz + 1) * nx + ix + 1]
	return lerp(lerp(a, b, tx), lerp(c, d, tx), tz)


func mask_at(x: float, z: float) -> Color:
	var px := clampi(int((x - X0) * 2.0), 0, mask_img.get_width() - 1)
	var pz := clampi(int((z - Z0) * 2.0), 0, mask_img.get_height() - 1)
	return mask_img.get_pixel(px, pz)


func smat(pattern: int, cols: Array, opts: Dictionary = {}) -> ShaderMaterial:
	var mt := ShaderMaterial.new()
	mt.shader = SURF
	mt.set_shader_parameter("pattern", pattern)
	for i in 4:
		mt.set_shader_parameter("c%d" % i, Color.html(cols[i]))
	for k in opts:
		mt.set_shader_parameter(k, opts[k])
	return mt


func _materials() -> void:
	var stone := ["#3d3440", "#736a6c", "#a39886", "#d0c4a8"]
	m = {
		"plaster": smat(0, ["#7a6560", "#bfa58e", "#e6d2b2", "#f7ead0"]),
		"plaster_b": smat(0, ["#7c5d5e", "#c9a294", "#efd3bf", "#fdeadb"]),
		"timber": smat(6, ["#24161a", "#432a26", "#62402f", "#82593c"], {"rough": 0.8}),
		"stone": smat(1, stone, {"moss": 0.3}),
		"stone_big": smat(1, stone, {"moss": 0.35, "course": 9.0}),
		"clay": smat(2, ["#4e1f22", "#93392b", "#c95e3a", "#ea9a5e"], {"rough": 0.65, "moss": 0.08}),
		"slate": smat(3, ["#1f2440", "#37446c", "#506595", "#7d93bd"], {"rough": 0.45, "spec": 0.6}),
		"thatch": smat(4, ["#4a3420", "#86622f", "#bc9448", "#e4c878"], {"moss": 0.12, "bump": 1.4}),
		"planks": smat(5, ["#33221d", "#5f3f2d", "#8a5e3c", "#b08458"]),
		"shutter_g": smat(5, ["#1f3a34", "#2f5e4e", "#47806a", "#6aa488"]),
		"shutter_b": smat(5, ["#1c2a48", "#2e4878", "#4568a0", "#6f92c4"]),
		"shutter_r": smat(5, ["#4a1c1e", "#7a2e2a", "#a8463a", "#cc6a50"]),
		"glass": smat(9, ["#2a1a18", "#6a3c2a", "#b07440", "#e8b066"], {"rough": 0.12, "spec": 0.9, "emissive": 0.6}),
		"lamp": smat(9, ["#6a3c20", "#c07a38", "#f0b860", "#fff0c0"], {"rough": 0.2, "emissive": 3.0, "emit_color": Color(1.0, 0.7, 0.35)}),
		"bark": smat(7, ["#2a2026", "#4a3934", "#6c5646", "#8c775c"], {"moss": 0.2}),
		"cobble": smat(8, stone, {"rough": 0.6}),
		"iron": smat(10, ["#16161c", "#25252e", "#383842", "#52525e"], {"rough": 0.45, "spec": 0.7}),
		"cloth_red": smat(10, ["#4a1c22", "#8a2e2e", "#b84a3a", "#d87050"]),
		"windmill": smat(0, ["#6a5e5a", "#a89a8c", "#d6c8b0", "#efe4cc"]),
	}
	glass_mats.append(m["glass"])
	lamp_mats.append(m["lamp"])


func build(camera_forward: Vector3, camera_pos: Vector3) -> void:
	cam_fwd = camera_forward
	cam_pos = camera_pos
	noise.seed = 7
	noise.frequency = 0.045
	noise.fractal_octaves = 3
	_materials()
	_terrain()
	_water()
	var b := Builder.new()
	b.mats = m
	_retaining_wall(b)
	_bridge(b)
	_houses(b)
	_props(b)
	_hill(b)
	add_child(b.commit("Architecture"))
	_trees()
	_grass()
	_far()
	_particles()


# ---------------------------------------------------------------- terrain / water

func _terrain() -> void:
	nx = int(XW / STEP) + 1
	nz = int(ZD / STEP) + 1
	heights.resize(nx * nz)
	for iz in nz:
		for ix in nx:
			heights[iz * nx + ix] = height(X0 + ix * STEP, Z0 + iz * STEP)
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var idx := PackedInt32Array()
	verts.resize(nx * nz)
	norms.resize(nx * nz)
	for iz in nz:
		for ix in nx:
			var i := iz * nx + ix
			var hl := heights[iz * nx + max(ix - 1, 0)]
			var hr := heights[iz * nx + min(ix + 1, nx - 1)]
			var hd := heights[max(iz - 1, 0) * nx + ix]
			var hu := heights[min(iz + 1, nz - 1) * nx + ix]
			verts[i] = Vector3(X0 + ix * STEP, heights[i], Z0 + iz * STEP)
			norms[i] = Vector3(hl - hr, 2.0 * STEP, hd - hu).normalized()
	for iz in nz - 1:
		for ix in nx - 1:
			var a := iz * nx + ix
			idx.append_array([a, a + 1, a + nx, a + 1, a + nx + 1, a + nx])
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = norms
	arr[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	# mask: r dirt path, g cobbles, a flower density (2 px / unit)
	mask_img = Image.create(int(XW * 2), int(ZD * 2), false, Image.FORMAT_RGBA8)
	var fl_spots := [Vector3(-8.5, -3.2, 2.2), Vector3(4.5, -3.6, 2.6), Vector3(-14.0, 2.5, 2.5), Vector3(11.0, 3.5, 3.0),
		Vector3(-1.0, 4.5, 2.0), Vector3(14.0, -12.5, 3.0), Vector3(-6.0, -12.0, 2.5), Vector3(5.0, 8.5, 3.0), Vector3(-17.0, -2.0, 3.0)]
	for pz in mask_img.get_height():
		for px in mask_img.get_width():
			var x := X0 + (px + 0.5) / 2.0
			var z := Z0 + (pz + 0.5) / 2.0
			var r := 0.0
			var g := 0.0
			var a := 0.0
			if z > -4.7:
				var dz: float = abs(z - path_z(x))
				r = 1.0 - _ss(1.0, 1.6, dz + noise.get_noise_2d(x * 4.0, 0.0) * 0.3)
				if x > 6.0 and x < 8.0 and z < 0.5:
					r = max(r, 1.0 - _ss(0.7, 1.2, abs(x - 7.0)))
				var cob := 1.0 - _ss(2.0, 2.8, Vector2((x - 7.0) / 1.3, z + 1.6).length())
				if x > -1.6 and x < 12.0:
					g = r
				g = max(g, cob)
				if x > -6.5 and x < -1.5:
					r *= 0.0 # bridge deck covers it
					g = 0.0
			if z > -4.75 and z < -3.6:
				a = 0.9
			for s in fl_spots:
				a = max(a, 1.0 - _ss(s.z * 0.5, s.z, Vector2(x - s.x, z - s.y).length()))
			mask_img.set_pixel(px, pz, Color(r, g, 0.0, a))
	var mt := ShaderMaterial.new()
	mt.shader = TERRAIN
	mt.set_shader_parameter("mask", ImageTexture.create_from_image(mask_img))
	mt.set_shader_parameter("bounds", Vector4(X0, Z0, XW, ZD))
	var gcols := Pix.GRASS
	for i in 5:
		mt.set_shader_parameter("g%d" % i, Color.html(gcols[i]))
	var dcols := ["#3e2c2a", "#6e5040", "#9c7a58", "#c6a87a"]
	var scols := ["#46393c", "#806f66", "#b0a086", "#dccba8"]
	for i in 4:
		mt.set_shader_parameter("d%d" % i, Color.html(dcols[i]))
		mt.set_shader_parameter("s%d" % i, Color.html(scols[i]))
	mt.set_shader_parameter("mud", Color.html("#3a3a26"))
	var mi := MeshInstance3D.new()
	mi.name = "Terrain"
	mi.mesh = mesh
	mi.material_override = mt
	add_child(mi)


func _water() -> void:
	var pm := PlaneMesh.new()
	pm.size = Vector2(17.0, 17.0)
	pm.subdivide_width = 1
	water_mat = ShaderMaterial.new()
	water_mat.shader = WATER
	water_mat.set_shader_parameter("shallow", Color.html("#3f6f6a"))
	water_mat.set_shader_parameter("deep", Color.html("#0b1d22"))
	var mi := MeshInstance3D.new()
	mi.name = "Water"
	mi.mesh = pm
	mi.material_override = water_mat
	mi.position = Vector3(-6.0, WATER_Y, 3.0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.layers = 2 # not seen by the reflection camera
	add_child(mi)
	# cascade from the culvert
	var cq := QuadMesh.new()
	cq.size = Vector2(1.9, 0.75)
	var cm := ShaderMaterial.new()
	cm.shader = CASCADE
	var ci := MeshInstance3D.new()
	ci.mesh = cq
	ci.material_override = cm
	ci.position = Vector3(-4.0, -0.02, -4.45)
	ci.rotation.x = deg_to_rad(-38.0)
	ci.layers = 2
	ci.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ci)
	# lily pads
	var lily_tex := Pix.lily_atlas()
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	for i in 11:
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf()) * 0.75
		var p := Vector3(POND.x + cos(a) * r * POND.z, WATER_Y + 0.01, POND.y + sin(a) * r * POND.w)
		if pond_e(p.x, p.z) > 0.7:
			continue
		var q := QuadMesh.new()
		q.size = Vector2(20.0, 14.0) / TEXEL
		q.orientation = PlaneMesh.FACE_Y
		var lm := StandardMaterial3D.new()
		lm.albedo_texture = lily_tex
		lm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		lm.uv1_scale = Vector3(0.5, 1, 1)
		lm.uv1_offset = Vector3(0.5 if i % 4 == 0 else 0.0, 0, 0)
		lm.roughness = 0.35
		var li := MeshInstance3D.new()
		li.mesh = q
		li.material_override = lm
		li.position = p
		li.rotation.y = rng.randf_range(-0.4, 0.4)
		li.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(li)
		lily_nodes.append(li)


# ---------------------------------------------------------------- architecture

func _retaining_wall(b) -> void:
	var lo := Color(0.72, 0.7, 0.74)
	var segs := [Vector2(-30.0, -5.2), Vector2(-2.8, 6.1), Vector2(7.9, 32.0)]
	for s in segs:
		b.boxp("stone", Vector3((s.x + s.y) * 0.5, 0.72, -4.98), Vector3(s.y - s.x, 2.1, 0.5), lo)
	# coping broken into runs of different heights + buttresses, so the wall is not one flat band
	var runs := [Vector3(-30.0, -15.0, 1.84), Vector3(-15.0, -9.5, 2.36), Vector3(-9.5, -5.2, 1.84), Vector3(-2.8, 2.0, 1.84),
		Vector3(2.0, 6.1, 1.7), Vector3(7.9, 11.0, 1.84), Vector3(11.0, 14.6, 2.3), Vector3(14.6, 32.0, 1.84)]
	for rn in runs:
		if rn.z > 2.0:
			b.boxp("stone", Vector3((rn.x + rn.y) * 0.5, 2.06, -5.0), Vector3(rn.y - rn.x, 0.5, 0.45), lo)
		b.boxp("stone_big", Vector3((rn.x + rn.y) * 0.5, rn.z, -4.95), Vector3(rn.y - rn.x + 0.04, 0.18, 0.62), Color(0.9, 0.9, 0.9))
	for bx in [-20.5, -12.2, -0.4, 10.0, 18.5]:
		b.boxp("stone_big", Vector3(bx, 0.62, -4.62), Vector3(0.55, 2.2, 0.36), lo)
	# lit wayside niche in the right wall run (warm pool of light on the path at golden hour, a beacon at night)
	b.boxp("iron", Vector3(12.8, 1.05, -4.74), Vector3(0.9, 1.1, 0.06), Color(0.12, 0.1, 0.12), Color(0.12, 0.1, 0.12))
	b.boxp("stone_big", Vector3(12.8, 0.45, -4.6), Vector3(1.1, 0.12, 0.32))
	b.boxp("stone_big", Vector3(12.8, 1.66, -4.6), Vector3(1.1, 0.14, 0.32))
	b.boxp("lamp", Vector3(12.8, 0.62, -4.66), Vector3(0.14, 0.22, 0.14))
	_light(Vector3(12.8, 0.9, -4.2), Color(1.0, 0.6, 0.3), 3.0, true)
	flower_spots.append(Vector3(12.8, 0.51, -4.62))
	# culvert: stepped arch over the stream mouth, dark recess behind
	for i in 8:
		var x := -5.2 + i * 0.3 + 0.15
		var k := (x + 4.0) / 1.2
		var top_of_opening: float = 0.15 + 0.65 * sqrt(max(0.0, 1.0 - k * k))
		b.boxp("stone_big", Vector3(x, (top_of_opening + 1.77) * 0.5, -4.98), Vector3(0.3, 1.77 - top_of_opening, 0.56), lo)
	b.boxp("stone", Vector3(-4.0, 1.84, -4.95), Vector3(2.4, 0.18, 0.62))
	b.boxp("iron", Vector3(-4.0, 0.4, -5.6), Vector3(2.4, 1.6, 0.2), Color(0.1, 0.1, 0.12), Color(0.1, 0.1, 0.12))
	b.boxp("stone_big", Vector3(-4.0, 0.08, -4.9), Vector3(2.2, 0.16, 0.7))
	# stairs up to T2
	for i in 6:
		var top := 0.27 * (i + 1)
		var zf := -2.6 - i * 0.36
		b.boxp("stone_big", Vector3(7.0, top * 0.5 - 0.1, (zf - 4.75) * 0.5), Vector3(1.8, top + 0.2, -4.75 - zf), lo)
	for sx in [6.0, 8.0]:
		b.boxp("stone", Vector3(sx, 1.0, -3.7), Vector3(0.25, 2.2, 2.2), lo)


func _bridge(b) -> void:
	var zc := path_z(-4.0)
	var n := 14
	var x0 := -6.6
	var x1 := -1.4
	var sw := (x1 - x0) / n
	var lo := Color(0.7, 0.68, 0.72)
	for i in n:
		var x := x0 + (i + 0.5) * sw
		var k := (x + 4.0) / 2.6
		var deck: float = 0.12 + 0.62 * (1.0 - k * k)
		var ko := (x + 4.0) / 1.45
		var under := -0.9
		if abs(ko) < 1.0:
			under = -0.3 + 0.95 * sqrt(1.0 - ko * ko)
		b.boxp("stone_big", Vector3(x, (deck + under) * 0.5, zc), Vector3(sw + 0.01, deck - under, 2.3), lo)
		b.boxp("cobble", Vector3(x, deck + 0.04, zc), Vector3(sw + 0.01, 0.08, 2.0))
		for side in [-1.0, 1.0]:
			b.boxp("stone", Vector3(x, deck + 0.28, zc + side * 1.08), Vector3(sw + 0.01, 0.5, 0.26), lo)
			b.boxp("stone_big", Vector3(x, deck + 0.56, zc + side * 1.08), Vector3(sw + 0.02, 0.08, 0.34))
	footprints.append(Rect2(x0 - 0.3, zc - 1.3, x1 - x0 + 0.6, 2.6))


func _house(b, c: Vector3, w: float, d: float, wh: float, roof: String, pitch_deg: float, shutter: String, wall: String, windows: Array, door_x: float, chimney_x: float) -> void:
	var lo := Color(0.62, 0.58, 0.62)
	var y0 := c.y
	b.boxp("stone", Vector3(c.x, y0 + 0.2, c.z), Vector3(w + 0.3, 1.0, d + 0.3), lo)
	var wb := y0 + 0.7
	var top := wb + wh
	b.boxp(wall, Vector3(c.x, wb + wh * 0.5, c.z), Vector3(w, wh, d), Color(0.8, 0.76, 0.78))
	# timber frame
	var fz := c.z + d * 0.5 + 0.03
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			b.boxp("timber", Vector3(c.x + sx * w * 0.5, wb + wh * 0.5, c.z + sz * d * 0.5), Vector3(0.26, wh, 0.26))
	for yy in [wb + 0.08, wb + wh * 0.5, top - 0.1]:
		b.boxp("timber", Vector3(c.x, yy, fz), Vector3(w + 0.08, 0.17, 0.12))
		for sx in [-1.0, 1.0]:
			b.boxp("timber", Vector3(c.x + sx * (w * 0.5 + 0.03), yy, c.z), Vector3(0.12, 0.17, d + 0.08))
	var studs := int(w / 1.4)
	for i in range(1, studs):
		var x := c.x - w * 0.5 + i * w / studs
		var clear := true
		for wnd in windows:
			if abs(x - (c.x + wnd.x)) < 0.75:
				clear = false
		if abs(x - (c.x + door_x)) < 0.8:
			clear = false
		if clear:
			b.boxp("timber", Vector3(x, wb + wh * 0.5, fz), Vector3(0.14, wh, 0.1))
			# diagonal brace in the lower panel
			var br := Transform3D(Basis(Vector3.BACK, deg_to_rad(38.0 if i % 2 == 0 else -38.0)), Vector3(x + 0.35 * (1 if i % 2 == 0 else -1), wb + wh * 0.27, fz))
			b.box("timber", br, Vector3(0.12, wh * 0.55, 0.09))
	# gables + roof
	var p := deg_to_rad(pitch_deg)
	var ov := 0.55 if roof == "thatch" else 0.45
	var th := 0.42 if roof == "thatch" else 0.16
	var rise := (d * 0.5) * tan(p)
	for sx in [-1.0, 1.0]:
		var gx: float = c.x + sx * w * 0.5
		var a := Vector3(gx, top, c.z - d * 0.5)
		var bb := Vector3(gx, top, c.z + d * 0.5)
		var r := Vector3(gx, top + rise, c.z)
		var nn := Vector3(sx, 0, 0)
		var right := Vector3(0, 0, -sx)
		var uv := func(q: Vector3) -> Vector2: return Vector2(q.dot(right), -q.y)
		b.tri(wall, [a, bb, r], [nn, nn, nn], [uv.call(a), uv.call(bb), uv.call(r)], [Color.WHITE, Color.WHITE, Color.WHITE])
		b.boxp("timber", Vector3(gx + sx * 0.03, top + rise * 0.5, c.z), Vector3(0.12, rise, 0.14))
	var half := d * 0.5 + ov
	var slope := half / cos(p)
	var ridge_y := top + rise
	for side in [1.0, -1.0]:
		var basis := Basis(Vector3.RIGHT, p * side)
		var mid := Vector3(c.x, ridge_y - half * tan(p) * 0.5, c.z + side * half * 0.5)
		mid += basis.y * (th * 0.5 + 0.02)
		b.box(roof, Transform3D(basis, mid), Vector3(w + ov * 2.0, th, slope), Color(0.75, 0.72, 0.75))
	b.boxp(roof, Vector3(c.x, ridge_y + th * 0.9, c.z), Vector3(w + ov * 2.0 + 0.05, th * 0.9, th * 2.2), Color(0.85, 0.85, 0.85))
	roof_spots.append(Vector3(c.x + w * 0.3, ridge_y + th * 1.4, c.z))
	# chimney
	var ch := Vector3(c.x + chimney_x, 0, c.z - d * 0.18)
	var ch_top := ridge_y + 0.7
	b.boxp("stone", Vector3(ch.x, (top + ch_top) * 0.5, ch.z), Vector3(0.7, ch_top - top, 0.7), lo)
	b.boxp("stone_big", Vector3(ch.x, ch_top + 0.08, ch.z), Vector3(0.86, 0.16, 0.86))
	_smoke_at(Vector3(ch.x, ch_top + 0.25, ch.z))
	# windows
	for wnd in windows:
		_window(b, Vector3(c.x + wnd.x, wb + wnd.y, fz), shutter)
	# side window (right gable wall)
	_window_side(b, Vector3(c.x + w * 0.5 + 0.03, wb + wh * 0.45, c.z))
	# door
	var dx := c.x + door_x
	b.boxp("planks", Vector3(dx, wb + 0.95, fz - 0.02), Vector3(0.95, 1.9, 0.08), Color(0.7, 0.66, 0.66))
	b.boxp("timber", Vector3(dx, wb + 1.95, fz + 0.03), Vector3(1.25, 0.16, 0.14))
	for sx in [-1.0, 1.0]:
		b.boxp("timber", Vector3(dx + sx * 0.56, wb + 0.95, fz + 0.03), Vector3(0.14, 1.9, 0.14))
	b.boxp("stone_big", Vector3(dx, wb - 0.12, fz + 0.35), Vector3(1.3, 0.24, 0.7))
	b.boxp("iron", Vector3(dx + 0.3, wb + 0.95, fz + 0.04), Vector3(0.06, 0.06, 0.05))
	# wall lamp by the door
	var lp := Vector3(dx + 0.95, wb + 1.75, fz + 0.18)
	b.boxp("iron", lp + Vector3(0, 0.25, -0.1), Vector3(0.06, 0.06, 0.3))
	b.boxp("iron", lp + Vector3(0, 0.17, 0), Vector3(0.26, 0.05, 0.26))
	b.boxp("lamp", lp, Vector3(0.18, 0.26, 0.18))
	_light(lp + Vector3(0, -0.05, 0.25), Color(1.0, 0.62, 0.3), 3.2, true)
	footprints.append(Rect2(c.x - w * 0.5 - 0.5, c.z - d * 0.5 - 0.5, w + 1.0, d + 1.6))


func _window(b, p: Vector3, shutter: String) -> void:
	b.boxp("glass", p + Vector3(0, 0, -0.03), Vector3(0.72, 0.9, 0.04))
	for sx in [-1.0, 1.0]:
		b.boxp("timber", p + Vector3(sx * 0.42, 0, 0.02), Vector3(0.12, 1.06, 0.1))
		b.boxp(shutter, p + Vector3(sx * 0.72, 0, 0.04), Vector3(0.4, 1.0, 0.06), Color(0.8, 0.8, 0.8))
	for sy in [-1.0, 1.0]:
		b.boxp("timber", p + Vector3(0, sy * 0.5, 0.02), Vector3(0.96, 0.12, 0.1))
	b.boxp("timber", p + Vector3(0, 0, 0.0), Vector3(0.06, 0.9, 0.06))
	b.boxp("timber", p + Vector3(0, 0.08, 0.0), Vector3(0.72, 0.06, 0.06))
	b.boxp("planks", p + Vector3(0, -0.66, 0.16), Vector3(1.0, 0.24, 0.32), Color(0.75, 0.72, 0.72))
	flower_spots.append(p + Vector3(0, -0.54, 0.16))
	_light(p + Vector3(0, -0.1, 0.55), Color(1.0, 0.6, 0.28), 4.0, false)


func _window_side(b, p: Vector3) -> void:
	b.boxp("glass", p + Vector3(-0.02, 0, 0), Vector3(0.04, 0.85, 0.7))
	for sz in [-1.0, 1.0]:
		b.boxp("timber", p + Vector3(0.02, 0, sz * 0.4), Vector3(0.1, 1.0, 0.12))
		b.boxp("timber", p + Vector3(0.02, sz * 0.47, 0), Vector3(0.1, 0.12, 0.92))
	_light(p + Vector3(0.5, -0.1, 0), Color(1.0, 0.6, 0.28), 3.0, false)


func _light(p: Vector3, col: Color, rng_: float, lantern: bool) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = p
	l.light_color = col
	l.omni_range = rng_
	l.omni_attenuation = 1.6
	l.light_specular = 0.6
	l.shadow_enabled = false
	add_child(l)
	if lantern:
		lantern_lights.append(l)
	else:
		window_lights.append(l)
	return l


func _houses(b) -> void:
	var ya := ground_y(-11.5, -9.5)
	_house(b, Vector3(-11.5, 1.6, -9.6), 6.0, 4.6, 2.5, "thatch", 48.0, "shutter_g", "plaster",
		[Vector2(-1.75, 1.15), Vector2(1.7, 1.15)], 0.0, 1.6)
	_house(b, Vector3(2.6, 1.6, -10.2), 6.4, 5.0, 3.2, "clay", 38.0, "shutter_b", "plaster_b",
		[Vector2(-2.0, 1.05), Vector2(1.95, 1.05), Vector2(-1.2, 2.4), Vector2(1.2, 2.4)], 0.0, -1.8)
	_house(b, Vector3(12.6, 1.6, -9.0), 5.4, 4.4, 2.6, "slate", 44.0, "shutter_r", "plaster",
		[Vector2(-1.45, 1.15), Vector2(1.5, 1.15)], 0.05, 1.3)
	# hill cottages (T3)
	_house(b, Vector3(-17.0, ground_y(-17.0, -25.0) - 0.3, -25.0), 4.2, 3.6, 2.2, "clay", 40.0, "shutter_g", "plaster",
		[Vector2(-1.0, 1.0)], 0.9, 1.0)
	_house(b, Vector3(16.5, ground_y(16.5, -24.0) - 0.3, -24.0), 4.6, 3.6, 2.2, "slate", 42.0, "shutter_b", "plaster_b",
		[Vector2(1.1, 1.0)], -0.6, -1.0)
	# banner with the studio kite emblem on house B
	_cloth(Vector3(-0.35, 1.6 + 0.7 + 3.3, -10.2 + 2.5 + 0.12), Vector2(0.5, 1.25), 3, 0.4)
	b.boxp("timber", Vector3(-0.35, 1.6 + 0.7 + 3.32, -10.2 + 2.5 + 0.12), Vector3(0.7, 0.06, 0.06))
	if ya < -100.0:
		push_error("unreachable")


func _cloth(top_center: Vector3, size: Vector2, cell: int, stiffness: float) -> void:
	var q := QuadMesh.new()
	q.size = size
	q.center_offset = Vector3(0, -size.y * 0.5, 0)
	var mt := ShaderMaterial.new()
	mt.shader = CLOTH
	mt.set_shader_parameter("tex", _cloth_tex())
	mt.set_shader_parameter("stiffness", stiffness)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = mt
	mi.position = top_center
	add_child(mi)
	# pick atlas cell through uv scale/offset on the mesh is not available for QuadMesh: bake it
	var arr := q.get_mesh_arrays()
	var uvs: PackedVector2Array = arr[Mesh.ARRAY_TEX_UV]
	for i in uvs.size():
		uvs[i].x = (uvs[i].x + cell) / 4.0
	arr[Mesh.ARRAY_TEX_UV] = uvs
	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	mi.mesh = am


var _cloth_cache: ImageTexture
func _cloth_tex() -> ImageTexture:
	if _cloth_cache == null:
		_cloth_cache = Pix.cloth_atlas()
	return _cloth_cache


func _props(b) -> void:
	var lo := Color(0.7, 0.66, 0.68)
	# lantern posts
	for lp in [Vector3(4.9, 0, 2.8), Vector3(-7.2, 0, -0.6), Vector3(10.5, 0, -2.2), Vector3(-10.2, 0, 1.9)]:
		var y := ground_y(lp.x, lp.z)
		b.boxp("stone_big", Vector3(lp.x, y + 0.1, lp.z), Vector3(0.5, 0.3, 0.5), lo)
		b.boxp("timber", Vector3(lp.x, y + 1.3, lp.z), Vector3(0.18, 2.4, 0.18), lo)
		b.boxp("timber", Vector3(lp.x + 0.22, y + 2.42, lp.z), Vector3(0.6, 0.1, 0.1))
		var hp := Vector3(lp.x + 0.42, y + 2.08, lp.z)
		b.boxp("iron", hp + Vector3(0, 0.24, 0), Vector3(0.36, 0.08, 0.36))
		b.boxp("iron", hp + Vector3(0, 0.34, 0), Vector3(0.16, 0.12, 0.16))
		b.boxp("lamp", hp, Vector3(0.24, 0.36, 0.24))
		b.boxp("iron", hp + Vector3(0, -0.21, 0), Vector3(0.3, 0.06, 0.3))
		_light(hp + Vector3(0, 0, 0.1), Color(1.0, 0.64, 0.32), 6.0, true)
		footprints.append(Rect2(lp.x - 0.4, lp.z - 0.4, 0.8, 0.8))
	# bench by the pond
	var bc := Vector3(-10.5, ground_y(-10.5, -0.9), -0.9)
	b.boxp("planks", bc + Vector3(0, 0.48, 0), Vector3(1.9, 0.08, 0.5))
	b.boxp("planks", bc + Vector3(0, 0.85, -0.24), Vector3(1.9, 0.32, 0.07))
	for sx in [-0.8, 0.8]:
		b.boxp("timber", bc + Vector3(sx, 0.24, 0), Vector3(0.1, 0.48, 0.44))
		b.boxp("timber", bc + Vector3(sx, 0.6, -0.24), Vector3(0.08, 0.6, 0.08))
	footprints.append(Rect2(bc.x - 1.1, bc.z - 0.4, 2.2, 0.8))
	# barrels and crates by the stairs
	for bp in [Vector3(9.3, 0, -3.6), Vector3(10.1, 0, -3.3), Vector3(4.9, 0, -3.9)]:
		var y := ground_y(bp.x, bp.z)
		b.prism("planks", Transform3D(Basis(), Vector3(bp.x, y, bp.z)), 10, 0.36, 0.36, 0.95, lo)
		for hy in [0.18, 0.77]:
			b.prism("iron", Transform3D(Basis(), Vector3(bp.x, y + hy, bp.z)), 10, 0.375, 0.375, 0.06, Color.WHITE, Color.WHITE, false)
		footprints.append(Rect2(bp.x - 0.45, bp.z - 0.45, 0.9, 0.9))
	for cp in [Vector3(8.7, 0.0, -2.9), Vector3(8.8, 0.7, -3.0), Vector3(3.9, 0.0, -3.5)]:
		var y: float = ground_y(cp.x, cp.z) + cp.y
		var xf := Transform3D(Basis(Vector3.UP, cp.x * 0.7), Vector3(cp.x, y + 0.34, cp.z))
		b.box("planks", xf, Vector3(0.7, 0.68, 0.7), lo)
		b.box("timber", xf, Vector3(0.74, 0.12, 0.74))
		footprints.append(Rect2(cp.x - 0.45, cp.z - 0.45, 0.9, 0.9))
	# laundry line on T2 between houses B and C
	var l0 := Vector3(6.6, 1.6, -6.4)
	var l1 := Vector3(9.3, 1.6, -6.7)
	for lp in [l0, l1]:
		b.boxp("timber", lp + Vector3(0, 1.2, 0), Vector3(0.12, 2.4, 0.12))
	var mid := (l0 + l1) * 0.5 + Vector3(0, 2.32, 0)
	var dir := l1 - l0
	b.box("timber", Transform3D(Basis(Vector3.UP, -atan2(dir.z, dir.x)), mid), Vector3(dir.length(), 0.03, 0.03))
	for i in 3:
		var t := 0.2 + i * 0.3
		_cloth(l0.lerp(l1, t) + Vector3(0, 2.33, 0.02), Vector2(0.55, 0.7), i % 3, 1.0)
	# T0: weathered fence in the right foreground (lands in the near bokeh)
	for i in 6:
		var x := 6.4 + i * 1.6
		var z := 7.4 + sin(i * 0.9) * 0.25 - i * 0.12
		var y := ground_y(x, z)
		b.boxp("timber", Vector3(x, y + 0.6, z), Vector3(0.18, 1.2 + (0.25 if i == 0 else 0.0), 0.18), lo)
		if i < 5:
			b.box("timber", Transform3D(Basis(Vector3.UP, 0.08), Vector3(x + 0.8, y + 0.85, z - 0.06)), Vector3(1.7, 0.1, 0.07))
			b.box("timber", Transform3D(Basis(Vector3.UP, 0.08), Vector3(x + 0.8, y + 0.42, z - 0.06)), Vector3(1.7, 0.1, 0.07))
	# rocks along the stream and pond
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	for rp in [Vector2(-2.6, -2.8), Vector2(-5.4, -3.4), Vector2(-2.9, 2.6), Vector2(-3.4, 4.6), Vector2(-11.0, 4.4), Vector2(-9.6, 6.6), Vector2(-4.6, 6.4), Vector2(-8.6, 2.0)]:
		var y := ground_y(rp.x, rp.y)
		var s := rng.randf_range(0.5, 0.9)
		var xf := Transform3D(Basis.from_euler(Vector3(rng.randf_range(-0.2, 0.2), rng.randf() * TAU, rng.randf_range(-0.2, 0.2))), Vector3(rp.x, y + s * 0.2, rp.y))
		b.box("stone_big", xf, Vector3(s * 1.3, s * 0.7, s), lo, Color.WHITE, true)


func _hill(b) -> void:
	# windmill on the left hill
	var wp := Vector3(-13.5, 0, -29.0)
	wp.y = ground_y(wp.x, wp.z) - 0.3
	b.prism("windmill", Transform3D(Basis(), wp), 8, 1.5, 1.05, 6.0, Color(0.7, 0.66, 0.68))
	b.prism("thatch", Transform3D(Basis(), wp + Vector3(0, 6.0, 0)), 8, 1.35, 0.1, 1.8, Color(0.8, 0.8, 0.8))
	b.boxp("planks", wp + Vector3(0, 0.9, 1.4), Vector3(0.8, 1.6, 0.2))
	b.boxp("glass", wp + Vector3(0, 3.6, 1.2), Vector3(0.5, 0.6, 0.12))
	windmill_sails = Node3D.new()
	windmill_sails.position = wp + Vector3(0, 6.0, 1.45)
	add_child(windmill_sails)
	var sb := Builder.new()
	sb.mats = m
	sb.boxp("timber", Vector3.ZERO, Vector3(0.4, 0.4, 0.4))
	for i in 4:
		var bas := Basis(Vector3.BACK, i * PI * 0.5)
		sb.box("timber", Transform3D(bas, bas * Vector3(0, 2.4, 0)), Vector3(0.14, 4.8, 0.1))
		sb.box("cloth_red", Transform3D(bas, bas * Vector3(0.42, 2.9, 0.02)), Vector3(0.7, 3.4, 0.04))
	windmill_sails.add_child(sb.commit("Sails"))


# ---------------------------------------------------------------- foliage

## Cards face the camera with yaw/tilt jitter only: the right axis stays horizontal, so leaf pixels never
## turn into diamonds (Octopath rule: pixels never rotate diagonally).
func _card_basis(rng: RandomNumberGenerator) -> Basis:
	var f := (-cam_fwd + Vector3(rng.randf_range(-0.45, 0.45), rng.randf_range(-0.15, 0.35), 0.0)).normalized()
	var r := Vector3.UP.cross(f).normalized()
	var u := f.cross(r).normalized()
	return Basis(r, u, f)


const LEAF_KEY := Vector3(-0.35, 0.86, -0.36) # up-weighted golden-hour key used to bake lobe value masses

## Leaf-card canopy: cards on/inside ellipsoid lobes, outward normals per vertex, AO by depth and a baked
## 3-step value mass per lobe (lit cap / mid band / dark core) so clumps read as big shapes, not fish scales.
func _canopy(fb, key: String, lobes: Array, cards: int, rng: RandomNumberGenerator, sway: float, card: float = 2.0) -> void:
	var total_v := 0.0
	for lb in lobes:
		total_v += lb[1].x * lb[1].y * lb[1].z
	for lb in lobes:
		var c: Vector3 = lb[0]
		var rad: Vector3 = lb[1]
		var n := int(cards * rad.x * rad.y * rad.z / total_v) + 3
		for i in n:
			var dir := Vector3(rng.randfn(), rng.randfn() * 0.8 + 0.25, rng.randfn() + 0.35).normalized()
			var depth := pow(rng.randf(), 0.5)
			var p := c + dir * rad * (0.55 + 0.45 * depth)
			var bas := _card_basis(rng)
			var hs := card * 0.5
			var cell := rng.randi_range(0, 7)
			var corners := [Vector3(-hs, -hs, 0), Vector3(hs, -hs, 0), Vector3(hs, hs, 0), Vector3(-hs, hs, 0)]
			var uvs := [Vector2(cell / 8.0, 1.0), Vector2((cell + 1) / 8.0, 1.0), Vector2((cell + 1) / 8.0, 0.0), Vector2(cell / 8.0, 0.0)]
			var kd := dir.dot(LEAF_KEY)
			var mass := 1.1 if kd > 0.4 else (0.92 if kd > -0.15 else 0.7)
			var pts := []
			var nrm := []
			var col := []
			for k in 4:
				var q: Vector3 = p + bas * corners[k]
				pts.append(q)
				var on := ((q - c) / (rad * rad)).normalized()
				nrm.append((on * 0.85 + bas.z * 0.15).normalized())
				var ao: float = clamp(0.5 + 0.5 * depth + on.y * 0.15, 0.35, 1.0) * mass
				col.append(Color(ao, ao, ao))
			var uv2 := Vector2(sway * clamp(0.4 + (p.y - (c.y - rad.y)) / (rad.y * 2.0) * 0.6, 0.0, 1.0), rng.randf() * 6.28)
			fb.tri(key, [pts[0], pts[1], pts[2]], [nrm[0], nrm[1], nrm[2]], [uvs[0], uvs[1], uvs[2]], [col[0], col[1], col[2]], uv2)
			fb.tri(key, [pts[0], pts[2], pts[3]], [nrm[0], nrm[2], nrm[3]], [uvs[0], uvs[2], uvs[3]], [col[0], col[2], col[3]], uv2)


## One 2x2-unit ivy card hanging from `top` down the wall face (+z), darker toward its tip.
func _ivy(fb, top: Vector3, rng: RandomNumberGenerator) -> void:
	var cell := rng.randi_range(0, 7)
	var pts := [top + Vector3(-1, -2, 0), top + Vector3(1, -2, 0), top + Vector3(1, 0, 0), top + Vector3(-1, 0, 0)]
	var uvs := [Vector2(cell / 8.0, 1.0), Vector2((cell + 1) / 8.0, 1.0), Vector2((cell + 1) / 8.0, 0.0), Vector2(cell / 8.0, 0.0)]
	var nb := Vector3(0, 0.35, 1).normalized()
	var nt := Vector3(0, 0.7, 0.7).normalized()
	var lo := Color(0.62, 0.62, 0.62)
	var hi := Color(0.95, 0.95, 0.95)
	var uv2 := Vector2(0.12, rng.randf() * 6.28)
	fb.tri("bush", [pts[0], pts[1], pts[2]], [nb, nb, nt], [uvs[0], uvs[1], uvs[2]], [lo, lo, hi], uv2)
	fb.tri("bush", [pts[0], pts[2], pts[3]], [nb, nt, nt], [uvs[0], uvs[2], uvs[3]], [lo, hi, hi], uv2)


func _foliage_mat(atlas: Texture2D, tint: Color, sway: float) -> ShaderMaterial:
	var mt := ShaderMaterial.new()
	mt.shader = FOLIAGE
	mt.set_shader_parameter("atlas", atlas)
	mt.set_shader_parameter("tint", tint)
	mt.set_shader_parameter("sway", sway)
	return mt


func _trunk(tb, base: Vector3, h: float, r: float, rng: RandomNumberGenerator, branches: Array) -> void:
	tb.prism("bark", Transform3D(Basis(), base), 11, r, r * 0.62, h, Color(0.6, 0.55, 0.6))
	for i in 5:
		var a := i * TAU / 5.0 + rng.randf()
		var bas := Basis(Vector3(cos(a + PI * 0.5), 0, sin(a + PI * 0.5)), 0.9)
		tb.box("bark", Transform3D(bas, base + Vector3(cos(a) * r * 0.9, 0.25, sin(a) * r * 0.9)), Vector3(r * 0.5, 1.0, r * 0.5), Color(0.55, 0.5, 0.55))
	for br in branches:
		var to: Vector3 = br
		var from := base + Vector3(0, h * 0.85, 0)
		var dv := to - from
		var up := dv.normalized()
		var side := up.cross(Vector3.FORWARD).normalized()
		if side.length() < 0.1:
			side = Vector3.RIGHT
		var bas := Basis(side, up, side.cross(up)).orthonormalized()
		tb.prism("bark", Transform3D(bas, from), 8, r * 0.4, r * 0.18, dv.length(), Color(0.6, 0.55, 0.6), Color.WHITE, false)

## God-ray slices: N camera-facing quads stacked along the view through the canopy / house-gap volume.
## Each fragment reads the real sun shadow map (shafts.gdshader), giving crisp dappled blades.
func _shafts() -> void:
	var center := Vector3(-2.0, 7.0, -13.5)
	var half := Vector3(11.0, 5.5, 7.0)
	var n := 10 # pure overdraw: blend_add + shadow lookup per fragment, 20 slices cost ~9 ms at 1440p
	var right := Vector3.UP.cross(-cam_fwd).normalized()
	var upv := (-cam_fwd).cross(right).normalized()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in n:
		var c := center + cam_fwd * lerpf(-9.0, 9.0, (i + 0.5) / n)
		var a := c - right * 11.0 - upv * 7.0
		var b := c + right * 11.0 - upv * 7.0
		var cc := c + right * 11.0 + upv * 7.0
		var d := c - right * 11.0 + upv * 7.0
		for v in [a, b, cc, a, cc, d]:
			st.set_normal(-cam_fwd)
			st.add_vertex(v)
	shafts = ShaderMaterial.new()
	shafts.shader = SHAFTS
	shafts.set_shader_parameter("box_center", center)
	shafts.set_shader_parameter("box_half", half)
	shafts.set_shader_parameter("density", 0.0075)
	var mi := MeshInstance3D.new()
	mi.name = "Shafts"
	mi.mesh = st.commit()
	mi.material_override = shafts
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.layers = 2 # not in the mirror
	add_child(mi)



func _trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 21
	var tb := Builder.new()
	tb.mats = m
	var fb := Builder.new()
	var nb := Builder.new() # far forest + lens branch: no shadow casting (cheap)
	var leaf_a := Pix.leaf_atlas(1)
	var leaf_far := Pix.leaf_atlas(2, ["#14262e", "#1d3a3a", "#2c5640", "#447646", "#6c9a52", "#a4bc6a"])
	fb.mats = {"leaf": _foliage_mat(leaf_a, Color(1, 1, 1), 0.35), "bush": _foliage_mat(leaf_a, Color(1.02, 1.04, 0.95), 0.5)}
	nb.mats = {"leaf_far": _foliage_mat(leaf_far, Color(0.95, 0.97, 1.0), 0.25), "bush": fb.mats["bush"]}
	# the big old tree behind, between houses A and B: sun shafts pass through it
	var big := Vector3(-4.2, 0, -17.0)
	big.y = ground_y(big.x, big.z) - 0.2
	var top := big + Vector3(0, 4.0, 0)
	_trunk(tb, big, 4.6, 0.95, rng, [top + Vector3(-3.2, 2.2, 0.4), top + Vector3(3.0, 2.6, -0.2), top + Vector3(0.3, 3.8, 0.8)])
	_canopy(fb, "leaf", [[top + Vector3(0, 4.4, 0), Vector3(5.6, 3.4, 4.2)], [top + Vector3(-4.0, 2.6, 0.6), Vector3(3.2, 2.4, 3.0)],
		[top + Vector3(4.2, 3.0, 0.2), Vector3(3.4, 2.6, 3.0)], [top + Vector3(0.5, 6.6, -0.5), Vector3(3.6, 2.2, 3.0)]], 300, rng, 0.8)
	# right tree over house C
	var rt := Vector3(22.0, 0, -12.0)
	rt.y = ground_y(rt.x, rt.z) - 0.2
	var rtop := rt + Vector3(0, 4.6, 0)
	_trunk(tb, rt, 5.0, 0.75, rng, [rtop + Vector3(-2.6, 2.0, 0.3), rtop + Vector3(1.6, 2.6, 0)])
	_canopy(fb, "leaf", [[rtop + Vector3(-0.5, 3.6, 0), Vector3(4.6, 3.0, 3.6)], [rtop + Vector3(-3.6, 2.4, 0.6), Vector3(2.8, 2.2, 2.6)],
		[rtop + Vector3(1.0, 5.6, -0.4), Vector3(3.0, 2.0, 2.6)]], 200, rng, 0.8)
	# small tree front-left on T2 edge
	var lt := Vector3(-19.5, 0, -6.6)
	lt.y = ground_y(lt.x, lt.z) - 0.2
	_trunk(tb, lt, 3.4, 0.5, rng, [lt + Vector3(1.4, 4.4, 0.3)])
	_canopy(fb, "leaf", [[lt + Vector3(0.3, 5.0, 0), Vector3(3.2, 2.4, 2.6)], [lt + Vector3(2.0, 4.2, 0.6), Vector3(2.0, 1.6, 1.8)]], 90, rng, 0.9)
	# forest edge on the hill (back), denser and bluer
	for i in 22:
		var x := -52.0 + i * 4.9 + rng.randf_range(-1.5, 1.5)
		var z := -40.0 - rng.randf_range(0.0, 9.0) - (6.0 if abs(x) < 10.0 else 0.0)
		var y := ground_y(x, z) - 0.3
		var s := rng.randf_range(2.6, 3.6)
		_trunk(tb, Vector3(x, y, z), s * 1.2, 0.35 * s / 3.0, rng, [])
		_canopy(nb, "leaf_far", [[Vector3(x, y + s * 1.2 + s * 0.9, z), Vector3(s * 1.2, s * 1.1, s)], [Vector3(x + s * 0.6, y + s * 2.6, z + 0.3), Vector3(s * 0.8, s * 0.7, s * 0.7)]], 34, rng, 0.5)
	# mid-hill trees between the cottages
	for tp in [Vector3(-9.0, 0, -27.0), Vector3(3.0, 0, -31.0), Vector3(25.0, 0, -36.0), Vector3(-30.0, 0, -18.0), Vector3(36.0, 0, -22.0)]:
		var y := ground_y(tp.x, tp.z) - 0.2
		var s := rng.randf_range(2.4, 3.2)
		_trunk(tb, Vector3(tp.x, y, tp.z), s * 1.3, 0.4, rng, [])
		_canopy(fb, "leaf", [[Vector3(tp.x, y + s * 1.3 + s, tp.z), Vector3(s * 1.2, s, s)]], 50, rng, 0.6)
	# bushes: along the retaining wall top, by houses and around the pond
	for bp in [Vector3(-7.5, 0, -6.2), Vector3(-15.6, 0, -6.3), Vector3(9.4, 0, -6.4), Vector3(17.6, 0, -6.4), Vector3(-1.9, 0, -6.2),
			Vector3(-16.5, 0, 2.2), Vector3(6.2, 0, 8.6), Vector3(13.5, 0, 1.2), Vector3(-21.0, 0, 1.0), Vector3(6.0, 0, -13.2), Vector3(-18.5, 0, -12.0)]:
		var y := ground_y(bp.x, bp.z)
		var s := rng.randf_range(0.9, 1.4)
		_canopy(fb, "bush", [[Vector3(bp.x, y + s * 0.7, bp.z), Vector3(s * 1.3, s * 0.8, s)]], 16, rng, 0.5)
	# ivy curtains draping over the coping (camera-facing, unrotated cards so the leaf pixels stay on-grid)
	for ix in [-18.2, -13.6, -7.9, 3.2, 8.6, 15.8]:
		var drop := rng.randf_range(0.0, 0.5)
		_ivy(fb, Vector3(ix, 1.55 - drop, -4.66), rng)
		if rng.randf() < 0.6:
			_ivy(fb, Vector3(ix + rng.randf_range(0.6, 1.1), 1.2 - drop, -4.68), rng)
	# leafy branch entering the top-left corner (foreground bokeh)
	var cp := cam_pos
	var right := Vector3.UP.cross(-cam_fwd).normalized()
	var upv := (-cam_fwd).cross(right).normalized()
	var bpos := cp + cam_fwd * 12.0 - right * 4.9 + upv * 2.55
	_canopy(nb, "bush", [[bpos, Vector3(1.8, 0.7, 0.8)], [bpos + right * 1.7 + upv * 0.25, Vector3(1.1, 0.5, 0.6)]], 18, rng, 0.9)
	_shafts()
	var tm := tb.commit("Trunks")
	add_child(tm)
	var fm := fb.commit("Canopies")
	add_child(fm)
	add_child(nb.commit("FarCanopies", false))
	_leaves_at(big + Vector3(0, 10.0, 0), Vector3(7.0, 3.0, 4.0), 70)
	_leaves_at(rt + Vector3(-1, 8.0, 0), Vector3(5.0, 2.5, 3.0), 40)
	_leaves_at(Vector3(-2.0, 6.5, -1.0), Vector3(9.0, 1.0, 3.0), 26) # gusts carry leaves across the focal tier


# ---------------------------------------------------------------- grass multimesh

## Tufts are instanced at exactly 1 texel = 1/32 unit (integer 2x only in the always-blurred T0/T3);
## variety comes from atlas cells, yaw and X-flips, never from non-uniform scale.
## Bank tufts/reeds go to a second MultiMesh on layer 1 so the water mirror reflects them.
func _grass() -> void:
	var q := QuadMesh.new()
	q.size = Vector2(24.0, 32.0) / TEXEL
	q.center_offset = Vector3(0, q.size.y * 0.5, 0)
	var rng := RandomNumberGenerator.new()
	rng.seed = 33
	var sets := [{"xf": [], "cu": [], "co": []}, {"xf": [], "cu": [], "co": []}] # 0 = main, 1 = water bank
	var add := func(p: Vector3, cell: int, s: float) -> void:
		var flip := -1.0 if rng.randf() < 0.5 else 1.0
		var bas := Basis(Vector3.UP, rng.randf_range(-0.3, 0.3)).scaled(Vector3(s * flip, s, s))
		var bank := p.z > -7.0 and p.y < WATER_Y + 0.7 and (pond_e(p.x, p.z) < 1.6 or stream_dist(p.x, p.z) < 2.6)
		var st: Dictionary = sets[1 if bank else 0]
		st.xf.append(Transform3D(bas, p - Vector3(0, 0.04, 0)))
		st.cu.append(Color(cell, rng.randf(), 0, 0))
		var t := rng.randf_range(0.88, 1.1)
		st.co.append(Color(t, t * rng.randf_range(0.97, 1.03), t * 0.95))
	var regions := [
		[Rect2(-30, -4.6, 60, 17.5), 3.2, 1.0], # T1 focal tier
		[Rect2(-30, 7.6, 60, 5.0), 1.2, 2.0], # T0 foreground, big blurred tufts (integer 2x)
		[Rect2(-30, -15, 60, 10.2), 2.0, 1.0], # T2
		[Rect2(-45, -46, 90, 31), 0.45, 2.0], # T3 hill (always out of focus)
	]
	for rg in regions:
		var r: Rect2 = rg[0]
		var count := int(r.get_area() * rg[1])
		for i in count:
			var x := r.position.x + rng.randf() * r.size.x
			var z := r.position.y + rng.randf() * r.size.y
			var y := ground_y(x, z)
			var mk := mask_at(x, z)
			if mk.r > 0.42 or mk.g > 0.4:
				continue
			var blocked := false
			for fp in footprints:
				if fp.has_point(Vector2(x, z)):
					blocked = true
					break
			if blocked:
				continue
			if z > -5.4 and z < -4.6:
				continue # retaining wall
			var near_water := z > -7.0 and y < WATER_Y + 0.25
			var s: float = rg[2]
			if z > -7.0 and y < WATER_Y + 0.02:
				if y > WATER_Y - 0.35 and rng.randf() < 0.16:
					add.call(Vector3(x, y, z), 7, 1.0)
				continue
			var cell := rng.randi_range(0, 2)
			if rng.randf() < 0.12:
				cell = 3
			if rng.randf() < mk.a * 0.6 + 0.04:
				cell = 4 + rng.randi_range(0, 2)
			if near_water and s < 1.5 and rng.randf() < 0.3:
				cell = 7
			add.call(Vector3(x, y, z), cell, s)
	for fs in flower_spots:
		for k in 4:
			add.call(fs + Vector3(rng.randf_range(-0.4, 0.4), 0, rng.randf_range(-0.08, 0.08)), 4 + rng.randi_range(0, 2), 1.0)
	var mt := ShaderMaterial.new()
	mt.shader = GRASS
	mt.set_shader_parameter("atlas", Pix.tuft_atlas())
	for k in 2:
		var st: Dictionary = sets[k]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.use_colors = true
		mm.use_custom_data = true
		mm.mesh = q
		mm.instance_count = st.xf.size()
		for i in st.xf.size():
			mm.set_instance_transform(i, st.xf[i])
			mm.set_instance_color(i, st.co[i])
			mm.set_instance_custom_data(i, st.cu[i])
		var mmi := MultiMeshInstance3D.new()
		mmi.name = "Grass" if k == 0 else "BankGrass"
		mmi.multimesh = mm
		mmi.material_override = mt
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mmi.layers = 4 if k == 0 else 1 # bank tufts + reeds are seen by the mirror camera
		add_child(mmi)


# ---------------------------------------------------------------- far hills + clouds

func _far() -> void:
	# ridges sit low so they show through the valley window on the right (camera looks ~17 deg down)
	var layers := [[-70.0, -10.0, -4.5, "#5d7088"], [-100.0, -8.5, -2.5, "#7b8aa4"], [-140.0, -8.0, -0.5, "#9aa6bc"]]
	var li := 0
	for L in layers:
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		var z: float = L[0]
		var lo: float = L[1]
		var hi: float = L[2]
		var n := 120
		for i in n:
			var xa := -260.0 + i * 520.0 / n
			var xb := xa + 520.0 / n
			var ya := lerpf(lo, hi, noise.get_noise_1d(xa * 0.35 + li * 50.0) * 0.5 + 0.5)
			var yb := lerpf(lo, hi, noise.get_noise_1d(xb * 0.35 + li * 50.0) * 0.5 + 0.5)
			for v in [Vector3(xa, -60, z), Vector3(xa, ya, z), Vector3(xb, yb, z), Vector3(xa, -60, z), Vector3(xb, yb, z), Vector3(xb, -60, z)]:
				st.set_normal(Vector3.BACK)
				st.set_uv(Vector2(0.5, 0.5))
				st.add_vertex(v)
		var mesh := st.commit()
		var mt := StandardMaterial3D.new()
		mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mt.albedo_color = Color.html(L[3])
		mt.disable_receive_shadows = true
		hill_mats.append(mt)
		var mi := MeshInstance3D.new()
		mi.mesh = mesh
		mi.material_override = mt
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
		li += 1
	cloud_mat = ShaderMaterial.new()
	cloud_mat.shader = CLOUD
	cloud_mat.set_shader_parameter("tex", Pix.cloud_atlas())
	var rng := RandomNumberGenerator.new()
	rng.seed = 3
	var clouds := Node3D.new()
	clouds.name = "Clouds"
	add_child(clouds)
	for i in 7:
		var q := QuadMesh.new()
		var s := rng.randf_range(0.18, 0.3)
		q.size = Vector2(128.0, 64.0) * s
		var arr := q.get_mesh_arrays()
		var uvs: PackedVector2Array = arr[Mesh.ARRAY_TEX_UV]
		var cell := i % 3
		for k in uvs.size():
			uvs[k].x = (uvs[k].x + cell) / 3.0
		arr[Mesh.ARRAY_TEX_UV] = uvs
		var am := ArrayMesh.new()
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		var mi := MeshInstance3D.new()
		mi.mesh = am
		mi.material_override = cloud_mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.position = Vector3(rng.randf_range(-10.0, 80.0), rng.randf_range(-10.0, -5.0), rng.randf_range(-120.0, -82.0))
		clouds.add_child(mi)


# ---------------------------------------------------------------- particles

func _smoke_at(p: Vector3) -> void:
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.15
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 12.0
	pm.initial_velocity_min = 0.3
	pm.initial_velocity_max = 0.45
	pm.gravity = Vector3(0.6, 0.04, 0.25)
	pm.damping_min = 0.1
	pm.damping_max = 0.2
	pm.scale_min = 0.55
	pm.scale_max = 0.85
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.35))
	sc.add_point(Vector2(1, 2.6))
	var sct := CurveTexture.new()
	sct.curve = sc
	pm.scale_curve = sct
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0.0))
	g.set_color(1, Color(1, 1, 1, 0.0))
	g.add_point(0.08, Color(1, 1, 1, 0.9))
	g.add_point(0.5, Color(0.95, 0.95, 1.0, 0.6))
	var gt := GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	pm.angle_min = -180.0
	pm.angle_max = 180.0
	pm.angular_velocity_min = -15.0
	pm.angular_velocity_max = 15.0
	var q := QuadMesh.new()
	q.size = Vector2(1.2, 1.2)
	var mt := StandardMaterial3D.new()
	mt.albedo_texture = _puff()
	mt.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.vertex_color_use_as_albedo = true
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mt.albedo_color = Color(0.92, 0.9, 0.92)
	mt.backlight_enabled = true
	mt.backlight = Color(0.5, 0.45, 0.4)
	mt.disable_receive_shadows = false
	q.material = mt
	var gp := GPUParticles3D.new()
	gp.amount = 32
	gp.lifetime = 7.0
	gp.preprocess = 7.0
	gp.process_material = pm
	gp.draw_pass_1 = q
	gp.position = p
	gp.visibility_aabb = AABB(Vector3(-8, -2, -8), Vector3(16, 14, 16))
	gp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(gp)
	smoke.append(gp)


var _puff_tex: ImageTexture
func _puff() -> ImageTexture:
	if _puff_tex == null:
		_puff_tex = Pix.puff_image()
	return _puff_tex


func _leaves_at(center: Vector3, extent: Vector3, amount: int) -> void:
	var pm := ShaderMaterial.new()
	pm.shader = LEAVES
	pm.set_shader_parameter("box_center", center)
	pm.set_shader_parameter("box_extent", extent)
	pm.set_shader_parameter("leaf_scale", 1.0)
	var q := QuadMesh.new()
	q.size = Vector2(6.0, 6.0) / TEXEL
	var dm := ShaderMaterial.new()
	dm.shader = LEAFDRAW
	dm.set_shader_parameter("tex", Pix.leaf_particles())
	q.material = dm
	var gp := GPUParticles3D.new()
	gp.amount = amount
	gp.lifetime = 16.0
	gp.preprocess = 16.0
	gp.process_material = pm
	gp.draw_pass_1 = q
	gp.visibility_aabb = AABB(Vector3(-60, -20, -40), Vector3(120, 40, 80))
	add_child(gp)
	leaves.append(gp)


func _particles() -> void:
	# dust motes / pollen: lit only, so they glitter in the sun shafts and vanish in shade
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(11, 4.0, 6.5)
	pm.gravity = Vector3(0.05, 0.02, 0)
	pm.initial_velocity_min = 0.02
	pm.initial_velocity_max = 0.1
	pm.direction = Vector3(1, 0.2, 0)
	pm.spread = 180.0
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.4
	pm.turbulence_noise_speed_random = 0.2
	pm.turbulence_noise_scale = 3.0
	pm.scale_min = 0.6
	pm.scale_max = 1.4
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0))
	g.set_color(1, Color(1, 1, 1, 0))
	g.add_point(0.2, Color(1, 1, 1, 1))
	g.add_point(0.8, Color(1, 1, 1, 1))
	var gt := GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	var q := QuadMesh.new()
	q.size = Vector2(2.0, 2.0) / TEXEL
	var mt := StandardMaterial3D.new()
	mt.albedo_color = Color(1.0, 0.9, 0.7)
	mt.vertex_color_use_as_albedo = true
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mt.backlight_enabled = true
	mt.backlight = Color(1.0, 0.85, 0.6)
	q.material = mt
	dust = GPUParticles3D.new()
	dust.amount = 280
	dust.lifetime = 12.0
	dust.preprocess = 12.0
	dust.process_material = pm
	dust.draw_pass_1 = q
	dust.position = Vector3(-2.0, 5.5, -12.0) # inside the shaft volume so motes glitter in the blades
	dust.visibility_aabb = AABB(Vector3(-20, -6, -12), Vector3(40, 14, 24))
	dust.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(dust)
	# fireflies: unshaded glowing dots, blink via colour ramp; amount_ratio scales with night
	var fm := ParticleProcessMaterial.new()
	fm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	fm.emission_box_extents = Vector3(17, 1.4, 9)
	fm.gravity = Vector3.ZERO
	fm.initial_velocity_min = 0.05
	fm.initial_velocity_max = 0.25
	fm.spread = 180.0
	fm.turbulence_enabled = true
	fm.turbulence_noise_strength = 1.2
	fm.turbulence_noise_scale = 4.0
	var fg := Gradient.new()
	fg.set_color(0, Color(0, 0, 0, 0))
	fg.set_color(1, Color(0, 0, 0, 0))
	fg.add_point(0.3, Color(1, 1, 1, 1))
	fg.add_point(0.45, Color(0.2, 0.2, 0.2, 0.2))
	fg.add_point(0.6, Color(1, 1, 1, 1))
	var fgt := GradientTexture1D.new()
	fgt.gradient = fg
	fm.color_ramp = fgt
	var fq := QuadMesh.new()
	fq.size = Vector2(0.07, 0.07)
	var fmt := StandardMaterial3D.new()
	fmt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmt.albedo_texture = Pix.dot_image()
	fmt.albedo_color = Color(0.85, 1.0, 0.45) * 4.0
	fmt.vertex_color_use_as_albedo = true
	fmt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fmt.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fmt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	fq.material = fmt
	fireflies = GPUParticles3D.new()
	fireflies.amount = 140
	fireflies.lifetime = 6.0
	fireflies.preprocess = 6.0
	fireflies.process_material = fm
	fireflies.draw_pass_1 = fq
	fireflies.position = Vector3(-3, 1.2, 2)
	fireflies.visibility_aabb = AABB(Vector3(-20, -4, -12), Vector3(40, 10, 24))
	fireflies.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(fireflies)
	# cascade splash
	var sm := ParticleProcessMaterial.new()
	sm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	sm.emission_box_extents = Vector3(0.8, 0.05, 0.1)
	sm.direction = Vector3(0, 1, 0.6)
	sm.spread = 35.0
	sm.initial_velocity_min = 0.6
	sm.initial_velocity_max = 1.4
	sm.gravity = Vector3(0, -6, 0)
	var sq := QuadMesh.new()
	sq.size = Vector2(2.0, 2.0) / TEXEL
	var smt := StandardMaterial3D.new()
	smt.albedo_color = Color(0.9, 0.95, 1.0)
	smt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	smt.roughness = 0.2
	sq.material = smt
	var sp := GPUParticles3D.new()
	sp.amount = 60
	sp.lifetime = 0.6
	sp.process_material = sm
	sp.draw_pass_1 = sq
	sp.position = Vector3(-4.0, WATER_Y + 0.02, -4.0)
	sp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sp)
	# rain (toggle R): streaks in a world-fixed volume around the focus
	var rm := ParticleProcessMaterial.new()
	rm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	rm.emission_box_extents = Vector3(26, 0.5, 16)
	rm.direction = Vector3(0.15, -1, 0.05)
	rm.spread = 2.0
	rm.initial_velocity_min = 16.0
	rm.initial_velocity_max = 19.0
	rm.gravity = Vector3(0, -4, 0)
	var rq := QuadMesh.new()
	rq.size = Vector2(1.0 / TEXEL, 0.55)
	var rmt := StandardMaterial3D.new()
	rmt.albedo_color = Color(0.75, 0.8, 0.9, 0.35)
	rmt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmt.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	rmt.roughness = 0.1
	rmt.backlight_enabled = true
	rmt.backlight = Color(0.5, 0.5, 0.5)
	rq.material = rmt
	rain_fx = GPUParticles3D.new()
	rain_fx.amount = 9000
	rain_fx.lifetime = 1.3
	rain_fx.process_material = rm
	rain_fx.draw_pass_1 = rq
	rain_fx.position = Vector3(0, 16, -2)
	rain_fx.visibility_aabb = AABB(Vector3(-30, -30, -20), Vector3(60, 34, 40))
	rain_fx.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	rain_fx.emitting = false
	add_child(rain_fx)
