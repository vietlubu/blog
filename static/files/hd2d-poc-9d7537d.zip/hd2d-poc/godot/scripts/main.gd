extends Node3D
## Windferry Hamlet bootstrap: camera, sun/moon, environment + volumetrics, planar water reflection,
## post pass, presets (golden hour <-> blue hour, rain), controls, HUD, capture mode and FPS log.

const World := preload("res://scripts/world.gd")
const Life := preload("res://scripts/life.gd")
const SKY := preload("res://shaders/sky.gdshader")
const POST := preload("res://shaders/post.gdshader")
const FOG := preload("res://shaders/fog.gdshader")
const TiltShift := preload("res://scripts/tiltshift.gd")

const FOCUS := Vector3(0.0, 2.9, -2.0)
const DIST := 40.0
const PITCH := 17.0
const FOV := 21.0


var cam_base_pos: Vector3
var cam_fwd: Vector3
var cam: Camera3D
var env: Environment
var refl_env: Environment
var attrs: CameraAttributesPractical
var tilt: CompositorEffect
var sun: DirectionalLight3D
var sky_mat: ShaderMaterial
var world: Node3D
var life: Node3D
var refl_vp: SubViewport
var refl_cam: Camera3D
var post_mat: ShaderMaterial
var hud: Label
var toast: Label
var haze_mat: ShaderMaterial
var mist_mat: ShaderMaterial

var night := 0.0
var night_target := 0.0
var rain := 0.0
var rain_target := 0.0
var t := 0.0
var pan := 0.0
var zoom := 0.0
var dragging := false
var hud_t := 0.0
var hud_on := true
var toast_t := 0.0
var fog_on := true
var dof_on := true
var bloom_on := true
var high_q := false # default "balanced"; Q or --high switches to the screenshot tier
var shot_path := ""
var shot_delay := 4.0
var shot_taken := false
var bench := false
var fps_next := 10.0


func _parse_args() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shot="):
			shot_path = a.substr(7)
		elif a.begins_with("--shot-delay="):
			shot_delay = a.substr(13).to_float()
		elif a == "--preset=night":
			night = 1.0
			night_target = 1.0
		elif a == "--rain":
			rain = 1.0
			rain_target = 1.0
		elif a == "--high":
			high_q = true
		elif a == "--bench":
			bench = true


func _ready() -> void:
	_parse_args()
	cam_fwd = Basis(Vector3.RIGHT, deg_to_rad(-PITCH)) * Vector3.FORWARD
	cam_base_pos = FOCUS - cam_fwd * DIST
	_environment()
	_camera()
	_sun()
	world = World.new()
	world.name = "World"
	add_child(world)
	world.build(cam_fwd, cam_base_pos)
	life = Life.new()
	life.name = "Life"
	add_child(life)
	life.setup(world, cam)
	_reflection()
	_post_and_hud()
	_apply()
	_set_quality(high_q)
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--scale="): # override the 3D render scale (MetalFX spatial), e.g. --scale=0.75
			get_viewport().scaling_3d_mode = Viewport.SCALING_3D_MODE_METALFX_SPATIAL
			get_viewport().scaling_3d_scale = a.substr(8).to_float()
		elif a.begins_with("--hide="): # diagnostics: hide world nodes by name, e.g. --hide=Shafts,Grass
			for nm in a.substr(7).split(","):
				world.get_node(nm).visible = false
		elif a == "--nodof":
			tilt.dof_enabled = false
		elif a == "--novol":
			env.volumetric_fog_enabled = false


func _environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = SKY
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_128
	sky.process_mode = Sky.PROCESS_MODE_AUTOMATIC # static sky shader: radiance only rebuilt on preset change
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.ssao_enabled = true
	env.ssao_radius = 1.4
	env.ssao_intensity = 1.8
	env.ssao_power = 1.4
	env.glow_enabled = true
	env.glow_normalized = false
	env.glow_intensity = 0.55
	env.glow_strength = 1.0
	env.glow_bloom = 0.04
	env.glow_hdr_threshold = 1.0
	env.glow_hdr_scale = 1.8
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	for i in 7:
		env.set_glow_level(i, [0.0, 0.6, 1.0, 1.0, 0.8, 0.5, 0.3][i])
	env.volumetric_fog_enabled = true
	env.volumetric_fog_length = 70.0
	env.volumetric_fog_detail_spread = 1.6
	env.volumetric_fog_anisotropy = 0.45
	env.volumetric_fog_ambient_inject = 0.0 # only lit fog glows: shafts keep their contrast
	env.volumetric_fog_sky_affect = 0.15
	env.volumetric_fog_temporal_reprojection_enabled = true
	env.volumetric_fog_temporal_reprojection_amount = 0.9
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_DEPTH # aerial haze only beyond the focal band
	env.fog_depth_begin = 48.0
	env.fog_depth_end = 240.0
	env.fog_depth_curve = 1.4
	env.fog_aerial_perspective = 0.35
	env.fog_sky_affect = 0.25
	env.fog_sun_scatter = 0.25
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.06
	env.adjustment_saturation = 1.1
	attrs = CameraAttributesPractical.new() # exposure only; DOF is the custom half-res tilt-shift compositor
	tilt = TiltShift.new()
	var we := WorldEnvironment.new()
	we.environment = env
	we.camera_attributes = attrs
	add_child(we)
	# drifting ground haze over the whole diorama + mist hugging the pond
	haze_mat = ShaderMaterial.new()
	haze_mat.shader = FOG
	haze_mat.set_shader_parameter("by_distance", true)
	haze_mat.set_shader_parameter("base_y", 0.0)
	haze_mat.set_shader_parameter("falloff", 0.25)
	haze_mat.set_shader_parameter("wisp", 0.45)
	haze_mat.set_shader_parameter("use_sdf", false)
	var haze := FogVolume.new()
	haze.shape = RenderingServer.FOG_VOLUME_SHAPE_WORLD
	haze.material = haze_mat
	add_child(haze)
	mist_mat = ShaderMaterial.new()
	mist_mat.shader = FOG
	mist_mat.set_shader_parameter("density", 0.1)
	mist_mat.set_shader_parameter("base_y", -0.3)
	mist_mat.set_shader_parameter("falloff", 2.2)
	mist_mat.set_shader_parameter("wisp", 0.8)
	mist_mat.set_shader_parameter("scale", 0.45)
	var mist := FogVolume.new()
	mist.shape = RenderingServer.FOG_VOLUME_SHAPE_ELLIPSOID
	mist.size = Vector3(9.0, 1.6, 6.0)
	mist.position = Vector3(-7.0, -0.2, 4.2)
	mist.material = mist_mat
	add_child(mist)


func _camera() -> void:
	cam = Camera3D.new()
	cam.fov = FOV
	cam.near = 0.5
	cam.far = 700.0
	cam.cull_mask = 0xFFFFF
	add_child(cam)
	cam.position = cam_base_pos
	cam.look_at(FOCUS)
	cam.current = true
	var comp := Compositor.new()
	comp.compositor_effects = [tilt]
	cam.compositor = comp


func _sun() -> void:
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 130.0
	sun.directional_shadow_split_1 = 0.08
	sun.directional_shadow_split_2 = 0.2
	sun.directional_shadow_split_3 = 0.45
	sun.directional_shadow_blend_splits = true
	sun.light_angular_distance = 0.0
	sun.shadow_blur = 1.2
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.2
	add_child(sun)


func _reflection() -> void:
	refl_vp = SubViewport.new()
	refl_vp.name = "Reflection"
	refl_vp.use_hdr_2d = true
	refl_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	refl_vp.positional_shadow_atlas_size = 0
	add_child(refl_vp)
	refl_env = env.duplicate()
	refl_env.volumetric_fog_enabled = false
	refl_env.ssao_enabled = false
	refl_env.glow_enabled = false
	refl_env.adjustment_enabled = false
	refl_env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	refl_env.fog_density = 0.012
	refl_cam = Camera3D.new()
	refl_cam.fov = FOV
	refl_cam.near = 0.5
	refl_cam.far = 700.0
	refl_cam.cull_mask = 1 | 16 # world + hero (hero lives on layer 16 so its contact decal skips it)
	refl_cam.environment = refl_env
	refl_cam.attributes = CameraAttributesPractical.new() # no DOF in the mirror
	refl_vp.add_child(refl_cam)
	refl_cam.current = true
	world.water_mat.set_shader_parameter("reflection_tex", refl_vp.get_texture())
	_resize_reflection()
	get_viewport().size_changed.connect(_resize_reflection)


func _resize_reflection() -> void:
	var s := get_viewport().get_visible_rect().size
	var k := 0.5 if high_q else 0.36
	refl_vp.size = Vector2i(max(64, int(s.x * k)), max(64, int(s.y * k)))


func _post_and_hud() -> void:
	var cl := CanvasLayer.new()
	cl.layer = 1
	add_child(cl)
	var cr := ColorRect.new()
	cr.set_anchors_preset(Control.PRESET_FULL_RECT)
	cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	post_mat = ShaderMaterial.new()
	post_mat.shader = POST
	cr.material = post_mat
	cl.add_child(cr)
	var hl := CanvasLayer.new()
	hl.layer = 2
	add_child(hl)
	hud = Label.new()
	hud.text = "WINDFERRY HAMLET  ·  HD-2D round 1 (Godot)\n1 golden hour   2 blue hour   R rain   F fog   G DOF   B bloom   Q quality   H HUD   P screenshot   drag/wheel: pan/zoom"
	hud.position = Vector2(22, 16)
	hud.add_theme_font_size_override("font_size", 15)
	hud.add_theme_color_override("font_color", Color(1.0, 0.95, 0.85))
	hud.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	hud.add_theme_constant_override("shadow_offset_x", 1)
	hud.add_theme_constant_override("shadow_offset_y", 1)
	hl.add_child(hud)
	toast = Label.new()
	toast.position = Vector2(22, 66)
	toast.add_theme_font_size_override("font_size", 15)
	toast.add_theme_color_override("font_color", Color(1.0, 0.85, 0.55))
	toast.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	toast.modulate.a = 0.0
	hl.add_child(toast)
	if shot_path != "" or OS.get_cmdline_user_args().has("--nohud"):
		hl.visible = false


func _toast(s: String) -> void:
	toast.text = s
	toast_t = 2.0


func _sun_dir(az_deg: float, el_deg: float) -> Vector3:
	var az := deg_to_rad(az_deg)
	var el := deg_to_rad(el_deg)
	return Vector3(cos(el) * sin(az), sin(el), -cos(el) * cos(az))


func _c(a: String, b: String, k: float) -> Color:
	return Color.html(a).lerp(Color.html(b), k)


## All look parameters are a blend of two presets (golden hour / blue hour) plus rain.
func _apply() -> void:
	var n := night
	var r := rain
	RenderingServer.global_shader_parameter_set("night", n)
	RenderingServer.global_shader_parameter_set("rain", r)
	RenderingServer.global_shader_parameter_set("wetness", r)
	RenderingServer.global_shader_parameter_set("wind_strength", 1.0 + r * 0.7)
	var to_light := _sun_dir(-40.0, 27.0).slerp(_sun_dir(-6.0, 20.0), n) # low moon behind the pond -> moon path
	sun.transform = Transform3D(Basis.looking_at(-to_light, Vector3.UP), Vector3.ZERO)
	world.water_mat.set_shader_parameter("sun_dir", to_light)
	life.sun_dir = to_light
	world.water_mat.set_shader_parameter("sun_col", _c("#ffc890", "#b8c8ff", n))
	world.water_mat.set_shader_parameter("glint", lerp(16.0, 5.0, n) * (1.0 - r * 0.8))
	# night keeps the moon glint to a few sparkles: a broad lobe turned the pond into one white blob that bloomed
	world.water_mat.set_shader_parameter("glint_lo", lerp(0.94, 0.995, n))
	sun.light_color = _c("#ffb46e", "#8fa8ff", n)
	sun.light_energy = lerp(4.4, 0.6, n) * (1.0 - r * 0.7)
	sun.light_volumetric_fog_energy = lerp(2.0, 2.0, n)
	env.ambient_light_energy = lerp(0.6, 0.6, n)
	env.ambient_light_sky_contribution = 0.45
	env.ambient_light_color = _c("#6f7fb8", "#2a3a78", n)
	sky_mat.set_shader_parameter("zenith", _c("#5f86c4", "#0a1430", n).lerp(Color.html("#5a6478"), r * 0.6))
	sky_mat.set_shader_parameter("horizon", _c("#ffc48c", "#30406e", n).lerp(Color.html("#8a8e98"), r * 0.6))
	sky_mat.set_shader_parameter("below", _c("#9a8a7a", "#141a30", n))
	sky_mat.set_shader_parameter("sun_glow", _c("#ff8a40", "#3a5aa0", n) * (1.0 - r * 0.7))
	sky_mat.set_shader_parameter("disc", lerp(0.99955, 0.99925, n))
	env.volumetric_fog_density = lerp(0.0, 0.0015, n) + r * 0.0015
	env.volumetric_fog_albedo = _c("#fff0dc", "#a8b8e8", n)
	env.volumetric_fog_emission = _c("#000000", "#06080f", n)
	env.fog_light_color = _c("#d4bfa6", "#1e2a50", n).lerp(Color.html("#7a808c"), r * 0.5)
	env.glow_hdr_threshold = lerp(1.0, 1.3, n)
	env.fog_density = lerp(0.8, 0.9, n)
	haze_mat.set_shader_parameter("albedo", _c("#ffe6c8", "#9cb0e0", n))
	haze_mat.set_shader_parameter("near_density", lerp(0.0015, 0.008, n) + r * 0.004)
	haze_mat.set_shader_parameter("density", lerp(0.022, 0.02, n) + r * 0.01)
	haze_mat.set_shader_parameter("near_d", 36.0)
	haze_mat.set_shader_parameter("far_d", 64.0)
	mist_mat.set_shader_parameter("albedo", _c("#fff4e8", "#b4c4f0", n))
	mist_mat.set_shader_parameter("density", lerp(0.035, 0.12, n) + r * 0.05)
	env.tonemap_exposure = lerp(1.0, 1.15, n)
	for l in world.window_lights:
		l.light_energy = lerp(0.5, 1.2, n)
		l.light_volumetric_fog_energy = lerp(1.0, 2.2, n)
	for l in world.lantern_lights:
		l.light_energy = lerp(1.1, 4.0, n)
		l.light_volumetric_fog_energy = lerp(2.0, 4.5, n)
	for mt in world.glass_mats:
		mt.set_shader_parameter("emissive", lerp(0.45, 1.05, n))
	life.hero.material_override.set_shader_parameter("rim_strength", lerp(0.9, 2.0, n))
	life.hero.material_override.set_shader_parameter("wrap", lerp(0.5, 0.8, n))
	for mt in world.lamp_mats:
		mt.set_shader_parameter("emissive", lerp(2.2, 3.0, n))
	world.fireflies.amount_ratio = clampf((n - 0.3) / 0.7, 0.0, 1.0) * 0.7 * (1.0 - r * 0.8)
	world.shafts.set_shader_parameter("strength", (1.0 - n) * (1.0 - 0.75 * r))
	for s in world.smoke:
		var sm: StandardMaterial3D = s.draw_pass_1.material
		sm.albedo_color = _c("#ebe6eb", "#3a4058", n)
		sm.backlight = _c("#807366", "#000000", n)
	world.dust.amount_ratio = lerp(1.0, 0.25, n) * (1.0 - r * 0.8)
	world.rain_fx.emitting = r > 0.02
	world.rain_fx.amount_ratio = r
	world.cloud_mat.set_shader_parameter("lit", _c("#ffe2bc", "#56689a", n).lerp(Color.html("#b8bcc4"), r * 0.6))
	world.cloud_mat.set_shader_parameter("shade", _c("#b9a0b8", "#222a48", n).lerp(Color.html("#6a7080"), r * 0.6))
	var hills := [["#6f86a0", "#1c2a4a"], ["#8c9ab4", "#253456"], ["#aab4c8", "#2e3e62"]]
	for i in world.hill_mats.size():
		world.hill_mats[i].albedo_color = _c(hills[i][0], hills[i][1], n).lerp(Color.html("#9098a8"), r * 0.5)
	post_mat.set_shader_parameter("shadow_tint", _c("#c8d8ff", "#c8d4ff", n))
	post_mat.set_shader_parameter("high_tint", _c("#fff0dc", "#ffe8cc", n))


## balanced: no MSAA (SMAA), no SSAO, 96x64 froxels, 2 shadow splits, 0.36 mirror at 30 Hz, medium bokeh.
## high: MSAA 2x, 128x96 froxels, 4 splits, 0.5 mirror every frame, high bokeh.
func _set_quality(high: bool) -> void:
	high_q = high
	var vp := get_viewport()
	vp.msaa_3d = Viewport.MSAA_2X if high else Viewport.MSAA_DISABLED
	env.ssao_enabled = high
	vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED if high else Viewport.SCREEN_SPACE_AA_SMAA
	RenderingServer.environment_set_volumetric_fog_volume_size(128 if high else 96, 96 if high else 64)
	tilt.max_coc = 22.0 if high else 18.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if high else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 120.0 if high else 64.0
	RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM if high else RenderingServer.SHADOW_QUALITY_SOFT_VERY_LOW)
	# balanced renders 3D at 0.8 and upscales with MetalFX spatial (pixel edges stay sharp at this ratio)
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR if high else Viewport.SCALING_3D_MODE_METALFX_SPATIAL
	vp.scaling_3d_scale = 1.0 if high else 0.8
	_resize_reflection()


func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo:
		match e.keycode:
			KEY_1:
				night_target = 0.0
				_toast("Golden hour")
			KEY_2:
				night_target = 1.0
				_toast("Blue hour / night")
			KEY_R:
				rain_target = 1.0 - rain_target
				_toast("Rain " + ("on" if rain_target > 0.5 else "off"))
			KEY_F:
				fog_on = not fog_on
				env.volumetric_fog_enabled = fog_on
				_toast("Volumetrics " + ("on" if fog_on else "off"))
			KEY_G:
				dof_on = not dof_on
				tilt.dof_enabled = dof_on
				_toast("Depth of field " + ("on" if dof_on else "off"))
			KEY_B:
				bloom_on = not bloom_on
				env.glow_enabled = bloom_on
				_toast("Bloom " + ("on" if bloom_on else "off"))
			KEY_Q:
				_set_quality(not high_q)
				_toast("Quality: " + ("high" if high_q else "balanced"))
			KEY_H:
				hud_on = not hud_on
			KEY_P:
				_save_shot()
			KEY_ESCAPE:
				get_tree().quit()
		hud_t = 0.0
	elif e is InputEventMouseButton:
		if e.button_index == MOUSE_BUTTON_LEFT:
			dragging = e.pressed
		elif e.button_index == MOUSE_BUTTON_WHEEL_UP and e.pressed:
			zoom = clamp(zoom - 1.5, -10.0, 8.0)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN and e.pressed:
			zoom = clamp(zoom + 1.5, -10.0, 8.0)
	elif e is InputEventMouseMotion and dragging:
		pan = clamp(pan - e.relative.x * 0.02, -9.0, 9.0)


func _save_shot() -> void:
	var dir := ProjectSettings.globalize_path("res://shots")
	DirAccess.make_dir_recursive_absolute(dir)
	var p := "%s/windferry_%s.png" % [dir, Time.get_datetime_string_from_system().replace(":", "-")]
	get_viewport().get_texture().get_image().save_png(p)
	_toast("Saved " + p.get_file())
	print("screenshot: ", p)

## --bench: average real frame rate over seconds 6..16, printed with draw stats, then quit.
var bench_t := 0.0
var bench_n := 0
func _bench(delta: float) -> void:
	if t < 6.0:
		return
	bench_t += delta
	bench_n += 1
	if t >= 16.0:
		print("BENCH %s: %.1f fps avg (%.2f ms)  draws %d  prims %d  at %s" % [" ".join(OS.get_cmdline_user_args()), bench_n / bench_t, bench_t * 1000.0 / bench_n,
			Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME), str(get_viewport().get_visible_rect().size)])
		get_tree().quit()


func _process(delta: float) -> void:
	t += delta
	if bench:
		_bench(delta)
	var nn := move_toward(night, night_target, delta * 0.4)
	var rr := move_toward(rain, rain_target, delta * 0.5)
	if nn != night or rr != rain:
		night = nn
		rain = rr
		_apply()
	# slow breathing drift (parallax) + user pan/zoom; default framing is the money shot
	var right := cam_fwd.cross(Vector3.UP).normalized()
	var drift := right * (sin(t * 0.11) * 0.9 + pan) + Vector3.UP * sin(t * 0.17) * 0.3
	cam.position = cam_base_pos + drift - cam_fwd * zoom
	cam.look_at(FOCUS + right * pan + Vector3(sin(t * 0.07) * 0.15, 0, 0))
	tilt.focus_distance = (life.hero.global_position + Vector3(0, 1, 0) - cam.global_position).dot(-cam.global_basis.z)
	# planar mirror camera
	var b := cam.global_basis
	var mirror := func(v: Vector3) -> Vector3: return Vector3(v.x, -v.y, v.z)
	var p := cam.global_position
	p.y = 2.0 * world.WATER_Y - p.y
	refl_cam.global_transform = Transform3D(Basis(-mirror.call(b.x), mirror.call(b.y), mirror.call(b.z)), p)
	life.tick(delta, 1.0 + rain * 0.7)
	haze_mat.set_shader_parameter("cam_pos", cam.global_position)
	if high_q or Engine.get_process_frames() % 2 == 0:
		refl_vp.render_target_update_mode = SubViewport.UPDATE_ONCE # balanced: 30 Hz mirror is plenty under ripples
	# HUD fade
	hud_t += delta
	hud.modulate.a = (clamp(1.0 - (hud_t - 6.0) / 1.5, 0.0, 1.0) if hud_on else 0.0)
	toast_t -= delta
	toast.modulate.a = clamp(toast_t, 0.0, 1.0)
	# capture mode
	if shot_path != "" and not shot_taken and t >= shot_delay:
		shot_taken = true
		await RenderingServer.frame_post_draw
		var img := get_viewport().get_texture().get_image()
		img.save_png(shot_path)
		print("shot saved: ", shot_path, " ", img.get_size())
		get_tree().quit()
	# FPS log every 10 s in normal runs
	if t >= fps_next:
		fps_next += 10.0
		print("FPS %d at %s (%s quality)" % [Engine.get_frames_per_second(), str(get_viewport().get_visible_rect().size), "high" if high_q else "balanced"])
