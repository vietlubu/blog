# Web track — review #1 (Windferry Hamlet, three.js)

Reviewer: WebReviewer · 2026-11-15 · build reviewed: `web/` working tree as of 23:05 (no commits in repo)

**How I captured it:** I ran `npm install && npm run dev` myself and used Chrome DevTools MCP with the viewport set to
1920×1080 CSS @ DPR 1.333. That gives a **2560×1440 internal** frame at `?q=high`, which is the brief's 1440p target. I hid the
HUD with `H`. The GPU is an Apple M1 Pro (ANGLE Metal). I took every still, crop, sequence and FPS number below myself. All
evidence is in `review/web/review-1/`. Region coordinates are pixels in the 2560×1440 captures unless I say otherwise. The
throwaway scripts in the same folder are `capture_seq.js` (canvas sequence) and `measure_fps.js` (rAF frame-time stats).
**The FPS numbers are contended:** the Godot track shares the GPU.

---

## Verdict

**Not ready for the owner yet. The tech is strong, but the default frame doesn't land "wow" or "unmistakably HD-2D".**

What works:
- The pipeline is real and well built: HDR, shadow-map-gated volumetric shafts, a planar mirror, gather bokeh, a single
  wind field, and clean code.
- Some moments are genuinely good: the shafts through the oak; the rainy night with lantern light streaking across the wet
  cobbles (`09b`, the best frame in the build); and the warm windows.

The default golden-hour frame has five problems:
- **Camera too flat.** It looks at the village almost side-on, with a 12° line of sight where the brief asks for 15–25°.
  The scene collapses into horizontal stripes: a wall of houses, the retaining wall, the path, then a 27 % band of blurred
  meadow.
- **Focus band too narrow.** It is ±2.5 u around the hero, so **the whole village tier, which carries most of the build's
  pixel art, is out of focus.**
- **Milky rose veil.** The volumetric pass supplies about half of the frame's brightness. Shadows lift to magenta instead of
  cool violet, and the top of the frame turns into haze.
- **Canopies are smooth spheres** with salt-and-pepper cells, not pixel clusters.
- **Night is crushed:** median luminance is 4× darker than `town_night`, with tiny light pools.
- **Life is hard to see in stills.** The bird flock flies behind the oak crowns, and the butterflies read as orange blocks.

Next to `town_day` and `town_autumn`, the reference shows a stage you look *down into*: a crisp mid-ground of props, a pond
and houses, with blur only at the extremes. This build shows a soft façade line-up behind a hedge. Most of the fixes are
parameters and layout rather than new tech, so a strong round 2 is realistic.

---

## Orchestrator observations — checked

| # | Observation | Result | Evidence |
|---|---|---|---|
| 1 | Hero ≈ 8 % of frame height, reads small | **Refuted on size.** I projected the sprite's bounding box through the live camera: **12.7 %** (137 / 1080 CSS px = 183 px at 1440p, 2.8 screen px per sprite texel). The `town_day` chibis are about 13.6 % (86/630 px). It does read weakly, but for other reasons: she stands in shade, has a weak rim, and sits boxed between two lanterns (see P1-10). | `02_hero_crop_2x.png`, `15_hero_shadow_rim_nopost_crop_3x.png` |
| 2 | Bottom ~30 % is a uniform blurred green mass | **Confirmed.** It is 27 % of the frame at 16:9 and about 29 % at 16:10. Sharpness with DOF on is 0.26–0.34× of DOF off. Local contrast (48-px block luma σ) is 0.059, against 0.067 (`town_day`) and 0.092 (`town_autumn`). The root cause is the low camera pitch (P0-1), with DOF (P0-2) on top. | `01_golden_full.png` y>1040, `11b_dof_foreground_T0_band.png`, `16_golden_16x10_macbook.jpeg` |
| 3 | Pond is a small sliver bottom-left, reflections barely register | **Confirmed.** About 3 % of the frame area (x 0–975, y 1075–1230), and its near half sits under foreground blur. The mirror itself works: windows and the bridge reflect with ripple distortion. | `04_pond_golden_crop_2x.png` |
| 4 | Houses read as flat textured boxes | **Confirmed in code and image.** Façades are `PlaneGeometry` with timber, windows and shutters *painted* on. Roofs are 0.16 u (5-texel) slabs with a 0.4/0.3 u overhang. There are no fascia boards, bargeboards, sills, window recesses or roof-edge silhouette. The thatch uses the same tiled slab, so it reads as shingles. | `12_houses_T2_crop.png`, `08_golden_dof_fog_off.png`, `world.js:503-543` |
| 5 | Canopies are soft green blobs, not crisp pixel clusters | **Confirmed.** Silhouettes are smooth icosphere outlines. Each cell's tone comes from a per-cell hash, which gives salt-and-pepper noise rather than clusters. Far DOF adds a circle of confusion of about 12 px on T3. The near branch shows triangle facets. | `11c_canopy_dof_off_crop_2x.png`, `11d_branch_dof_off_crop_2x.png`, `11a_dof_background_T3_canopy.png` |
| 6 | Night is too dark overall, tiny light pools | **Confirmed.** Median luminance is 0.028 against 0.109 in `town_night`; p90 is 0.21 against 0.30. Only 5 lights actually light surfaces (3 path lanterns and 2 window point lights). The house lanterns glow but light nothing. | `03_night_full.png`, `21_cmp_night_vs_town_night.jpg` |
| 7 | Sky/clouds barely visible | **Confirmed.** No cloud is visible in any capture. Top-quarter local contrast is 0.041 against about 0.09 in the references. The studio kite clips the top edge (≈1920, 25–96). Tiered framing is *meant* to limit sky, so the fix is designed sky windows, not more sky (P1-11). | `01_golden_full.png` y<360, `07_golden_dof_off.png` |
| 8 | Little visible animal life in stills | **Confirmed.** I captured the flock at mid-pass (cycle 10.4 s): it flies at y≈9, z=−20, behind the oak crowns, and no bird is visible. Butterflies are about 28 px and read as two orange rectangles. The roof bird is a speck in far blur. | `13_flock_pass.png`, `13b_flock_pass_crop.png`, `17_butterfly_crop_4x.png` |

Findings that were not on the list: the village tier is out of focus (P0-2), the golden air veil and magenta shadows (P0-3),
the camera pitch below the brief's range (P0-1), the hero standing in shade at golden hour (P1-10), heavy chromatic aberration
at the corners (P2-13), and `q=high` not holding 60 fps (P1-12).

---

## Scores (1–10)

| Category | Score | Why |
|---|---|---|
| Composition & tiered depth | **4** | The tiers exist (wall → terrace → hill), but the 12° line of sight flattens them into horizontal stripes. The frame is symmetric around the centre, the meadow band is 27 %, and the pond is a sliver. Compare `20_cmp_golden_vs_town_day.jpg`. |
| Pixel-art fidelity & texel consistency | **6** | Texel density is consistently 32 tpu, sampling is nearest, UVs are world-space, and the hero is crisp 1:1 (`02`). But DOF blurs the T2 houses (0.36–0.55× sharpness), canopy cells are smeared and diagonal, and the branch shows icosphere facets. |
| Lighting & volumetrics | **6** | Real shadowed shafts through the oak (`01`, x 400–1220, y 130–770) and lantern scattering. But the air veil carries about 50 % of the frame's luminance, and the hero stands in shade next to a sunlit patch. |
| Reflections | **6** | The planar mirror with ripple distortion works, and the wet cobbles at night are excellent (`09b`). The pond is too small and hidden to show it off (`04`). |
| DOF & camera | **4** | The narrow 22° FOV, lens shift and breathing drift are right. But the focus band is ±2.5 u, the foreground is mush, the pitch is below the brief's range, and corner CA is strong. |
| Life / animation | **5** | A lot moves: one wind field drives grass, canopies, smoke, rain, dust, fireflies, the wheel, the windmill and the kite. In stills, though, the life is invisible or illegible (flock occluded, butterflies are blocks). |
| Palette & grading | **5** | Shadows are lifted and magenta (0.27, 0.13, 0.20) where the brief asks for cool violet. A rose veil sits over the day; the night is crushed navy. |
| Character integration (2-head, lit by scene) | **6** | Correct size (12.7 % of frame height, close to the reference). She is lit by the lanterns at night, casts a shadow and has a contact shadow. In golden hour she is in shade, her rim is faint, and two lanterns crowd her. |
| Own HD-2D identity | **5** | The README's identity bullets are good, but on screen it reads as a generic cozy village under a rose filter. The kite signature is clipped, and "Windferry" isn't visible anywhere. |
| Performance / stability | **6** | 0 console errors or warnings. `med` runs at 94–96 fps (1080p internal). `high` (1440p) ran at **37–61 fps with p95 24–42 ms** across two runs (contended). |
| Code quality | **7** | A clean, readable pipeline with URL quality overrides and review hooks. Some fragile couplings (P2-14). |

---

## Change requests

### P0 — must fix before the owner sees it

**P0-1 · Camera pitch and composition: look *down into* the diorama, not at a façade line-up**
- *Evidence:* `01_golden_full.png` is horizontal bands: houses y 200–810, retaining wall y≈825–900 across 100 % of the width,
  path y≈990–1040, then meadow from y 1040 to 1440. `20_cmp_golden_vs_town_day.jpg` and `22_cmp_golden_vs_town_autumn.jpg`
  show the difference. `16_golden_16x10_macbook.jpeg` shows that a MacBook 16:10 window makes the meadow band even bigger.
- *Wrong vs reference:* `town_day` and `town_autumn` look down at roughly 25–30°. The ground plane becomes the stage: the
  path is a diagonal, the pond sits in the lower-middle, and props cluster at different depths. Here the ground is foreshortened
  to slivers, so the T0 grass cards are seen side-on and stack into a wall. `main.js:55` sets `sight: 12°, pitch: 13°`, below
  the brief's "pitch ~15–25° down".
- *Fix:*
  - Set `rig.sight ≈ 22°`, `rig.pitch ≈ 23°`, `dist ≈ 38`, `heroNdc ≈ −0.2`. Keep FOV at 22°.
  - Add a slight yaw (`rig.yaw ≈ −6…−8°`) so the wall and path recede left→right instead of running parallel to the frame.
  - Step the retaining wall back 1–1.5 u at the stairs to break its 100 %-width line.
  - Stagger the houses in depth and height: bring the thatched cottage forward about 2 u, push the slate house back, and vary
    the plinths. Octopath's hina-dan rule is to stage the back higher so a tilted camera sees dense content (4Gamer report:
    <https://business.4gamer.net/article/1810/18101801/>).
  - Composition rule: foreground frames, the centre of interest dominates, and the background recedes. Leading lines (path,
    stream, fence) should point at the hero
    (<https://www.gamedeveloper.com/design/composition-in-level-design>).
- *Acceptance:*
  - The ground plane (path, pond, T1 props) fills 35–45 % of the frame height.
  - The foreground band is ≤ 15 %.
  - No single horizontal edge spans more than 70 % of the frame width.
  - Re-check at 16:9 and 16:10.

**P0-2 · Widen the focal region: the whole T1 + T2 village must be crisp; blur only T0 and T3+**
- *Evidence:*
  - Sharpness (Laplacian) of the DOF-on frame relative to DOF-off, by image row: **0.36–0.55** across the houses band
    (rows 25–55 %) and ≈0.95 only around the hero (rows 65–75 %).
  - Compare `01_golden_full.png` with `07_golden_dof_off.png`.
  - In `14_texel_crawl_roof_a_vs_b_4x.png` the clay-roof tiles are smeared.
  - `12_houses_T2_crop.png`: windows, timbers and shutters are all soft.
- *Wrong vs reference:* in `town_day` and `town_autumn` the houses, shrine and props are crisp, and only the extreme
  foreground and the far trees blur. The brief says "keep the focal band crisp" and puts the pixel art at the focal plane. Here
  `coc()` in `shaders.js` is symmetric, with `focusRange = 2.5`. House B, about 12 u behind the hero, gets a radius of about
  8 px at 1440p.
- *Fix:* replace the symmetric range with a **flat focal region plus near/far transition regions**. This is UE4's legacy
  Bokeh DOF model (Focal Distance, Focal Region, Near/Far Transition Region), which Octopath shipped on
  (<https://miyahuji111.hatenablog.com/entry/2015/11/13/141118>,
  <https://docs.unrealengine.com/4.26/en-US/RenderingAndGraphics/PostProcessEffects/DepthOfField>).
  ```glsl
  // uFocus = hero distance; region [uFocus - uNearIn, uFocus + uFarIn] is sharp
  float coc(float lin) {
    float n = smoothstep(uFocus - uNearIn, uFocus - uNearIn - uNearRamp, lin) * uNearK;
    float f = smoothstep(uFocus + uFarIn,  uFocus + uFarIn  + uFarRamp,  lin) * uFarK;
    return clamp(f - n, -1.0, 1.0) * uMaxCoc;
  }
  ```
  - Starting values: `uNearIn 4`, `uNearRamp 10`, `uFarIn 14` (covers the wall, the terrace and all three T2 houses),
    `uFarRamp 30`, `nearK 1.0`, `farK 0.85`, `maxCoc 11` (1080 baseline).
  - Re-tune after the P0-1 camera change.
- *Acceptance:* sharpness ratio ≥ 0.85 for T1–T2 rows and ≤ 0.4 for T0 and T3+.

**P0-3 · Golden hour: remove the milky magenta veil; let the shafts read against clean, cool shadows**
- *Evidence:*
  - **Mean frame RGB is (0.47, 0.37, 0.27) with fog on and (0.18, 0.19, 0.11) with fog and DOF off**
    (`01` vs `08_golden_dof_fog_off.png`). The volumetric pass supplies about half the image and fakes the ambient light.
  - The darkest 20 % of pixels average **(0.27, 0.13, 0.20)**: lifted and magenta. `town_day` gives (0.14, 0.19, 0.16) and
    `town_autumn` (0.14, 0.14, 0.11).
  - Top-quarter local contrast is **0.041** against **0.090 / 0.087** in the references (`01`, y<360).
- *Wrong vs reference:* the brief asks for "cool blue-violet ambient in shadow". In the LONG GONE sheet (panel 4, pink
  sunset), the warm haze sits *behind* dark, readable silhouettes. Here the haze sits in front of everything, including the
  focal band, so the image goes flat and rose-tinted.
- *Fix (`main.js` `PRESETS.golden`, `pipeline.js`):*
  - Surfaces carry their own ambient: `hemiI` 1.05→~1.6, `fillI` 0.55→0.8 with `fillCol` about (0.62, 0.72, 1.0). Tune
    `exposure` so the frame mean with fog off is about 0.30.
  - Thin the air: `fogDen` 0.007→~0.004, local volume `vol` 0.034→~0.014.
  - Raise the phase asymmetry `g` from 0.62 to about 0.78 so in-scattering concentrates toward the sun and the shadowed air
    between shafts goes darker.
  - Fade density in from about focus+5 to focus+25 (multiply by `smoothstep`) so the focal band isn't veiled.
  - Grade: `shadowTint` toward blue, about (−0.02, −0.005, 0.04).
  - Reference for energy-conserving in-scattering: Hillaire / Frostbite
    (<https://www.ea.com/frostbite/news/physically-based-unified-volumetric-rendering-in-frostbite>).
- *Acceptance:*
  - The darkest-20 % average has B ≥ R, with luminance 0.12–0.16.
  - Top-quarter block σ ≥ 0.07.
  - Shafts stay visible in `01`'s oak region.

**P0-4 · Night: "feel dark, don't be dark"; bigger light pools and a warm focal light near the hero**
- *Evidence:*
  - `03_night_full.png`: median luminance **0.028** against **0.109** in `town_night` (mean 0.083 against 0.147).
  - Roofs, canopies and sky merge into navy (y 0–580).
  - The lantern pools are about 2 u wide (`03b_night_hero_crop_2x.png`).
  - Side by side: `21_cmp_night_vs_town_night.jpg`.
  - Code: only 3 path lanterns (`world.js:671`, 12 cd, range 9, decay 2) and 2 window lights (`main.js:116` `slice(0,2)`)
    light any surface.
- *Wrong vs reference:* `town_night` keeps the blue-lit trees and sky readable. The campfire throws a big warm pool that
  anchors the characters, and every window and lantern spills onto the walls and ground.
- *Fix (`PRESETS.night`):*
  - Moon key: `sunI` 1.5→~3.5, `sunCol` about (0.55, 0.68, 1.0), so roof planes and canopy tops get a cold rim against a
    lighter sky band.
  - `hemiGround` 0.06→0.12; `exposure` 1.35→~1.7.
  - Lanterns: `lanternI` about 35, distance 12, decay 1.5 (stylised falloff).
  - Add a **warm focal light near the hero**: a small brazier or campfire by the bench, with flicker, embers and smoke lit
    from below. This is the analogue of the campfire in `town_night`.
  - Replace the missing window lights with **cheap additive light-pool decals**: warm radial quads on the ground and walls
    under every window and hanging lantern, with intensity driven by `uNight`. That gives large pools at zero lighting cost.
  - Show the moon and a blue-hour gradient in a sky window (P1-11).
  - Rule of thumb from <https://book.leveldesignbook.com/process/lighting/darkness>: keep exposure up, separate silhouettes
    from a brighter horizon with rim light, and let only *some* shadows reach black.
- *Acceptance:* median luminance ≥ 0.08 and p90 ≥ 0.30. Roof and tree silhouettes are readable against the sky.

**P0-5 · Canopies: build real pixel clusters (clustered tones, stepped silhouettes), not noisy spheres**
- *Evidence:*
  - `11c_canopy_dof_off_crop_2x.png` (DOF off): cell size is 1/11 u, about 6 px at T3. Tone comes from a per-cell hash, so
    it reads as noise. The outlines are smooth circles.
  - `11d_branch_dof_off_crop_2x.png`: the top-left branch shows icosphere triangle facets.
  - `11a` / `01` top: with DOF on, everything becomes soft green balls.
  - Code: `foliage.js:224-268`.
- *Wrong vs reference:* `town_day` and `town_autumn` canopies are chunky voxel or pixel clusters, each about 6–10 texels.
  Each has a lit top cap, a mid band, dark undersides and a stair-stepped outline against the sky. That is the owner's
  signature reference element.
- *Fix (pick one):*
  - **(a) Voxel clumps.** `InstancedMesh` cubes with 0.25–0.3 u edges (8–10 texels), Poisson-placed in the clump's outer
    shell. Each face carries an 8×8 leaf pixel tile.
    - Tone: a 4-step ramp of `dot(sun, clumpNormal)` plus depth-in-clump AO plus *low-frequency* noise, so same-tone cells
      group into clusters.
    - Sway the instances with the wind field in the vertex shader.
    - Cubes cast real shadows, so the shafts survive.
  - **(b) Sphere-of-billboards.** Hand-pixel leaf-cluster sprites (16–24 px) on a jagged sphere, lit with the sphere normal,
    cel-stepped with a rim. A still proxy casts the shadow so the shadows don't flicker.
    - <https://wrightfunctions.com/misc/pixel-art/> (section 2, "Trees are spheres made of billboards")
    - <https://www.youtube.com/watch?v=pslJg8vpeHo> (jagged-sphere shadow casters plus leaf sprites)
    - <https://www.davidhol.land/articles/3d-pixel-art-rendering>
    - three.js version: <https://douges.dev/blog/threejs-trees-1>
  - Either way, replace the corner-branch icosphere with a hand-pixel leaf-card cluster so its bokeh reads as leaves.
- *Acceptance:* with DOF off, each canopy shows 3–4 tone bands in readable clusters, a stepped silhouette, and no
  triangle facets.

**P0-6 · Make the life readable in a still frame (birds, butterflies)**
- *Evidence:*
  - `13_flock_pass.png` / `13b_flock_pass_crop.png`: flock captured at mid-pass, no bird visible. It flies at y≈8.6–9.8,
    z=−20, which projects to NDC y≈0.77, behind the oak crowns (`life.js:288-296`).
  - `17_butterfly_crop_4x.png`: the butterflies read as two orange rectangles.
  - The roof hopper is a speck in far blur.
- *Wrong vs reference:* the brief's hard requirement #1 is birds and butterflies, and the owner judges "liveliness".
- *Fix:*
  - Route the flock through *visible* air: in front of the T2 roofs and below the canopy line (y≈6–7, z≈−4…−8, or a
    screen-space band at NDC y 0.35–0.6). Pass every 12–15 s, not every 26 s. Scale it to about 1 u, use a banking path,
    and give it loose boids spacing (<https://www.red3d.com/cwr/boids/>).
  - Land 3–4 birds on the retaining wall or fence near the hero, and have them take off on wind gusts.
  - Butterflies: about 12, scale about 0.7, with a readable sprite (body, 2-frame wing silhouette, a pale or yellow
    contrast colour against the green). Put 3 of them within 3 u of the hero, below 1.5 u height.
  - Optional: two ducks on the pond.
- *Acceptance:* every 5-second window of the default view shows at least 2 creatures that read as creatures at 1440p.

### P1

**P1-7 · Design the foreground (T0) rather than carpeting it**
- *Evidence:* `11b_dof_foreground_T0_band.png` and `01` y>1040 show uniform olive-brown mush (numbers in observation 2).
- *Wrong vs reference:* the `town_day` / `town_autumn` foregrounds use a few *shapes*: blocky bushes, a log, saturated red
  flower clusters, and semi-sharp grass blades with gaps that show the ground.
- *Fix (after P0-1):*
  - Halve the T0 card count and vary heights so the ground shows through.
  - Place 3–4 designed bokeh "actors": a weathered fence post with a diagonal rail entering from the lower right, a big
    blocky shrub at the lower left, and backlit seed heads or foxtails whose sun-rim exceeds the bloom threshold, so they
    turn into round bokeh highlights.
  - Keep one saturated flower hue per clump.
  - Lower `nearK` to about 1.4, so the meadow within about 6 u in front of the hero stays readable.

**P1-8 · Make the pond a showpiece in the focal band**
- *Evidence:* `04_pond_golden_crop_2x.png`, `04b_pond_night_crop_2x.png`, and `01` at x 0–975, y 1075–1230 (about 3 % of
  the frame, half of it under foreground blur).
- *Wrong vs reference:* the `town_autumn` pond takes about 28 % of the width × 14 % of the height in the lower-middle. It is
  crisp, reflects a bright sky, and has lily pads and reeds framing it.
- *Fix:*
  - Move `POND` to about x −5…−1, z 3–6 (lower-left third, inside the focal region), and raise `rz` from 3.3 to about 4.5.
  - Keep the far bank low so the mirror shows the bridge, a house, the sky gradient and a cloud.
  - With the higher pitch, Fresnel drops, so boost the sky term in the reflection.
  - Keep the pixel sun-glints in the sunlit areas, and add crisp pixel lily flowers.

**P1-9 · Houses: give them 3D trim, eaves, roof silhouettes and wear**
- *Evidence:* `12_houses_T2_crop.png`, `08_golden_dof_fog_off.png` (y 200–810). Code: `world.js:511-543`.
- *Wrong vs reference:* the `town_autumn` half-timbered house has protruding beams, a deep red-tile eave with a stepped
  edge, and moss patches. The blue slate roof has strong per-course value bands and a thick edge.
- *Fix (all at 32 tpu):*
  - Eaves 0.6–0.8 u, with visible rafter tails and a 2-texel dark under-eave band.
  - Bargeboards on the gables.
  - Timber frame as 3D boxes protruding 2 texels, so the low sun gives a lit edge plus a shadow line.
  - Windows recessed 0.1 u, with a sill and lintel; shutters as separate boxes, slightly ajar.
  - Stepped tile-course roof edge (alpha-cut sawtooth eave line) and ridge caps.
  - Thatch as a 0.45 u rounded eave roll with a layered fringe card.
  - Top-projected moss on the slate (world-normal.y, Octopath's "top-facing projection"); streaks under the windows; a
    porch or lean-to on one house.
  - Pixel-art reading of eaves and trim: SLYNYRD
    <https://www.slynyrd.com/blog/2018/4/12/pixelblog-4-graphical-projection-part-2>.

**P1-10 · Stage the hero: put her in the light, rim her, give her room**
- *Evidence:*
  - `15_hero_shadow_rim_nopost_crop_3x.png` (fog and DOF off): she stands in shade, and the sunlit cobbles start about
    1–1.5 u to her right.
  - `02_hero_crop_2x.png`: path lanterns stand 2.7 u to her left and 1.9 u to her right (`world.js:735-736`, hero x 0.9).
    The lamp heads are the brightest things next to her face.
  - The rim is a faint 1–2 px orange on her hair.
- *Wrong vs reference:* the `town_*` heroes stand in open space next to the brightest light source. The Last Night tribute
  separates its sprites with crisp rims.
- *Fix:*
  - Move `HERO.x` to about 2.4, into the sunlit patch, or rotate `sunDir` so a shaft between the houses lands on her.
    If she moves, also move the lantern at x 2.75 out to about x 5, so she isn't standing under it.
  - Raise `uRimK` about 2×, and compute the rim from the sprite's alpha edge in texel space so it is a crisp 1-texel line.
  - Make the long golden-hour cast shadow visible on the path toward the camera.
  - Afterwards keep the lanterns asymmetric (one at ≥ 2.5 u, the other ≥ 4 u away), so she isn't framed symmetrically.
  - Optional: a 1-px breathe or blink idle.
  - Keep her at ≥ 12 % of frame height after P0-1.

**P1-11 · Top band and identity: sky windows, readable clouds, kite in frame, "wind" as the signature**
- *Evidence:*
  - `01` / `07`, y<360: no cloud visible anywhere; contrast numbers in observation 7.
  - The kite is clipped at the top edge (≈1920, 25–96).
  - The identity bullets in `web/README.md` don't show on screen.
- *Wrong vs reference:* LONG GONE uses painterly cloud skies as a light source. The brief asks for "own identity", and the
  scene is named *Windferry*.
- *Fix:*
  - Open 1–2 sky windows between the crowns (thin the oak's top-left).
  - Draw pixel cumulus with silver-lined rims, since the sun is behind them.
  - Fly the kite fully inside a sky window, with its string and tail visible.
  - Make the wind visible as the signature: bunting or pennants strung across the stream, pinwheels on the fence, and
    dandelion seeds drifting through the shafts, all on the existing wind field.
  - A small rope ferry or punt at the pond's edge would make "Windferry" literal.

**P1-12 · Performance: `?q=high` (the default the owner will open) does not hold 60 fps at 1440p**
- *Evidence:* `measure_fps.js` gives 6 s rAF windows after a 2 s settle, on a contended GPU:

  | Quality / resolution | Run | Golden | Night | Golden + rain | p95 frame time |
  |---|---|---|---|---|---|
  | `high` 2560×1440 | 1 | 52.6 fps | 59.8 fps | 60.6 fps | 24–33 ms |
  | `high` 2560×1440 | 2 | 37.4 fps | 40.8 fps | 53.8 fps | 33–42 ms |
  | `med` 1920×1080 | — | 96.1 fps | 93.7 fps | 95.2 fps | ≈17 ms |

  At 16:10 (2304×1440), the HUD counter read about 68 fps.
- *Fix:*
  - Add an adaptive internal resolution: start at 1440, and step down to 1260 and then 1080 while p95 > 18 ms.
  - Stop re-rendering the 4096² sun shadow map every frame (`pipeline.js:251`). Cache static casters and re-render only the
    swaying canopies, or update at 30 Hz.
  - Cap DOF taps at about 48. At 1440p the gather does about 100 taps per half-res pixel
    (`maxCoc` 14.7 / `radScale` 1.05); scale `radScale` with resolution.
  - The canopy rebuild (P0-5) also removes the `DoubleSide` + `discard` overdraw that defeats early-Z.
  - Profile each pass with `EXT_disjoint_timer_query_webgl2`
    (<https://registry.khronos.org/webgl/extensions/EXT_disjoint_timer_query_webgl2/>).

### P2

**P2-13 · Chromatic aberration is too strong at the corners**
- *Evidence:* `11d_branch_dof_off_crop_2x.png` shows a 6–8 px RGB split on the branch, and `04_pond_golden_crop_2x.png`
  shows fringed reeds at the left.
- *Wrong vs brief:* the brief asks for "very light CA at the edges". In `FINAL_FRAG`, `ca = dir*r²*0.012` reaches about
  0.003 UV, roughly 8 px at 2560.
- *Fix:* set `uCA ≈ 0.004` and mask it with `smoothstep(0.3, 0.55, r)`.

**P2-14 · Fragile render-pipeline couplings**
- *Fog toggle hack:* main-pass fog is disabled by setting `scene.fog.near/far = 1e6` every frame (`pipeline.js:249-256`).
  Use a material define or uniform instead.
- *Shadow map as a side effect:* the sun shadow map is only rendered inside the reflection render (`pipeline.js:251`). Skip
  the mirror (pond off-screen, or low quality) and the shafts and shadows silently go stale. Render shadows explicitly.
- *Silent light caps:* fog lights are truncated at 16 (`main.js:197`), and only 2 window point lights exist
  (`main.js:116`). Make the light budget explicit; the light decals from P0-4 remove most of the need.
- *Non-integer sprite scale:* the hero samples at 2.8 px per texel, so her pixel columns are uneven. Consider snapping the
  camera distance so the hero is exactly 3.0 px per texel at the default 1440 framing (about `dist` 37.7 at the current
  pitch).

**P2-15 · Rain polish (keep — it's the best moment)**
- *Evidence:* `09_night_rain.png`, `09b_night_rain_path_crop_2x.png`, `10_golden_rain.png`.
- *Fix:*
  - Add pixel splash sprites on the path and the hero's shoulders, eave drips, and ripple rings in the path puddles near
    the hero.
  - In golden + rain, reduce the uniform full-frame streak density beyond the focal region, so the far tiers aren't
    over-scratched.

---

## Strengths to keep
- Shadow-map-gated sun shafts through the oak (`01`, `07`); the wind field shared by every moving thing; and lantern/window
  in-scattering.
- Night rain on the wet cobbles with streaked lantern reflections (`09b`): this is the "wow" frame.
- Consistent 32-tpu texel density, world-space UVs, and the hero sized from the PNG; volume normals and a contact shadow on
  the sprite.
- Code: modular `pipeline.js` / `shaders.js`, quality presets with per-field URL overrides, and the `window.__hd2d` review
  hooks (they made this review fast).

## Evidence index (`review/web/review-1/`)
- `01_golden_full.png`: default golden hour, 2560×1440.
- `02_hero_crop_2x.png`: 2× crop around the hero.
- `03_night_full.png`, `03b_night_hero_crop_2x.png`: night preset.
- `04_pond_golden_crop_2x.png`, `04b_pond_night_crop_2x.png`: pond reflection region.
- `05_motion_a/b/e.png`, `05_motion_diff_a_e.png`: full-resolution frames spanning about 1.5 s, plus a motion heat-map.
- `06_seq_golden_00…08.jpg`, `06_seq_golden.gif`, `06_seq_golden_sheet.jpg`: 9 frames over about 4.9 s (t = 132.5 → 137.4).
- `07_golden_dof_off.png`, `08_golden_dof_fog_off.png`: the same view with DOF off, and with DOF and fog off.
- `09_night_rain.png`, `09b_…`, `10_golden_rain.png`: rain.
- `11a…11d`: DOF regions (T3 canopy, T0 band, canopy and branch with DOF off).
- `12_houses_T2_crop.png`: house detail.
- `13_flock_pass.png`, `13b_…`: flock at mid-pass (occluded).
- `14_texel_crawl_roof_a_vs_b_4x.png`: roof tiles under far blur.
- `15_hero_shadow_rim_nopost_crop_3x.png`: hero lighting with fog and DOF off.
- `16_golden_16x10_macbook.jpeg`: 1440×900 @2x framing.
- `17_butterfly_crop_4x.png`: butterfly sprite.
- `20/21/22_cmp_*.jpg`: side-by-side comparisons with `town_day`, `town_night` and `town_autumn`.
