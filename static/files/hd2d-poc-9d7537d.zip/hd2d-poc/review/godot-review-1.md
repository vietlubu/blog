# Godot track — review #1 (Windferry Hamlet, HD-2D round 1)

Reviewer: GodotReviewer · 2026-11-15 · build `godot/` as found at 23:20 · Godot 4.7.1.rc2 Forward+ (Metal) · Apple M1 Pro ·
window 2560×1440. **The GPU was shared with a Chrome/WebGL tab the whole session (web reviewer), so every FPS number is a
contended lower bound.** All evidence below was captured by me; paths are relative to the repo root, regions are
`x0–x1, y0–y1` in 2560×1440 pixels.

Captures (`review/godot/review-1/`): `01_golden_default` · `02_golden_high` · `03_night` · `04_rain` · `05_night_rain` ·
`06_night_high` · crops `10–22` · side-by-sides with references `30–32` · diagnostics from my driver (`40–46`: DOF off,
volumetrics off, zoom/pan extremes, raw mirror render target) · water A/B `50–54` · fidelity crops `60–64`, `68` · perf
variants `70–74` · motion `motion/` (frames t=2…13 s, `t6-10s.gif`, `clip_t2-14s_720p.mp4`, `pond_t8-12s.mp4`,
`contact_t2-12s.png`, `sky_strip_t6-13s.png`) · `fps_breakdown.txt` · `logs_stdout.txt`.
Reproduce: `capture.sh` (stills), `driver.gd` (`godot --path godot --script $PWD/review/godot/review-1/driver.gd -- --nohud --diag-{shots,water,bench,perfshots}=<out>`),
`crops.py`. stdout/stderr of every run: **no script or shader errors, no warnings.**

## Verdict

Cozy, yes. "Wow", not yet. The golden-hour frame already speaks HD-2D: surfaces are pixel art locked to a 32-texel
world grid, the hero is crisp inside a narrow tilt-shift band, there's a warm key with cool fill, and the windows are
lit. The night preset (lanterns, fireflies, blue ambient: `03_night.png`) is the build's best image and holds up next to
`refs/hi/town_night.jpg` (`31_vs_town_night.png`). Four things stop the owner from saying "wow":
1. **The pond, which is the reflection showcase, reads as a muddy brown patch in the bottom-left corner.** Part of
   the cause is a real colour-space bug: the linear mirror render target gets decoded a second time.
2. **The top 45 % of the frame is a single defocused amber haze.** The sun shafts are there, but they're soft and buried.
   There's no far tier, no sky, and the kite and flock get lost in it.
3. **The composition is horizontal bands stacked on each other,** with a full-width stone wall across the middle and a
   cramped, clipped right edge.
4. **It runs at 49 fps (contended).** The built-in DOF alone costs about 5 ms.

The "texel-true world" idea is a real identity, but on screen the scene still reads as a warmer cousin of the reference
town. The Windferry theme (wind, kite, windmill) is barely visible in the default frame. Fix the four P0s and this
build is a "wow" candidate.

## Scores (1–10)

| Category | Score | Why (short) |
| --- | :-: | --- |
| Composition & tiered depth | **6** | T0 grass → T1 path → wall → T2 houses → T3 tree all read; but stacked bands, full-width wall (`01` y 780–975), right edge cramped/clipped (house C, blurred cottage blob, kite at x 2240–2330), pond cut by the bottom-left corner, no T4/sky in the default frame. `44_zoom_out_max` already frames better. |
| Pixel-art fidelity & texel consistency | **6** | Architecture/terrain/hero share 32 texels/unit and world-space UVs: excellent (`20_texel_density_3x`). Broken by rotated leaf cards (diagonal pixel grids, `60`), randomly scaled grass tufts / birds / kite, white-noise per-texel shading on thatch & plaster (`63`), visible prism trunk (`62`). |
| Lighting & volumetrics | **7** | Warm key / lavender fill, lit windows and lantern scattering work; shadowed shafts exist (`18`) but are froxel-soft and drowned in amber haze (compare `01` vs `43_volumetric_off`). |
| Reflections | **3** | Pond nearly mirror-less and muddy (`12`, `54` row 1); colour-space bug; reeds absent from mirror; mirror mostly sees the bridge underside; wet cobbles at night-rain show no lamp streaks (`14`). |
| DOF & camera | **7** | Convincing miniature read, focus tracks the hero, FOV 21°. Pitch 12.5° is flatter than the brief's 15–25° (little ground plane, pond grazing). DOF costs 5.1 ms; bright bokeh only on dust motes. |
| Life / animation | **6** | One wind field drives grass, canopies, laundry, smoke, leaves, kite and windmill. Good. But the flock is visible only ~6 s of every 28 s, is small and dark against a dark canopy (`motion/t12s_flock_crop.png`); only ~2 of the 6 butterflies sit in the sharp band; golden-hour fireflies are big lime blobs next to the hero (`42`). |
| Palette & grading | **7** | Cozy, coherent, hue-shifted ramps; night palette is lovely. Golden hour drifts to a monochrome amber in the upper half; edge chromatic aberration (CA) fringes visible (`64`). |
| Character integration | **7** | Exactly 2 heads, size derived from the PNG, lit by sun/lanterns, contact shadow. The rim light is overcooked (hero glows like a lamp, `64`, `10`) and the billboard self-shadows with sub-texel speckle (`61`). |
| Own HD-2D identity | **6** | "Texel-true" ripples/glints and leaf-cluster canopies are deliberate choices; the signature (kite, windmill, wind) is off-frame, cut or blurred. Reads close to the reference town. |
| Performance / stability | **5** | 49.3 fps balanced, 33.5 high, 47.5 rain at 1440p (contended). Rock-solid: no errors, deterministic, capture mode works. DOF 5.1 ms is the main cost; `--scale=0.8` already gives 65.7 fps. |
| Code quality | **7** | Compact, fully procedural, one shared wind include, clean preset blending, honest README. Colour-space bug, duplicated wind formula, per-pixel procedural patterns that won't scale. |

**What to keep:** world-locked 32-texel surface shader + cotangent normals, the cobbles, the hero lighting model (minus the
rim strength), the preset cross-fade architecture, the night lighting, the mist on the pond, contact shadow, falling leaves.

## Change requests

### P0 — must fix before the owner sees it

**P0-1 · Make the pond the "wow" shot: fix the mirror decode, put reeds in it, give it something bright to reflect.**
- *Evidence:* `12_pond_golden.png` (x 0–1280, y 1100–1440): brown mud, no readable mirror image. `41_mirror_rt_raw.png` +
  driver log: the mirror render target is `FORMAT_RGBAH` (half-float, **linear**), mean luminance 0.272. After
  `water.gdshader` applies `refl = pow(refl, vec3(2.2))` it is ≈ 0.057, about **5× too dark**. `54_pond_golden_AB_stack.png`:
  row 1 as shipped, row 2 with only that line removed (the bridge reflects), row 3 with grass/reeds visible to the mirror.
  `54_pond_night_AB_stack.png`: the lit-window reflections appear only after the fix (rows 2–3). As shipped, the night pond
  is black with an orange blob.
- *Vs reference:* `refs/hi/town_autumn.jpg` (and `30_vs_town_autumn.png`): the pond sits in the focal band, a bright
  sky/canopy mirror with lily pads. That's an instant read. `refs/hi/town_night.jpg`: lamp light reflected in the water.
- *Fix:*
  1. Delete `refl = pow(refl, vec3(2.2));`. With `use_hdr_2d = true` the viewport is rendered linear and "can be used
     in 3D rendering without color space adjustments" ([Viewport.use_hdr_2d](https://docs.godotengine.org/en/stable/classes/class_viewport.html#class-viewport-property-use-hdr-2d)).
     Keep `refl_env.tonemap_mode = LINEAR`.
  2. Reeds/bank tufts are absent from the mirror because the whole grass MultiMesh is on layer 4 and `refl_cam.cull_mask = 1`.
     There's no clip-plane problem here. Split water-edge instances (atlas cell 7 plus tufts within ~1 u of `WATER_Y`)
     into a second `MultiMeshInstance3D` on layer 1. Add the same 2-line below-plane `discard` that terrain/surface use
     to `grass.gdshader` so nothing under the plane leaks into the mirror.
  3. Give the mirror something to show. At pitch 12.5° the reflected rays rise only ~12° and hit the bridge underside and
     the retaining wall (grey). Raise the pitch (P0-3: 17°) so the rays clear the wall and pick up the lit T2 facades and
     canopy. Put one lantern on the pond bank (e.g. near x −6.5, z 3.6) so a warm vertical streak reflects. Stretch the
     ripple distortion vertically (`off.y *= 3`) for the classic elongated light reflection.
  4. Bring the whole pond into frame and closer to the focal band (pond centre z 5.3 → ~4, or re-aim `FOCUS`).
     Loosen the near blur a little (`dof_blur_near_distance = focus_d - 4.0`).
  5. Push the refraction colours from mud to water: `shallow #a8c4a0 → ~#3f6f6a`, `deep #14302e → ~#0b1d22`.
  6. Night: place the moon where it can glint. The glints need moon elevation ≈ camera pitch, behind the scene. Moon
     at `_sun_dir(15–25°, 18–20°)` instead of 38° elevation gives a moon path on the pond.
- *Accept when:* a still of the default frame shows an unmistakable mirror image (houses/canopy/lantern) in the pond at
  both presets.

**P0-2 · Hold 60 fps in the default (balanced) tier at 2560×1440.**
- *Evidence:* `fps_breakdown.txt`. I toggled one feature at a time with my driver. Baseline 49.3 fps (20.3 ms).
  Costs: **DOF 5.1 ms** (66.0 fps without it), sun shadows 2.0 ms, SMAA 1.3 ms, glow 1.1 ms, planar mirror 0.7 ms,
  volumetric fog 0.5 ms, canvas post 0.5 ms, grass ≈0. DOF `QUALITY_LOW` reaches 59.7 fps but turns bokeh into noisy
  star blobs (`74_perf_variants_bg_bokeh.png`, row 2), so reject it. Hexagon bokeh saves nothing. MetalFX spatial 0.75
  gives 71.1 fps with a mild softening of the hero pixels (`73_perf_variants_hero_2x.png`, right). The builder's own
  `--scale=0.8` gives **65.7 fps**.
- *Fix (for tomorrow):* make balanced = MetalFX spatial at 0.8 (the existing `--scale` path, set by default) and keep
  circle/medium DOF. Also, in balanced, try `directional_shadow_max_distance 80 → ~60`: the big tree is ~47 u from the
  camera; check that the canopy-shadow stripes on the hill in `42_dof_off` survive. Try `soft_shadow_filter_quality
  2 → 1` too, then re-measure (shadows cost 2.0 ms in total). Keep `Q` = native-resolution "high" for stills.
  See [Resolution scaling](https://docs.godotengine.org/en/stable/tutorials/3d/resolution_scaling.html).
- *Then (round 2):* replace the built-in DOF with a half-resolution tilt-shift DOF (P1-12). That brings back native-res
  crisp focal pixels at 60+.

**P0-3 · Re-frame the default shot: depth diagonal, a far tier, room on the right, a broken-up wall.**
- *Evidence:* `01_golden_default.png`. Top band y 0–640 is blurred amber with no T4 and no sky. The right edge
  x 2200–2560 clips house C, puts a blown cottage-window blob behind it and cuts the kite (x 2240–2330, y 50–160). The
  retaining wall is one uniform 2.1 u stone band across 100 % of the width (y 780–975). The pond is cut by the
  bottom-left corner. `44_zoom_out_max.png` (zoom +8) already reads as a complete diorama. The three far ridges and
  clouds that `_far()` builds at z −95…−185 never appear in the default frame (`43`).
- *Vs reference:* `town_autumn` uses a diagonal path, the pond in the focal band and air behind the props. The Octopath
  talk describes a tiered (hina-dan) layout that keeps the back filled with content (see brief). LONG GONE sunset
  (`refs/longgone_sheet.jpg`, row 2 left) has haze, but in layered silhouettes.
- *Fix:*
  - `PITCH 12.5 → ~17°` (brief range 15–25°), `DIST 34 → ~38`, FOV stays 21°. Re-aim `FOCUS` so the hero lands at
    about (0.45 w, 0.66 h) and the pond is fully inside the frame.
  - Drop the T3 hill crest behind houses B/C by ~2–3 u (or pull its forest back) so the top-right third shows two haze
    ridges, a sliver of sky and clouds. That gives the kite and flock a clean backdrop (P1-8).
  - Move house C ~1.5 u left or open a gap between B and C. Break the wall into 2–3 segments of different heights, add a
    lit niche or the culvert arch with ivy *curtains* (the current ivy reads as bushes stuck on the wall, `64`), and give
    the coping some variation.
  - Verify with `G` (DOF off) that the frame still composes without blur.

**P0-4 · Clear the amber soup and give the god rays real blades.**
- *Evidence:* `01` vs `43_volumetric_off.png`. With volumetrics on, the tree, hill and cottages in y 0–640 collapse
  into one amber value. `18_godrays_canopy.png`: the shafts are wide and low-frequency. At balanced, a 96×64 froxel grid
  over 2560×1440 means each froxel is ~27×22 px. That's the Godot limitation the builder flagged
  ([proposal #11073](https://github.com/godotengine/godot-proposals/issues/11073) describes the same issue).
- *Vs reference:* `refs/hi/tribute_fog.jpg` / `32_vs_tribute_fog.png` (crisp shadowed blades), `refs/longgone_sheet.jpg`
  (dusty shafts with separated silhouettes).
- *Fix:*
  1. Haze. `haze_mat` far `density 0.055 → ~0.022` and `falloff 0.12 → ~0.25`, so the haze sits in the valley instead of
     filling the frame. `volumetric_fog_anisotropy 0.62 → ~0.45`. `volumetric_fog_length 110 → ~70`, because the docs say
     "keep this as low as possible" for detail ([volumetric fog](https://docs.godotengine.org/en/stable/tutorials/3d/volumetric_fog.html))
     and the shafts live 35–60 u from the camera.
  2. Crisp blades with **shadow-map slices**. Use a `MultiMesh` of 16–24 parallel quads stacked through a bounded box
     around the big tree canopy and the A|B and B|C house gaps. Shader: `render_mode blend_add, depth_draw_never,
     cull_disabled`. `light()` adds `LIGHT_COLOR * ATTENUATION * density * phase` only for the directional light, so each
     slice samples the real shadow map at full resolution and the leaf-card holes become real dappled blades. Add a
     depth-texture proximity fade (~1 u) and an end fade, scale by `(1-night)*(1-0.7*rain)`, and flicker with
     `wind_gust`. This is the t3ssel8r / David Holland technique, implemented in Godot as instanced quads
     ([3D Pixel Art Rendering — Volumetric Lighting](https://www.davidhol.land/articles/3d-pixel-art-rendering)).
     Measure the cost and keep the slice count where it stays under ~1 ms.
  3. Cheaper fallback if the slices are too slow: 6–10 artist-placed additive shaft cards along `-to_light` with a
     texel-quantised stripe pattern (fits the "texel-true" identity) and a proximity fade. Godot references:
     [SimplestGodRay3D](https://godotengine.org/asset-library/asset/4146),
     [God rays shader](https://godotshaders.com/shader/god-rays/).
  4. Spawn the dust motes inside the shaft volumes so they glitter there, and not as a uniform field.

### P1 — next

**P1-5 · Leaf cards: no rotated pixel grids, and stronger value masses.**
- *Evidence:* `60_leafcards_rotated_grid_3x.png` (from `42_dof_off`, x 820–1060, y 560–700) and `19_canopy_cards_2x.png`.
  `_card_basis()` rolls every card ±0.6 rad, so texels render as diamonds and neighbouring cards' grids disagree. Every
  bush and canopy reads as a uniform "fish-scale" texture. `62_tree_trunk_prism_dofoff.png`: 7-sided prism trunk with
  straight prism branches.
- *Vs reference:* the brief's Octopath rule that pixels never rotate diagonally. `town_day`/`town_autumn` canopies have
  big clusters with clear lit / mid / core-shadow masses and sky holes.
- *Fix:* remove the roll (`.rotated(f, …)`) and keep each card's up axis = world up, with only yaw/tilt toward the
  camera. Grow the leaf atlas from 4 to 8+ clump silhouettes with gaps. Bake a per-lobe value into `COLOR` from
  `dot(lobe_normal, to_light)` quantised to 3 steps, so each lobe has a lit cap, a mid band and a dark core. Punch a
  few sky/backlight holes in the big tree. Trunk: 10–12 sides, 2–3 root flares, branch joints hidden under lobes.

**P1-6 · One texel density for everything in focus.**
- *Evidence:* `20_texel_density_3x.png` shows tuft pixels at a different size from the cobble and hero pixels. Code:
  tufts are scaled `0.75–1.25 ×` with non-uniform `x 0.85–1.15 / y 0.8–1.2`, T0 `×1.9`, T3 `×1.4`, flowers `×0.7`
  (`world.gd` `_grass`). Birds `×1.6`, kite and tail `×2.2` (`life.gd`).
- *Fix:* instance tufts at exactly 1.0 (allow an integer 2× only for T0, which is always out of focus). Get height
  variety from extra atlas cells (short/medium/tall), and use X-flip for variety instead of non-uniform scale. Redraw
  bird and kite sprites at the needed pixel size and place them at 1×.

**P1-7 · Hero: tame the rim and stop the billboard shadowing itself.**
- *Evidence:* `10_hero_crop_2x.png` and `61_hero_leg_shadow_noise_3x.png`. Hair and bag saturate to yellow-white and
  bloom ~8 px past the silhouette; there's sub-texel speckle and a vertical line on the left leg and bag edge.
  `64_hero_rim_glow_panleft.png`: after a pan the hero's head looks like a lamp.
- *Vs reference:* `refs/hi/tribute_closeup.jpg`: a thin, 1-texel, unbloomed rim.
- *Fix:*
  - Rim: `rim_strength 2.2 → ~0.9` (night `5 → ~2`), `edge = pow(edge, 6.0)` so only the outer 1–2 texels light up, and
    cap the rim at ~0.6 × `LIGHT_COLOR`.
  - Shadows: set the visible quad's `cast_shadow = OFF`. Add a `SHADOWS_ONLY` proxy quad with the same texture/scissor,
    yawed toward the sun azimuth and offset ~0.25 u *away* from the light. Then its shadow volume can't cross the visible
    quad, and the contact decal hides the gap at the feet. Background:
    [billboards self-shadow ("almost always going to be half in shadow")](https://tw0catsgames.com/update/2023/11/06/perfecting-unitys_billboard_shader_for_hd2d_01.html).
  - Check that the contact `Decal` (box y −0.2…0.4) doesn't darken the boots: give it a `cull_mask` that excludes the
    hero's layer. [INFERENCE: the boots look darker than the sprite's own art.]

**P1-8 · Make the animal life readable within the first 5 seconds.**
- *Evidence:* `motion/sky_strip_t6-13s.png` and `motion/t12s_flock_crop.png`. The flock only crosses at t≈8–14 s of each
  28 s cycle, as small dark sprites over the dark canopy. `68_small_life_4x.png`: the path songbird reads (~40 px), the
  roof songbird is a blurred speck. Butterflies (9×7-texel frames, ~30 px on screen) read well when they cross a dark
  bush (`motion/t8s_butterfly_barrels_2x.png`), but only ~2 of the 6 homes are inside the sharp band. The rest are in
  the foreground blur or off-frame, and 2 of the 6 tints are near-white on pale plaster. `42_dof_off.png`: golden-hour
  fireflies are bright lime additive blobs right next to the hero.
- *Fix:* first flock pass at t≈1.5 s, then a 14–16 s period, routed through the new sky window (P0-3), with a sun rim
  on the undersides. Butterflies: move 4 of the 6 homes onto the flower beds and bushes *inside* the focal band (around
  the hero and the T1 beds), use saturated tints (orange tip, sulphur yellow, blue) against the greens, and add a
  landing/resting frame with figure-eight paths so they visibly settle. Fireflies: `amount_ratio = 0` until
  `night > 0.3`, and keep their core ≤ 4 px.

**P1-9 · Night polish: blown door lamp, searchlight smoke, no moon.**
- *Evidence:* `21_night_windows.png` (`03_night` x ~1530–1600, y ~480–580). The door lamp (`lamp_mats` emissive 7.0) plus
  a window omni blows out to white over the door and the right window. `22_night_smoke_streak_2x.png` (`05_night_rain`
  top centre): chimney smoke stretched by the rain wind reads as a white searchlight beam. No moon or sky in frame.
- *Vs reference:* `refs/hi/town_night.jpg`: warm windows with readable mullions, smoke dimly lit grey-blue, light pooled
  on the ground and in the water.
- *Fix:* lamp emissive at night `7 → ~3`. Raise `glow_hdr_threshold` from 1.0 to ~1.3 at night. Window glass gets 2 px
  mullions plus a curtain or silhouette pattern so the panes don't go flat. Smoke: `albedo_color` lerps to ~`#3a4058`
  at night and `backlight` goes to 0. Moon placement as in P0-1.6, so it is either visible in the sky window or glinting
  on the pond.

**P1-10 · Surface patterns: pixel clusters, not white noise.**
- *Evidence:* `63_thatch_noise.png` (`46_pan_left_max`, house A roof): the thatch reads as noisy carpet. Plaster
  stains are blotchy, and the stones carry salt-and-pepper speckle (`64`, wall). The cause is the per-texel `hash12(t)`
  term in every `pat()` branch, which pushes texels across the 4-tone ramp boundaries.
- *Vs reference:* `town_autumn` roofs: clean tiles, clustered highlights, deliberate shapes.
- *Fix:* cut the per-texel hash amplitude to ≤ 0.04 or switch to 2×2 clustered noise (`hash12(floor(t*0.5))`). Thatch:
  3–4 px vertical bundles with a lit tip row and a dark under-row, plus a ridge cap. Add an AO band under eaves.
  Plaster: fewer, larger stains with a 1 px darker edge.

**P1-11 · Make "Windferry" visible: the signature in the money shot.**
- *Evidence:* `01`: the windmill (x −13.5, z −29) is off-frame, the kite is blurred and cut at the top-right corner,
  and the banner's kite emblem is ~10 px.
- *Fix:* put the windmill silhouette on the T3 crest inside the frame, with sails driven by gusts (already wired). Fly
  the kite fully inside the sky window. Make the wind visible: gust "wind ribbons" (1-texel pixel streak particles,
  6–12 px long, that travel with the `wind_gust` fronts across the meadow) and dandelion seeds that glow when they cross
  a shaft. Push the amber/teal complement (hero scarf, shutters) into the shadow ramps and the water. Update the README
  identity bullets to match what's on screen.

**P1-12 · Replace the built-in DOF with a half-resolution tilt-shift DOF (Compositor).**
- *Evidence:* the built-in DOF costs 5.1 ms (`fps_breakdown.txt`). Bright discs appear only on dust motes, and the
  near-field grass smears instead of making discs (`15_dof_foreground.png`).
- *Fix:* a `CompositorEffect` (post-transparent) compute pass:
  - CoC from depth, using a band around `focus_d` (tilt-shift) and capped at ~20 px.
  - Half-res premultiplied downsample.
  - Gather in a single pass with Gustafsson's scatter-as-gather (the tribute uses the same thing:
    `refs/the-last-night-tribute/src/render/shaders.js` "Depth of field (scatter-as-gather…)", including its energy
    clamp so tiny over-bright texels don't sparkle).
  - Bilateral composite at full res; focal-band pixels stay untouched, so they're perfectly crisp.
  
  Links: [Bokeh depth of field in a single pass](https://blog.voxagon.se/2018/05/04/bokeh-depth-of-field-in-single-pass.html),
  [The Compositor](https://docs.godotengine.org/en/stable/tutorials/rendering/compositor.html). Expected cost ~1–1.5 ms
  [INFERENCE]. Then drop MetalFX from balanced.

### P2 — later

**P2-13 · Wet look in rain.** `14_wet_cobbles_night_rain.png`: at night-rain the cobbles around the lantern show no
streaks. Rain was optional. Add a low-frequency puddle mask in `terrain.gdshader` (roughness 0.03, flattened normal), and
enable SSR only when `rain > 0.3` (`ssr_max_steps 32–48`, fade-in 0.15). Then the lanterns and windows streak on the
cobbles like `refs/hi/tribute_screenshot.jpg`.

**P2-14 · Grading details.** CA fringes are visible on edge grass (`64`, bottom-right): `post.gdshader ca 0.0012 → 0.0006`.
Golden hour is too monochrome above the wall: cool `shadow_tint` toward `#c8d8ff` and reduce `fog_light_color` amber so the
greens survive in the midtones (compare `43` against `01`).

**P2-15 · Code fragility / scalability.**
- (a) The wind field lives twice (`common.gdshaderinc` and `life.gd gust()`), `WIND_DIR` is duplicated outside the
  `wind_dir` global, and the shader comment points at a non-existent `scripts/wind.gd`. Use one `Wind` script that
  owns the constants and sets the global uniform.
- (b) `surface.gdshader` evaluates `pat()` 3× per fragment (cobbles: 27 Voronoi cells per pixel), in every material
  and every overdraw layer. Fine for one diorama, too costly for a game. Bake (value, height) per material into a
  nearest-filtered texture at startup; that also lets artists override with hand-drawn tiles.
- (c) The mirror pass culls below the plane only in terrain/surface (`CAMERA_POSITION_WORLD.y < water_level`). Add it
  to every shader whose geometry can reach the mirror.
- (d) `world.gd` is 1140 lines of hard-coded coordinates. For round 2, move the layout into a `.tscn` with markers so
  composition changes (P0-3) are edits, not code.

## Builder weak-spot list: verification

| Builder said | Verdict |
| --- | --- |
| God rays soft / low-frequency | **Confirmed** (`18`, `43`), and worse in context: haze density turns the whole upper half amber → P0-4. |
| Built-in DOF lacks bright bokeh discs | **Partly.** The dust motes make nice round discs (`74` row 1); the near field has nothing bright, and grass smears. The real problem is cost, 5.1 ms → P0-2 / P1-12. |
| Reflections subtle; no clip plane, so reeds missing | **Confirmed, different cause.** Reeds are missing because of the layer mask (grass on layer 4, mirror mask 1), not a missing clip plane. Reflections are also ~5× too dark from a double sRGB decode → P0-1. |
| Composition cramped on the right; no open sky / far mountains | **Confirmed** → P0-3. |
| Night windows slightly blown | **Confirmed**, mainly the door lamp on house B → P1-9. |
| ~49 fps default under contention; is 60 reachable? | **Confirmed 49.3 fps.** Yes: DOF dominates; MetalFX 0.8 = 65.7 fps, 0.75 = 71.1 fps → P0-2. |
| (orchestrator) Pond dark/dull | **Confirmed**, root cause found → P0-1. |
| (orchestrator) Animal life readable? | **Partly.** The path songbird reads; flock, butterflies and roof bird don't, in stills or in a short look → P1-8. |
| (orchestrator) Texel density hero 32 px/u vs environment | **Consistent for surfaces/terrain/hero**; broken by tuft/bird/kite scaling and rotated leaf cards → P1-5, P1-6. |
