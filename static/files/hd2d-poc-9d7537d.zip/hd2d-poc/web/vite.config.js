export default {
  base: './',
  server: { host: '127.0.0.1', port: 5180, strictPort: true },
  preview: { host: '127.0.0.1', port: 5180, strictPort: true },
  build: { outDir: 'dist', target: 'esnext', chunkSizeWarningLimit: 1500 },
};
