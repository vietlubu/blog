import * as THREE from 'three';
import * as S from './shaders.js';
import { U, LAYER } from './shared.js';
import { WATER_Y } from './layout.js';

export const NP = 16; // analytic fog lights (lanterns + windows)

class FSQuad {
  constructor() {
    this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2));
    this.mesh.frustumCulled = false;
  }
  render(r, material, target) {
    this.mesh.material = material;
    r.setRenderTarget(target);
    r.render(this.mesh, this.camera);
  }
}
const pass = (frag, uniforms) => new THREE.ShaderMaterial({ vertexShader: S.FS_VERT, fragmentShader: frag, uniforms, depthTest: false, depthWrite: false });
function rt(w, h, opts = {}) {
  const t = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, format: THREE.RGBAFormat, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, ...opts });
  t.texture.generateMipmaps = false;
  return t;
}

export class Pipeline {
  constructor(renderer, scene, camera, sun, quality) {
    this.r = renderer;
    this.scene = scene;
    this.camera = camera;
    this.sun = sun;
    this.q = quality;
    this.quad = new FSQuad();
    this.P = {
      fog: true,
      dof: true,
      bloomOn: true,
      bloom: 0.07,
      bloomThresh: 1.2,
      exposure: 1.0,
      focus: 40,
      // flat focal region (UE4 legacy-Bokeh model): sharp from focus-nearIn to focus+farIn, ramps beyond
      nearIn: 3,
      nearRamp: 6,
      farIn: 13.5, // covers the wall, the terrace, all three T2 houses and the trees overhanging them (view depth 42–52, hero ~39)
      farRamp: 12, // hill crest / forest edge (66+) are fully soft
      nearK: 1.0,
      farK: 0.85,
      maxCoc: 11, // half-res pixels at 1080p, scaled with resolution
      ca: 0.004,
      grain: 0.03,
      vignette: 0.3,
      saturation: 1.18,
      contrast: 1.12,
      lift: new THREE.Color(0.006, 0.01, 0.026),
      gain: new THREE.Color(1.03, 1.0, 0.95),
      shadowTint: new THREE.Color(-0.006, -0.002, 0.018),
      highTint: new THREE.Color(0.02, 0.008, -0.02),
      fogA: new THREE.Vector4(0.02, 0.16, 0.0, 0.7),
      fogB: new THREE.Vector4(0.05, 110, 0.35, WATER_Y),
      fogC: new THREE.Vector4(0.45, 0.004, 1.0, 6),
      sunScat: new THREE.Color(1, 0.7, 0.4),
      ambLow: new THREE.Color(0.1, 0.1, 0.13),
      ambHigh: new THREE.Color(0.12, 0.12, 0.16),
      haze: new THREE.Color(0.7, 0.6, 0.55),
      reflFog: new THREE.Color(0.6, 0.55, 0.5),
      wind: new THREE.Vector3(0.02, 0.003, -0.008),
      volC: new THREE.Vector4(-3, 4, -8, 0.05),
      volR: new THREE.Vector3(15, 6.5, 10),
      fade: new THREE.Vector3(40, 60, 0.35), // fog density fade-in along the ray, set from the focus each frame
      shadowEvery: 2, // re-render the 4096² sun shadow map every N frames (canopies sway slowly)
    };
    this.fogLights = []; // { pos, color(THREE.Color), intensity, range }

    this.reflCam = new THREE.PerspectiveCamera();
    this.reflCam.layers.set(LAYER.WORLD);
    this.scene.fog = new THREE.Fog(this.P.reflFog, 40, 400);
    this.scene.fog.enabledInMain = false;

    const dd = new THREE.DepthTexture(1, 1, THREE.UnsignedIntType);
    dd.compareFunction = THREE.LessEqualCompare;
    dd.minFilter = dd.magFilter = THREE.LinearFilter;
    this.dummyRT = new THREE.WebGLRenderTarget(1, 1, { depthTexture: dd, depthBuffer: true });
    renderer.setRenderTarget(this.dummyRT);
    renderer.clear();
    renderer.setRenderTarget(null);
    this.dummyShadow = dd;
    U.tSunShadow.value = dd;

    const near = { value: camera.near };
    const far = { value: camera.far };
    this.near = near;
    this.far = far;
    this.mCopy = pass(S.COPY_FRAG, { tSrc: { value: null } });
    this.mBlur = pass(S.BLUR_FRAG, { tSrc: { value: null }, uDir: { value: new THREE.Vector2() } });
    this.mDepthDown = pass(S.DEPTH_DOWN_FRAG, { tDepth: { value: null }, uTexel: { value: new THREE.Vector2() }, uNear: near, uFar: far });
    const P = this.P;
    this.mFog = pass(S.fogFrag(NP, quality.fogSteps), {
      tDepth: { value: null },
      tNoise: U.tNoise3D,
      tSplat: U.tSplat,
      uSplatBox: U.uSplatBox,
      tSunShadow: U.tSunShadow,
      uSunShadowMat: U.uSunShadowMat,
      uProjInv: { value: new THREE.Matrix4() },
      uViewInv: { value: new THREE.Matrix4() },
      uCamPos: { value: new THREE.Vector3() },
      uTime: U.uTime,
      uSunDir: U.uSunDir,
      uSunScat: { value: P.sunScat },
      uAmbLow: { value: P.ambLow },
      uAmbHigh: { value: P.ambHigh },
      uHaze: { value: P.haze },
      uFogA: { value: P.fogA },
      uFogB: { value: P.fogB },
      uFogC: { value: P.fogC },
      uWind: { value: P.wind },
      uVolC: { value: P.volC },
      uVolR: { value: P.volR },
      uFade: { value: P.fade },
      uPtPos: { value: Array.from({ length: NP }, () => new THREE.Vector3()) },
      uPtCol: { value: Array.from({ length: NP }, () => new THREE.Vector4()) },
    });
    this.mBilateral = pass(S.BILATERAL_FRAG, { tSrc: { value: null }, tDepth: { value: null }, uDir: { value: new THREE.Vector2() } });
    this.mFogComp = pass(S.FOG_COMPOSITE_FRAG, { tScene: { value: null }, tDepth: { value: null }, tFog: { value: null }, tFogDepth: { value: null }, uFogRes: { value: new THREE.Vector2() }, uNear: near, uFar: far, uFogOn: { value: 1 } });
    const coc = { uFocus: { value: 40 }, uNearIn: { value: 3 }, uNearRamp: { value: 7 }, uFarIn: { value: 14 }, uFarRamp: { value: 26 }, uNearK: { value: 1 }, uFarK: { value: 1 }, uMaxCoc: { value: 10 } };
    this.coc = coc;
    this.mDofPre = pass(S.DOF_PRE_FRAG, { ...coc, tColor: { value: null }, tDepth: { value: null }, uNear: near, uFar: far, uTexel: { value: new THREE.Vector2() } });
    this.mTileMax = pass(S.TILE_MAX_FRAG, { tPre: { value: null }, uSrcTexel: { value: new THREE.Vector2() } });
    this.mTileDilate = pass(S.TILE_DILATE_FRAG, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } });
    this.mDofGather = pass(S.DOF_GATHER_FRAG, { tPre: { value: null }, tTile: { value: null }, uTexel: { value: new THREE.Vector2() }, uMaxCoc: coc.uMaxCoc, uRadScale: { value: quality.dofRad } });
    this.mDofComp = pass(S.DOF_COMPOSITE_FRAG, { ...coc, tColor: { value: null }, tBlur: { value: null }, tDepth: { value: null }, uNear: near, uFar: far });
    this.mBloomDown = pass(S.BLOOM_DOWN_FRAG, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() }, uFirst: { value: 0 }, uThresh: { value: 1 } });
    this.mBloomUp = pass(S.BLOOM_UP_FRAG, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } });
    Object.assign(this.mBloomUp, { blending: THREE.CustomBlending, blendEquation: THREE.AddEquation, blendSrc: THREE.OneFactor, blendDst: THREE.OneFactor, transparent: true });
    this.mFinal = pass(S.FINAL_FRAG, {
      tColor: { value: null },
      tBloom: { value: null },
      uExposure: { value: 1 },
      uBloom: { value: 0 },
      uCA: { value: 0 },
      uGrain: { value: 0 },
      uVignette: { value: 0 },
      uTime: U.uTime,
      uSaturation: { value: 1 },
      uContrast: { value: 1 },
      uLift: { value: P.lift },
      uGain: { value: P.gain },
      uShadowTint: { value: P.shadowTint },
      uHighTint: { value: P.highTint },
    });
    this.setSize(1280, 720);
  }

  setSize(w, h) {
    w = Math.max(64, Math.floor(w / 2) * 2);
    h = Math.max(64, Math.floor(h / 2) * 2);
    if (this.w === w && this.h === h) return;
    this.w = w;
    this.h = h;
    for (const t of [this.mainRT, this.reflRT, this.reflBlurA, this.reflBlurB, this.depthHalf, this.fogRT, this.fogTmp, this.hdrRT, this.dofPre, this.dofBlur, this.tileA, this.tileB, this.postRT, ...(this.bloomMips || [])]) t && t.dispose();
    const hw = w >> 1;
    const hh = h >> 1;
    this.mainRT = rt(w, h, { samples: this.q.msaa, depthBuffer: true, depthTexture: new THREE.DepthTexture(w, h, THREE.FloatType) });
    this.reflRT = rt(hw, hh, { depthBuffer: true, samples: 2 });
    this.reflBlurA = rt(hw >> 1, hh >> 1);
    this.reflBlurB = rt(hw >> 1, hh >> 1);
    const fs = this.q.fogScale;
    const fw = Math.round(w * fs);
    const fh = Math.round(h * fs);
    this.depthHalf = rt(fw, fh, { format: THREE.RedFormat, type: THREE.FloatType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
    this.fogRT = rt(fw, fh);
    this.fogTmp = rt(fw, fh);
    this.hdrRT = rt(w, h);
    this.dofPre = rt(hw, hh);
    this.dofBlur = rt(hw, hh);
    const tileOpts = { format: THREE.RedFormat, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter };
    this.tileA = rt(Math.ceil(hw / 8), Math.ceil(hh / 8), tileOpts);
    this.tileB = rt(Math.ceil(hw / 8), Math.ceil(hh / 8), tileOpts);
    this.postRT = rt(w, h);
    this.bloomMips = [];
    let bw = hw;
    let bh = hh;
    for (let i = 0; i < 6; i++) {
      this.bloomMips.push(rt(Math.max(bw, 2), Math.max(bh, 2)));
      bw >>= 1;
      bh >>= 1;
    }
    U.tReflSharp.value = this.reflRT.texture;
    U.tReflBlur.value = this.reflBlurB.texture;
  }

  _reflection() {
    const cam = this.camera;
    const n = new THREE.Vector3(0, 1, 0);
    const pp = new THREE.Vector3(0, WATER_Y, 0);
    const camPos = new THREE.Vector3().setFromMatrixPosition(cam.matrixWorld);
    const rot = new THREE.Matrix4().extractRotation(cam.matrixWorld);
    const view = pp.clone().sub(camPos).reflect(n).negate().add(pp);
    const look = new THREE.Vector3(0, 0, -1).applyMatrix4(rot).add(camPos);
    const target = pp.clone().sub(look).reflect(n).negate().add(pp);
    const rc = this.reflCam;
    rc.position.copy(view);
    rc.up.set(0, 1, 0).applyMatrix4(rot).reflect(n);
    rc.lookAt(target);
    rc.near = cam.near;
    rc.far = cam.far;
    rc.updateMatrixWorld();
    rc.projectionMatrix.copy(cam.projectionMatrix);
    const M = U.uReflMatrix.value;
    M.set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1);
    M.multiply(rc.projectionMatrix).multiply(rc.matrixWorldInverse);
    // oblique near-plane clipping at the water plane (Lengyel)
    const plane = new THREE.Plane().setFromNormalAndCoplanarPoint(n, pp.clone().add(new THREE.Vector3(0, -0.02, 0)));
    plane.applyMatrix4(rc.matrixWorldInverse);
    const clip = new THREE.Vector4(plane.normal.x, plane.normal.y, plane.normal.z, plane.constant);
    const pm = rc.projectionMatrix;
    const q = new THREE.Vector4((Math.sign(clip.x) + pm.elements[8]) / pm.elements[0], (Math.sign(clip.y) + pm.elements[9]) / pm.elements[5], -1, (1 + pm.elements[10]) / pm.elements[14]);
    clip.multiplyScalar(2 / clip.dot(q));
    pm.elements[2] = clip.x;
    pm.elements[6] = clip.y;
    pm.elements[10] = clip.z + 1;
    pm.elements[14] = clip.w;
    rc.projectionMatrixInverse.copy(pm).invert();
  }

  _fogUniforms() {
    const u = this.mFog.uniforms;
    const cam = this.camera;
    u.uProjInv.value.copy(cam.projectionMatrixInverse);
    u.uViewInv.value.copy(cam.matrixWorld);
    u.uCamPos.value.setFromMatrixPosition(cam.matrixWorld);
    for (let i = 0; i < NP; i++) {
      const L = this.fogLights[i];
      if (!L || L.intensity <= 0) {
        u.uPtCol.value[i].set(0, 0, 0, 1);
        continue;
      }
      u.uPtPos.value[i].copy(L.pos);
      u.uPtCol.value[i].set(L.color.r * L.intensity, L.color.g * L.intensity, L.color.b * L.intensity, L.range);
    }
  }

  render() {
    const r = this.r;
    const P = this.P;
    const cam = this.camera;
    const scene = this.scene;
    this.near.value = cam.near;
    this.far.value = cam.far;
    cam.updateMatrixWorld();
    r.autoClear = false;
    r.setClearColor(0x000000, 1);

    // 1) planar reflection (uses last frame's shadow map)
    this._reflection();
    scene.fog.color.copy(P.reflFog);
    // the reflection has no volumetric pass: a linear haze stands in so mirrored trees/houses
    // carry the same airy brightness as the fogged main view instead of reading as dark holes
    scene.fog.near = 40;
    scene.fog.far = 320;
    if (!this.sun.shadow.map) r.shadowMap.needsUpdate = true; // first frame: create the map before anyone samples it
    r.setRenderTarget(this.reflRT);
    r.clear();
    r.render(scene, this.reflCam);
    scene.fog.near = 1e6;
    scene.fog.far = 1e6 + 1;
    const bw = this.reflBlurA.width;
    const bh = this.reflBlurA.height;
    this.mBlur.uniforms.tSrc.value = this.reflRT.texture;
    this.mBlur.uniforms.uDir.value.set(1.5 / bw, 0);
    this.quad.render(r, this.mBlur, this.reflBlurA);
    this.mBlur.uniforms.tSrc.value = this.reflBlurA.texture;
    this.mBlur.uniforms.uDir.value.set(0, 2.5 / bh);
    this.quad.render(r, this.mBlur, this.reflBlurB);

    // 2) main HDR pass; the sun shadow map is refreshed explicitly here every `shadowEvery` frames
    this.frame = (this.frame || 0) + 1;
    if (this.frame % P.shadowEvery === 0 || !this.sun.shadow.map) r.shadowMap.needsUpdate = true;
    cam.layers.set(LAYER.WORLD);
    cam.layers.enable(LAYER.WATER);
    cam.layers.enable(LAYER.MAIN);
    r.setRenderTarget(this.mainRT);
    r.clear();
    r.render(scene, cam);
    const sm = this.sun.shadow.map;
    if (sm && sm.depthTexture) {
      U.tSunShadow.value = sm.depthTexture;
      U.uSunShadowMat.value.copy(this.sun.shadow.matrix);
    }

    // 3) volumetric fog
    const fw = this.depthHalf.width;
    const fh = this.depthHalf.height;
    this.mDepthDown.uniforms.tDepth.value = this.mainRT.depthTexture;
    this.mDepthDown.uniforms.uTexel.value.set(1 / this.w, 1 / this.h);
    this.quad.render(r, this.mDepthDown, this.depthHalf);
    if (P.fog) {
      P.fade.set(P.focus + P.farIn * 0.4, P.focus + P.farIn + P.farRamp * 0.5, P.fade.z);
      this._fogUniforms();
      this.mFog.uniforms.tDepth.value = this.depthHalf.texture;
      this.quad.render(r, this.mFog, this.fogRT);
      const b = this.mBilateral.uniforms;
      b.tDepth.value = this.depthHalf.texture;
      b.tSrc.value = this.fogRT.texture;
      b.uDir.value.set(1 / fw, 0);
      this.quad.render(r, this.mBilateral, this.fogTmp);
      b.tSrc.value = this.fogTmp.texture;
      b.uDir.value.set(0, 1 / fh);
      this.quad.render(r, this.mBilateral, this.fogRT);
    }
    const fc = this.mFogComp.uniforms;
    fc.tScene.value = this.mainRT.texture;
    fc.tDepth.value = this.mainRT.depthTexture;
    fc.tFog.value = this.fogRT.texture;
    fc.tFogDepth.value = this.depthHalf.texture;
    fc.uFogRes.value.set(fw, fh);
    fc.uFogOn.value = P.fog ? 1 : 0;
    this.quad.render(r, this.mFogComp, this.hdrRT);

    // 4) tilt-shift bokeh DOF
    let src = this.hdrRT;
    if (P.dof) {
      const c = this.coc;
      c.uFocus.value = P.focus;
      c.uNearIn.value = P.nearIn;
      c.uNearRamp.value = P.nearRamp;
      c.uFarIn.value = P.farIn;
      c.uFarRamp.value = P.farRamp;
      c.uNearK.value = P.nearK;
      c.uFarK.value = P.farK;
      c.uMaxCoc.value = P.maxCoc * (this.h / 1080);
      const pre = this.mDofPre.uniforms;
      pre.tColor.value = this.hdrRT.texture;
      pre.tDepth.value = this.mainRT.depthTexture;
      pre.uTexel.value.set(1 / this.w, 1 / this.h);
      this.quad.render(r, this.mDofPre, this.dofPre);
      const tm = this.mTileMax.uniforms;
      tm.tPre.value = this.dofPre.texture;
      tm.uSrcTexel.value.set(1 / this.dofPre.width, 1 / this.dofPre.height);
      this.quad.render(r, this.mTileMax, this.tileA);
      const td = this.mTileDilate.uniforms;
      td.tSrc.value = this.tileA.texture;
      td.uTexel.value.set(1 / this.tileA.width, 1 / this.tileA.height);
      this.quad.render(r, this.mTileDilate, this.tileB);
      const g = this.mDofGather.uniforms;
      g.tPre.value = this.dofPre.texture;
      g.tTile.value = this.tileB.texture;
      g.uTexel.value.set(1 / this.dofPre.width, 1 / this.dofPre.height);
      // keep the tap count roughly constant across resolutions (CoC radius grows with height)
      g.uRadScale.value = this.q.dofRad * (this.h / 1080);
      this.quad.render(r, this.mDofGather, this.dofBlur);
      const d = this.mDofComp.uniforms;
      d.tColor.value = this.hdrRT.texture;
      d.tBlur.value = this.dofBlur.texture;
      d.tDepth.value = this.mainRT.depthTexture;
      this.quad.render(r, this.mDofComp, this.postRT);
      src = this.postRT;
    }

    // 5) bloom
    const mips = this.bloomMips;
    let s = src;
    for (let i = 0; i < mips.length; i++) {
      const d = this.mBloomDown.uniforms;
      d.tSrc.value = s.texture;
      d.uTexel.value.set(1 / s.width, 1 / s.height);
      d.uFirst.value = i === 0 ? 1 : 0;
      d.uThresh.value = P.bloomThresh;
      this.quad.render(r, this.mBloomDown, mips[i]);
      s = mips[i];
    }
    for (let i = mips.length - 1; i > 0; i--) {
      const u = this.mBloomUp.uniforms;
      u.tSrc.value = mips[i].texture;
      u.uTexel.value.set(1 / mips[i].width, 1 / mips[i].height);
      this.quad.render(r, this.mBloomUp, mips[i - 1]);
    }
    if (P.debugTex) {
      // dev view of an intermediate buffer (window.__hd2d.pipeline.P.debugTex = 'refl' | 'reflBlur' | 'fog' | 'pre' | 'tile')
      const t = { refl: this.reflRT, reflBlur: this.reflBlurB, fog: this.fogRT, pre: this.dofPre, tile: this.tileB }[P.debugTex];
      this.mCopy.uniforms.tSrc.value = t.texture;
      this.quad.render(r, this.mCopy, null);
      return;
    }

    // 6) grade to screen
    const f = this.mFinal.uniforms;
    f.tColor.value = src.texture;
    f.tBloom.value = mips[0].texture;
    f.uExposure.value = P.exposure;
    f.uBloom.value = P.bloomOn ? P.bloom : 0;
    f.uCA.value = P.ca;
    f.uGrain.value = P.grain;
    f.uVignette.value = P.vignette;
    f.uSaturation.value = P.saturation;
    f.uContrast.value = P.contrast;
    this.quad.render(r, this.mFinal, null);
  }
}
