import * as THREE from 'three';
import { RNG, TPU } from './core.js';
import * as T from './textures.js';
import { U } from './shared.js';
import { windAt, gustAt } from './wind.js';
import { WATER_Y, T2_Y, POND, HERO, FIRE, pathZ, wallZ, groundY, waterDist, onPath } from './layout.js';
import { TREES } from './foliage.js';
import { floaters } from './world.js';

// Point-sprite creatures and particles. Every sprite is a 32x32-texel atlas cell drawn at 1 world unit, i.e. the
// scene's 32 texels/unit density; lit by ambient + sun x real shadow-map visibility.
const SPRITE_VERT = /* glsl */ `
attribute float aSize; attribute vec4 aInfo; attribute vec4 aCol;
uniform float uProjScale;
varying vec4 vInfo; varying vec4 vCol; varying vec3 vWP; varying float vDepth;
void main() {
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = max(aSize * uProjScale / -mv.z, 1.0);
  vInfo = aInfo; vCol = aCol; vWP = position; vDepth = -mv.z;
}`;

const SHADOW_GLSL = /* glsl */ `
precision highp sampler2DShadow;
uniform sampler2DShadow tSunShadow; uniform mat4 uSunShadowMat;
float sunVis(vec3 p) {
  vec4 sc = uSunShadowMat * vec4(p, 1.0);
  if (sc.x <= 0.0 || sc.x >= 1.0 || sc.y <= 0.0 || sc.y >= 1.0 || sc.z >= 1.0) return 1.0;
  return texture(tSunShadow, vec3(sc.xy, sc.z - 0.002));
}`;

// aInfo: tile, rotation, mirror, emissive
const SPRITE_FRAG = /* glsl */ `
${SHADOW_GLSL}
uniform sampler2D tAtlas; uniform vec3 uSunCol, uAmbCol, uFireCol, uFirePos;
varying vec4 vInfo; varying vec4 vCol; varying vec3 vWP; varying float vDepth;
void main() {
  vec2 pc = gl_PointCoord - 0.5;
  float c = cos(vInfo.y), s = sin(vInfo.y);
  pc = vec2(c * pc.x - s * pc.y, s * pc.x + c * pc.y);
  if (vInfo.z > 0.5) pc.x = -pc.x;
  pc += 0.5;
  if (pc.x < 0.0 || pc.y < 0.0 || pc.x > 1.0 || pc.y > 1.0) discard;
  vec2 cell = vec2(mod(vInfo.x, 8.0), floor(vInfo.x / 8.0));
  vec4 t = texture2D(tAtlas, vec2((cell.x + pc.x) / 8.0, 1.0 - (cell.y + pc.y) / 4.0));
  if (t.a < 0.5) discard;
  vec3 d = uFirePos - vWP;
  vec3 light = uAmbCol * 1.7 + uSunCol * sunVis(vWP) * 0.8 + uFireCol / (1.0 + dot(d, d) * 0.5);
  gl_FragColor = vec4(t.rgb * vCol.rgb * mix(light, vec3(1.0), vInfo.w), vCol.a);
}`;

const GLOW_FRAG = /* glsl */ `
${SHADOW_GLSL}
uniform vec3 uSunCol; uniform float uShaft;
varying vec4 vInfo; varying vec4 vCol; varying vec3 vWP; varying float vDepth;
void main() {
  vec2 pc = abs(gl_PointCoord - 0.5) * 2.0;
  if (max(pc.x, pc.y) > 1.0) discard;
  // dust: only glitters inside sun shafts; fireflies / embers: self-lit
  float k = vInfo.x > 0.5 ? 1.0 : sunVis(vWP) * uShaft;
  vec3 c = vInfo.x > 0.5 ? vCol.rgb : vCol.rgb * uSunCol;
  gl_FragColor = vec4(c * k * vCol.a, 1.0);
}`;

class Sprites {
  constructor(scene, n, mat) {
    this.n = n;
    const g = new THREE.BufferGeometry();
    this.pos = new Float32Array(n * 3);
    this.size = new Float32Array(n);
    this.info = new Float32Array(n * 4);
    this.col = new Float32Array(n * 4).fill(1);
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aSize', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aInfo', new THREE.BufferAttribute(this.info, 4).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aCol', new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    this.g = g;
    this.points = new THREE.Points(g, mat);
    this.points.frustumCulled = false;
    scene.add(this.points);
  }
  set(i, x, y, z, size, tile = 0, rot = 0, mirror = 0, r = 1, g = 1, b = 1, a = 1, emis = 0) {
    this.pos[i * 3] = x;
    this.pos[i * 3 + 1] = y;
    this.pos[i * 3 + 2] = z;
    this.size[i] = size;
    this.info[i * 4] = tile;
    this.info[i * 4 + 1] = rot;
    this.info[i * 4 + 2] = mirror;
    this.info[i * 4 + 3] = emis;
    this.col[i * 4] = r;
    this.col[i * 4 + 1] = g;
    this.col[i * 4 + 2] = b;
    this.col[i * 4 + 3] = a;
  }
  hide(i) {
    this.size[i] = 0;
    this.pos[i * 3 + 1] = -1000;
  }
  flush() {
    for (const k of ['position', 'aSize', 'aInfo', 'aCol']) this.g.attributes[k].needsUpdate = true;
  }
}

const P = T.PART;
const smooth = (t) => t * t * (3 - 2 * t);

export function buildLife(scene, { houses, lilyPads, quality }) {
  const atlas = T.particleAtlas().toTextures({ name: 'particles', normal: 0 });
  atlas.map.wrapS = atlas.map.wrapT = THREE.ClampToEdgeWrapping;
  atlas.map.minFilter = THREE.NearestFilter;
  atlas.map.generateMipmaps = false;
  const fireU = { uFireCol: { value: new THREE.Color(0, 0, 0) }, uFirePos: { value: new THREE.Vector3(FIRE.x, 0.6, FIRE.z) } };
  const common = { uProjScale: U.uProjScale, tSunShadow: U.tSunShadow, uSunShadowMat: U.uSunShadowMat, uSunCol: U.uSunCol, uAmbCol: U.uAmbCol, ...fireU };
  const spriteMat = new THREE.ShaderMaterial({ uniforms: { ...common, tAtlas: { value: atlas.map } }, vertexShader: SPRITE_VERT, fragmentShader: SPRITE_FRAG });
  const smokeMat = new THREE.ShaderMaterial({ uniforms: { ...common, tAtlas: { value: atlas.map } }, vertexShader: SPRITE_VERT, fragmentShader: SPRITE_FRAG, transparent: true, depthWrite: false });
  const glowMat = new THREE.ShaderMaterial({ uniforms: { ...common, uShaft: { value: 1 } }, vertexShader: SPRITE_VERT, fragmentShader: GLOW_FRAG, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const r = new RNG(9);
  const W = new THREE.Vector2();

  // --- falling leaves -----------------------------------------------------------
  const NL = 60;
  const leaves = new Sprites(scene, NL, spriteMat);
  const crowns = TREES.slice(0, 3);
  const L = [];
  const spawnLeaf = (l, initial) => {
    const tr = r.pick(crowns);
    const c = tr.crown;
    l.x = c[0] + r.float(-c[3], c[3]) * 0.8;
    l.y = c[1] + r.float(-c[4], 0.2) * 0.7;
    l.z = c[2] + r.float(-c[5], c[5]) * 0.6 + 1.5;
    if (initial) l.y -= r.float(0, 7);
    l.vy = -r.float(0.35, 0.65);
    l.ph = r.float(0, 7);
    l.spin = r.float(1.5, 4) * (r.chance(0.5) ? 1 : -1);
    l.tile = tr === TREES[1] || r.chance(0.25) ? 1 : 0;
    l.rest = 0;
  };
  for (let i = 0; i < NL; i++) {
    const l = {};
    spawnLeaf(l, true);
    L.push(l);
  }

  // --- butterflies: 12, three of them around the hero below 1.5 u -----------------------
  const homes = [
    [HERO.x - 1.6, 0.55, HERO.z + 1.2], [HERO.x + 1.4, 0.7, HERO.z + 1.6], [HERO.x + 0.6, 0.9, HERO.z - 1.6],
    [-4.0, T2_Y + 0.7, wallZ(-4) - 1.3], [6.2, T2_Y + 0.7, wallZ(6.2) - 1.4], [-9.0, T2_Y + 0.8, wallZ(-9) - 1.2],
    [POND.x + 2.6, 0.6, POND.z + 2.8], [POND.x - 3.0, 0.6, POND.z + 2.6], [8.4, 0.6, 5.0],
    [11.0, 0.6, 2.2], [-1.2, 0.7, 6.4], [6.4, 0.8, 1.0],
  ];
  const butterflies = new Sprites(scene, homes.length, spriteMat);
  const B = homes.map((h, i) => ({ h, ph: r.float(0, 10), sp: r.float(0.45, 0.8), base: P.fly[i % 3], land: 0, landT: r.float(3, 9) }));

  // --- swallows: a loose flock banking along visible air in front of the roofs, every 13 s ---------------------
  const NF = 7;
  const flock = new Sprites(scene, NF, spriteMat);
  const formation = Array.from({ length: NF }, (_, i) => [r.float(-1.8, 1.8) - i * 0.55, r.float(-0.6, 0.6), r.float(-1.2, 1.2), r.float(0, 6)]);
  const FLOCK_T = 13;

  // --- sparrows perched on the wall cap / fence near the hero; a gust (or a whim) sends them up --------------------
  const capY = T2_Y + 0.26;
  const perches = [
    [-0.2, capY, wallZ(-0.2) - 0.22], [0.35, capY, wallZ(0.35) - 0.22], [4.6, capY, wallZ(4.6) - 0.22],
    [5.3, capY, wallZ(5.3) - 0.22], [HERO.x - 1.3, groundY(HERO.x - 1.3, HERO.z + 0.4), HERO.z + 0.4], [HERO.x + 1.5, groundY(HERO.x + 1.5, HERO.z - 0.5), HERO.z - 0.5],
  ];
  const NS_ = 4;
  const sparrows = new Sprites(scene, NS_, spriteMat);
  const S = Array.from({ length: NS_ }, (_, i) => ({ slot: [0, 2, 4, 3][i], x: 0, y: 0, z: 0, state: 'sit', t: r.float(1, 4), dir: r.chance(0.5) ? 1 : -1, pose: 14, fly: null }));
  for (const s of S) [s.x, s.y, s.z] = perches[s.slot];
  const taken = new Set(S.map((s) => s.slot));

  // --- ducks on the pond --------------------------------------------------------------
  const ducks = new Sprites(scene, 2, spriteMat);
  const D = [{ a: 0.5, r: 0.55, sp: 0.05 }, { a: 2.6, r: 0.4, sp: -0.035 }];

  // --- chimney + campfire smoke, campfire embers -----------------------------------------
  const vents = houses.map((h) => h.userData.spec.smoke).filter(Boolean).map((p) => ({ p, k: 1 }));
  vents.push({ p: new THREE.Vector3(FIRE.x, groundY(FIRE.x, FIRE.z) + 1.1, FIRE.z), k: 0.55 });
  const NSm = 30;
  const smoke = new Sprites(scene, vents.length * NSm, smokeMat);
  const SM = [];
  for (let c = 0; c < vents.length; c++)
    for (let i = 0; i < NSm; i++) SM.push({ c, age: (i / NSm) * 7, life: 7, x: vents[c].p.x, y: vents[c].p.y + (i / NSm) * 3, z: vents[c].p.z, tile: P.smoke + (i % 2), rot: r.float(0, 6) });

  // --- glow: dust motes (in shafts), fireflies, embers -------------------------------------
  const ND = Math.round(320 * quality.particles);
  const NFF = 90;
  const NE = 26;
  const glow = new Sprites(scene, ND + NFF + NE, glowMat);
  const Dm = Array.from({ length: ND }, () => ({ x: r.float(-16, 16), y: r.float(0.3, 9), z: r.float(-16, 9), ph: r.float(0, 10) }));
  const FF = Array.from({ length: NFF }, () => {
    let x;
    let z;
    do {
      x = r.float(-16, 18);
      z = r.float(-8, 10);
    } while (waterDist(x, z) < -1.5);
    return { hx: x, hz: z, y: r.float(0.3, 1.8), ph: r.float(0, 10), sp: r.float(0.3, 0.8) };
  });
  const E = Array.from({ length: NE }, () => ({ age: r.float(0, 2), life: r.float(1.2, 2.2), x: 0, y: -100, z: 0 }));

  // --- dandelion seeds drifting through the shafts ---------------------------------------
  const NSd = 40;
  const seeds = new Sprites(scene, NSd, spriteMat);
  const Sd = Array.from({ length: NSd }, () => ({ x: r.float(-14, 16), y: r.float(0.5, 6), z: r.float(-8, 9), ph: r.float(0, 10) }));

  // --- rain (toggle) + splashes ------------------------------------------------------------
  const NR = Math.round(9000 * quality.particles);
  const rp = new Float32Array(NR * 2 * 3);
  const re = new Float32Array(NR * 2);
  for (let i = 0; i < NR; i++) {
    const x = r.next();
    const y = r.next();
    const z = r.next();
    rp.set([x, y, z, x, y, z], i * 6);
    re[i * 2 + 1] = 1;
  }
  const rg = new THREE.BufferGeometry();
  rg.setAttribute('position', new THREE.BufferAttribute(rp, 3));
  rg.setAttribute('aEnd', new THREE.BufferAttribute(re, 1));
  const rainU = { uTime: U.uTime, uRain: { value: 0 }, uWindDir: U.uWindDir, uSunCol: U.uSunCol, uAmbCol: U.uAmbCol, uFocus: { value: 40 } };
  const rain = new THREE.LineSegments(
    rg,
    new THREE.ShaderMaterial({
      uniforms: rainU,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: /* glsl */ `
        attribute float aEnd; uniform float uTime, uFocus; uniform vec2 uWindDir; varying float vA;
        void main() {
          vec3 box = vec3(56.0, 22.0, 34.0);
          vec3 o = vec3(-26.0, -1.0, -20.0);
          vec3 p = position;
          p.y = fract(p.y - uTime * (0.75 + p.x * 0.1));
          vec3 wp = o + p * box;
          wp.xz += uWindDir * (1.0 - p.y) * 2.0;
          wp += vec3(uWindDir.x * 0.08, 0.55, uWindDir.y * 0.08) * aEnd;
          vec4 mv = viewMatrix * vec4(wp, 1.0);
          // thinner beyond the focal region so the far tiers are not over-scratched
          vA = smoothstep(0.0, 0.05, p.y) * mix(1.0, 0.3, smoothstep(uFocus + 4.0, uFocus + 22.0, -mv.z));
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `uniform float uRain; uniform vec3 uSunCol, uAmbCol; varying float vA; void main(){ gl_FragColor = vec4((uAmbCol * 2.2 + uSunCol * 0.25) * 0.5 * uRain * vA, 1.0); }`,
    })
  );
  rain.frustumCulled = false;
  rain.visible = false;
  scene.add(rain);
  const NSp = 36;
  const splashes = new Sprites(scene, NSp, spriteMat);
  const Sp = Array.from({ length: NSp }, () => ({ age: r.float(0, 0.3), x: 0, y: -100, z: 0 }));

  // --- kite over the village (the studio's signature), string to a flyer's stake on the hill -------------------
  const kiteImg = T.cloth('kite');
  const kt = kiteImg.toTextures({ name: 'kite', normal: 0 });
  const kite = new THREE.Mesh(new THREE.PlaneGeometry(kiteImg.w / TPU, kiteImg.h / TPU), new THREE.MeshStandardMaterial({ map: kt.map, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.8 }));
  kite.castShadow = true;
  scene.add(kite);
  // the flyer's stake is on the terrace by the laundry; the kite rides downwind (+x, -z) over the slate house
  const anchor = new THREE.Vector3(4.6, T2_Y + 0.9, -6.4);
  const kiteBase = new THREE.Vector3(7.0, 6.6, -10.2);
  const strG = new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(new Float32Array(16 * 3), 3));
  const str = new THREE.Line(strG, new THREE.LineBasicMaterial({ color: 0xe8dcc0, transparent: true, opacity: 0.7 }));
  str.frustumCulled = false;
  scene.add(str);
  const tailN = 10;
  const tail = new Sprites(scene, tailN, spriteMat);

  return {
    rain,
    rainU,
    fireU,
    update(t, dt, camera, focus) {
      rainU.uFocus.value = focus;
      // leaves
      for (let i = 0; i < NL; i++) {
        const l = L[i];
        if (l.rest > 0) {
          l.rest -= dt;
          if (l.rest <= 0) spawnLeaf(l, false);
        } else {
          windAt(l.x, l.z, t, W);
          l.x += (W.x * 1.4 + Math.sin(t * 1.3 + l.ph) * 0.35) * dt;
          l.z += (W.y * 1.4 + Math.cos(t * 1.1 + l.ph) * 0.2) * dt;
          l.y += (l.vy + Math.sin(t * 2.0 + l.ph) * 0.25) * dt;
          const gy = Math.max(groundY(l.x, l.z), WATER_Y) + 0.03;
          if (l.y < gy) {
            l.y = gy;
            l.rest = r.float(2, 5);
          }
        }
        leaves.set(i, l.x, l.y, l.z, 1, P.leaf + l.tile, l.rest > 0 ? l.ph : t * l.spin + l.ph);
      }
      leaves.flush();
      // butterflies: wander around a flower home, flap open/half/closed, land now and then with wings folded
      for (let i = 0; i < B.length; i++) {
        const b = B[i];
        b.landT -= dt;
        if (b.landT < 0) {
          b.land = b.land ? 0 : 1;
          b.landT = b.land ? r.float(1.5, 3.5) : r.float(4, 10);
        }
        const tt = t * b.sp + b.ph;
        const x = b.h[0] + Math.sin(tt * 0.9) * 1.1 + Math.sin(tt * 2.3) * 0.25;
        const z = b.h[2] + Math.cos(tt * 0.7) * 0.7;
        const flutter = b.land ? 0 : Math.abs(Math.sin(t * 7 + b.ph)) * 0.14 + Math.sin(tt * 1.3) * 0.22 + 0.3;
        const y = b.h[1] + flutter;
        const ph = Math.floor(t * 14 + b.ph * 3) % 4;
        const frame = b.land ? (Math.sin(t * 1.5 + b.ph) > 0.6 ? 0 : 2) : [0, 1, 2, 1][ph];
        // butterflies roost at night (fireflies take over)
        if (U.uNight.value > 0.5) butterflies.hide(i);
        else butterflies.set(i, x, y, z, 1, b.base + frame, b.land ? 0 : Math.sin(tt * 2) * 0.2, Math.cos(tt * 0.9) < 0 ? 1 : 0);
      }
      butterflies.flush();
      // swallows: banking S-curve in front of the roofs; loose boids-style jitter around the leader
      const cyc = t % FLOCK_T;
      const u = cyc / 10.5;
      for (let i = 0; i < NF; i++) {
        const [ox, oy, oz, ph] = formation[i];
        if (u > 1) {
          flock.hide(i);
          continue;
        }
        const lx = -22 + u * 48;
        const ly = 5.1 + Math.sin(u * Math.PI * 2.2) * 0.7 - Math.sin(u * Math.PI) * 0.4;
        const lz = -3.4 + Math.sin(u * Math.PI * 1.3) * 1.2;
        const slope = Math.cos(u * Math.PI * 2.2) * 0.9 * 2.2 * Math.PI / 48;
        const jx = Math.sin(t * 1.3 + ph) * 0.4;
        const jy = Math.sin(t * 1.9 + ph * 2) * 0.25;
        const frame = Math.floor(t * 10 + ph * 3) % 4;
        flock.set(i, lx + ox + jx, ly + oy + jy, lz + oz, 1, P.bird + [0, 1, 2, 1][frame], -Math.atan(slope * 4), 0);
      }
      flock.flush();
      // sparrows
      for (let i = 0; i < NS_; i++) {
        const s = S[i];
        s.t -= dt;
        if (s.state === 'sit') {
          const gust = gustAt(s.x, s.z, t);
          if ((gust > 0.82 && r.chance(dt * 1.5)) || s.t < -12) {
            // take off: loop up over the terrace and come back to a free perch
            taken.delete(s.slot);
            const free = perches.map((_, k) => k).filter((k) => !taken.has(k));
            const to = r.pick(free);
            taken.add(to);
            s.fly = { from: [s.x, s.y, s.z], to: perches[to], T: 0, dur: r.float(3.5, 5.5), side: r.chance(0.5) ? 1 : -1 };
            s.slot = to;
            s.state = 'fly';
          } else if (s.t < 0) {
            s.t = r.float(0.8, 2.6);
            const roll = r.next();
            s.pose = roll < 0.35 ? 15 : roll < 0.55 ? 16 : 14;
            if (roll > 0.7) {
              s.hop = 0.3;
              s.dir = r.chance(0.5) ? 1 : -1;
            }
          }
          let jump = 0;
          if (s.hop > 0) {
            s.hop -= dt;
            const home = perches[s.slot];
            s.x = Math.min(Math.max(s.x + s.dir * dt * 0.9, home[0] - 0.4), home[0] + 0.4);
            jump = Math.sin(Math.max(s.hop, 0) / 0.3 * Math.PI) * 0.14;
          }
          sparrows.set(i, s.x, s.y + jump + 0.375 - 0.03, s.z, 1, s.pose, 0, s.dir < 0 ? 1 : 0);
        } else {
          const f = s.fly;
          f.T += dt / f.dur;
          const k = Math.min(f.T, 1);
          const e = smooth(k);
          const loop = Math.sin(k * Math.PI);
          s.x = f.from[0] + (f.to[0] - f.from[0]) * e + Math.sin(k * Math.PI * 2) * 2.2 * f.side;
          s.y = f.from[1] + (f.to[1] - f.from[1]) * e + loop * 3.2;
          s.z = f.from[2] + (f.to[2] - f.from[2]) * e - loop * 2.5;
          const frame = Math.floor(t * 12 + i) % 4;
          sparrows.set(i, s.x, s.y + 0.3, s.z, 1, P.bird + [0, 1, 2, 1][frame], 0, Math.cos(k * Math.PI * 2) * f.side < 0 ? 1 : 0);
          if (f.T >= 1) {
            s.state = 'sit';
            [s.x, s.y, s.z] = f.to;
            s.t = r.float(1, 3);
          }
        }
      }
      sparrows.flush();
      // ducks: slow circles, dabbling now and then
      for (let i = 0; i < 2; i++) {
        const d = D[i];
        d.a += d.sp * dt;
        const x = POND.x + Math.cos(d.a) * POND.rx * d.r;
        const z = POND.z + Math.sin(d.a) * POND.rz * d.r;
        const dab = Math.sin(t * 0.6 + i * 2.3) > 0.82 ? 1 : 0;
        const bob = Math.sin(t * 2 + i) * 0.015;
        ducks.set(i, x, WATER_Y + 0.26 + bob, z, 1, P.duck + dab, 0, Math.sin(d.a) * d.sp > 0 ? 1 : 0);
      }
      ducks.flush();
      // smoke
      for (let i = 0; i < SM.length; i++) {
        const p = SM[i];
        p.age += dt;
        const o = vents[p.c].p;
        if (p.age > p.life) {
          p.age = 0;
          p.x = o.x + r.float(-0.08, 0.08);
          p.y = o.y;
          p.z = o.z;
        }
        windAt(p.x, p.z, t, W);
        const k = p.age / p.life;
        p.x += W.x * dt * (0.4 + k * 1.2);
        p.z += W.y * dt * (0.4 + k * 1.2);
        p.y += dt * (0.5 + k * 0.25);
        const a = Math.min(p.age * 3, 1) * (1 - k) * (1 - k) * vents[p.c].k;
        smoke.set(i, p.x, p.y, p.z, (0.6 + k * 2.2) * (0.6 + 0.4 * vents[p.c].k), p.tile, p.rot + k * 1.5, 0, 1, 1, 1, a);
      }
      smoke.flush();
      // dust + fireflies + embers
      const night = U.uNight.value;
      for (let i = 0; i < ND; i++) {
        const d = Dm[i];
        windAt(d.x, d.z, t, W);
        d.x += (W.x * 0.25 + Math.sin(t * 0.5 + d.ph) * 0.05) * dt;
        d.y += Math.sin(t * 0.7 + d.ph * 2) * 0.04 * dt;
        d.z += W.y * 0.25 * dt;
        if (d.x > 16) d.x -= 32;
        if (d.x < -16) d.x += 32;
        if (d.z < -16) d.z += 25;
        if (d.z > 9) d.z -= 25;
        const tw = 0.55 + 0.45 * Math.sin(t * 2.3 + d.ph * 5);
        glow.set(i, d.x, d.y, d.z, 0.032, 0, 0, 0, 1.0, 0.85, 0.6, tw * 0.5);
      }
      const ffk = U.uGlow.value;
      for (let i = 0; i < NFF; i++) {
        const f = FF[i];
        const tt = t * f.sp + f.ph;
        const x = f.hx + Math.sin(tt * 0.7) * 1.2 + Math.sin(tt * 1.9) * 0.3;
        const z = f.hz + Math.cos(tt * 0.6) * 1.0;
        const y = Math.max(groundY(x, z), WATER_Y) + f.y + Math.sin(tt * 1.3) * 0.3;
        const blink = Math.max(0, Math.sin(t * 1.7 + f.ph * 4)) ** 3;
        glow.set(ND + i, x, y, z, 0.095, 1, 0, 0, 0.75 * ffk, 1.0 * ffk, 0.3 * ffk, blink * (0.2 + 0.8 * night) + 0.03);
      }
      for (let i = 0; i < NE; i++) {
        const e = E[i];
        e.age += dt;
        if (e.age > e.life) {
          e.age = 0;
          e.life = r.float(1.2, 2.4);
          e.x = FIRE.x + r.float(-0.2, 0.2);
          e.y = groundY(FIRE.x, FIRE.z) + 0.3;
          e.z = FIRE.z + r.float(-0.2, 0.2);
        }
        windAt(e.x, e.z, t, W);
        e.x += (W.x * 0.6 + Math.sin(t * 9 + i) * 0.3) * dt;
        e.z += W.y * 0.6 * dt;
        e.y += dt * (0.9 - e.age * 0.25);
        const k = 1 - e.age / e.life;
        glow.set(ND + NFF + i, e.x, e.y, e.z, 0.05, 1, 0, 0, 3.0, 1.2, 0.3, k * (0.4 + night * 0.6) * (Math.sin(t * 30 + i) > -0.3 ? 1 : 0.2));
      }
      glow.flush();
      // dandelion seeds
      for (let i = 0; i < NSd; i++) {
        const s = Sd[i];
        windAt(s.x, s.z, t, W);
        s.x += (W.x * 0.9 + Math.sin(t * 0.8 + s.ph) * 0.15) * dt;
        s.z += (W.y * 0.9) * dt;
        s.y += Math.sin(t * 0.9 + s.ph * 3) * 0.12 * dt;
        if (s.x > 18) {
          s.x = -14;
          s.z = r.float(-8, 9);
          s.y = r.float(0.5, 6);
        }
        if (s.z < -9) s.z += 18;
        if (s.z > 10) s.z -= 18;
        seeds.set(i, s.x, s.y, s.z, 1, P.seed, Math.sin(t * 2 + s.ph) * 0.4, 0, 1, 1, 1, 1);
      }
      seeds.flush();
      // rain splashes on the path around the hero
      const wet = rainU.uRain.value;
      for (let i = 0; i < NSp; i++) {
        const s = Sp[i];
        s.age += dt;
        if (s.age > 0.28) {
          s.age = r.float(-0.4, 0);
          s.x = HERO.x + r.float(-6, 6);
          s.z = pathZ(s.x) + r.float(-2.2, 2.2);
          if (onPath(s.x, s.z) > 0.6 && r.chance(0.6)) s.z = pathZ(s.x) + r.float(-1, 1);
          s.y = Math.max(groundY(s.x, s.z), WATER_Y);
        }
        if (wet < 0.3 || s.age < 0) splashes.hide(i);
        else splashes.set(i, s.x, s.y + 0.36, s.z, 1, P.splash, 0, 0, 1, 1, 1, 1, 0.6);
      }
      splashes.flush();
      // kite: drifts and dips with the gusts; string sags; ribbon tail
      windAt(kiteBase.x, kiteBase.z, t, W);
      const kx = kiteBase.x + Math.sin(t * 0.37) * 0.9 + W.x * 0.6;
      const ky = kiteBase.y + Math.sin(t * 0.53) * 0.4 + W.length() * 0.4;
      const kz = kiteBase.z + Math.sin(t * 0.29) * 0.4;
      kite.position.set(kx, ky, kz);
      kite.rotation.set(-0.25, Math.atan2(camera.position.x - kx, camera.position.z - kz), Math.sin(t * 1.7) * 0.25 + W.x * 0.15);
      const sp = strG.attributes.position;
      for (let i = 0; i < 16; i++) {
        const k = i / 15;
        sp.setXYZ(i, anchor.x + (kx - anchor.x) * k, anchor.y + (ky - 0.9 - anchor.y) * k - Math.sin(k * Math.PI) * 0.9, anchor.z + (kz - anchor.z) * k);
      }
      sp.needsUpdate = true;
      for (let i = 0; i < tailN; i++) {
        const k = (i + 1) / tailN;
        tail.set(i, kx - k * 0.3 + Math.sin(t * 4 - i * 0.8) * 0.25 * k, ky - 0.95 - k * 2.6, kz, 1, P.petal, t * 2 + i);
      }
      tail.flush();
      // things floating on the pond bob
      for (const p of lilyPads) p.m.position.y = WATER_Y + 0.015 + Math.sin(t * 1.1 + p.ph) * 0.012;
      for (const f of floaters) {
        f.obj.position.y = f.y + Math.sin(t * 0.9 + f.ph) * 0.02;
        f.obj.rotation.z = Math.sin(t * 0.7 + f.ph) * 0.02;
      }
    },
  };
}
