import * as THREE from 'three';

// One texel density for every environment texture and sprite: 32 texels = 1 world unit.
export const TPU = 32;

export class RNG {
  constructor(seed = 1) {
    this.s = seed >>> 0 || 1;
  }
  next() {
    let t = (this.s += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  float(a = 0, b = 1) {
    return a + (b - a) * this.next();
  }
  int(a, b) {
    return Math.floor(this.float(a, b + 1));
  }
  pick(a) {
    return a[Math.floor(this.next() * a.length)];
  }
  chance(p) {
    return this.next() < p;
  }
}

export const hex = (c) => (Array.isArray(c) ? c : [((c >> 16) & 255) / 255, ((c >> 8) & 255) / 255, (c & 255) / 255]);
export const mixc = (a, b, t) => {
  a = hex(a);
  b = hex(b);
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
};
// Hue-shifted ramp step: t < 0 darkens toward cool violet, t > 0 lightens toward warm butter.
const COOL = [0.13, 0.1, 0.24];
const WARM = [1.0, 0.93, 0.66];
export function tone(c, t) {
  c = hex(c);
  return t < 0 ? mixc(c, COOL, Math.min(-t, 1) * 0.75) : mixc(c, WARM, Math.min(t, 1) * 0.55);
}

export function smoothstep(a, b, x) {
  const t = Math.min(Math.max((x - a) / (b - a), 0), 1);
  return t * t * (3 - 2 * t);
}

// Value noise (cheap, deterministic) for CPU-side placement and painting.
function h2(x, y) {
  let n = (x * 374761393 + y * 668265263) | 0;
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}
export function vnoise(x, y) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = h2(xi, yi);
  const b = h2(xi + 1, yi);
  const c = h2(xi, yi + 1);
  const d = h2(xi + 1, yi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
export const fbm = (x, y) => vnoise(x, y) * 0.55 + vnoise(x * 2.1 + 7.3, y * 2.1 - 3.1) * 0.3 + vnoise(x * 4.3 - 1.7, y * 4.3 + 9.2) * 0.15;

// Multi-channel pixel painter: albedo / height / roughness / emissive.
// Height becomes a per-texel normal map so dot art reacts to real 3D light.
export class PixelImage {
  constructor(w, h, { wrap = true, transparent = false } = {}) {
    this.w = w;
    this.h = h;
    this.wrap = wrap;
    this.albedo = new Float32Array(w * h * 4);
    if (!transparent) for (let i = 0; i < w * h; i++) this.albedo[i * 4 + 3] = 1;
    this.height = new Float32Array(w * h);
    this.rough = new Float32Array(w * h).fill(0.9);
    this.emis = new Float32Array(w * h * 3);
    this.hasEmis = false;
  }
  idx(x, y) {
    x = Math.floor(x);
    y = Math.floor(y);
    if (this.wrap) {
      x = ((x % this.w) + this.w) % this.w;
      y = ((y % this.h) + this.h) % this.h;
    } else if (x < 0 || y < 0 || x >= this.w || y >= this.h) return -1;
    return y * this.w + x;
  }
  // b: { c: color, a: alpha, h: height, dh: height add, r: roughness, e: emissive color, ek: emissive gain, erase }
  px(x, y, b) {
    const i = this.idx(x, y);
    if (i < 0) return;
    if (b.c !== undefined) {
      const c = hex(b.c);
      const a = b.a === undefined ? 1 : b.a;
      const o = i * 4;
      this.albedo[o] += (c[0] - this.albedo[o]) * a;
      this.albedo[o + 1] += (c[1] - this.albedo[o + 1]) * a;
      this.albedo[o + 2] += (c[2] - this.albedo[o + 2]) * a;
      if (b.keepAlpha !== true) this.albedo[o + 3] = 1;
    }
    if (b.erase) this.albedo[i * 4 + 3] = 0;
    if (b.h !== undefined) this.height[i] = b.h;
    if (b.dh !== undefined) this.height[i] += b.dh;
    if (b.r !== undefined) this.rough[i] = b.r;
    if (b.e !== undefined) {
      const e = hex(b.e);
      const k = b.ek === undefined ? 1 : b.ek;
      this.emis[i * 3] = e[0] * k;
      this.emis[i * 3 + 1] = e[1] * k;
      this.emis[i * 3 + 2] = e[2] * k;
      this.hasEmis = true;
    }
  }
  get(x, y) {
    const i = this.idx(x, y);
    return i < 0 ? null : [this.albedo[i * 4], this.albedo[i * 4 + 1], this.albedo[i * 4 + 2], this.albedo[i * 4 + 3]];
  }
  rect(x, y, w, h, b) {
    for (let yy = Math.floor(y); yy < Math.floor(y) + h; yy++)
      for (let xx = Math.floor(x); xx < Math.floor(x) + w; xx++) {
        const r = typeof b === 'function' ? b(xx - Math.floor(x), yy - Math.floor(y), xx, yy) : b;
        if (r) this.px(xx, yy, r);
      }
  }
  disc(cx, cy, r, b) {
    for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++)
      for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
        const dx = x + 0.5 - cx;
        const dy = y + 0.5 - cy;
        const d = dx * dx + dy * dy;
        if (d > r * r) continue;
        const v = typeof b === 'function' ? b(dx, dy, Math.sqrt(d) / r) : b;
        if (v) this.px(x, y, v);
      }
  }
  line(x0, y0, x1, y1, b, thick = 1) {
    const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1);
    for (let s = 0; s <= n; s++) {
      const x = x0 + ((x1 - x0) * s) / n;
      const y = y0 + ((y1 - y0) * s) / n;
      if (thick <= 1) this.px(Math.round(x), Math.round(y), b);
      else this.disc(x, y, thick / 2, b);
    }
  }
  noise(rng, amt = 0.06) {
    for (let i = 0; i < this.w * this.h; i++) {
      const k = 1 + (rng.next() * 2 - 1) * amt;
      this.albedo[i * 4] *= k;
      this.albedo[i * 4 + 1] *= k;
      this.albedo[i * 4 + 2] *= k;
    }
  }
  blurHeight(passes = 1) {
    for (let p = 0; p < passes; p++) {
      const src = this.height.slice();
      for (let y = 0; y < this.h; y++)
        for (let x = 0; x < this.w; x++) {
          let s = 0;
          let n = 0;
          for (let oy = -1; oy <= 1; oy++)
            for (let ox = -1; ox <= 1; ox++) {
              const i = this.idx(x + ox, y + oy);
              if (i < 0) continue;
              s += src[i];
              n++;
            }
          this.height[y * this.w + x] = s / n;
        }
    }
  }
  toTextures({ normal = 2.0, name = 'tex' } = {}) {
    const { w, h } = this;
    const N = w * h;
    const alb = new Uint8Array(N * 4);
    const nrm = new Uint8Array(N * 4);
    const rgh = new Uint8Array(N * 4);
    const emi = this.hasEmis ? new Uint8Array(N * 4) : null;
    const to8 = (v) => Math.max(0, Math.min(255, Math.round(v * 255)));
    const H = (x, y) => {
      const i = this.idx(x, y);
      return i < 0 ? 0 : this.height[i];
    };
    for (let y = 0; y < h; y++) {
      const ty = h - 1 - y; // DataTexture row 0 = v 0 (bottom)
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        const o = (ty * w + x) * 4;
        // painted values are sRGB (hex palette), uploaded as SRGB textures
        for (let k = 0; k < 3; k++) alb[o + k] = to8(this.albedo[i * 4 + k]);
        alb[o + 3] = to8(this.albedo[i * 4 + 3]);
        const nx = -(H(x + 1, y) - H(x - 1, y)) * normal;
        const ny = (H(x, y + 1) - H(x, y - 1)) * normal;
        const l = Math.hypot(nx, ny, 1);
        nrm[o] = to8((nx / l) * 0.5 + 0.5);
        nrm[o + 1] = to8((ny / l) * 0.5 + 0.5);
        nrm[o + 2] = to8((1 / l) * 0.5 + 0.5);
        nrm[o + 3] = 255;
        rgh[o] = 255;
        rgh[o + 1] = to8(this.rough[i]);
        rgh[o + 2] = 0;
        rgh[o + 3] = 255;
        if (emi) {
          for (let k = 0; k < 3; k++) emi[o + k] = to8(this.emis[i * 3 + k]);
          emi[o + 3] = 255;
        }
      }
    }
    const mk = (data, srgb, label) => dataTex(data, w, h, { srgb, wrap: this.wrap, name: `${name}.${label}` });
    return {
      map: mk(alb, true, 'albedo'),
      normalMap: mk(nrm, false, 'normal'),
      roughnessMap: mk(rgh, false, 'rough'),
      emissiveMap: emi ? mk(emi, true, 'emissive') : null,
      w,
      h,
    };
  }
}

export function dataTex(data, w, h, { srgb = false, wrap = true, name = 'tex', mips = true } = {}) {
  const t = new THREE.DataTexture(data, w, h, THREE.RGBAFormat, THREE.UnsignedByteType);
  t.name = name;
  t.magFilter = THREE.NearestFilter; // crisp dot art when magnified (focal plane)
  t.minFilter = mips ? THREE.LinearMipmapLinearFilter : THREE.NearestFilter; // no shimmer when minified
  t.generateMipmaps = mips;
  t.wrapS = t.wrapT = wrap ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

// Standard lit material from a painted PixelImage.
export function pixMat(img, opts = {}) {
  const t = img.toTextures({ normal: opts.normal ?? 2, name: opts.name });
  const m = new THREE.MeshStandardMaterial({
    map: t.map,
    normalMap: t.normalMap,
    roughnessMap: t.roughnessMap,
    roughness: 1,
    metalness: 0,
    side: opts.side ?? THREE.FrontSide,
    alphaTest: opts.alphaTest ?? 0,
  });
  m.normalScale.set(1, 1);
  if (t.emissiveMap) {
    m.emissiveMap = t.emissiveMap;
    m.emissive = new THREE.Color(1, 1, 1);
    m.emissiveIntensity = opts.emissive ?? 2.5;
  }
  m.userData.tex = t;
  return m;
}

// Box with per-face UVs scaled so 1 unit = TPU texels of a (texW x texH) repeating texture.
export function texelBox(w, h, d, texW = 64, texH = 64) {
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv;
  const pos = g.attributes.position;
  const nrm = g.attributes.normal;
  for (let i = 0; i < uv.count; i++) {
    const nx = Math.abs(nrm.getX(i));
    const ny = Math.abs(nrm.getY(i));
    const x = pos.getX(i) + w / 2;
    const y = pos.getY(i) + h / 2;
    const z = pos.getZ(i) + d / 2;
    let u;
    let v;
    if (nx > 0.5) [u, v] = [z, y];
    else if (ny > 0.5) [u, v] = [x, z];
    else [u, v] = [x, y];
    uv.setXY(i, (u * TPU) / texW, (v * TPU) / texH);
  }
  return g;
}
