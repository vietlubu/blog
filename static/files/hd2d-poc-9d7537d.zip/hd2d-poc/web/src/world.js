import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { TPU, RNG, pixMat, texelBox, dataTex, smoothstep, vnoise } from './core.js';
import * as T from './textures.js';
import { U, LAYER } from './shared.js';
import { WIND_GLSL } from './wind.js';
import { BOX, WATER_Y, T2_Y, WALL, wallZ, isT1, BRIDGE, STAIRS, SPILL, POND, FIRE, pathZ, channelX, waterDist, channelDist, onPath, groundY } from './layout.js';
import { HOUSES, lightSpots, buildHouses, buildLightDecals } from './houses.js';

const HASH_GLSL = /* glsl */ `
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vn2(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash12(i), hash12(i + vec2(1, 0)), f.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), f.x), f.y); }
`;

function add(parent, geo, mat, { cast = true, receive = true } = {}) {
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = cast;
  m.receiveShadow = receive;
  parent.add(m);
  return m;
}

const injectWorldPos = (sh) => {
  sh.vertexShader = sh.vertexShader
    .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;')
    .replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;');
};

// ---------------------------------------------------------------------------
// Splat map: R path, G cobble, B depth inside water (0 shore .. 1 deep), A wet bank
// ---------------------------------------------------------------------------
function buildSplat() {
  const R = 8; // texels per unit
  const w = (BOX.x1 - BOX.x0) * R;
  const h = (BOX.z1 - BOX.z0) * R;
  const data = new Uint8Array(w * h * 4);
  const cobbleZone = (x, z) => {
    if (x > -2.6 && x < 15.5 && onPath(x, z) < 0) return 1; // village cobbles along the focal stretch
    const wz = wallZ(x);
    if (x > STAIRS.x0 - 0.1 && x < STAIRS.x1 + 0.1 && z < pathZ(x) && z > wz - 0.2) return 1; // spur to stairs
    if (z < wz && z > -8.6 && Math.abs(x - 2.5) < 0.75) return 1; // walk to door B
    return 0;
  };
  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) {
      const x = BOX.x0 + (i + 0.5) / R;
      const z = BOX.z0 + (j + 0.5) / R;
      const o = (j * w + i) * 4;
      const t1 = isT1(x, z);
      const p = t1 ? onPath(x, z) : 9;
      const cz = cobbleZone(x, z);
      let path = t1 ? smoothstep(0.35, -0.35, p) : 0;
      // trodden dirt yards in front of the cottage doors + the campfire clearing
      if (!t1 && z > -13) {
        const ea = Math.hypot((x + 10.4) / 1.7, (z + 4.6) / 0.9);
        const ec = Math.hypot((x - 9.0) / 1.6, (z + 5.4) / 0.9);
        path = Math.max(path, smoothstep(1.0, 0.7, Math.min(ea, ec) + (vnoise(x * 1.3, z * 1.3) - 0.5) * 0.3));
      }
      if (t1) path = Math.max(path, smoothstep(1.5, 1.1, Math.hypot(x - FIRE.x, z - FIRE.z) + (vnoise(x * 1.7, z * 1.7) - 0.5) * 0.4));
      path = Math.max(path, cz);
      const wd = t1 ? waterDist(x, z) : channelDist(x, z);
      data[o] = path * 255;
      data[o + 1] = cz * 255;
      data[o + 2] = wd < 0 ? Math.min(1, -wd / 2.2) * 255 : 0;
      data[o + 3] = wd > 0 ? smoothstep(0.9, 0.0, wd) * 255 : 255;
    }
  const tex = dataTex(data, w, h, { wrap: false, mips: false, name: 'splat' });
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearFilter;
  U.tSplat.value = tex;
  U.uSplatBox.value.set(BOX.x0, BOX.z0, 1 / (BOX.x1 - BOX.x0), 1 / (BOX.z1 - BOX.z0));
}

// ---------------------------------------------------------------------------
// Terrain: one heightfield, world-space UVs (Octopath master-material trick: texels never rotate,
// no seams), splat-driven path/cobble with per-texel dithered edges, low-frequency gradient tint.
// ---------------------------------------------------------------------------
function buildTerrain(scene) {
  const step = 0.25;
  const nx = Math.round((BOX.x1 - BOX.x0) / step);
  const nz = Math.round((BOX.z1 - BOX.z0) / step);
  const g = new THREE.PlaneGeometry(BOX.x1 - BOX.x0, BOX.z1 - BOX.z0, nx, nz);
  g.rotateX(-Math.PI / 2);
  g.translate((BOX.x0 + BOX.x1) / 2, 0, (BOX.z0 + BOX.z1) / 2);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) pos.setY(i, groundY(pos.getX(i), pos.getZ(i)));
  g.computeVertexNormals();
  const grass = T.grassGround().toTextures({ normal: 1.5 });
  const dirt = T.dirt().toTextures({ normal: 2 });
  const cob = T.cobble().toTextures({ normal: 2.5 });
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, metalness: 0 });
  const u = {
    tGrass: { value: grass.map },
    tGrassN: { value: grass.normalMap },
    tDirt: { value: dirt.map },
    tDirtN: { value: dirt.normalMap },
    tCob: { value: cob.map },
    tCobN: { value: cob.normalMap },
    tSplat: U.tSplat,
    uSplatBox: U.uSplatBox,
    uWet: U.uWet,
    uTime: U.uTime,
    tReflBlur: U.tReflBlur,
    uReflMatrix: U.uReflMatrix,
  };
  mat.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, u);
    injectWorldPos(sh);
    sh.fragmentShader = sh.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform sampler2D tGrass, tGrassN, tDirt, tDirtN, tCob, tCobN, tSplat, tReflBlur;
        uniform vec4 uSplatBox; uniform float uWet; uniform float uTime; uniform mat4 uReflMatrix;
        varying vec3 vWPos;
        ${HASH_GLSL}
        vec4 gSp; float gPath; float gCob; vec2 gTuv; float gPuddle;`
      )
      .replace(
        '#include <map_fragment>',
        /* glsl */ `
        vec2 tq = floor(vWPos.xz * 32.0);
        vec2 wc = (tq + 0.5) / 32.0;
        gSp = texture2D(tSplat, (wc - uSplatBox.xy) * uSplatBox.zw);
        float jit = hash12(tq) * 0.36 - 0.18;
        gPath = step(0.5, gSp.r + jit);
        gCob = step(0.5, gSp.g + jit * 0.5) * gPath;
        gTuv = vWPos.xz * 0.5;
        vec3 cG = texture2D(tGrass, gTuv).rgb;
        vec3 cD = texture2D(tDirt, gTuv).rgb;
        vec3 cC = texture2D(tCob, gTuv).rgb;
        vec3 col = mix(cG, mix(cD, cC, gCob), gPath);
        // gradient tint breaks 64-texel repetition (warm sunlit meadow vs cool lush patches)
        float tn = vn2(vWPos.xz * 0.07);
        float tn2 = vn2(vWPos.xz * 0.23 + 7.0);
        vec3 tint = mix(vec3(0.82, 0.98, 0.92), vec3(1.16, 1.05, 0.78), tn) * (0.9 + 0.2 * tn2);
        col *= mix(tint, vec3(1.0), gPath * 0.7);
        // damp earth near water, darker below the waterline
        col *= mix(1.0, 0.55, gSp.a * (1.0 - gPath * 0.5));
        col = mix(col, col * vec3(0.45, 0.6, 0.5), gSp.b > 0.0 ? 1.0 : 0.0);
        // rain puddles collect in the path ruts
        gPuddle = uWet * smoothstep(0.55, 0.62, vn2(wc * 1.3) * 0.7 + vn2(wc * 4.0) * 0.3) * (0.4 + 0.6 * gPath);
        col *= mix(1.0, 0.62, uWet);
        col = mix(col, col * 0.3, gPuddle);
        diffuseColor.rgb *= col;
        `
      )
      .replace(
        '#include <roughnessmap_fragment>',
        /* glsl */ `float roughnessFactor = mix(0.95, mix(0.88, 0.62, gCob), gPath);
        roughnessFactor = mix(roughnessFactor, 0.35, gSp.a * 0.7);
        roughnessFactor = mix(roughnessFactor, roughnessFactor * 0.5, uWet);
        roughnessFactor = mix(roughnessFactor, 0.05, gPuddle);`
      )
      .replace(
        '#include <normal_fragment_maps>',
        /* glsl */ `
        {
          vec3 nG = texture2D(tGrassN, gTuv).xyz;
          vec3 nD = texture2D(tDirtN, gTuv).xyz;
          vec3 nC = texture2D(tCobN, gTuv).xyz;
          vec3 nt = mix(nG, mix(nD, nC, gCob), gPath) * 2.0 - 1.0;
          nt.xy *= (1.0 - gPuddle);
          vec3 Nw = inverseTransformDirection(normal, viewMatrix);
          vec3 Tw = normalize(vec3(1.0, 0.0, 0.0) - Nw * Nw.x);
          vec3 Bw = cross(Tw, Nw);
          vec3 nw = normalize(Tw * nt.x + Bw * nt.y + Nw * nt.z);
          normal = normalize((viewMatrix * vec4(nw, 0.0)).xyz);
        }`
      )
      .replace(
        '#include <opaque_fragment>',
        /* glsl */ `
        if (gPuddle > 0.01) {
          vec4 rc = uReflMatrix * vec4(vWPos, 1.0);
          vec3 refl = texture2D(tReflBlur, rc.xy / rc.w).rgb;
          float NoV = clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0);
          float F = 0.04 + 0.96 * pow(1.0 - NoV, 5.0);
          outgoingLight += refl * gPuddle * mix(0.35, 1.0, F);
        }
        #include <opaque_fragment>`
      );
  };
  mat.customProgramCacheKey = () => 'terrain';
  const m = add(scene, g, mat, { cast: true, receive: true });
  m.name = 'terrain';
  return m;
}

// ---------------------------------------------------------------------------
// Water: planar reflection + pixel-quantised ripple normals + Fresnel + GGX sun glints
// ---------------------------------------------------------------------------
export function makeWaterMaterial({ flow = 0.25 } = {}) {
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.06, metalness: 0 });
  const u = {
    tReflSharp: U.tReflSharp,
    tReflBlur: U.tReflBlur,
    uReflMatrix: U.uReflMatrix,
    tSplat: U.tSplat,
    uSplatBox: U.uSplatBox,
    uTime: U.uTime,
    tNoise3D: U.tNoise3D,
    uWet: U.uWet,
    uFlow: { value: flow },
    uNight: U.uNight,
    uSunDir: U.uSunDir,
    uSunCol: U.uSunCol,
  };
  mat.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, u);
    injectWorldPos(sh);
    sh.fragmentShader = sh.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        precision highp sampler3D;
        uniform sampler2D tReflSharp, tReflBlur, tSplat; uniform sampler3D tNoise3D;
        uniform mat4 uReflMatrix; uniform vec4 uSplatBox; uniform float uTime, uFlow, uWet, uNight; uniform vec3 uSunDir, uSunCol;
        varying vec3 vWPos;
        ${HASH_GLSL}
        float gDepth; float gFoam;
        float wh(vec2 p) {
          vec2 f = vec2(0.0, uTime * uFlow);
          return texture(tNoise3D, vec3((p - f) * 0.23, uTime * 0.03)).r * 0.65
               + texture(tNoise3D, vec3((p - f * 1.6) * 0.71 + 3.1, uTime * 0.05 + 0.4)).r * 0.35;
        }
        vec2 rings(vec2 p, float t) {
          vec2 g = vec2(0.0);
          for (int k = 0; k < 2; k++) {
            vec2 q = p * 0.55 + float(k) * vec2(0.37, 0.71);
            vec2 cell = floor(q);
            float h = hash12(cell + float(k) * 17.0);
            float ph = fract(t * (0.12 + h * 0.08) + h * 7.0);
            vec2 d = fract(q) - 0.5 - (vec2(hash12(cell + 3.1), hash12(cell + 7.7)) - 0.5) * 0.4;
            float r = length(d);
            float x = r - ph * 0.45;
            g += cos(x * 60.0) * exp(-x * x * 300.0) * (1.0 - ph) * d / max(r, 1e-3);
          }
          return g;
        }`
      )
      .replace(
        '#include <map_fragment>',
        /* glsl */ `
        vec2 tq = floor(vWPos.xz * 32.0);
        vec2 wc = (tq + 0.5) / 32.0;
        vec4 sp = texture2D(tSplat, (wc - uSplatBox.xy) * uSplatBox.zw);
        gDepth = sp.b;
        vec3 shallow = vec3(0.03, 0.06, 0.055);
        vec3 deep = vec3(0.008, 0.022, 0.03);
        diffuseColor.rgb = mix(shallow, deep, smoothstep(0.0, 0.45, gDepth));
        float fn = texture(tNoise3D, vec3(wc * 0.45 - vec2(0.0, uTime * uFlow * 0.4), uTime * 0.04)).r;
        gFoam = step(gDepth, 0.012 + fn * 0.04) * step(0.62, hash12(tq + floor(uTime * 3.0)) + fn * 0.3);
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.62, 0.66, 0.6), gFoam * 0.8);
        `
      )
      .replace(
        '#include <roughnessmap_fragment>',
        `float roughnessFactor = mix(0.07, 0.6, gFoam);`
      )
      .replace(
        '#include <normal_fragment_maps>',
        /* glsl */ `
        {
          vec2 q = (floor(vWPos.xz * 16.0) + 0.5) / 16.0; // 2-texel ripple pixels
          float e = 0.12;
          float h0 = wh(q);
          vec2 g = vec2(wh(q + vec2(e, 0.0)) - h0, wh(q + vec2(0.0, e)) - h0) * 4.0;
          g += rings(q, uTime) * (0.25 + uWet * 1.6);
          vec3 nw = normalize(vec3(-g.x * 0.5, 1.0, -g.y * 0.5));
          normal = normalize((viewMatrix * vec4(nw, 0.0)).xyz);
        }`
      )
      .replace(
        '#include <opaque_fragment>',
        /* glsl */ `
        {
          vec4 rc = uReflMatrix * vec4(vWPos, 1.0);
          vec3 nW = inverseTransformDirection(normal, viewMatrix);
          vec2 ruv = rc.xy / rc.w + nW.xz * vec2(0.012, 0.022);
          vec3 refl = mix(texture2D(tReflSharp, ruv).rgb, texture2D(tReflBlur, ruv).rgb, 0.12 + uWet * 0.3);
          float NoV = clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0);
          float F = 0.02 + 0.98 * pow(1.0 - NoV, 5.0);
          float k = mix(0.72, 1.0, F) * (1.0 - gFoam * 0.85) * smoothstep(0.0, 0.05, gDepth + 0.02);
          outgoingLight = outgoingLight * (1.0 - k * 0.6) + refl * k;
          // sun glints: wide reflection lobe x sparse twinkling 2-texel cells x real sun visibility
          vec3 Rv = reflect(normalize(vWPos - cameraPosition), nW);
          float lobe = pow(max(dot(Rv, uSunDir), 0.0), 40.0);
          vec2 gc = floor(vWPos.xz * 16.0);
          float sparkle = step(0.86, hash12(gc + floor(uTime * 5.0 + hash12(gc) * 5.0)));
          float vis = 1.0;
          #if NUM_DIR_LIGHT_SHADOWS > 0
            vis = getShadow(directionalShadowMap[0], directionalLightShadows[0].shadowMapSize, directionalLightShadows[0].shadowIntensity, directionalLightShadows[0].shadowBias, directionalLightShadows[0].shadowRadius, vDirectionalShadowCoord[0]);
          #endif
          outgoingLight += uSunCol * lobe * sparkle * vis * (1.0 - gFoam) * 14.0 * (1.0 - uNight * 0.7);
        }
        #include <opaque_fragment>`
      );
  };
  mat.customProgramCacheKey = () => 'water';
  return mat;
}

function buildWater(scene) {
  const g = new THREE.PlaneGeometry(POND.rx * 2 + 7, 12.6, 1, 1);
  g.rotateX(-Math.PI / 2);
  g.translate(POND.x, WATER_Y, 2.5);
  const m = add(scene, g, makeWaterMaterial({ flow: 0.18 }), { cast: false, receive: true });
  m.layers.set(LAYER.WATER);
  // T2 channel (feeds the waterfall and the water wheel)
  const cg = new THREE.PlaneGeometry(2.2, 10.4);
  cg.rotateX(-Math.PI / 2);
  cg.translate(-6.4, T2_Y - 0.25, -8.6);
  const c = add(scene, cg, makeWaterMaterial({ flow: 0.6 }), { cast: false, receive: true });
  c.layers.set(LAYER.WATER);
  // waterfall sheet over the spillway
  const fg = new THREE.PlaneGeometry(SPILL.x1 - SPILL.x0 - 0.12, T2_Y - 0.25 - WATER_Y + 0.05, 1, 6);
  const fm = new THREE.ShaderMaterial({
    uniforms: { uTime: U.uTime, uSunCol: U.uSunCol, uAmbCol: U.uAmbCol },
    transparent: true,
    depthWrite: false,
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; vec3 p = position; p.z += (1.0 - uv.y) * (1.0 - uv.y) * 0.35; gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0); }`,
    fragmentShader: /* glsl */ `
      uniform float uTime; uniform vec3 uSunCol; uniform vec3 uAmbCol; varying vec2 vUv;
      float h(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 45758.5); }
      void main(){
        vec2 px = floor(vUv * vec2(42.0, 40.0));
        float col = px.x;
        float sp = 0.8 + h(vec2(col, 1.0)) * 0.9;
        float streak = h(vec2(col, floor(px.y * 0.25 + uTime * 9.0 * sp)));
        float a = mix(0.45, 0.95, step(0.55, streak));
        float foam = smoothstep(0.25, 0.0, vUv.y);
        vec3 c = mix(vec3(0.3, 0.45, 0.45) * uAmbCol * 2.0 + uSunCol * 0.15, vec3(0.9, 0.95, 0.92) * (uAmbCol + uSunCol * 0.6), max(step(0.82, streak), foam));
        gl_FragColor = vec4(c, a * (0.75 + foam * 0.25));
      }`,
  });
  const f = new THREE.Mesh(fg, fm);
  f.position.set((SPILL.x0 + SPILL.x1) / 2, (T2_Y - 0.25 + WATER_Y) / 2, wallZ(SPILL.x0) + 0.06);
  scene.add(f);
}

// ---------------------------------------------------------------------------
// Stone: retaining wall, spillway, stairs, bridge
// ---------------------------------------------------------------------------
function buildStonework(scene, mats) {
  // wall runs (stepped in z), cut for the spillway and the stairs, plus short return walls at each step
  const runs = [];
  for (const s of WALL) {
    let cuts = [[s.x0, s.x1]];
    for (const [c0, c1] of [[SPILL.x0, SPILL.x1], [STAIRS.x0, STAIRS.x1]])
      cuts = cuts.flatMap(([a, b]) => (c1 <= a || c0 >= b ? [[a, b]] : [[a, c0], [c1, b]].filter(([p, q]) => q - p > 0.01)));
    for (const [a, b] of cuts) runs.push([a, b, s.z]);
  }
  const geos = [];
  const capGeos = [];
  const top = T2_Y + 0.12;
  const bot = -0.6;
  const T = 0.5;
  for (const [a, b, z] of runs) {
    const g = texelBox(b - a, top - bot, T);
    g.translate((a + b) / 2, (top + bot) / 2, z - T / 2);
    geos.push(g);
    const c = texelBox(b - a, 0.14, T + 0.12);
    c.translate((a + b) / 2, top + 0.07, z - T / 2 + 0.02);
    capGeos.push(c);
  }
  for (let i = 1; i < WALL.length; i++) {
    const x = WALL[i].x0;
    const z0 = Math.max(WALL[i - 1].z, WALL[i].z);
    const z1 = Math.min(WALL[i - 1].z, WALL[i].z) - T;
    const xo = x + (WALL[i].z > WALL[i - 1].z ? T / 2 : -T / 2);
    const g = texelBox(T, top - bot, z0 - z1);
    g.translate(xo, (top + bot) / 2, (z0 + z1) / 2);
    geos.push(g);
    const c = texelBox(T + 0.12, 0.14, z0 - z1 + 0.06);
    c.translate(xo, top + 0.07, (z0 + z1) / 2);
    capGeos.push(c);
  }
  // spillway lip
  const wz = wallZ(SPILL.x0);
  const s = texelBox(SPILL.x1 - SPILL.x0, T2_Y - 0.3 - bot, 0.7);
  s.translate((SPILL.x0 + SPILL.x1) / 2, (T2_Y - 0.3 + bot) / 2, wz - 0.3);
  geos.push(s);
  // stairs up to the terrace, inside the recess
  const sz = wallZ(STAIRS.x0);
  for (let i = 0; i < 4; i++) {
    const h = ((i + 1) * T2_Y) / 4 + 0.3;
    const front = sz + (3 - i) * 0.36 + 0.36;
    const back = sz - 0.5;
    const g = texelBox(STAIRS.x1 - STAIRS.x0, h, front - back);
    g.translate((STAIRS.x0 + STAIRS.x1) / 2, h / 2 - 0.3, (front + back) / 2);
    capGeos.push(g);
  }
  add(scene, mergeGeometries(geos), mats.wall);
  add(scene, mergeGeometries(capGeos), mats.wallCap);
  buildBridge(scene, mats);
}

function buildBridge(scene, mats) {
  const { x: bx, L, W, rise } = BRIDGE;
  const zc = pathZ(bx);
  const N = 28;
  const half = L / 2;
  const archHalf = 1.55;
  const deckY = (x) => 0.08 + rise * Math.cos(((x - bx) / L) * Math.PI);
  const archY = (x) => {
    const u = (x - bx) / archHalf;
    return Math.abs(u) < 1 ? WATER_Y - 0.25 + 0.95 * Math.sqrt(1 - u * u) : WATER_Y - 0.7;
  };
  const para = 0.42;
  const pt = 0.22;
  const pos = [];
  const uv = [];
  const k = TPU / 64;
  const quad = (a, b, c, d, uva, uvb, uvc, uvd) => {
    pos.push(...a, ...b, ...c, ...a, ...c, ...d);
    uv.push(...uva, ...uvb, ...uvc, ...uva, ...uvc, ...uvd);
  };
  const deckPos = [];
  const deckUv = [];
  for (let i = 0; i < N; i++) {
    const x0 = bx - half + (L * i) / N;
    const x1 = bx - half + (L * (i + 1)) / N;
    const t0 = deckY(x0) + para;
    const t1 = deckY(x1) + para;
    const b0 = archY(x0);
    const b1 = archY(x1);
    // outer faces (front +z, back -z)
    for (const [z, s] of [[zc + W / 2, 1], [zc - W / 2, -1]]) {
      const A = [x0, b0, z];
      const B = [x1, b1, z];
      const C = [x1, t1, z];
      const D = [x0, t0, z];
      if (s > 0) quad(A, B, C, D, [x0 * k, b0 * k], [x1 * k, b1 * k], [x1 * k, t1 * k], [x0 * k, t0 * k]);
      else quad(B, A, D, C, [x1 * k, b1 * k], [x0 * k, b0 * k], [x0 * k, t0 * k], [x1 * k, t1 * k]);
    }
    // parapet tops + inner faces
    for (const [zo, zi, s] of [[zc + W / 2, zc + W / 2 - pt, 1], [zc - W / 2, zc - W / 2 + pt, -1]]) {
      const A = [x0, t0, zi];
      const B = [x1, t1, zi];
      const C = [x1, t1, zo];
      const D = [x0, t0, zo];
      if (s > 0) quad(A, B, C, D, [x0 * k, zi * k], [x1 * k, zi * k], [x1 * k, zo * k], [x0 * k, zo * k]);
      else quad(B, A, D, C, [x1 * k, zi * k], [x0 * k, zi * k], [x0 * k, zo * k], [x1 * k, zo * k]);
      const d0 = deckY(x0);
      const d1 = deckY(x1);
      const E = [x0, d0, zi];
      const F = [x1, d1, zi];
      if (s > 0) quad(F, E, A, B, [x1 * k, d1 * k], [x0 * k, d0 * k], [x0 * k, t0 * k], [x1 * k, t1 * k]);
      else quad(E, F, B, A, [x0 * k, d0 * k], [x1 * k, d1 * k], [x1 * k, t1 * k], [x0 * k, t0 * k]);
    }
    // arch soffit
    if (Math.abs((x0 + x1) / 2 - bx) < archHalf) {
      const A = [x0, b0, zc - W / 2];
      const B = [x1, b1, zc - W / 2];
      const C = [x1, b1, zc + W / 2];
      const D = [x0, b0, zc + W / 2];
      quad(A, D, C, B, [x0 * k, 0], [x0 * k, W * k], [x1 * k, W * k], [x1 * k, 0]);
    }
    // deck (cobbled)
    {
      const d0 = deckY(x0);
      const d1 = deckY(x1);
      const za = zc - W / 2 + pt;
      const zb = zc + W / 2 - pt;
      deckPos.push(x0, d0, zb, x1, d1, zb, x1, d1, za, x0, d0, zb, x1, d1, za, x0, d0, za);
      const u0 = x0 * k;
      const u1 = x1 * k;
      deckUv.push(u0, zb * k, u1, zb * k, u1, za * k, u0, zb * k, u1, za * k, u0, za * k);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.computeVertexNormals();
  add(scene, g, mats.bridge);
  const dg = new THREE.BufferGeometry();
  dg.setAttribute('position', new THREE.Float32BufferAttribute(deckPos, 3));
  dg.setAttribute('uv', new THREE.Float32BufferAttribute(deckUv, 2));
  dg.computeVertexNormals();
  add(scene, dg, mats.cobble);
}

// ---------------------------------------------------------------------------
// Props: lanterns, bench, crates, barrels, fence, signpost, laundry, banner, water wheel, windmill
// ---------------------------------------------------------------------------
export const lanterns = [];
function lantern(scene, mats, x, z, y = groundY(x, z), { hang = false, h = 2.15 } = {}) {
  if (!hang) {
    const post = add(scene, texelBox(0.14, h, 0.14), mats.timber);
    post.position.set(x, y + h / 2, z);
    const base = add(scene, texelBox(0.3, 0.2, 0.3), mats.wallCap);
    base.position.set(x, y + 0.1, z);
    const arm = add(scene, texelBox(0.5, 0.08, 0.08), mats.timber);
    arm.position.set(x + 0.2, y + h - 0.05, z);
  }
  const lx = hang ? x : x + 0.38;
  const ly = hang ? y : y + h - 0.38;
  const cage = add(scene, texelBox(0.32, 0.06, 0.32), mats.iron);
  cage.position.set(lx, ly + 0.24, z);
  const roofc = add(scene, new THREE.ConeGeometry(0.26, 0.18, 4), mats.iron);
  roofc.position.set(lx, ly + 0.36, z);
  roofc.rotation.y = Math.PI / 4;
  const glass = add(scene, new THREE.BoxGeometry(0.24, 0.36, 0.24), mats.lanternGlass, { cast: false });
  glass.position.set(lx, ly, z);
  const bot = add(scene, texelBox(0.3, 0.05, 0.3), mats.iron);
  bot.position.set(lx, ly - 0.2, z);
  // explicit light budget: path lanterns are real point lights (stylised 1.5 falloff, 12 u reach); hanging
  // lanterns only glow in the fog, rim the hero and paint a light-pool decal
  let light;
  if (hang) light = { color: new THREE.Color(0xffa04a), intensity: 4 };
  else {
    light = new THREE.PointLight(0xffa04a, 4, 12, 1.5);
    light.position.set(lx, ly - 0.05, z + 0.05);
    scene.add(light);
  }
  const L = { pos: new THREE.Vector3(lx, ly, z), light, color: new THREE.Color(1.0, 0.6, 0.28), kind: 'lantern', hang, flick: Math.random() * 10 };
  lanterns.push(L);
  lightSpots.push(L);
  return L;
}

// Campfire: stone ring, crossed logs, a pixel flame billboard (procedural, 32 tpu), a flickering warm light.
export const fire = { pos: new THREE.Vector3(FIRE.x, groundY(FIRE.x, FIRE.z) + 0.55, FIRE.z), color: new THREE.Color(1.0, 0.55, 0.22), kind: 'fire', flick: 3.7 };
function buildFire(scene, mats) {
  const gy = groundY(FIRE.x, FIRE.z);
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2;
    const s = add(scene, new THREE.DodecahedronGeometry(0.15 + (i % 3) * 0.03, 0), mats.wallCap);
    s.position.set(FIRE.x + Math.cos(a) * 0.5, gy + 0.06, FIRE.z + Math.sin(a) * 0.5);
    s.rotation.set(i, i * 2.1, 0);
  }
  for (const r of [0.5, -0.6]) {
    const lg = add(scene, new THREE.CylinderGeometry(0.07, 0.08, 0.8, 6).rotateZ(Math.PI / 2), mats.plank);
    lg.position.set(FIRE.x, gy + 0.1, FIRE.z);
    lg.rotation.y = r;
  }
  const seat = add(scene, new THREE.CylinderGeometry(0.2, 0.22, 1.4, 8).rotateZ(Math.PI / 2), mats.plank);
  seat.position.set(FIRE.x + 0.1, gy + 0.18, FIRE.z - 1.05);
  seat.rotation.y = 0.15;
  const stump = add(scene, new THREE.CylinderGeometry(0.24, 0.27, 0.42, 8), mats.plank);
  stump.position.set(FIRE.x + 1.15, gy + 0.21, FIRE.z - 0.15);
  const flame = new THREE.Mesh(
    new THREE.PlaneGeometry(29 / 32, 38 / 32).translate(0, 19 / 32, 0),
    new THREE.ShaderMaterial({
      uniforms: { uTime: U.uTime, uK: { value: 1 } },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          vec3 right = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]);
          vec3 wp = (modelMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz + normalize(vec3(right.x, 0.0, right.z)) * position.x + vec3(0.0, position.y, 0.0);
          gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
        }`,
      fragmentShader: /* glsl */ `
        uniform float uTime, uK; varying vec2 vUv;
        float h(vec2 p) { return fract(sin(dot(p, vec2(41.3, 289.1))) * 45758.5); }
        float n(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
          return mix(mix(h(i), h(i + vec2(1, 0)), f.x), mix(h(i + vec2(0, 1)), h(i + vec2(1, 1)), f.x), f.y); }
        void main() {
          vec2 px = floor(vUv * vec2(29.0, 38.0));
          vec2 q = (px + 0.5) / vec2(29.0, 38.0);
          float t = floor(uTime * 12.0) / 12.0;
          float turb = n(vec2(q.x * 6.0, q.y * 4.0 - t * 5.0)) * 0.6 + n(vec2(q.x * 13.0, q.y * 9.0 - t * 9.0)) * 0.4;
          float w = (0.42 - q.y * 0.36) * (0.75 + 0.5 * turb);
          float d = abs(q.x - 0.5 + (turb - 0.5) * 0.18 * q.y) - w;
          float body = step(d, 0.0) * step(q.y, 0.92 - turb * 0.25);
          if (body < 0.5) discard;
          float heat = clamp(-d / max(w, 0.01) * 1.2 + (1.0 - q.y) * 0.5, 0.0, 1.0);
          vec3 c = heat > 0.7 ? vec3(1.0, 0.92, 0.6) : heat > 0.4 ? vec3(1.0, 0.62, 0.18) : heat > 0.18 ? vec3(0.95, 0.32, 0.08) : vec3(0.6, 0.12, 0.05);
          gl_FragColor = vec4(c * (2.0 + heat * 4.0) * uK, 1.0);
        }`,
    })
  );
  flame.position.set(FIRE.x, gy + 0.05, FIRE.z);
  flame.frustumCulled = false;
  flame.renderOrder = 3;
  scene.add(flame);
  fire.flame = flame;
  fire.light = new THREE.PointLight(0xff9a4a, 10, 12, 1.5);
  fire.light.position.copy(fire.pos);
  scene.add(fire.light);
  lanterns.push(fire);
  lightSpots.push(fire);
}

function crate(scene, mats, x, y, z, s = 0.7, rot = 0) {
  const c = add(scene, texelBox(s, s, s), mats.crate);
  c.position.set(x, y + s / 2, z);
  c.rotation.y = rot;
}
function barrel(scene, mats, x, y, z) {
  const g = new THREE.CylinderGeometry(0.34, 0.3, 0.86, 12, 1);
  const uv = g.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * ((2 * Math.PI * 0.34 * TPU) / 64), uv.getY(i) * ((0.86 * TPU) / 64));
  const b = add(scene, g, mats.plank);
  b.position.set(x, y + 0.43, z);
  for (const hy of [0.16, 0.7]) {
    const r = add(scene, new THREE.CylinderGeometry(0.35, 0.35, 0.06, 12, 1, true), mats.iron);
    r.position.set(x, y + hy, z);
  }
}

function clothMat(img) {
  const m = pixMat(img, { side: THREE.DoubleSide, alphaTest: 0.5, normal: 0.5 });
  m.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, { uTime: U.uTime, uWindDir: U.uWindDir, uWindStr: U.uWindStr });
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\n' + WIND_GLSL)
      .replace(
        '#include <begin_vertex>',
        /* glsl */ `vec3 transformed = position;
        {
          vec3 wp = (modelMatrix * vec4(position, 1.0)).xyz;
          vec2 w = windAt(wp.xz);
          float hang = 1.0 - uv.y; // pinned along the top edge
          float wave = sin(uTime * 5.0 + uv.x * 6.0 + wp.x * 0.7) * 0.5 + sin(uTime * 8.3 + uv.y * 9.0) * 0.25;
          transformed.z += hang * (length(w) * 0.55 + wave * 0.12 * (0.4 + length(w)));
          transformed.x += hang * hang * dot(w, vec2(1.0, 0.0)) * 0.15;
        }`
      );
  };
  m.customProgramCacheKey = () => 'cloth';
  const dm = new THREE.MeshDepthMaterial({ map: m.map, alphaTest: 0.5, side: THREE.DoubleSide });
  return { m, dm };
}

function clothPiece(scene, img, w, h, x, y, z, rotY = 0, shared = null) {
  const { m, dm } = shared || clothMat(img);
  const g = new THREE.PlaneGeometry(w, h, 6, 6);
  g.translate(0, -h / 2, 0);
  const mesh = add(scene, g, m);
  mesh.customDepthMaterial = dm;
  mesh.position.set(x, y, z);
  mesh.rotation.y = rotY;
  return mesh;
}

// a sagging string between two points (for laundry, bunting, the ferry rope)
function rope(scene, p0, p1, sag, color = 0x3a3028) {
  const at = (t) => new THREE.Vector3(p0.x + (p1.x - p0.x) * t, p0.y + (p1.y - p0.y) * t - Math.sin(t * Math.PI) * sag, p0.z + (p1.z - p0.z) * t);
  scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(Array.from({ length: 17 }, (_, i) => at(i / 16))), new THREE.LineBasicMaterial({ color })));
  return at;
}

export const floaters = []; // objects bobbing on the pond: { obj, y, ph }

function buildProps(scene, mats) {
  // path lanterns placed asymmetrically around the hero (3.2 u right on the near side, 4.2 u left, one far right)
  lantern(scene, mats, 5.6, pathZ(5.6) + 1.35);
  lantern(scene, mats, -1.75, pathZ(-1.75) + 1.3);
  lantern(scene, mats, 8.8, pathZ(8.8) - 1.45);
  for (const h of HOUSES) for (const p of h.lampPts || []) lantern(scene, mats, p.x, p.z, p.y, { hang: true });
  buildFire(scene, mats);
  // bench against the retaining wall + crates/barrels
  const bz = wallZ(6.6);
  const seat = add(scene, texelBox(1.7, 0.1, 0.48), mats.plank);
  seat.position.set(6.6, 0.5, bz + 0.35);
  const backr = add(scene, texelBox(1.7, 0.42, 0.08), mats.plank);
  backr.position.set(6.6, 0.86, bz + 0.12);
  for (const lx of [5.9, 7.3]) {
    const l = add(scene, texelBox(0.1, 0.5, 0.42), mats.timber);
    l.position.set(lx, 0.25, bz + 0.35);
  }
  crate(scene, mats, 8.9, 0, bz + 0.5, 0.72, 0.1);
  crate(scene, mats, 9.55, 0, bz + 0.55, 0.6, -0.2);
  crate(scene, mats, 9.1, 0.72, bz + 0.5, 0.5, 0.4);
  barrel(scene, mats, 10.4, 0, bz + 0.55);
  barrel(scene, mats, -0.4, T2_Y, -6.0);
  crate(scene, mats, -13.2, T2_Y, -4.9, 0.66, 0.3);
  barrel(scene, mats, -7.4, T2_Y, -4.9);
  // foreground fence (T0) with one broken diagonal rail entering from the lower right, two pinwheels
  const posts = [[8.0, 9.3], [9.5, 9.9], [11.0, 10.6], [12.5, 11.4]];
  posts.forEach(([fx, fz], i) => {
    const p = add(scene, texelBox(0.2, 1.25, 0.2), mats.plank);
    p.position.set(fx, groundY(fx, fz) + 0.55, fz);
    p.rotation.z = [0.04, -0.06, 0.1, -0.03][i];
    if (i < posts.length - 1) {
      const [nx, nz] = posts[i + 1];
      const len = Math.hypot(nx - fx, nz - fz);
      for (const ry of i === 1 ? [0.85] : [0.45, 0.88]) {
        const rail = add(scene, texelBox(len + 0.15, 0.11, 0.08), mats.plank);
        rail.position.set((fx + nx) / 2, groundY(fx, fz) + ry, (fz + nz) / 2 + 0.12);
        rail.rotation.y = -Math.atan2(nz - fz, nx - fx);
      }
    }
    if (i === 0 || i === 2) {
      const hub = new THREE.Group();
      hub.position.set(fx, groundY(fx, fz) + 1.3, fz + 0.14);
      scene.add(hub);
      const cols = [mats.pinA, mats.pinB];
      for (let k = 0; k < 4; k++) {
        const b = add(hub, new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0.28, 0.02, 0), new THREE.Vector3(0.2, 0.2, 0.02)]), cols[k % 2], { cast: true });
        b.geometry.computeVertexNormals();
        b.rotation.z = (k * Math.PI) / 2;
      }
      spinners.push({ obj: hub, axis: 'z', speed: -6, wind: true });
    }
  });
  // the broken rail leaning on the ground
  const br = add(scene, texelBox(1.6, 0.11, 0.08), mats.plank);
  br.position.set(10.2, groundY(10.2, 10.3) + 0.35, 10.35);
  br.rotation.set(0, -0.4, 0.42);
  // signpost by the bridge: "WINDFERRY"
  const sx = -1.7;
  const sz = pathZ(sx) - 1.5;
  const sp = add(scene, texelBox(0.14, 1.7, 0.14), mats.timber);
  sp.position.set(sx, groundY(sx, sz) + 0.85, sz);
  const board = add(scene, new THREE.PlaneGeometry(1.5, 0.375), mats.sign);
  board.position.set(sx, groundY(sx, sz) + 1.45, sz + 0.09);
  const back = add(scene, texelBox(1.54, 0.4, 0.06), mats.plank);
  back.position.set(sx, groundY(sx, sz) + 1.45, sz + 0.03);
  // laundry line between the clay and slate houses
  const p0 = new THREE.Vector3(6.5, T2_Y + 1.82, -5.7);
  const p1 = new THREE.Vector3(9.2, T2_Y + 1.82, -5.2);
  for (const p of [p0, p1]) {
    const pole = add(scene, texelBox(0.1, 1.9, 0.1), mats.timber);
    pole.position.set(p.x, T2_Y + 0.95, p.z);
  }
  const lineAt = rope(scene, p0, p1, 0.12);
  const rotL = -Math.atan2(p1.z - p0.z, p1.x - p0.x);
  for (const [t, kind, seed, w, h] of [[0.18, 'shirt', 5, 0.7, 0.7], [0.5, 'sheet', 6, 1.25, 1.1], [0.82, 'shirt', 9, 0.66, 0.66]]) {
    const s = lineAt(t);
    clothPiece(scene, T.cloth(kind, seed), w, h, s.x, s.y, s.z, rotL);
  }
  // banner with the kite emblem on a pole beside the stairs
  const bp = add(scene, texelBox(0.12, 3.4, 0.12), mats.timber);
  bp.position.set(0.45, T2_Y + 1.7, -4.35);
  const bar = add(scene, texelBox(0.9, 0.08, 0.08), mats.timber);
  bar.position.set(0.85, T2_Y + 3.3, -4.35);
  clothPiece(scene, T.cloth('banner'), 0.75, 1.5, 0.87, T2_Y + 3.27, -4.33, 0);
  // bunting strung across the stream: the wind field made visible
  const b0 = new THREE.Vector3(-7.4, 2.7, -1.9);
  const b1 = new THREE.Vector3(-3.5, 2.7, -1.1);
  for (const b of [b0, b1]) {
    const pole = add(scene, texelBox(0.12, 2.8, 0.12), mats.timber);
    pole.position.set(b.x, groundY(b.x, b.z) + 1.4, b.z);
  }
  const bAt = rope(scene, b0, b1, 0.35, 0xe8dcc0);
  const flagMats = [0xd8503a, 0xf2c838, 0x3a8ab0, 0xf4f0e2].map((c) => clothMat(T.pennant(c)));
  const rotB = -Math.atan2(b1.z - b0.z, b1.x - b0.x);
  for (let i = 0; i < 9; i++) {
    const s = bAt((i + 0.5) / 9);
    clothPiece(scene, null, 0.375, 0.5, s.x, s.y, s.z, rotB, flagMats[i % 4]);
  }
  // rope ferry ("Windferry"): a guide rope across the pond and a moored punt
  const r0 = new THREE.Vector3(POND.x - POND.rx - 0.3, 0.95, POND.z - 0.7);
  const r1 = new THREE.Vector3(POND.x + POND.rx + 0.2, 0.95, POND.z + 0.3);
  for (const r of [r0, r1]) {
    const post = add(scene, texelBox(0.16, 1.4, 0.16), mats.timber);
    post.position.set(r.x, groundY(r.x, r.z) + 0.55, r.z);
  }
  rope(scene, r0, r1, 0.45, 0xc8b490);
  const punt = new THREE.Group();
  const hull = add(punt, texelBox(2.1, 0.22, 0.86), mats.plank);
  hull.position.y = 0.08;
  for (const s of [-1, 1]) {
    const side = add(punt, texelBox(2.2, 0.18, 0.08), mats.timber);
    side.position.set(0, 0.24, s * 0.43);
    const end = add(punt, texelBox(0.1, 0.2, 0.9), mats.timber);
    end.position.set(s * 1.05, 0.22, 0);
  }
  const bench = add(punt, texelBox(0.3, 0.06, 0.8), mats.plank);
  bench.position.set(0.2, 0.28, 0);
  const pole = add(punt, texelBox(0.06, 0.06, 2.6), mats.timber);
  pole.position.set(-0.3, 0.36, 0);
  pole.rotation.set(0, 1.35, 0.12);
  punt.position.set(POND.x - 1.6, WATER_Y, POND.z - 0.3);
  punt.rotation.y = -0.22;
  scene.add(punt);
  floaters.push({ obj: punt, y: WATER_Y, ph: 0.7 });
}

export const spinners = []; // { obj, axis, speed }
function buildWaterWheel(scene, mats) {
  const grp = new THREE.Group();
  const cx = channelX(-8.6);
  grp.position.set(cx, T2_Y - 0.25 + 0.95, -8.6);
  scene.add(grp);
  const R = 1.2;
  const geos = [];
  for (let s = 0; s < 16; s++) {
    const a = (s / 16) * Math.PI * 2;
    for (const side of [-0.28, 0.28]) {
      const g = texelBox(0.1, 0.12, (2 * Math.PI * R) / 16 + 0.04);
      g.rotateX(-a);
      g.translate(side, Math.sin(a) * R, Math.cos(a) * R);
      geos.push(g);
    }
    if (s % 2 === 0) {
      const p = texelBox(0.62, 0.5, 0.07);
      p.translate(0, 0, 0);
      p.rotateX(-a + Math.PI / 2);
      p.translate(0, Math.sin(a) * (R - 0.12), Math.cos(a) * (R - 0.12));
      geos.push(p);
      const spoke = texelBox(0.08, 0.08, R);
      spoke.translate(0, 0, R / 2);
      spoke.rotateX(-a);
      geos.push(spoke);
    }
  }
  const wheel = add(grp, mergeGeometries(geos), mats.plank);
  wheel.geometry.computeVertexNormals();
  const axle = add(grp, new THREE.CylinderGeometry(0.1, 0.1, 2.6, 8), mats.iron);
  axle.rotation.z = Math.PI / 2;
  axle.position.x = -1.2;
  spinners.push({ obj: wheel, axis: 'x', speed: -0.7 });
}

function buildWindmill(scene, mats) {
  const x = 8.5;
  const z = -27.5;
  const y = groundY(x, z) - 0.2;
  const g = new THREE.CylinderGeometry(1.05, 1.5, 5.6, 10, 1);
  const uv = g.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * ((2 * Math.PI * 1.3 * TPU) / 64), uv.getY(i) * ((5.6 * TPU) / 64));
  const tower = add(scene, g, mats.wallLight);
  tower.position.set(x, y + 2.8, z);
  const cap = add(scene, new THREE.ConeGeometry(1.45, 1.7, 10), mats.thatch);
  cap.position.set(x, y + 6.45, z);
  const hub = new THREE.Group();
  hub.position.set(x, y + 5.3, z + 1.35);
  scene.add(hub);
  const blades = [];
  for (let i = 0; i < 4; i++) {
    const b = texelBox(0.62, 3.6, 0.05);
    b.translate(0.22, 2.0, 0);
    b.rotateZ((i * Math.PI) / 2);
    blades.push(b);
    const spar = texelBox(0.1, 4.0, 0.08);
    spar.translate(0, 2.0, 0.04);
    spar.rotateZ((i * Math.PI) / 2);
    blades.push(spar);
  }
  add(hub, mergeGeometries(blades), mats.sail);
  spinners.push({ obj: hub, axis: 'z', speed: 0.35 });
  const door = add(scene, texelBox(0.7, 1.4, 0.1), mats.plank);
  door.position.set(x, y + 0.9, z + 1.43);
}

// ---------------------------------------------------------------------------
// Sky dome with banded/dithered ramps, stars & moon; painterly pixel clouds; far hills
// ---------------------------------------------------------------------------
export const skyU = {
  uZenith: { value: new THREE.Color() },
  uHorizon: { value: new THREE.Color() },
  uGlow: { value: new THREE.Color() },
  uSunDir: U.uSunDir,
  uMoonDir: { value: new THREE.Vector3(0.45, 0.5, -0.75).normalize() },
  uNight: U.uNight,
  uTime: U.uTime,
};
function buildSky(scene) {
  const m = new THREE.ShaderMaterial({
    uniforms: skyU,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position + cameraPosition, 1.0); gl_Position = p.xyww; }`,
    fragmentShader: /* glsl */ `
      uniform vec3 uZenith, uHorizon, uGlow, uSunDir, uMoonDir; uniform float uNight, uTime; varying vec3 vDir;
      float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
      void main(){
        vec3 d = normalize(vDir);
        float y = clamp(d.y, -0.2, 1.0);
        // SNES-style banded ramp with 2x2 ordered dither between bands
        float t = pow(clamp(y * 1.6 + 0.05, 0.0, 1.0), 0.6);
        float bands = 14.0;
        vec2 px = floor(gl_FragCoord.xy / 3.0);
        float bayer = mod(px.x + 2.0 * mod(px.y, 2.0), 4.0) / 4.0;
        t = floor(t * bands + bayer) / bands;
        vec3 c = mix(uHorizon, uZenith, t);
        float sd = max(dot(d, uSunDir), 0.0);
        c += uGlow * (pow(sd, 6.0) * 0.6 + pow(sd, 40.0) * 1.5) * (1.0 - uNight);
        c += uGlow * 12.0 * smoothstep(0.9993, 0.9996, sd) * (1.0 - uNight);
        // stars + moon
        if (uNight > 0.01) {
          vec2 sp = floor(vec2(atan(d.z, d.x) * 300.0, d.y * 300.0));
          float s = step(0.996, h(sp)) * smoothstep(0.02, 0.2, d.y);
          float tw = 0.6 + 0.4 * sin(uTime * 3.0 + h(sp + 1.0) * 40.0);
          c += vec3(0.9, 0.95, 1.2) * s * tw * uNight * 1.6;
          float md = dot(d, uMoonDir);
          c += vec3(0.95, 0.97, 1.1) * smoothstep(0.9988, 0.9991, md) * uNight * 6.0;
          c += vec3(0.3, 0.4, 0.7) * pow(max(md, 0.0), 30.0) * uNight * 0.5;
        }
        gl_FragColor = vec4(c, 1.0);
      }`,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(10, 32, 16), m);
  sky.frustumCulled = false;
  sky.renderOrder = -10;
  scene.add(sky);
}

export const clouds = [];
export const cloudU = { uLit: { value: new THREE.Color(1, 0.85, 0.65) }, uShade: { value: new THREE.Color(0.6, 0.55, 0.7) } };
function buildClouds(scene) {
  const r = new RNG(77);
  const card = (seed, s, x, y, z) => {
    const t = T.cloud(seed).toTextures({ name: 'cloud' });
    const m = new THREE.ShaderMaterial({
      uniforms: { map: { value: t.map }, ...cloudU },
      transparent: true,
      depthWrite: false,
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform sampler2D map; uniform vec3 uLit, uShade; varying vec2 vUv; void main(){ vec4 c = texture2D(map, vUv); if (c.a < 0.5) discard; float l = dot(c.rgb, vec3(0.33)); gl_FragColor = vec4(mix(uShade, uLit, smoothstep(0.55, 0.95, l)) * (0.7 + l * 0.6), 1.0); }`,
    });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(s * 2.5, s), m);
    mesh.position.set(x, y, z);
    mesh.lookAt(0, mesh.position.y * 0.5, 40);
    mesh.renderOrder = -5;
    scene.add(mesh);
    clouds.push({ mesh, speed: r.float(1.5, 3.5) });
  };
  for (let i = 0; i < 9; i++) card(500 + i, r.float(14, 30), r.float(-260, 260), r.float(16, 40), r.float(-520, -400));
  // high cumulus ~25-35° above the pond: outside the tilted main view, but they sail through the pond's mirror
  for (let i = 0; i < 4; i++) card(540 + i, r.float(16, 24), -24 + i * 16 + r.float(-4, 4), r.float(34, 46), r.float(-80, -60));
}

function buildFarHills(scene) {
  const layers = [
    { z: -95, h: 8, base: 2, col: 0x46663e, seed: 1 },
    { z: -160, h: 13, base: 0, col: 0x4e6a5a, seed: 2 },
    { z: -260, h: 22, base: -4, col: 0x6a7a88, seed: 3 },
  ];
  for (const L of layers) {
    const N = 120;
    const pos = [];
    const xs = 520;
    for (let i = 0; i < N; i++) {
      const x0 = -xs + (2 * xs * i) / N;
      const x1 = -xs + (2 * xs * (i + 1)) / N;
      const h0 = L.base + L.h * (0.45 + 0.55 * (vnoise(x0 * 0.012 + L.seed * 10, 0) * 0.7 + vnoise(x0 * 0.05, L.seed) * 0.3));
      const h1 = L.base + L.h * (0.45 + 0.55 * (vnoise(x1 * 0.012 + L.seed * 10, 0) * 0.7 + vnoise(x1 * 0.05, L.seed) * 0.3));
      pos.push(x0, -30, L.z, x1, -30, L.z, x1, h1, L.z, x0, -30, L.z, x1, h1, L.z, x0, h0, L.z);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    const n = new Float32Array(pos.length);
    for (let i = 0; i < n.length; i += 3) {
      n[i + 1] = 0.75;
      n[i + 2] = 0.66;
    }
    g.setAttribute('normal', new THREE.BufferAttribute(n, 3));
    const m = new THREE.MeshStandardMaterial({ color: L.col, roughness: 1 });
    m.onBeforeCompile = (sh) => {
      injectWorldPos(sh);
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', `#include <common>\nvarying vec3 vWPos;\n${HASH_GLSL}`)
        .replace(
          '#include <map_fragment>',
          // treeline speckle in coarse pixels
          `{ vec2 c = floor(vWPos.xy * vec2(0.5, 0.5)); float n = hash12(c); diffuseColor.rgb *= 0.82 + 0.3 * n; }`
        );
    };
    const mesh = new THREE.Mesh(g, m);
    mesh.receiveShadow = false;
    scene.add(mesh);
  }
}

// ---------------------------------------------------------------------------
export function buildWorld(scene) {
  buildSplat();
  const mk = (img, o) => pixMat(img, o);
  const mats = {
    wall: mk(T.stoneWall(14), { normal: 2.5 }),
    wallLight: mk(T.facade({ w: 64, h: 64, seed: 9, noTimber: true, foundation: 0 }), { normal: 1.5 }),
    wallCap: mk(T.stoneWall(19, { light: 0.25 }), { normal: 2.5 }),
    bridge: mk(T.stoneWall(23, { light: 0.12 }), { normal: 2.5 }),
    cobble: mk(T.cobble(29), { normal: 2.5 }),
    thatch: addMoss(mk(T.roofTiles('thatch', 31), { normal: 2.5 }), 0.35),
    clay: addMoss(mk(T.roofTiles('clay', 32), { normal: 2.5 }), 0.5),
    slate: addMoss(mk(T.roofTiles('slate', 33), { normal: 2.5 }), 0.8),
    plank: mk(T.planks(41), { normal: 2 }),
    crate: mk(T.planks(42, { vertical: false, w: 7 }), { normal: 2 }),
    sail: mk(T.planks(43, { vertical: true, w: 4 }), { normal: 1, side: THREE.DoubleSide }),
    timber: mk(T.planks(44, { w: 4 }), { normal: 1.5 }),
    frame: mk(T.planks(45, { w: 3 }), { normal: 1 }),
    sign: mk(T.signBoard('WINDFERRY'), { normal: 1.5 }),
  };
  mats.sign.map.wrapS = mats.sign.map.wrapT = THREE.ClampToEdgeWrapping;
  mats.wallLight.map.wrapS = mats.wallLight.map.wrapT = THREE.RepeatWrapping;
  mats.ridge = new THREE.MeshStandardMaterial({ color: 0x3a2a28, roughness: 0.8 });
  mats.iron = new THREE.MeshStandardMaterial({ color: 0x1c1a1e, roughness: 0.5, metalness: 0.6 });
  mats.lanternGlass = new THREE.MeshStandardMaterial({ color: 0xffd090, emissive: 0xffa040, emissiveIntensity: 6, roughness: 0.2 });
  mats.pinA = new THREE.MeshStandardMaterial({ color: 0xe8483a, roughness: 0.6, side: THREE.DoubleSide });
  mats.pinB = new THREE.MeshStandardMaterial({ color: 0xf2d04a, roughness: 0.6, side: THREE.DoubleSide });
  mats.timber.color.set(0x8a7a70);
  mats.frame.color.set(0x6a5a52);
  const shutters = new Map();
  mats.shutter = (c) => {
    if (!shutters.has(c)) shutters.set(c, mk(T.louvers(c), { normal: 1.5 }));
    return shutters.get(c);
  };

  buildTerrain(scene);
  buildWater(scene);
  buildStonework(scene, mats);
  const houses = buildHouses(scene, mats);
  buildProps(scene, mats);
  buildLightDecals(scene);
  buildWaterWheel(scene, mats);
  buildWindmill(scene, mats);
  buildSky(scene);
  buildClouds(scene);
  buildFarHills(scene);
  return { mats, houses };
}

// Octopath-style top-facing projection: moss patches on roofs, driven by world position + world normal.
function addMoss(mat, amount) {
  mat.onBeforeCompile = (sh) => {
    injectWorldPos(sh);
    sh.uniforms.uMoss = { value: amount };
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', `#include <common>\nvarying vec3 vWPos; uniform float uMoss;\n${HASH_GLSL}`)
      .replace(
        '#include <normal_fragment_maps>',
        `#include <normal_fragment_maps>
        {
          vec3 nW = inverseTransformDirection(normal, viewMatrix);
          vec2 q = floor(vWPos.xz * 32.0) / 32.0;
          float m = vn2(q * 1.3 + vWPos.y * 0.7) * 0.7 + hash12(floor(vWPos.xz * 32.0)) * 0.3;
          float k = step(1.0 - uMoss * 0.45, m) * smoothstep(0.45, 0.8, nW.y);
          diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.2, 0.3, 0.11) * (0.8 + 0.4 * m), k);
        }`
      );
  };
  mat.customProgramCacheKey = () => 'moss' + amount;
  return mat;
}
