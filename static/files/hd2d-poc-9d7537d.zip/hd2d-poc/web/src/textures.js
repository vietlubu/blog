import { PixelImage, RNG, tone, mixc, hex, fbm, vnoise } from './core.js';

// Palette: late-summer golden hour. Every ramp is hue-shifted (shadows cool/violet, lights warm/butter).
export const PAL = {
  grass: [0x22402e, 0x2f5530, 0x426e33, 0x5b8a38, 0x7ea43e, 0xa9c254],
  dirt: [0x5e4433, 0x7a5a40, 0x93704c, 0xa98559, 0xc2a173],
  stone: [0x5a5250, 0x77706a, 0x8f877c, 0xa59b8a, 0xbdb39e],
  plaster: [0xb9a88e, 0xd2c2a2, 0xe6d8b8, 0xf3e8cc],
  timber: [0x3a2620, 0x4f3426, 0x66452f, 0x7d5a3c],
  thatch: [0x7a5428, 0x9c7034, 0xbd8f45, 0xd9b062, 0xecd08a],
  clay: [0x6a2c26, 0x8f3c2e, 0xb35538, 0xcf7044, 0xe39058],
  slate: [0x2c3350, 0x3b4668, 0x4d5b84, 0x6474a0, 0x8a98bc],
  plank: [0x5a3e2c, 0x75523a, 0x926a48, 0xab8458, 0xc6a070],
  bark: [0x3a2c26, 0x4f3c30, 0x66503c, 0x7f6648],
  moss: [0x3d5a2c, 0x56743a, 0x78944a],
};

const pick = (ramp, t) => ramp[Math.max(0, Math.min(ramp.length - 1, Math.round(t * (ramp.length - 1))))];

export function grassGround(seed = 11) {
  const r = new RNG(seed);
  const W = 64;
  const img = new PixelImage(W, W);
  for (let y = 0; y < W; y++)
    for (let x = 0; x < W; x++) {
      const n = fbm(x * 0.09, y * 0.09) * 0.7 + r.next() * 0.3;
      img.px(x, y, { c: pick(PAL.grass.slice(0, 5), n * 0.95), h: 0.3, r: 0.95 });
    }
  // short blade strokes, darker root -> warm tip
  for (let i = 0; i < 260; i++) {
    const x = r.int(0, W - 1);
    const y = r.int(0, W - 1);
    const len = r.int(2, 4);
    const lean = r.pick([-1, 0, 0, 1]);
    for (let k = 0; k < len; k++) {
      const t = k / len;
      img.px(x + Math.round(lean * t), y - k, { c: pick(PAL.grass, 0.45 + t * 0.55 * r.float(0.7, 1)), h: 0.6 + t * 0.6 });
    }
  }
  // clover / tiny blossoms
  for (let i = 0; i < 10; i++) {
    const x = r.int(0, W - 1);
    const y = r.int(0, W - 1);
    const c = r.pick([0xf2ead0, 0xf3d65a, 0xe7a0b8]);
    img.px(x, y, { c, h: 1 });
    if (r.chance(0.5)) img.px(x + 1, y, { c: tone(c, -0.2), h: 0.9 });
  }
  return img;
}

export function dirt(seed = 12) {
  const r = new RNG(seed);
  const W = 64;
  const img = new PixelImage(W, W);
  for (let y = 0; y < W; y++)
    for (let x = 0; x < W; x++) {
      const n = fbm(x * 0.12 + 3, y * 0.12) * 0.75 + r.next() * 0.25;
      img.px(x, y, { c: pick(PAL.dirt, 0.15 + n * 0.75), h: 0.4 + n * 0.2, r: 0.95 });
    }
  for (let i = 0; i < 46; i++) {
    const x = r.float(0, W);
    const y = r.float(0, W);
    const rad = r.float(0.8, 2.2);
    const base = r.pick([PAL.stone[2], PAL.stone[3], PAL.dirt[4], PAL.stone[1]]);
    img.disc(x, y, rad, (dx, dy, d) => ({ c: tone(base, dx + dy < 0 ? 0.35 : -0.25 * d), h: 1.0 - d * 0.4, r: 0.75 }));
  }
  // wheel/foot ruts: faint darker streaks along u
  for (const yy of [18, 44]) for (let x = 0; x < W; x++) if (r.chance(0.7)) img.px(x, yy + (vnoise(x * 0.2, yy) > 0.5 ? 1 : 0), { c: PAL.dirt[0], a: 0.35, h: 0.25 });
  return img;
}

export function cobble(seed = 13) {
  const r = new RNG(seed);
  const W = 64;
  const img = new PixelImage(W, W);
  img.rect(0, 0, W, W, () => ({ c: mixc(PAL.moss[0], 0x3a3430, r.float(0.3, 0.9)), h: 0, r: 0.95 }));
  let y = 0;
  let row = 0;
  while (y < W) {
    const rh = row % 2 ? 7 : 8;
    let x = (row * 5) % 9;
    while (x < W + 8) {
      const rw = r.int(7, 11);
      const base = pick(PAL.stone, r.float(0.25, 0.95));
      for (let yy = 0; yy < rh - 1; yy++)
        for (let xx = 0; xx < rw - 1; xx++) {
          const ex = (xx + 0.5) / (rw - 1) - 0.5;
          const ey = (yy + 0.5) / (rh - 1) - 0.5;
          const d = ex * ex * 3.2 + ey * ey * 3.2;
          if (d > 0.95) continue;
          const lit = -ex - ey; // light from top-left
          img.px(x + xx, y + yy, { c: tone(base, lit * 0.5 - d * 0.25 + r.float(-0.06, 0.06)), h: 1 - d * 0.7, r: r.float(0.55, 0.8) });
        }
      x += rw;
    }
    y += rh;
    row++;
  }
  return img;
}

export function stoneWall(seed = 14, { light = 0 } = {}) {
  const r = new RNG(seed);
  const W = 64;
  const img = new PixelImage(W, W);
  img.rect(0, 0, W, W, () => ({ c: tone(0x4a4038, r.float(-0.1, 0.1)), h: 0, r: 0.95 }));
  let y = 0;
  while (y < W) {
    const rh = r.int(6, 9);
    let x = r.int(-6, 0);
    while (x < W) {
      const rw = r.int(7, 15);
      const base = tone(pick(PAL.stone, r.float(0.3, 0.95)), light + r.float(-0.08, 0.08));
      for (let yy = 0; yy < rh - 1; yy++)
        for (let xx = 0; xx < rw - 1; xx++) {
          const corner = (xx === 0 || xx === rw - 2) && (yy === 0 || yy === rh - 2);
          if (corner && r.chance(0.8)) continue;
          const top = yy === 0;
          const bot = yy === rh - 2;
          const left = xx === 0;
          const t = (top ? 0.35 : 0) + (left ? 0.15 : 0) - (bot ? 0.3 : 0) + r.float(-0.05, 0.05);
          img.px(x + xx, y + yy, { c: tone(base, t), h: top || left ? 0.75 : bot ? 0.6 : 1, r: 0.8 });
        }
      x += rw;
    }
    y += rh;
  }
  // moss creeping in the joints
  for (let i = 0; i < 40; i++) {
    const x = r.int(0, W - 1);
    const yy = r.int(0, W - 1);
    img.disc(x, yy, r.float(0.6, 1.8), { c: r.pick(PAL.moss), a: 0.7, h: 0.7 });
  }
  return img;
}

export function planks(seed = 15, { vertical = true, w = 6 } = {}) {
  const r = new RNG(seed);
  const W = 64;
  const img = new PixelImage(W, W);
  for (let p = 0; p * w < W; p++) {
    const base = pick(PAL.plank, r.float(0.25, 0.85));
    const off = r.int(0, 60);
    for (let a = 0; a < w; a++)
      for (let b = 0; b < W; b++) {
        const grain = vnoise(a * 0.9 + p * 13, (b + off) * 0.15) > 0.62;
        const edge = a === 0 ? -0.35 : a === w - 1 ? -0.15 : a === 1 ? 0.15 : 0;
        const c = tone(base, edge + (grain ? -0.18 : 0) + r.float(-0.03, 0.03));
        const [x, y] = vertical ? [p * w + a, b] : [b, p * w + a];
        img.px(x, y, { c, h: a === 0 ? 0.3 : 1, r: 0.85 });
      }
    const nb = r.int(4, 12);
    const [nx, ny] = vertical ? [p * w + 2, nb] : [nb, p * w + 2];
    img.px(nx, ny, { c: 0x2a2220, h: 0.6 });
  }
  return img;
}

export function bark(seed = 16) {
  const r = new RNG(seed);
  const W = 32;
  const H = 64;
  const img = new PixelImage(W, H);
  for (let x = 0; x < W; x++) {
    const ridge = 0.5 + 0.5 * Math.sin(x * 1.25 + vnoise(x * 0.3, 0) * 3);
    for (let y = 0; y < H; y++) {
      const n = vnoise(x * 0.5, y * 0.08) * 0.6 + ridge * 0.4 + r.float(-0.08, 0.08);
      img.px(x, y, { c: pick(PAL.bark, n), h: n, r: 0.95 });
    }
  }
  for (let i = 0; i < 14; i++) img.disc(r.float(0, W), r.float(0, H), r.float(1, 2.5), { c: r.pick(PAL.moss), a: 0.65, h: 0.8 });
  return img;
}

// Roof shingles: u runs along the eave, v up the slope. Rows overlap: each row
// rises toward its top edge so the per-texel normals catch the low sun.
export function roofTiles(kind, seed = 17) {
  const r = new RNG(seed);
  const W = 64;
  const img = new PixelImage(W, W);
  const ramp = PAL[kind];
  if (kind === 'thatch') {
    for (let x = 0; x < W; x++)
      for (let y = 0; y < W; y++) {
        const row = Math.floor(y / 10);
        const ry = (y % 10) / 9; // 0 top of row (image space), 1 bottom
        const strand = vnoise(x * 0.9 + row * 31, y * 0.12) * 0.7 + r.next() * 0.3;
        const t = strand * 0.75 + (1 - ry) * 0.1 - (ry > 0.85 ? 0.35 : 0);
        img.px(x, y, { c: pick(ramp, Math.max(0, t)), h: 0.3 + ry * 0.7 + strand * 0.2, r: 0.95 });
      }
    for (let i = 0; i < 18; i++) img.disc(r.float(0, W), r.float(0, W), r.float(1, 2.5), { c: PAL.moss[r.int(0, 1)], a: 0.5, h: 0.9 });
    return img;
  }
  const tw = kind === 'slate' ? 8 : 6;
  const th = kind === 'slate' ? 7 : 6;
  for (let row = 0; row * th < W; row++) {
    const off = row % 2 ? tw / 2 : 0;
    for (let c = -1; c * tw < W + tw; c++) {
      const base = pick(ramp, r.float(0.35, 0.85));
      for (let a = 0; a < tw; a++)
        for (let b = 0; b < th; b++) {
          const x = c * tw + a + off;
          const y = row * th + b;
          const ry = b / (th - 1); // 0 top .. 1 bottom (lower edge overlaps next row)
          let t = 0.15 - ry * 0.25 + r.float(-0.04, 0.04);
          let h = 0.2 + ry * 0.8;
          if (kind === 'clay') {
            // barrel tiles: rounded across u
            const ax = (a + 0.5) / tw - 0.5;
            t += -ax * 0.6 - Math.abs(ax) * 0.4;
            h += (0.25 - ax * ax) * 1.2;
          }
          if (a === 0 && kind === 'slate') t -= 0.4;
          if (b === th - 1) {
            t -= 0.45;
            h = 1.0;
          }
          img.px(x, y, { c: tone(base, t), h, r: kind === 'slate' ? 0.55 : 0.8 });
        }
    }
  }
  for (let i = 0; i < 10; i++) img.disc(r.float(0, W), r.float(0, W), r.float(0.7, 1.6), { c: r.pick(PAL.moss), a: 0.55 });
  return img;
}

// Timber-frame façade (plaster panels + beams + windows + door) painted at exact
// texel size of the wall. y grows downward in image space.
// opts: { w, h, gable (texels), foundation, floors: [y of beams], windows: [{x,y,w,h}], door: {x,w,h}, shutter, seed }
export function facade(o) {
  const r = new RNG(o.seed || 1);
  const W = o.w;
  const H = o.h + (o.gable || 0);
  const img = new PixelImage(W, H, { wrap: false });
  const top = o.gable || 0; // wall starts at this image row
  const plaster = o.plaster || PAL.plaster;
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const n = fbm(x * 0.07 + o.seed, y * 0.07) * 0.6 + r.next() * 0.25;
      const grime = Math.max(0, (y - (H - 30)) / 30) * 0.35;
      img.px(x, y, { c: tone(pick(plaster, n), -grime + r.float(-0.02, 0.02)), h: 0.5 + n * 0.1, r: 0.92 });
    }
  // under-eave shadow band
  img.rect(0, top, W, 3, { c: plaster[0], a: 0.5 });
  const beam = (x, y, w, h) =>
    img.rect(x, y, w, h, (a, b) => {
      const g = vnoise((x + a) * 0.6, (y + b) * 0.2) > 0.6;
      const e = a === 0 || b === 0 ? 0.25 : a === w - 1 || b === h - 1 ? -0.35 : 0;
      return { c: tone(PAL.timber[2], e + (g ? -0.2 : 0) + r.float(-0.03, 0.03)), h: 1.1, r: 0.9 };
    });
  const brace = (x0, y0, x1, y1) => img.line(x0, y0, x1, y1, { c: PAL.timber[1], h: 1.05, r: 0.9 }, 3);
  const fh = o.foundation ?? 12;
  // foundation stones
  const sw = stoneWall(o.seed + 3);
  for (let y = H - fh; y < H; y++)
    for (let x = 0; x < W; x++) {
      const c = sw.get(x, y);
      img.px(x, y, { c: [c[0], c[1], c[2]], h: sw.height[sw.idx(x, y)] * 1.2, r: 0.85 });
    }
  if (!o.noTimber) {
    beam(0, top, W, 4);
    beam(0, H - fh - 4, W, 4);
    for (const fy of o.floors || []) beam(0, fy, W, 4);
    const posts = o.posts || [0, W - 4];
    for (const px of posts) beam(px, top, 4, H - fh - top);
    for (const [x0, y0, x1, y1] of o.braces || []) brace(x0, y0, x1, y1);
    if (o.gable) {
      // gable timbers: king post + rafters follow the triangle edges
      beam(Math.floor(W / 2) - 2, 0, 4, top);
      for (let y = 0; y < top; y++) {
        const half = Math.round(((y + 1) / top) * (W / 2));
        img.rect(Math.floor(W / 2) - half, y, 3, 1, { c: PAL.timber[1], h: 1.1 });
        img.rect(Math.floor(W / 2) + half - 3, y, 3, 1, { c: PAL.timber[1], h: 1.1 });
      }
      beam(0, top - 4, W, 4);
    }
  }
  for (const win of o.windows || []) window_(img, win, o, r);
  if (o.door) door(img, o.door, H - fh, o, r);
  return img;
}

function window_(img, { x, y, w, h, lit = 1 }, o, r) {
  const frame = PAL.timber[3];
  img.rect(x - 2, y - 2, w + 4, h + 4, (a, b) => ({ c: tone(frame, a === 0 || b === 0 ? 0.2 : -0.1), h: 1.2 }));
  // warm glass with interior hints (curtains, a plant), emissive
  const glow = [1.0, 0.72, 0.36];
  img.rect(x, y, w, h, (a, b) => {
    const curtain = a < 3 || a >= w - 3;
    const plant = b > h - 6 && a > w / 2 - 3 && a < w / 2 + 2;
    const vy = b / h;
    const k = lit * (0.55 + 0.45 * vy) * (curtain ? 0.45 : 1) * (plant ? 0.25 : 1);
    const col = plant ? [0.2, 0.3, 0.12] : curtain ? [0.7, 0.32, 0.22] : mixc(glow, [1, 0.88, 0.6], 1 - vy);
    return { c: col, e: col, ek: k, h: 0.2, r: 0.15 };
  });
  // mullions
  img.rect(x + Math.floor(w / 2) - 1, y, 2, h, { c: frame, h: 1, e: 0, ek: 0 });
  img.rect(x, y + Math.floor(h / 2) - 1, w, 2, { c: frame, h: 1, e: 0, ek: 0 });
  // sill
  img.rect(x - 3, y + h + 2, w + 6, 2, { c: PAL.stone[4], h: 1.3 });
  img.rect(x - 3, y + h + 4, w + 6, 1, { c: PAL.stone[1], h: 0.8 });
  // weathering: rain streaks running down from the sill (3D shutters/frames are geometry now)
  for (let k = 0; k < 4; k++) {
    const sx = x - 2 + r.int(0, w + 4);
    const len = r.int(6, 16);
    for (let b = 0; b < len; b++) img.px(sx, y + h + 5 + b, { c: 0x4a4038, a: 0.35 * (1 - b / len), keepAlpha: true });
  }
}

// Louvered shutter boards in one hue (64x64 tile, horizontal slats every 4 texels).
export function louvers(color, seed = 51) {
  const r = new RNG(seed);
  const img = new PixelImage(64, 64);
  for (let y = 0; y < 64; y++)
    for (let x = 0; x < 64; x++) {
      const slat = y % 4;
      const t = slat === 0 ? 0.28 : slat === 3 ? -0.38 : x % 21 === 0 ? -0.3 : 0;
      img.px(x, y, { c: tone(color, t + r.float(-0.04, 0.04)), h: slat === 3 ? 0.4 : 1 - slat * 0.15, r: 0.8 });
    }
  return img;
}

function door(img, { x, w, h, color = 0x6a4430 }, floorY, o, r) {
  const y = floorY - h;
  img.rect(x - 3, y - 3, w + 6, h + 3, (a, b) => ({ c: tone(PAL.timber[2], a < 2 || b < 2 ? 0.2 : -0.1), h: 1.25 }));
  img.rect(x, y, w, h, (a, b) => {
    const arch = b < 5 && Math.abs(a - w / 2 + 0.5) > w / 2 - (5 - b) * 0.9 + 1;
    if (arch) return { c: PAL.timber[1], h: 1.2 };
    const seam = a % 6 === 0;
    return { c: tone(color, (seam ? -0.35 : 0) + r.float(-0.04, 0.04) + (a === 1 ? 0.12 : 0)), h: seam ? 0.6 : 0.9, r: 0.8 };
  });
  // small lit window in the door + iron band + knob
  img.rect(x + Math.floor(w / 2) - 3, y + 10, 6, 6, (a, b) => ({ c: [1, 0.75, 0.4], e: [1, 0.72, 0.36], ek: 0.8, h: 0.3 }));
  img.rect(x, y + Math.floor(h * 0.62), w, 2, { c: 0x2a2626, h: 1.05, r: 0.5 });
  img.rect(x + w - 6, y + Math.floor(h * 0.5), 2, 2, { c: 0xd8b060, h: 1.3, r: 0.3 });
  // stone step
  img.rect(x - 5, floorY, w + 10, 3, { c: PAL.stone[3], h: 1.3 });
}

// ---------------------------------------------------------------------------
// Sprite atlases (transparent, clamp)
// ---------------------------------------------------------------------------

// 8 foliage cards of 32x32 texels (1x1 world unit): 0-2 grass tufts, 3 tall grass,
// 4 poppies, 5 buttercups, 6 daisies, 7 lavender, 8 reeds/cattails, 9 fern, 10 foxtail seed heads
export const TUFTS = 11;
export function tuftAtlas(seed = 21) {
  const r = new RNG(seed);
  const C = 32;
  const img = new PixelImage(C * TUFTS, C, { wrap: false, transparent: true });
  const blade = (ox, x, len, lean, ramp, w = 1, curl = 0) => {
    for (let k = 0; k < len; k++) {
      const t = k / (len - 1);
      const xx = ox + x + Math.round(lean * t * t + curl * Math.sin(t * 3));
      const c = tone(pick(ramp, 0.15 + t * 0.85), (t > 0.85 ? 0.15 : 0) - (t < 0.2 ? 0.2 : 0));
      for (let q = 0; q < w; q++) img.px(xx + q, C - 1 - k, { c, h: t });
    }
  };
  const grassRamp = PAL.grass;
  const tuft = (cell, n, lmin, lmax, spread = 12) => {
    const ox = cell * C;
    for (let i = 0; i < n; i++) {
      const x = 16 + Math.round(r.float(-spread, spread) * (0.4 + 0.6 * r.next()));
      blade(ox, x, r.int(lmin, lmax), r.float(-6, 6), grassRamp, r.chance(0.3) ? 2 : 1);
    }
  };
  tuft(0, 14, 6, 13);
  tuft(1, 18, 8, 17);
  tuft(2, 11, 5, 10, 14);
  tuft(3, 22, 14, 30, 13);
  const flowers = (cell, petal, center, n, size) => {
    const ox = cell * C;
    tuft(cell, 7, 5, 11);
    for (let i = 0; i < n; i++) {
      const x = 16 + r.int(-11, 11);
      const len = r.int(10, 24);
      const lean = r.float(-3, 3);
      blade(ox, x, len, lean, [0x2c4a2a, 0x3f6a32, 0x5a8a3a]);
      const hx = ox + x + Math.round(lean);
      const hy = C - len;
      if (size === 'cup') {
        img.rect(hx - 1, hy - 2, 3, 2, { c: petal, h: 1 });
        img.px(hx - 1, hy - 3, { c: tone(petal, 0.3), h: 1 });
        img.px(hx + 1, hy - 3, { c: tone(petal, -0.2), h: 1 });
        img.px(hx, hy - 1, { c: center, h: 1 });
      } else if (size === 'spike') {
        for (let k = 0; k < 5; k++) img.px(hx + (k % 2), hy - k, { c: tone(petal, k * 0.08 - 0.15), h: 1 });
      } else {
        img.px(hx, hy - 2, { c: tone(petal, 0.25), h: 1 });
        img.px(hx - 1, hy - 1, { c: petal, h: 1 });
        img.px(hx + 1, hy - 1, { c: tone(petal, -0.15), h: 1 });
        img.px(hx, hy, { c: tone(petal, -0.2), h: 1 });
        img.px(hx, hy - 1, { c: center, h: 1 });
      }
    }
  };
  flowers(4, 0xd8342c, 0x2a1a1a, 5, 'cup');
  flowers(5, 0xf2c838, 0xc07a1a, 6, 'star');
  flowers(6, 0xf4f0e2, 0xf0c030, 6, 'star');
  flowers(7, 0x9a78d8, 0x9a78d8, 6, 'spike');
  // reeds + cattails
  {
    const ox = 8 * C;
    for (let i = 0; i < 9; i++) blade(ox, 16 + r.int(-9, 9), r.int(16, 31), r.float(-4, 4), [0x3a5a30, 0x5a7a3a, 0x8aa050]);
    for (let i = 0; i < 3; i++) {
      const x = ox + 16 + r.int(-7, 7);
      const len = r.int(22, 29);
      img.rect(x, C - len, 1, len, { c: 0x4a6a34, h: 0.5 });
      img.rect(x - 1, C - len - 1, 3, 6, (a, b) => ({ c: tone(0x6a4028, a === 0 ? 0.2 : a === 2 ? -0.3 : 0), h: 1 }));
    }
  }
  // fern
  {
    const ox = 9 * C;
    for (let f = 0; f < 5; f++) {
      const ang = -1.2 + f * 0.6;
      for (let k = 0; k < 14; k++) {
        const x = 16 + Math.sin(ang) * k * 1.0;
        const y = C - 1 - Math.cos(ang) * k * 1.0 + (k * k) / 30;
        img.px(ox + x, y, { c: pick([0x2f5530, 0x426e33, 0x5b8a38, 0x7ea43e], k / 13), h: 1 });
        if (k % 2 === 0) {
          img.px(ox + x - 1, y - 1, { c: 0x5b8a38, h: 1 });
          img.px(ox + x + 1, y - 1, { c: 0x426e33, h: 1 });
        }
      }
    }
  }
  // foxtail / seed heads: tall pale stems with fuzzy heads that catch the back-light (bokeh highlights)
  {
    const ox = 10 * C;
    for (let i = 0; i < 7; i++) {
      const x = 16 + r.int(-10, 10);
      const len = r.int(18, 30);
      const lean = r.float(-5, 5);
      blade(ox, x, len, lean, [0x5a6a34, 0x8a8a44, 0xb0a058]);
      const hx = ox + x + Math.round(lean);
      const hy = C - len;
      for (let k = 0; k < 6; k++) {
        img.px(hx + (k % 2), hy - k, { c: tone(0xe8d49a, 0.15 - k * 0.05), h: 1 });
        if (k > 0 && k < 5) img.px(hx - 1 + ((k + 1) % 2) * 2, hy - k, { c: 0xf4e6b8, h: 1 });
      }
    }
  }
  return img;
}

// Creature / particle atlas: 32x32-texel cells (one cell = 1 world unit, the scene's texel density), 8 x 4.
// 0-1 leaves · 2-4 brimstone butterfly (open/half/closed) · 5-7 cabbage white · 8-10 common blue ·
// 11-13 swallow in flight (up/mid/down) · 14-16 sparrow (sit/peck/look back) · 17-18 smoke · 19 petal ·
// 20 dandelion seed · 21 rain splash · 22-23 mallard (float/dabble) · 24 ember
export const PART = { leaf: 0, fly: [2, 5, 8], bird: 11, sit: 14, smoke: 17, petal: 19, seed: 20, splash: 21, duck: 22, ember: 24 };
export function particleAtlas() {
  const C = 32;
  const img = new PixelImage(C * 8, C * 4, { wrap: false, transparent: true });
  const cell = (i) => [(i % 8) * C, Math.floor(i / 8) * C];
  const P = (i, x, y, c) => {
    const [ox, oy] = cell(i);
    img.px(ox + x, oy + y, { c });
  };
  const ell = (i, cx, cy, rx, ry, colFn) => {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const dx = (x + 0.5 - cx) / rx;
        const dy = (y + 0.5 - cy) / ry;
        if (dx * dx + dy * dy <= 1) P(i, x, y, typeof colFn === 'function' ? colFn(dx, dy) : colFn);
      }
  };
  // 1-texel dark outline around every opaque pixel of a cell (readability against foliage)
  const outline = (i, c) => {
    const [ox, oy] = cell(i);
    const op = (x, y) => x >= 0 && y >= 0 && x < C && y < C && img.albedo[((oy + y) * img.w + ox + x) * 4 + 3] > 0.5;
    const pts = [];
    for (let y = 0; y < C; y++) for (let x = 0; x < C; x++) if (!op(x, y) && (op(x - 1, y) || op(x + 1, y) || op(x, y - 1) || op(x, y + 1))) pts.push([x, y]);
    for (const [x, y] of pts) P(i, x, y, c);
  };
  const leaf = (i, c) => {
    const pts = [[15, 13], [16, 13], [14, 14], [15, 14], [16, 14], [17, 14], [14, 15], [15, 15], [16, 15], [17, 15], [18, 15], [15, 16], [16, 16], [17, 16], [16, 17], [17, 18]];
    for (const [x, y] of pts) P(i, x, y, tone(c, (x - 15.5) * -0.1 + (y - 15) * -0.1));
  };
  leaf(0, 0x8aa83c);
  leaf(1, 0xd8902c);
  const butterfly = (base, wing, spot, edge) => {
    for (let f = 0; f < 3; f++) {
      const i = base + f;
      const k = [1, 0.55, 0][f];
      if (f < 2) {
        for (const s of [-1, 1]) {
          ell(i, 16 + s * (1 + 4 * k), 13, 0.6 + 4 * k, 3.6, (dx, dy) => tone(wing, -dy * 0.15 + (Math.abs(dx) > 0.75 ? -0.12 : 0.05)));
          ell(i, 16 + s * (1 + 3 * k), 18, 0.6 + 3 * k, 2.6, (dx, dy) => tone(wing, -0.12 - dy * 0.1));
          if (f === 0) {
            P(i, 16 + s * 7, 11, spot);
            P(i, 16 + s * 6, 11, edge);
            P(i, 16 + s * 4, 18, spot);
          }
        }
      } else {
        ell(i, 16.5, 12.5, 1.6, 4.2, (dx, dy) => tone(wing, -dy * 0.2));
        P(i, 16, 10, spot);
      }
      for (let y = 11; y <= 20; y++) P(i, 16, y, 0x2a2018);
      P(i, 16, 10, 0x2a2018);
      P(i, 15, 9, 0x2a2018);
      P(i, 14, 8, 0x2a2018);
      P(i, 17, 9, 0x2a2018);
      P(i, 18, 8, 0x2a2018);
      outline(i, 0x3a2a20);
    }
  };
  butterfly(2, 0xf6d64a, 0xe07a2a, 0xfff2a0);
  butterfly(5, 0xf8f4ea, 0x2a2622, 0xffffff);
  butterfly(8, 0x6aa8ea, 0xf4f4ff, 0xa8d4ff);
  // swallows in flight: slate back, cream throat, forked tail
  const flyBird = (i, wingY) => {
    const c = 0x2e2c3a;
    ell(i, 16, 16, 4.5, 1.7, (dx, dy) => (dy > 0.2 ? 0xd8cdb8 : c));
    ell(i, 20.5, 15.2, 1.8, 1.6, c);
    P(i, 22, 15, 0x5a3a2a);
    P(i, 23, 15, 0x1a1418);
    P(i, 21, 14, 0x0a0a0a);
    P(i, 11, 16, c);
    P(i, 10, 15, c);
    P(i, 9, 14, c);
    P(i, 10, 17, c);
    P(i, 9, 18, c);
    for (const s of [-1, 1]) {
      const pts = [[1, 0], [3, wingY * 0.35], [5, wingY * 0.7], [7, wingY], [9, wingY * 1.15], [11, wingY * 1.2]];
      pts.forEach(([dx, dy], k) => {
        const x = 16 + s * dx;
        const y = Math.round(15 + dy);
        P(i, x, y, c);
        if (k < 4) P(i, x, y + 1, c);
        if (k < 3) P(i, x + s, y, c);
      });
    }
  };
  flyBird(11, -6);
  flyBird(12, 0);
  flyBird(13, 4);
  // sparrows: sit / peck / look back
  const sparrow = (i, pose) => {
    const body = 0x7a5638;
    ell(i, 15, 23, 4.4, 3.2, (dx, dy) => (dy > 0.25 ? 0xe8dcc4 : dx < -0.2 && dy < 0 ? tone(body, -0.25) : body));
    P(i, 10, 21, tone(body, -0.4));
    P(i, 9, 20, tone(body, -0.4));
    P(i, 10, 22, tone(body, -0.4));
    for (let x = 12; x < 17; x++) P(i, x, 22, tone(body, x % 2 ? -0.3 : 0.15));
    const [hx, hy, bx] = pose === 'peck' ? [20, 24, 22] : pose === 'look' ? [18, 19, 16] : [19, 19, 21];
    ell(i, hx, hy, 2.3, 2.1, (dx, dy) => (dy > 0.3 ? 0xb8b0a8 : 0x8a6a48));
    P(i, hx + (bx > hx ? 1 : -1), hy - 1, 0x101010);
    P(i, bx + (bx > hx ? 1 : -1), hy, 0xe8a040);
    P(i, bx, hy, 0xd88a30);
    P(i, 14, 27, 0x3a2a20);
    P(i, 16, 27, 0x3a2a20);
    outline(i, 0x2a1e18);
  };
  sparrow(14, 'sit');
  sparrow(15, 'peck');
  sparrow(16, 'look');
  const puff = (i, seed) => {
    const r = new RNG(seed);
    for (let k = 0; k < 9; k++) ell(i, 16 + r.float(-6, 6), 16 + r.float(-5, 5), r.float(4, 7), r.float(4, 7), (dx, dy) => tone(0xe8e4dc, -dy * 0.12 - dx * 0.05 - 0.05));
  };
  puff(17, 3);
  puff(18, 9);
  P(19, 15, 15, 0xf0b0c8);
  P(19, 16, 15, 0xf0b0c8);
  P(19, 17, 16, 0xd890a8);
  for (let y = 16; y <= 19; y++) P(20, 16, y, 0xd8d0b8);
  for (const [x, y] of [[16, 15], [15, 14], [17, 14], [14, 13], [18, 13], [16, 13], [15, 12], [17, 12]]) P(20, x, y, 0xffffff);
  for (const [x, y] of [[13, 18], [19, 18], [14, 17], [18, 17], [16, 18], [15, 18], [17, 18], [16, 16]]) P(21, x, y, 0xdceaf4);
  const duck = (i, dabble) => {
    if (dabble) {
      ell(i, 15, 22, 5.5, 2.6, (dx, dy) => (dx > 0.5 ? 0x6a4030 : 0x9a8a78));
      for (const [x, y] of [[9, 20], [8, 19], [9, 19], [8, 18], [7, 18]]) P(i, x, y, 0x2a2a30);
      P(i, 21, 23, 0x2a6a3a);
    } else {
      ell(i, 16, 22, 7, 2.8, (dx, dy) => (dx > 0.55 ? 0x7a4a30 : dy < -0.3 ? 0xb0a494 : 0x9a8a78));
      for (const [x, y] of [[8, 21], [7, 20], [8, 20]]) P(i, x, y, 0x2a2a30);
      for (let y = 17; y <= 19; y++) P(i, 22, y, 0x2a6a3a);
      ell(i, 23, 15.5, 2.2, 2, 0x2a6a3a);
      P(i, 22, 20, 0xffffff);
      P(i, 23, 20, 0xffffff);
      P(i, 24, 15, 0x0a0a0a);
      P(i, 25, 16, 0xe8c040);
      P(i, 26, 16, 0xe8c040);
    }
    outline(i, 0x2a2420);
    // waterline: everything below row 24 is under water
    const [ox, oy] = cell(i);
    for (let y = 25; y < C; y++) for (let x = 0; x < C; x++) img.px(ox + x, oy + y, { erase: true });
  };
  duck(22, false);
  duck(23, true);
  for (const [x, y] of [[15, 15], [16, 15], [15, 16], [16, 16]]) P(24, x, y, 0xffd060);
  return img;
}

// Face tile for voxel canopies (size x size texels, neutral grey): each cube face reads as a little cluster of
// leaves — bright top-left rim, darker bottom-right, a few leaf-shaped speckles. Tinted per voxel in the shader.
export function leafTile(size, seed = 71) {
  const r = new RNG(seed);
  const img = new PixelImage(size * 4, size);
  for (let v = 0; v < 4; v++)
    for (let y = 0; y < size; y++)
      for (let x = 0; x < size; x++) {
        const e = x === 0 || y === 0 ? 0.18 : x === size - 1 || y === size - 1 ? -0.2 : 0;
        const n = vnoise((x + v * 13) * 0.55, y * 0.55) - 0.5;
        const k = 0.78 + e + n * 0.22 + r.float(-0.03, 0.03);
        img.px(v * size + x, y, { c: [k, k, k], h: 0.6 + n });
      }
  // leaf speckles: little 2-texel highlights and 1-texel dark gaps
  for (let i = 0; i < size * 2; i++) {
    const x = r.int(1, size * 4 - 3);
    const y = r.int(1, size - 3);
    if (r.chance(0.6)) {
      img.px(x, y, { c: [0.98, 0.98, 0.98], h: 1 });
      img.px(x + 1, y, { c: [0.9, 0.9, 0.9], h: 0.9 });
    } else img.px(x, y, { c: [0.5, 0.5, 0.5], h: 0.2 });
  }
  return img;
}

// Hand-pixel leaf-card clusters for the near corner branch (64x64 texels each, 2 variants side by side).
export function leafCards(seed = 81) {
  const r = new RNG(seed);
  const img = new PixelImage(128, 64, { wrap: false, transparent: true });
  const ramp = [0x1f3a22, 0x2f5530, 0x4a7a34, 0x6e9a3a, 0x9cbc48];
  for (let v = 0; v < 2; v++) {
    const ox = v * 64;
    img.line(ox + 4, 60, ox + 50, 14, { c: 0x4a3a2a }, 2);
    for (let i = 0; i < 26; i++) {
      const t = r.next();
      const bx = ox + 4 + 46 * t + r.float(-10, 10);
      const by = 60 - 46 * t + r.float(-10, 10);
      const ang = r.float(0, Math.PI * 2);
      const L = r.float(5, 9);
      for (let k = 0; k < L; k++) {
        const w = Math.round(Math.sin((k / L) * Math.PI) * 2.2);
        for (let q = -w; q <= w; q++) {
          const x = bx + Math.cos(ang) * k - Math.sin(ang) * q;
          const y = by + Math.sin(ang) * k + Math.cos(ang) * q;
          const lit = -Math.sin(ang) * 0.5 + (q < 0 ? 0.25 : -0.15);
          img.px(Math.round(x), Math.round(y), { c: ramp[Math.max(0, Math.min(4, Math.round(2 + lit * 2 + r.float(-0.4, 0.4))))] });
        }
      }
    }
  }
  return img;
}

// Triangular bunting pennant (12 x 16 texels) in one colour with a darker hem.
export function pennant(color) {
  const img = new PixelImage(12, 16, { wrap: false, transparent: true });
  for (let y = 0; y < 16; y++) {
    const half = Math.round(6 * (1 - y / 15));
    for (let x = 6 - half; x < 6 + half; x++) img.px(x, y, { c: tone(color, y < 2 ? -0.35 : (x - 6) * -0.04) });
  }
  return img;
}

// Pixel signboard with a 3x5 font ("WINDFERRY"), 48 x 12 texels.
const FONT = {
  W: ['101', '101', '101', '111', '101'],
  I: ['111', '010', '010', '010', '111'],
  N: ['101', '111', '111', '111', '101'],
  D: ['110', '101', '101', '101', '110'],
  F: ['111', '100', '110', '100', '100'],
  E: ['111', '100', '110', '100', '111'],
  R: ['110', '101', '110', '101', '101'],
  Y: ['101', '101', '010', '010', '010'],
};
export function signBoard(text = 'WINDFERRY') {
  const W = 48;
  const H = 12;
  const img = new PixelImage(W, H);
  const r = new RNG(5);
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++) {
      const e = y === 0 || x === 0 ? 0.2 : y === H - 1 || x === W - 1 ? -0.35 : y % 4 === 3 ? -0.15 : 0;
      img.px(x, y, { c: tone(0x9a6e44, e + r.float(-0.04, 0.04)), h: y % 4 === 3 ? 0.4 : 1, r: 0.85 });
    }
  const tw = text.length * 4 - 1;
  let cx = Math.floor((W - tw) / 2);
  for (const ch of text) {
    const g = FONT[ch];
    if (g) for (let y = 0; y < 5; y++) for (let x = 0; x < 3; x++) if (g[y][x] === '1') img.px(cx + x, 3 + y, { c: 0xf2e2b0, h: 0.3 });
    cx += 4;
  }
  return img;
}

// Painterly pixel cumulus, back-lit: lavender bodies with stepped tones and a 1-2 texel silver lining on the
// upper rims (the sun sits behind the clouds at golden hour).
export function cloud(seed, w = 160, h = 64) {
  const r = new RNG(seed);
  const img = new PixelImage(w, h, { wrap: false, transparent: true });
  const blobs = [];
  for (let i = 0; i < 9; i++) {
    const t = i / 8;
    blobs.push([w * (0.15 + 0.7 * t) + r.float(-6, 6), h * 0.62 - Math.sin(t * Math.PI) * h * 0.22 + r.float(-4, 4), r.float(10, 18) * (0.6 + Math.sin(t * Math.PI) * 0.6)]);
  }
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      let inside = 0;
      let ny = 0;
      let nx = 0;
      for (const [cx, cy, rr] of blobs) {
        const dx = (x - cx) / rr;
        const dy = (y - cy) / rr;
        const d = dx * dx + dy * dy;
        if (d < 1) {
          const k = 1 - d;
          inside = Math.max(inside, k);
          nx += dx * k;
          ny += dy * k;
        }
      }
      if (y > h * 0.74) inside *= Math.max(0, 1 - (y - h * 0.74) / 3);
      if (inside <= 0.02) continue;
      const lit = -ny * 0.9 - nx * 0.4;
      const t = lit > 0.35 ? 0.3 : lit > 0 ? 0.05 : lit > -0.4 ? -0.15 : -0.35;
      // silver lining: thin outer band on the sun-facing (upper) rim
      const rim = inside < 0.16 && ny < 0.15 ? 0.95 : inside < 0.3 && ny < -0.3 ? 0.6 : null;
      img.px(x, y, { c: tone(0xf0e2d4, rim ?? t) });
    }
  return img;
}

// Cloth for the laundry line / banner (transparent cards).
export function cloth(kind, seed = 31) {
  const r = new RNG(seed);
  if (kind === 'banner') {
    const img = new PixelImage(24, 48, { wrap: false, transparent: true });
    img.rect(0, 0, 24, 44, (a, b) => ({ c: tone(0x2f6a8a, (a === 0 ? 0.2 : a === 23 ? -0.3 : 0) + r.float(-0.03, 0.03)) }));
    for (let a = 0; a < 24; a++) if (a % 6 < 3) img.rect(a, 44, 1, 4 - (a % 3), { c: 0x2f6a8a });
    img.rect(0, 2, 24, 2, { c: 0xe8c860 });
    // kite emblem (Kites Studio)
    const cx = 12;
    const cy = 20;
    for (let k = 0; k <= 7; k++) {
      img.rect(cx - k, cy - 9 + k, k * 2 + 1, 1, { c: k < 4 ? 0xf2d070 : 0xe8a050 });
      img.rect(cx - k, cy + 7 - k, k * 2 + 1, 1, { c: k < 4 ? 0xd85a3a : 0xe88050 });
    }
    img.line(cx, cy + 8, cx - 2, cy + 18, { c: 0xf0e0c0 });
    img.px(cx - 3, cy + 13, { c: 0xd85a3a });
    img.px(cx - 1, cy + 16, { c: 0xf2d070 });
    return img;
  }
  if (kind === 'sheet') {
    const img = new PixelImage(40, 36, { wrap: false, transparent: true });
    img.rect(0, 0, 40, 36, (a, b) => ({ c: tone(0xf2ece0, ((a + b) % 10 < 1 ? -0.1 : 0) + (b < 2 ? -0.2 : 0)) }));
    for (let a = 0; a < 40; a += 8) img.rect(a, 0, 3, 36, { c: 0x8ab0d0, a: 0.6 });
    return img;
  }
  if (kind === 'shirt') {
    const img = new PixelImage(22, 22, { wrap: false, transparent: true });
    const c = r.pick([0xd85a4a, 0xe8c050, 0x6a9a5a]);
    img.rect(5, 0, 12, 22, { c });
    img.rect(0, 0, 22, 7, { c: tone(c, 0.1) });
    img.rect(9, 0, 4, 2, { c: tone(c, -0.4) });
    img.rect(5, 18, 12, 4, { c: tone(c, -0.15) });
    return img;
  }
  // kite: diamond with two panels (48x60 texels = 1.5 x 1.9 units, a "big" festival kite)
  const KW = 48;
  const KH = 60;
  const cx = KW / 2;
  const top = 22;
  const img = new PixelImage(KW, KH, { wrap: false, transparent: true });
  for (let y = 0; y < KH; y++) {
    const half = y < top ? Math.round((y / top) * (cx - 1)) : Math.round(((KH - 1 - y) / (KH - 1 - top)) * (cx - 1));
    for (let x = cx - half; x <= cx + half; x++) {
      const left = x < cx;
      const upper = y < top;
      const c = upper ? (left ? 0xf2d070 : 0xe8a040) : left ? 0xd8503a : 0xa83a3a;
      const edge = x === cx - half || x === cx + half;
      img.px(x, y, { c: edge ? tone(c, -0.35) : c });
    }
  }
  img.line(cx, 0, cx, KH - 1, { c: 0x4a3020 });
  img.line(1, top, KW - 2, top, { c: 0x4a3020 });
  return img;
}

export function lilyPad(seed = 41) {
  const r = new RNG(seed);
  const img = new PixelImage(32, 32, { wrap: false, transparent: true });
  img.disc(16, 16, 13, (dx, dy, d) => {
    const ang = Math.atan2(dy, dx);
    if (ang > 0.15 && ang < 0.55) return null; // notch
    return { c: tone(0x4a7a3a, -dx * 0.03 - dy * 0.03 + (d > 0.85 ? -0.25 : 0) + r.float(-0.05, 0.05)), h: 1 - d * 0.3, r: 0.4 };
  });
  for (let k = 0; k < 10; k++) img.px(16 + Math.cos(k * 0.6) * k, 16 + Math.sin(k * 0.6) * k * 0.3, { c: 0x6a9a4a });
  if (seed % 2) {
    img.disc(12, 13, 3, (dx, dy) => ({ c: dy < 0 ? 0xf8e4ec : 0xe8a8c0, h: 1.5 }));
    img.px(12, 13, { c: 0xf2d050 });
  }
  return img;
}
