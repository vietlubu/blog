import * as THREE from 'three';
import { TPU, dataTex } from './core.js';
import { U } from './shared.js';
import { lanterns } from './world.js';

// Hero sprite: a quad sized from the PNG's pixel size at the world texel density (never hardcoded), pivot =
// centre of the last opaque row. It faces the camera fully (tilted back with the view), so every sprite texel
// lands on a square block of screen pixels. Volume normals come from the blurred alpha silhouette; the rim is
// a crisp 1-texel line found in texel space: an opaque texel whose neighbour toward the light is transparent
// lights up (sun rim gated by the real shadow map, plus the 4 nearest lanterns / the campfire). A 1-texel
// breathe squashes the upper body every few seconds. Casts and receives shadows; soft contact shadow.
const NRIM = 4;
const RIM_GLSL = /* glsl */ `
uniform vec3 uSunDir; uniform vec3 uSunCol;
uniform vec3 uRimPos[${NRIM}]; uniform vec3 uRimCol[${NRIM}];
uniform float uRimK, uBreathe, uWaist;
uniform vec3 uRight, uUp;
uniform vec2 uTexel;
varying vec3 vHW;
float aAt(vec2 uv) { return texture2D(map, uv).a; }
// 1 if this texel sits on the silhouette edge facing direction l (world), with 'wrap' for back lights
float rimEdge(vec2 uv, vec3 l, vec3 Vw) {
  vec2 d = vec2(dot(l, uRight), dot(l, uUp));
  float back = clamp(-dot(l, Vw), 0.0, 1.0);
  float e = 0.0;
  if (length(d) > 0.05) {
    vec2 s = floor(normalize(d) * 1.4 + 0.5);
    e = step(aAt(uv + s * uTexel), 0.5);
  }
  // light behind the sprite wraps the whole outline
  float any4 = max(max(step(aAt(uv + vec2(uTexel.x, 0.0)), 0.5), step(aAt(uv - vec2(uTexel.x, 0.0)), 0.5)),
                   max(step(aAt(uv + vec2(0.0, uTexel.y)), 0.5), step(aAt(uv - vec2(0.0, uTexel.y)), 0.5)));
  return max(e, any4 * back * back);
}
vec3 spriteRim(vec2 uv, vec3 Vw, vec3 P, float sunVis) {
  vec3 rim = uSunCol * rimEdge(uv, uSunDir, Vw) * sunVis * 1.6;
  for (int i = 0; i < ${NRIM}; i++) {
    vec3 d = uRimPos[i] - P;
    float d2 = dot(d, d);
    rim += uRimCol[i] * rimEdge(uv, d * inversesqrt(d2), Vw) / (1.0 + d2 * 0.35);
  }
  return rim * uRimK;
}
`;

export async function buildHero(scene, url, pos) {
  const img = await new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = rej;
    i.src = url;
  });
  const w = img.width;
  const h = img.height;
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const cx = cv.getContext('2d');
  cx.drawImage(img, 0, 0);
  const px = cx.getImageData(0, 0, w, h).data;
  // feet: last opaque row; pivot = centre of that row's opaque pixels
  let footRow = h - 1;
  for (let y = h - 1; y >= 0; y--) {
    let any = false;
    for (let x = 0; x < w; x++) if (px[(y * w + x) * 4 + 3] > 127) any = true;
    if (any) {
      footRow = y;
      break;
    }
  }
  let sx = 0;
  let n = 0;
  for (let x = 0; x < w; x++)
    if (px[(footRow * w + x) * 4 + 3] > 127) {
      sx += x + 0.5;
      n++;
    }
  const footX = n ? sx / n : w / 2;
  // height = blurred alpha (rounded volume)
  let H = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) H[i] = px[i * 4 + 3] > 127 ? 1 : 0;
  for (let p = 0; p < 3; p++) {
    const src = H.slice();
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        let s = 0;
        let c = 0;
        for (let oy = -1; oy <= 1; oy++)
          for (let ox = -1; ox <= 1; ox++) {
            const xx = x + ox;
            const yy = y + oy;
            if (xx < 0 || yy < 0 || xx >= w || yy >= h) {
              c++;
              continue;
            }
            s += src[yy * w + xx];
            c++;
          }
        H[y * w + x] = s / c;
      }
  }
  const alb = new Uint8Array(w * h * 4);
  const nrm = new Uint8Array(w * h * 4);
  const at = (x, y) => (x < 0 || y < 0 || x >= w || y >= h ? 0 : H[y * w + x]);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const o = ((h - 1 - y) * w + x) * 4;
      for (let k = 0; k < 4; k++) alb[o + k] = px[i * 4 + k];
      const nx = -(at(x + 1, y) - at(x - 1, y)) * 2.2;
      const ny = (at(x, y + 1) - at(x, y - 1)) * 2.2;
      const l = Math.hypot(nx, ny, 1);
      nrm[o] = ((nx / l) * 0.5 + 0.5) * 255;
      nrm[o + 1] = ((ny / l) * 0.5 + 0.5) * 255;
      nrm[o + 2] = ((1 / l) * 0.5 + 0.5) * 255;
      nrm[o + 3] = 255;
    }
  const map = dataTex(alb, w, h, { srgb: true, wrap: false, name: 'hero', mips: false });
  const normalMap = dataTex(nrm, w, h, { wrap: false, name: 'heroN', mips: false });
  const ww = w / TPU;
  const hh = h / TPU;
  const g = new THREE.PlaneGeometry(ww, hh);
  g.translate(ww / 2 - footX / TPU, hh / 2 - (h - 1 - footRow) / TPU, 0);
  const uRim = {
    uSunDir: U.uSunDir,
    uSunCol: U.uSunCol,
    uRimPos: { value: Array.from({ length: NRIM }, () => new THREE.Vector3(0, -100, 0)) },
    uRimCol: { value: Array.from({ length: NRIM }, () => new THREE.Color(0, 0, 0)) },
    uRimK: { value: 1.0 },
    uBreathe: { value: 0 },
    uWaist: { value: (h - 1 - footRow + (footRow + 1) * 0.45) / h },
    uRight: { value: new THREE.Vector3(1, 0, 0) },
    uUp: { value: new THREE.Vector3(0, 1, 0) },
    uTexel: { value: new THREE.Vector2(1 / w, 1 / h) },
  };
  const mat = new THREE.MeshStandardMaterial({ map, normalMap, alphaTest: 0.5, roughness: 0.7, metalness: 0 });
  mat.normalScale.set(1.3, 1.3);
  mat.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, uRim);
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vHW;')
      .replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvHW = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <map_pars_fragment>', '#include <map_pars_fragment>\n' + RIM_GLSL + '\nvec2 gUv;')
      .replace(
        '#include <map_fragment>',
        // 1-texel breathe: rows above the waist sample one texel higher (content drops by one texel)
        `gUv = vMapUv;
        if (uBreathe > 0.5 && gUv.y > uWaist) gUv.y += uTexel.y;
        diffuseColor *= texture2D(map, gUv);`
      )
      .replace(
        '#include <opaque_fragment>',
        /* glsl */ `
        {
          vec3 Vw = normalize(cameraPosition - vHW);
          float sunVis = 1.0;
          #if NUM_DIR_LIGHT_SHADOWS > 0
            sunVis = getShadow(directionalShadowMap[0], directionalLightShadows[0].shadowMapSize, directionalLightShadows[0].shadowIntensity, directionalLightShadows[0].shadowBias, directionalLightShadows[0].shadowRadius, vDirectionalShadowCoord[0]);
          #endif
          vec2 tc = (floor(gUv / uTexel) + 0.5) * uTexel;
          outgoingLight += spriteRim(tc, Vw, vHW, sunVis) * (diffuseColor.rgb * 1.4 + 0.3);
        }
        #include <opaque_fragment>`
      );
  };
  mat.customProgramCacheKey = () => 'heroRim';
  const mesh = new THREE.Mesh(g, mat);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.customDepthMaterial = new THREE.MeshDepthMaterial({ map, alphaTest: 0.5, side: THREE.DoubleSide });
  mesh.position.copy(pos);
  scene.add(mesh);

  // soft contact shadow under the feet
  const cs = new THREE.Mesh(
    new THREE.PlaneGeometry(ww * 0.95, ww * 0.42).rotateX(-Math.PI / 2),
    new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: 'varying vec2 vUv; void main(){ float d = length((vUv - 0.5) * 2.0); gl_FragColor = vec4(0.02, 0.01, 0.03, 0.55 * smoothstep(1.0, 0.2, d)); }',
    })
  );
  cs.position.set(pos.x, pos.y + 0.02, pos.z);
  scene.add(cs);

  return {
    mesh,
    size: [w, h],
    worldH: (footRow + 1) / TPU,
    update(camera, t) {
      // face the camera fully (pivot at the feet), so sprite texels stay square on screen
      mesh.quaternion.copy(camera.quaternion);
      mesh.updateMatrixWorld();
      uRim.uRight.value.set(1, 0, 0).applyQuaternion(mesh.quaternion);
      uRim.uUp.value.set(0, 1, 0).applyQuaternion(mesh.quaternion);
      uRim.uBreathe.value = t % 3.4 > 2.5 ? 1 : 0;
      // feed the nearest lanterns / the campfire into the rim term
      const near = lanterns
        .map((l) => [l, l.pos.distanceToSquared(mesh.position)])
        .sort((a, b) => a[1] - b[1])
        .slice(0, NRIM);
      near.forEach(([l], i) => {
        uRim.uRimPos.value[i].copy(l.pos);
        uRim.uRimCol.value[i].copy(l.light.color).multiplyScalar(l.light.intensity * 0.12);
      });
    },
    uRim,
  };
}
