import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { TPU, pixMat, texelBox } from './core.js';
import * as T from './textures.js';
import { U, LAYER } from './shared.js';
import { WATER_Y, T2_Y, groundY } from './layout.js';

function add(parent, geo, mat, { cast = true, receive = true } = {}) {
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = cast;
  m.receiveShadow = receive;
  parent.add(m);
  return m;
}

// ---------------------------------------------------------------------------
// Houses: painted timber-and-plaster façades at exact texel size, dressed with real 3D trim so the low sun
// draws lit edges + shadow lines: protruding timber frame, window frames with sills and lintels, louvered
// shutters left ajar, deep eaves with fascia, bargeboards and rafter tails, a thatch eave roll, ridge caps,
// chimneys with pots and a porch.
// ---------------------------------------------------------------------------
export const facadeMats = [];
function facadeMat(o) {
  const m = pixMat(T.facade(o), { normal: 2.2, emissive: 1.5 });
  facadeMats.push(m);
  return m;
}

// Face spec in units from the wall's bottom-left: windows [[x,y,w,h]], door [x,w,h], posts [x], floors [y], braces [[x0,y0,x1,y1]]
function faceOpts(wU, hU, gU, f, extra) {
  const H = Math.round((hU + gU) * TPU);
  const yImg = (yu) => H - Math.round(yu * TPU);
  return {
    w: Math.round(wU * TPU),
    h: Math.round(hU * TPU),
    gable: Math.round(gU * TPU),
    windows: (f.windows || []).map(([x, y, w, h, lit = 1]) => ({ x: Math.round(x * TPU), y: yImg(y + h), w: Math.round(w * TPU), h: Math.round(h * TPU), lit })),
    door: f.door ? { x: Math.round(f.door[0] * TPU), w: Math.round(f.door[1] * TPU), h: Math.round(f.door[2] * TPU), color: f.door[3] } : null,
    posts: f.posts ? f.posts.map((x) => Math.min(Math.round(x * TPU), Math.round(wU * TPU) - 4)) : undefined,
    floors: (f.floors || []).map((y) => yImg(y) - 2),
    braces: (f.braces || []).map(([a, b, c, d]) => [Math.round(a * TPU), yImg(b), Math.round(c * TPU), yImg(d)]),
    noTimber: f.noTimber,
    ...extra,
  };
}

function pentagon(d, h, gab) {
  const s = new THREE.Shape([new THREE.Vector2(-d / 2, 0), new THREE.Vector2(d / 2, 0), new THREE.Vector2(d / 2, h), new THREE.Vector2(0, h + gab), new THREE.Vector2(-d / 2, h)]);
  const g = new THREE.ShapeGeometry(s);
  const p = g.attributes.position;
  const uv = g.attributes.uv;
  for (let i = 0; i < p.count; i++) uv.setXY(i, (p.getX(i) + d / 2) / d, p.getY(i) / (h + gab));
  return g;
}

export const lightSpots = []; // { pos, n?, color, kind: 'window' | 'lantern' | 'fire', size?, sill?, hang? }

const TB = 0.125; // timber width (4 texels)
const TP = 0.0625; // timber protrusion (2 texels)
const FH = 0.375; // painted stone foundation height (12 texels)

// 3D trim on one face. `grp` sits in the face plane (local z = 0, +z outward); u runs 0..W along local x
// (x = u - W/2) and v is the height above the wall base — the same coordinates as the façade painter.
function faceTrim(grp, W, H, gable, f, mats, shutterMat) {
  const box = (u0, v0, u1, v1, p, mat) => {
    const m = add(grp, texelBox(Math.max(u1 - u0, 0.02), Math.max(v1 - v0, 0.02), p), mat);
    m.position.set((u0 + u1) / 2 - W / 2, (v0 + v1) / 2, p / 2);
    return m;
  };
  if (!f.noTimber) {
    for (const pu of f.posts || [0, W]) {
      const u = Math.min(Math.max(pu, 0), W - TB);
      box(u, FH, u + TB, H, TP, mats.timber);
    }
    box(0, H - TB, W, H, TP, mats.timber);
    box(0, FH, W, FH + TB, TP, mats.timber);
    for (const fy of f.floors || []) box(0, fy - TB / 2, W, fy + TB / 2, TP, mats.timber);
    for (const [a, b, c, d] of f.braces || []) {
      const m = box(0, 0, Math.hypot(c - a, d - b), TB, TP * 0.8, mats.timber);
      m.position.set((a + c) / 2 - W / 2, (b + d) / 2, TP * 0.4);
      m.rotation.z = Math.atan2(d - b, c - a);
    }
    if (gable) box(W / 2 - TB / 2, H, W / 2 + TB / 2, H + gable, TP, mats.timber);
  }
  const fw = 0.07;
  for (const [x, y, ww, wh] of f.windows || []) {
    box(x - fw, y - fw, x + ww + fw, y, 0.08, mats.frame);
    box(x - fw, y + wh, x + ww + fw, y + wh + fw, 0.08, mats.frame);
    box(x - fw, y, x, y + wh, 0.08, mats.frame);
    box(x + ww, y, x + ww + fw, y + wh, 0.08, mats.frame);
    box(x - 0.15, y - 0.15, x + ww + 0.15, y - fw, 0.18, mats.wallCap);
    box(x - 0.1, y + wh + fw, x + ww + 0.1, y + wh + fw + 0.1, 0.11, mats.timber);
    if (!shutterMat) continue;
    // louvered shutters, hinged on the frame and left ajar (outer edge swung ~25-45° off the wall)
    const sw = 0.22;
    for (const side of [-1, 1]) {
      const pivot = new THREE.Group();
      pivot.position.set((side < 0 ? x - fw : x + ww + fw) - W / 2, y + wh / 2, 0.02);
      pivot.rotation.y = -side * (0.42 + ((x * 7.3 + y * 3.1) % 0.35));
      grp.add(pivot);
      const b = add(pivot, texelBox(sw, wh + 0.1, 0.045), shutterMat);
      b.position.set((side * sw) / 2, 0, 0.0225);
    }
  }
  if (f.door) {
    const [dx, dw, dh] = f.door;
    box(dx - 0.1, FH, dx, FH + dh + 0.1, 0.1, mats.frame);
    box(dx + dw, FH, dx + dw + 0.1, FH + dh + 0.1, 0.1, mats.frame);
    box(dx - 0.16, FH + dh + 0.1, dx + dw + 0.16, FH + dh + 0.24, 0.14, mats.timber);
  }
}

function buildHouse(scene, spec, mats) {
  const { w, d, wallH: h, roofH: rh, roof, seed } = spec;
  const grp = new THREE.Group();
  grp.position.set(spec.x, spec.y, spec.z);
  grp.rotation.y = spec.rot || 0;
  scene.add(grp);
  grp.updateMatrixWorld(true);
  const extra = { seed, plaster: spec.plaster };
  const shutterMat = spec.shutter ? mats.shutter(spec.shutter) : null;
  const backSpec = spec.back || { windows: [[w / 2 - 0.5, 1.0, 1.0, 0.9]] };
  // faces: [local position, rotation.y, width, painted spec, gable height]
  const faces = [
    [[0, 0, d / 2], 0, w, spec.front || {}, 0],
    [[0, 0, -d / 2], Math.PI, w, backSpec, 0],
    [[w / 2, 0, 0], Math.PI / 2, d, spec.right || {}, rh],
    [[-w / 2, 0, 0], -Math.PI / 2, d, spec.left || {}, rh],
  ];
  faces.forEach(([p, ry, W, f, gab], i) => {
    const m = facadeMat(faceOpts(W, h, gab, f, { ...extra, seed: seed + 1 + i }));
    const mesh = add(grp, gab ? pentagon(W, h, gab) : new THREE.PlaneGeometry(W, h).translate(0, h / 2, 0), m);
    mesh.position.set(...p);
    mesh.rotation.y = ry;
    const tg = new THREE.Group();
    tg.position.set(...p);
    tg.rotation.y = ry;
    grp.add(tg);
    faceTrim(tg, W, h, gab, f, mats, shutterMat);
  });
  // roof: slabs with deep eaves, fascia / thatch roll, rafter tails, bargeboards, ridge
  const ov = spec.ov ?? 0.72;
  const ovG = 0.45;
  const a = Math.atan2(rh, d / 2);
  const run = d / 2 + ov;
  const L = run / Math.cos(a);
  const th = roof === 'thatch' ? 0.36 : 0.16;
  const rmat = mats[roof];
  const midY = h + rh - (run / 2) * Math.tan(a);
  for (const s of [1, -1]) {
    const m = add(grp, texelBox(w + ovG * 2, th, L), rmat);
    m.position.set(0, midY + (th / 2) * Math.cos(a), (s * run) / 2 + s * (th / 2) * Math.sin(a));
    m.rotation.set(s > 0 ? a : -a, s > 0 ? Math.PI : 0, 0);
    const ey = h + rh - run * Math.tan(a);
    if (roof === 'thatch') {
      const roll = add(grp, new THREE.CylinderGeometry(0.24, 0.24, w + ovG * 2 + 0.1, 10).rotateZ(Math.PI / 2), rmat);
      roll.position.set(0, ey + 0.1, s * (run + 0.02));
    } else {
      const fa = add(grp, texelBox(w + ovG * 2 + 0.04, 0.2, 0.07), mats.timber);
      fa.position.set(0, ey + 0.02, s * (run + 0.02));
      for (let x = -w / 2 + 0.2; x <= w / 2 - 0.1; x += 0.55) {
        const t = add(grp, texelBox(0.08, 0.08, ov + 0.05), mats.timber, { cast: false });
        t.position.set(x, h + rh - (d / 2 + ov / 2) * Math.tan(a) - 0.05, s * (d / 2 + ov / 2));
        t.rotation.x = s > 0 ? a : -a;
      }
    }
    for (const gx of [1, -1]) {
      const bb = add(grp, texelBox(0.09, roof === 'thatch' ? 0.42 : 0.26, L + 0.08), roof === 'thatch' ? rmat : mats.timber);
      bb.position.set(gx * (w / 2 + ovG + 0.04), midY + (th / 2) * Math.cos(a), (s * run) / 2 + s * (th / 2) * Math.sin(a));
      bb.rotation.x = s > 0 ? a : -a;
    }
  }
  const ridgeY = h + rh + th * 0.9;
  if (roof === 'clay') {
    const rc = add(grp, new THREE.CylinderGeometry(0.15, 0.15, w + ovG * 2 + 0.08, 8).rotateZ(Math.PI / 2), mats.clay);
    rc.position.set(0, ridgeY, 0);
  } else if (roof === 'thatch') {
    const rc = add(grp, new THREE.CylinderGeometry(0.3, 0.3, w + ovG * 2, 10).rotateZ(Math.PI / 2), mats.thatch);
    rc.position.set(0, ridgeY - 0.05, 0);
  } else {
    const ridge = add(grp, texelBox(w + ovG * 2 + 0.05, 0.2, 0.34), mats.ridge);
    ridge.position.set(0, ridgeY, 0);
  }
  if (spec.chimney) {
    const [cx, cz] = spec.chimney;
    const ch = rh + 1.3;
    const c = add(grp, texelBox(0.72, ch, 0.72), mats.wall);
    c.position.set(cx, h + ch / 2 + 0.2, cz);
    const cap = add(grp, texelBox(0.9, 0.14, 0.9), mats.wallCap);
    cap.position.set(cx, h + ch + 0.27, cz);
    const pot = add(grp, new THREE.CylinderGeometry(0.13, 0.15, 0.3, 8), mats.clay);
    pot.position.set(cx + 0.12, h + ch + 0.48, cz);
    spec.smoke = grp.localToWorld(new THREE.Vector3(cx + 0.12, h + ch + 0.66, cz));
  }
  if (spec.porch) {
    // small lean-to over the door on two posts
    const [px, pw, pd, py] = spec.porch;
    const u = px - w / 2;
    const pr = add(grp, texelBox(pw, 0.12, pd + 0.2), roof === 'thatch' ? mats.plank : rmat);
    pr.position.set(u, py, d / 2 + pd / 2);
    pr.rotation.x = 0.32;
    for (const sx of [-1, 1]) {
      const post = add(grp, texelBox(0.12, py, 0.12), mats.timber);
      post.position.set(u + sx * (pw / 2 - 0.12), py / 2, d / 2 + pd - 0.08);
    }
  }
  spec.flowerPts = [];
  for (const [fx, fy, fw] of spec.flowerBoxes || []) {
    const b = add(grp, texelBox(fw + 0.2, 0.22, 0.28), mats.plank);
    b.position.set(-w / 2 + fx + fw / 2, fy - 0.24, d / 2 + 0.3);
    for (let i = 0; i < 4; i++) spec.flowerPts.push(grp.localToWorld(new THREE.Vector3(-w / 2 + fx + 0.1 + (fw * (i + 0.5)) / 4, fy - 0.14, d / 2 + 0.3)));
  }
  // lit windows: glow spots for fog scattering, light-pool decals and the hero's lantern rim
  const nrm = new THREE.Vector3();
  for (const [face, f] of [['front', spec.front], ['right', spec.right], ['left', spec.left]]) {
    for (const [x, y, ww, wh, lit = 1] of (f && f.windows) || []) {
      if (!lit) continue;
      let p;
      if (face === 'front') {
        p = new THREE.Vector3(-w / 2 + x + ww / 2, y + wh / 2, d / 2 + 0.25);
        nrm.set(0, 0, 1);
      } else {
        const sd = face === 'right' ? 1 : -1;
        p = new THREE.Vector3(sd * (w / 2 + 0.25), y + wh / 2, sd * (d / 2 - x - ww / 2));
        nrm.set(sd, 0, 0);
      }
      p.applyMatrix4(grp.matrixWorld);
      const n = nrm.clone().transformDirection(grp.matrixWorld);
      lightSpots.push({ pos: p, n, color: new THREE.Color(1.0, 0.62, 0.3), kind: 'window', size: ww, sill: spec.y + y });
    }
  }
  spec.lampPts = (spec.lamps || []).map((p) => grp.localToWorld(new THREE.Vector3(...p)));
  grp.userData.spec = spec;
  return grp;
}

export const HOUSES = [
  {
    // thatched cottage, left — forward on the terrace, water wheel beside it, porch over the door
    x: -10.4, z: -6.9, y: T2_Y, rot: 0.2, w: 5.4, d: 4.2, wallH: 2.5, roofH: 2.5, roof: 'thatch', seed: 101, shutter: 0x4a7a5a,
    front: { windows: [[0.55, 0.85, 0.95, 0.85], [3.75, 0.85, 0.95, 0.85]], door: [2.15, 1.15, 2.05, 0x7a4a2e], posts: [0, 1.75, 3.5, 5.4], braces: [[0.1, 0.45, 1.6, 2.4]] },
    right: { windows: [[1.6, 0.9, 1.0, 0.8]], posts: [0, 4.2] },
    left: { windows: [[1.6, 0.9, 1.0, 0.8, 0]] },
    chimney: [-1.6, -0.6],
    flowerBoxes: [[0.55, 0.85, 0.95], [3.75, 0.85, 0.95]],
    lamps: [[1.4, 1.65, 2.35]],
  },
  {
    // two-storey clay-tile house at the centre, highest plinth, at the top of the stairs
    x: 2.5, z: -11.0, y: T2_Y + 0.8, plinth: 0.8, rot: -0.08, w: 6.2, d: 4.6, wallH: 4.3, roofH: 2.6, roof: 'clay', seed: 202, shutter: 0x3a7a80,
    front: {
      windows: [[0.7, 0.95, 1.0, 0.95], [4.5, 0.95, 1.0, 0.95], [0.7, 2.75, 1.0, 1.0], [2.6, 2.75, 1.0, 1.0], [4.5, 2.75, 1.0, 1.0, 0]],
      door: [2.55, 1.1, 2.15, 0x5a3a52],
      posts: [0, 2.15, 3.95, 6.2],
      floors: [2.35],
      braces: [[0.1, 2.4, 0.6, 4.2], [6.05, 2.4, 5.6, 4.2]],
    },
    right: { windows: [[1.8, 2.8, 1.0, 0.9]], floors: [2.35], posts: [0, 4.6] },
    left: { windows: [[1.8, 2.8, 1.0, 0.9], [1.8, 0.95, 1.0, 0.9]], floors: [2.35], posts: [0, 4.6] },
    chimney: [2.0, -0.7],
    flowerBoxes: [[0.7, 2.75, 1.0], [2.6, 2.75, 1.0], [0.7, 0.95, 1.0]],
    lamps: [[1.0, 2.5, 2.6]],
  },
  {
    // slate-roofed house, gable end turned toward the camera, pushed back on a low plinth
    x: 11.2, z: -9.6, y: T2_Y + 0.35, plinth: 0.35, rot: -Math.PI / 2 + 0.4, w: 4.4, d: 5.0, wallH: 2.8, roofH: 2.5, roof: 'slate', seed: 303, shutter: 0xa84a3a, plaster: [0xb8ac9a, 0xd0c4ae, 0xe2d8c2, 0xf0e8d6],
    front: { windows: [[1.7, 1.0, 1.0, 0.9]] },
    right: { windows: [[0.55, 0.95, 0.95, 0.9], [2.1, 3.3, 0.8, 0.8]], door: [2.9, 1.1, 2.05, 0x3a5a7a], posts: [0, 1.95, 2.55, 4.04, 5.0], braces: [[4.1, 0.5, 4.9, 2.6]] },
    left: { windows: [[2.0, 1.0, 1.0, 0.9, 0]] },
    chimney: [-1.2, 1.4],
    flowerBoxes: [],
    lamps: [[2.6, 2.3, -1.0]],
  },
];

export function buildHouses(scene, mats) {
  const groups = HOUSES.map((s) => {
    if (s.plinth) {
      const p = add(scene, texelBox(s.w + 0.7, s.plinth + 0.8, s.d + 0.7), mats.wall);
      p.position.set(s.x, s.y - (s.plinth + 0.8) / 2 + 0.02, s.z);
      p.rotation.y = s.rot;
      // two steps up the plinth on the front side
      for (let i = 0; i < 2; i++) {
        const sh = ((i + 1) * s.plinth) / 2;
        const st = add(scene, texelBox(1.5, sh + 0.2, 0.42), mats.wallCap);
        const out = s.d / 2 + 0.35 + 0.42 * (1.5 - i);
        st.position.set(s.x + Math.sin(s.rot) * out, T2_Y + sh / 2 - 0.1, s.z + Math.cos(s.rot) * out);
        st.rotation.y = s.rot;
      }
    }
    return buildHouse(scene, s, mats);
  });
  // small cottage up the hill (T3) on a stone plinth
  const hx = -15.5;
  const hz = -20.5;
  const gy = Math.min(groundY(hx - 2, hz - 2), groundY(hx + 2, hz + 2), groundY(hx - 2, hz + 2), groundY(hx + 2, hz - 2));
  const plinth = add(scene, texelBox(4.6, 1.6, 4.0), mats.wall);
  plinth.position.set(hx, gy - 0.6, hz);
  const spec = { x: hx, z: hz, y: gy + 0.2, rot: 0.25, w: 4.0, d: 3.4, wallH: 2.2, roofH: 1.9, roof: 'clay', seed: 404, shutter: 0x8a6a3a, front: { windows: [[0.6, 0.8, 0.9, 0.8], [2.6, 0.8, 0.9, 0.8]] }, chimney: [1.2, 0.4] };
  HOUSES.push(spec);
  groups.push(buildHouse(scene, spec, mats));
  return groups;
}

// Warm light-pool decals: additive radial quads conforming to the ground in front of every lit window and
// under every lantern, plus a soft wash on the wall below each window. Big readable pools at zero lighting
// cost; strength follows uNight (faint at golden hour).
export const decalU = { uNight: U.uNight, uK: { value: 1 } };
export function buildLightDecals(scene) {
  const mat = new THREE.ShaderMaterial({
    uniforms: decalU,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
    vertexShader: `attribute vec4 aCol; varying vec2 vUv; varying vec4 vCol; void main(){ vUv = uv; vCol = aCol; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: /* glsl */ `
      uniform float uNight, uK; varying vec2 vUv; varying vec4 vCol;
      void main(){
        float r = length((vUv - 0.5) * 2.0);
        // banded falloff keeps the pool reading as pixel-art light rather than a smooth airbrush
        float f = clamp(1.0 - r, 0.0, 1.0);
        f *= f;
        f = floor(f * 6.0 + 0.5) / 6.0 * 0.6 + f * 0.4;
        gl_FragColor = vec4(vCol.rgb * f * vCol.a * mix(0.12, 1.0, uNight) * uK, 1.0);
      }`,
  });
  const geos = [];
  const colored = (g, col, k) => {
    const c = new Float32Array(g.attributes.position.count * 4);
    for (let i = 0; i < c.length / 4; i++) c.set([col.r, col.g, col.b, k], i * 4);
    g.setAttribute('aCol', new THREE.BufferAttribute(c, 4));
    geos.push(g);
  };
  const ground = (x, z, rx, rz, col, k) => {
    const g = new THREE.PlaneGeometry(rx * 2, rz * 2, 8, 8);
    g.rotateX(-Math.PI / 2);
    g.translate(x, 0, z);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) p.setY(i, Math.max(groundY(p.getX(i), p.getZ(i)), WATER_Y) + 0.03);
    colored(g, col, k);
  };
  for (const s of lightSpots) {
    if (s.kind === 'window') {
      const out = s.pos.clone().addScaledVector(s.n, 1.1);
      ground(out.x, out.z, 1.5, 1.5, s.color, s.pos.y - s.sill > 2 ? 0.25 : 0.55);
      const g = new THREE.PlaneGeometry(s.size + 1.2, 1.6);
      g.rotateY(Math.atan2(s.n.x, s.n.z));
      const wp = s.pos.clone().addScaledVector(s.n, -0.22);
      g.translate(wp.x, wp.y - 0.55, wp.z);
      colored(g, s.color, 0.35);
    } else if (s.kind === 'lantern') {
      ground(s.pos.x, s.pos.z, 2.2, 2.2, s.color, s.hang ? 0.6 : 0.35);
    }
  }
  const m = new THREE.Mesh(mergeGeometries(geos), mat);
  m.layers.set(LAYER.MAIN);
  m.renderOrder = 2;
  scene.add(m);
}
