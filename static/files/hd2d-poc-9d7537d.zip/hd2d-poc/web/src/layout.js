import { smoothstep, vnoise, fbm } from './core.js';

// "Windferry Hamlet" layout. X runs left→right along the diorama strip, -Z goes back (up the tiers).
export const WATER_Y = -0.32;
export const T2_Y = 0.9; // house terrace behind the retaining wall
export const BOX = { x0: -56, x1: 56, z0: -64, z1: 30 }; // terrain extent

export const HERO = { x: 2.4, z: 1.55 };
export const BRIDGE = { x: -4.9, L: 5.2, W: 2.0, rise: 0.75 };
export const STAIRS = { x0: 1.6, x1: 3.4 };
export const SPILL = { x0: -7.1, x1: -5.7 };
export const FIRE = { x: 4.9, z: -0.7 }; // campfire on the grass between path and wall (warm focal light)

// Retaining wall front face, stepped so no single edge spans the frame: a forward run on the left (waterfall),
// a 1.2 u recess holding the stairs behind the hero, and a slightly set-back run on the right.
export const WALL = [
  { x0: -56, x1: 0.9, z: -3.5 },
  { x0: 0.9, x1: 4.1, z: -4.7 },
  { x0: 4.1, x1: 56, z: -3.8 },
];
export function wallZ(x) {
  for (const s of WALL) if (x < s.x1) return s.z;
  return WALL[WALL.length - 1].z;
}

export const pathZ = (x) => 0.95 + 0.32 * Math.sin(x * 0.13 + 0.6);
export const PATH_HW = 1.2;

// T1 stream: from the waterfall (x≈-6.4 at the wall) bending to pass under the bridge, then into the pond.
export const streamX = (z) => -4.9 - 1.5 * smoothstep(-0.6, -3.5, z) + 0.25 * Math.sin(z * 0.9);
// T2 channel feeding the waterfall (and turning the water wheel)
export const channelX = (z) => -6.4 + 0.2 * Math.sin(z * 0.5);
// pond in the lower-left third, inside the focal region, right below the bridge so it mirrors bridge + cottage
export const POND = { x: -4.7, z: 4.9, rx: 4.6, rz: 2.5 };

// Signed distance-ish to T1 water (negative = inside water).
export function waterDist(x, z) {
  let d = 1e9;
  const wz = wallZ(x);
  if (z > wz - 0.2 && z < 4) {
    const hw = 1.15 + 0.2 * smoothstep(1, 3, z);
    d = Math.abs(x - streamX(z)) - hw;
    if (z < wz + 0.05) d = Math.max(d, wz - 0.2 - z);
  }
  const ex = (x - POND.x) / POND.rx;
  const ez = (z - POND.z) / POND.rz;
  const e = Math.sqrt(ex * ex + ez * ez);
  const pd = (e - 1) * Math.min(POND.rx, POND.rz) + (vnoise(x * 0.45, z * 0.45) - 0.5) * 0.7;
  return Math.min(d, pd);
}

export function channelDist(x, z) {
  if (z > wallZ(x) - 0.05 || z < -13.5) return 1e9;
  return Math.abs(x - channelX(z)) - 0.62;
}

export function onPath(x, z) {
  return Math.abs(z - pathZ(x)) - PATH_HW - (vnoise(x * 0.7, 3.3) - 0.5) * 0.35;
}

export const isT1 = (x, z) => z > wallZ(x) - 0.1;

export function baseHeight(x, z) {
  let y;
  if (isT1(x, z)) {
    y = (fbm(x * 0.07, z * 0.07) - 0.5) * 0.25 * smoothstep(1.5, 4, Math.abs(z - pathZ(x)));
    y += 0.25 * smoothstep(10, 22, z) * fbm(x * 0.05 + 4, z * 0.05);
  } else if (z > -13) {
    y = T2_Y + (fbm(x * 0.09 + 9, z * 0.09) - 0.5) * 0.2;
  } else {
    const t = smoothstep(-13, -38, z);
    y = T2_Y + 4.4 * t + (fbm(x * 0.05, 2.3) - 0.45) * 2.2 * smoothstep(-14, -30, z) + (fbm(x * 0.12, z * 0.12) - 0.5) * 0.5 * t;
  }
  return y;
}

export function groundY(x, z) {
  let y = baseHeight(x, z);
  if (isT1(x, z)) {
    const p = onPath(x, z);
    if (p < 0.4) y *= smoothstep(-0.4, 0.4, p);
    const wd = waterDist(x, z);
    if (wd < 0.7) {
      const deep = WATER_Y - 0.15 - 0.55 * smoothstep(0, 2.2, -wd);
      y = y + (deep - y) * smoothstep(0.7, -0.35, wd);
    }
    // campfire clearing
    const fd = Math.hypot(x - FIRE.x, z - FIRE.z);
    if (fd < 1.4) y *= smoothstep(0.6, 1.4, fd);
  } else if (z > -14) {
    const cd = channelDist(x, z);
    if (cd < 0.5) y = y + (T2_Y - 0.65 - y) * smoothstep(0.5, -0.2, cd);
  }
  return y;
}
