import * as THREE from 'three';
import { U } from './shared.js';
import { buildWorld, lanterns, fire, spinners, skyU, cloudU, clouds } from './world.js';
import { lightSpots, facadeMats, HOUSES, decalU } from './houses.js';
import { buildGrass, buildTrees, finishTrees, buildBranch, buildLilyPads } from './foliage.js';
import { buildHero } from './hero.js';
import { buildLife } from './life.js';
import { Pipeline } from './pipeline.js';
import { gustAt } from './wind.js';
import { HERO, groundY } from './layout.js';

const params = new URLSearchParams(location.search);
// maxH: internal render height cap; adaptive: step the internal height down (1440 → 1260 → 1080) while
// frame time p95 stays above 18 ms, and back up when there is headroom (?fixed disables it)
const QUALITIES = {
  low: { maxH: 720, msaa: 0, fogSteps: 24, fogScale: 0.5, shadow: 2048, dofRad: 1.3, particles: 0.5, grass: 0.55 },
  med: { maxH: 1080, msaa: 2, fogSteps: 32, fogScale: 0.5, shadow: 4096, dofRad: 1.0, particles: 0.8, grass: 0.8 },
  high: { maxH: 1440, msaa: 2, fogSteps: 36, fogScale: 0.5, shadow: 4096, dofRad: 1.0, particles: 1, grass: 1 },
};
const QN = QUALITIES[params.get('q')] ? params.get('q') : 'high';
const Q = QUALITIES[QN];
for (const k of Object.keys(Q)) if (params.has(k)) Q[k] = +params.get(k); // e.g. ?q=med&msaa=0&fogSteps=24
const ADAPTIVE = !params.has('fixed');

const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', preserveDrawingBuffer: params.has('capture') });
renderer.setPixelRatio(1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.shadowMap.autoUpdate = false;
renderer.toneMapping = THREE.NoToneMapping;
document.getElementById('stage').appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(22, 16 / 9, 0.5, 1500);

// --- lights ---------------------------------------------------------------------
const sun = new THREE.DirectionalLight(0xffffff, 3);
sun.castShadow = true;
sun.shadow.mapSize.set(Q.shadow, Q.shadow);
Object.assign(sun.shadow.camera, { left: -52, right: 52, top: 42, bottom: -42, near: 1, far: 220 });
sun.shadow.camera.updateProjectionMatrix();
sun.shadow.bias = -0.0004;
sun.shadow.normalBias = 0.02;
scene.add(sun, sun.target);
const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1);
scene.add(hemi);
const fill = new THREE.DirectionalLight(0xffffff, 0.3); // cool sky bounce from the camera side, no shadows
fill.position.set(0.3, 0.6, 1);
scene.add(fill);

// --- camera rig ---------------------------------------------------------------------
// Narrow FOV (22° vertical). The body is pitched 23° down and the frustum is lens-shifted so the hero sits at
// NDC y -0.2 on a 22° line of sight: we look *down into* the diorama (ground plane = the stage). A -7° yaw makes
// the wall and path recede left → right. Distance puts the hero at exactly 3.0 screen px per sprite texel at
// the default 1440p internal height. Slow breathing drift; drag = limited pan, wheel = small zoom.
const deg = THREE.MathUtils.degToRad;
const rig = { tx: HERO.x - 1.4, ty: 1.0, tz: HERO.z - 0.4, dist: 1440 / (2 * 32 * Math.tan(deg(11)) * 3), sight: deg(22), pitch: deg(23), heroNdc: -0.2, yaw: deg(-7), panX: 0, zoom: 0 };
function updateProjection() {
  camera.updateProjectionMatrix();
  // NDC_y = tan(angle above the axis) / tan(fov/2) - shift
  camera.projectionMatrix.elements[9] = Math.tan(rig.pitch - rig.sight) / Math.tan(deg(camera.fov / 2)) - rig.heroNdc;
  camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();
}
function placeCamera(t) {
  const yaw = rig.yaw + Math.sin(t * 0.11) * 0.014;
  const breathe = Math.sin(t * 0.083 + 1) * 0.004;
  const sight = rig.sight + breathe;
  const dist = rig.dist + rig.zoom + Math.sin(t * 0.07) * 0.4;
  const tx = rig.tx + rig.panX;
  camera.position.set(tx + Math.sin(yaw) * Math.cos(sight) * dist, rig.ty + Math.sin(sight) * dist, rig.tz + Math.cos(yaw) * Math.cos(sight) * dist);
  camera.rotation.set(-rig.pitch - breathe, yaw, 0, 'YXZ');
}
const adapt = { levels: [1, 0.875, 0.75], level: 0, hist: [], calm: 0 };
function resize() {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const ih = Math.round(Math.min(Math.round(vh * Math.min(window.devicePixelRatio || 1, 2)), Q.maxH) * adapt.levels[adapt.level]);
  const iw = Math.round((ih * vw) / vh);
  renderer.setSize(iw, ih, false);
  renderer.domElement.style.width = vw + 'px';
  renderer.domElement.style.height = vh + 'px';
  camera.aspect = vw / vh;
  updateProjection();
  pipeline.setSize(iw, ih);
  U.uProjScale.value = ih / (2 * Math.tan(deg(camera.fov / 2)));
}
camera.aspect = window.innerWidth / window.innerHeight;
updateProjection();
placeCamera(0);
camera.updateMatrixWorld();

// --- world ------------------------------------------------------------------------
const world = buildWorld(scene);
const treeData = buildTrees({ quality: Q.grass });
const trees = finishTrees(scene, treeData);
buildBranch(scene, camera);
const pads = buildLilyPads(scene);
const flowerPts = HOUSES.flatMap((h) => h.flowerPts || []);
const grass = buildGrass(scene, { houses: world.houses, extra: flowerPts, density: Q.grass, camPos: camera.position });
const life = buildLife(scene, { houses: world.houses, lilyPads: pads, quality: Q });
const pipeline = new Pipeline(renderer, scene, camera, sun, Q);
window.addEventListener('resize', resize);
resize();

const heroPos = new THREE.Vector3(HERO.x, groundY(HERO.x, HERO.z), HERO.z);
const hero = await buildHero(scene, `${import.meta.env.BASE_URL}hero.png`, heroPos);
const heroMid = heroPos.clone().setY(heroPos.y + hero.worldH * 0.5);
const windowSpots = lightSpots.filter((s) => s.kind === 'window').sort((a, b) => a.pos.distanceTo(heroPos) - b.pos.distanceTo(heroPos));

// --- presets (1 golden hour, 2 blue hour / night) ------------------------------------
// Golden hour: surfaces carry their own cool ambient (hemi + fill) so the volumetric pass only adds shafts and a
// thin haze; fog density fades in behind the focal band. Night: "feel dark, don't be dark" — a strong cold moon
// key, high exposure, big warm pools from lanterns, the campfire and window decals.
const PRESETS = {
  golden: {
    sunDir: [-0.72, 0.36, -0.6], sunCol: [1.0, 0.74, 0.5], sunI: 6.3,
    hemiSky: [0.46, 0.6, 1.0], hemiGround: [0.24, 0.26, 0.32], hemiI: 2.2, fillI: 1.1, fillCol: [0.55, 0.68, 1.0],
    zenith: [0.25, 0.42, 0.7], horizon: [1.0, 0.74, 0.5], glow: [1.0, 0.6, 0.3], cloudLit: [1.0, 0.86, 0.66], cloudShade: [0.58, 0.54, 0.72],
    fogDen: 0.006, vol: 0.03, fogFall: 0.12, mist: 0.1, g: 0.72, haze: 0.0045, shaft: 4.2, fadeMin: 0.4,
    sunScat: [1.0, 0.64, 0.4], ambLow: [0.008, 0.012, 0.03], ambHigh: [0.012, 0.016, 0.036], hazeCol: [0.5, 0.52, 0.66], reflFog: [0.6, 0.6, 0.66],
    exposure: 1.42, bloom: 0.06, windowE: 1.1, lanternE: 3.5, lanternI: 4, fireI: 6, fireK: 0.9, windowI: 0.8, fogLantern: 1.0, fogWindow: 0.4, decal: 0.6,
    fireflies: 0.35, night: 0, shadowTint: [-0.05, -0.02, 0.06], highTint: [0.035, 0.012, -0.03], contrast: 1.14, saturation: 1.08,
  },
  night: {
    sunDir: [0.45, 0.6, -0.62], sunCol: [0.55, 0.68, 1.0], sunI: 2.8,
    hemiSky: [0.24, 0.32, 0.6], hemiGround: [0.08, 0.09, 0.14], hemiI: 1.1, fillI: 0.35, fillCol: [0.42, 0.52, 0.95],
    zenith: [0.03, 0.05, 0.12], horizon: [0.12, 0.15, 0.28], glow: [0.1, 0.12, 0.25], cloudLit: [0.32, 0.38, 0.56], cloudShade: [0.1, 0.12, 0.2],
    fogDen: 0.012, vol: 0.02, fogFall: 0.14, mist: 0.4, g: 0.55, haze: 0.009, shaft: 1.8, fadeMin: 0.45,
    sunScat: [0.3, 0.4, 0.7], ambLow: [0.012, 0.016, 0.032], ambHigh: [0.016, 0.02, 0.04], hazeCol: [0.06, 0.08, 0.15], reflFog: [0.06, 0.08, 0.15],
    exposure: 1.15, bloom: 0.085, windowE: 3.4, lanternE: 9, lanternI: 22, fireI: 26, fireK: 1.3, windowI: 4, fogLantern: 3.5, fogWindow: 1.3, decal: 1.0,
    fireflies: 3.2, night: 1, shadowTint: [-0.02, -0.005, 0.05], highTint: [0.025, 0.01, -0.015], contrast: 1.1, saturation: 1.05,
  },
};
let blend = 0;
let blendTarget = 0;
const mix = (a, b, t) => (Array.isArray(a) ? a.map((v, i) => v + (b[i] - v) * t) : a + (b - a) * t);
function applyPreset(t) {
  const A = PRESETS.golden;
  const B = PRESETS.night;
  const p = {};
  for (const k of Object.keys(A)) p[k] = mix(A[k], B[k], t);
  const sd = new THREE.Vector3(...p.sunDir).normalize();
  U.uSunDir.value.copy(sd);
  sun.position.copy(sd).multiplyScalar(110).add(new THREE.Vector3(0, 0, -8));
  sun.target.position.set(0, 0, -8);
  sun.color.setRGB(...p.sunCol);
  sun.intensity = p.sunI;
  U.uSunCol.value.setRGB(...p.sunCol).multiplyScalar(p.sunI * 0.3);
  hemi.color.setRGB(...p.hemiSky);
  hemi.groundColor.setRGB(...p.hemiGround);
  hemi.intensity = p.hemiI;
  fill.intensity = p.fillI;
  fill.color.setRGB(...p.fillCol);
  U.uAmbCol.value.setRGB(...p.hemiSky).multiplyScalar(p.hemiI * 0.3);
  skyU.uZenith.value.setRGB(...p.zenith);
  skyU.uHorizon.value.setRGB(...p.horizon);
  skyU.uGlow.value.setRGB(...p.glow);
  skyU.uMoonDir.value.copy(sd);
  cloudU.uLit.value.setRGB(...p.cloudLit);
  cloudU.uShade.value.setRGB(...p.cloudShade);
  U.uNight.value = p.night;
  U.uGlow.value = p.fireflies;
  const P = pipeline.P;
  P.fogA.x = p.fogDen;
  P.volC.w = p.vol;
  P.fogA.y = p.fogFall;
  P.fogB.z = p.mist;
  P.fogC.x = p.g;
  P.fogC.y = p.haze;
  P.fogC.z = p.shaft;
  P.fade.z = p.fadeMin;
  P.sunScat.setRGB(...p.sunScat).multiplyScalar(p.sunI * 0.9);
  P.ambLow.setRGB(...p.ambLow);
  P.ambHigh.setRGB(...p.ambHigh);
  P.haze.setRGB(...p.hazeCol);
  P.reflFog.setRGB(...p.reflFog);
  P.exposure = p.exposure;
  P.bloom = p.bloom;
  P.contrast = p.contrast;
  P.saturation = p.saturation;
  P.shadowTint.setRGB(...p.shadowTint);
  P.highTint.setRGB(...p.highTint);
  for (const m of facadeMats) m.emissiveIntensity = p.windowE;
  world.mats.lanternGlass.emissiveIntensity = p.lanternE;
  for (const l of lanterns) l.baseI = l.kind === 'fire' ? p.fireI : p.lanternI;
  fire.flame.material.uniforms.uK.value = p.fireK;
  life.fireU.uFireCol.value.copy(fire.color).multiplyScalar(p.fireI * 0.05);
  // explicit fog-light budget (16): lanterns + campfire first, then the windows nearest the hero
  pipeline.fogLights = [
    ...lanterns.map((l) => ({ pos: l.pos, color: l.color, intensity: l.kind === 'fire' ? p.fogLantern * 1.6 : p.fogLantern, range: l.kind === 'fire' ? 9 : 7 })),
    ...windowSpots.map((s) => ({ pos: s.pos, color: s.color, intensity: p.fogWindow, range: 5 })),
  ].slice(0, 16);
  decalU.uK.value = p.decal;
}
applyPreset(0);

// --- input + HUD --------------------------------------------------------------------
const hud = document.getElementById('hud');
const fpsEl = document.getElementById('fps');
let hudHidden = false;
let lastInput = performance.now();
const poke = () => {
  lastInput = performance.now();
};
const toggles = { rain: false };
window.addEventListener('keydown', (e) => {
  poke();
  const k = e.key.toLowerCase();
  const P = pipeline.P;
  if (k === '1') blendTarget = 0;
  if (k === '2') blendTarget = 1;
  if (k === 'f') P.fog = !P.fog;
  if (k === 'g') P.dof = !P.dof;
  if (k === 'b') P.bloomOn = !P.bloomOn;
  if (k === 'r') toggles.rain = !toggles.rain;
  if (k === 'h') hudHidden = !hudHidden;
});
let drag = null;
window.addEventListener('pointerdown', (e) => {
  poke();
  drag = { x: e.clientX, pan: rig.panX };
});
window.addEventListener('pointermove', (e) => {
  if (!drag) return;
  poke();
  rig.panX = THREE.MathUtils.clamp(drag.pan - ((e.clientX - drag.x) / window.innerWidth) * 18, -9, 9);
});
window.addEventListener('pointerup', () => (drag = null));
window.addEventListener('wheel', (e) => {
  poke();
  rig.zoom = THREE.MathUtils.clamp(rig.zoom + e.deltaY * 0.01, -10, 6);
});

// --- loop -------------------------------------------------------------------------
const stats = { fps: 0, ms: 0, p95: 0, frames: 0, w: 0, h: 0, quality: QN, adaptive: ADAPTIVE, level: 0, cards: grass.count, voxels: trees.voxels };
let last = performance.now();
let time = 0;
let acc = 0;
let n = 0;
let paused = false;
const hv = new THREE.Vector3();
function step(dt) {
  time += dt;
  U.uTime.value = time;
  blend += Math.sign(blendTarget - blend) * Math.min(Math.abs(blendTarget - blend), dt / 1.5);
  applyPreset(blend * blend * (3 - 2 * blend));
  const rainK = THREE.MathUtils.clamp(U.uWet.value + (toggles.rain ? dt / 3 : -dt / 6), 0, 1);
  U.uWet.value = rainK;
  life.rain.visible = rainK > 0.01;
  life.rainU.uRain.value = rainK;
  U.uWindStr.value = 1 + rainK * 0.6;
  placeCamera(time);
  camera.updateMatrixWorld();
  hero.update(camera, time);
  // focus = view depth of the hero's middle (the CoC works in linear view depth)
  const focus = -hv.copy(heroMid).applyMatrix4(camera.matrixWorldInverse).z;
  pipeline.P.focus = focus;
  life.update(time, dt, camera, focus);
  for (const s of spinners) s.obj.rotation[s.axis] += s.speed * dt * (s.wind ? 0.3 + gustAt(s.obj.position.x, s.obj.position.z, time) * 1.6 : s.axis === 'z' ? U.uWindStr.value : 1);
  for (const l of lanterns) l.light.intensity = (l.baseI ?? 2) * (l.kind === 'fire' ? 0.8 + 0.2 * Math.sin(time * 13 + l.flick) * Math.sin(time * 7.7) : 0.92 + 0.08 * Math.sin(time * 9 + l.flick) * Math.sin(time * 5.3 + l.flick * 2));
  for (const c of clouds) {
    c.mesh.position.x += c.speed * dt;
    if (c.mesh.position.x > 300) c.mesh.position.x = -300;
  }
  pipeline.render();
}
function adaptResolution(frameMs) {
  if (!ADAPTIVE) return;
  adapt.hist.push(frameMs);
  if (time < 4) return; // shader compiles / first shadow renders are not representative
  if (adapt.hist.length < 120) return;
  const s = adapt.hist.slice().sort((a, b) => a - b);
  const p95 = s[Math.floor(s.length * 0.95)];
  stats.p95 = +p95.toFixed(1);
  adapt.hist.length = 0;
  if (p95 > 18 && adapt.level < adapt.levels.length - 1) {
    adapt.level++;
    adapt.calm = 0;
    resize();
  } else if (p95 < 13.5 && adapt.level > 0 && ++adapt.calm >= 3) {
    adapt.level--;
    adapt.calm = 0;
    resize();
  }
  stats.level = adapt.level;
}
function frame(now) {
  const ms = now - (frame.prev || now);
  frame.prev = now;
  const dt = Math.min((now - last) / 1000, 1 / 15);
  last = now;
  if (!paused) step(dt);
  if (ms > 0 && !paused) adaptResolution(ms);
  acc += ms;
  n++;
  if (acc > 500) {
    stats.fps = Math.round((n * 1000) / acc);
    stats.ms = +(acc / n).toFixed(2);
    stats.w = pipeline.w;
    stats.h = pipeline.h;
    fpsEl.textContent = `${stats.fps} fps · ${pipeline.w}×${pipeline.h} · ${QN}${ADAPTIVE && adapt.level ? ' (adaptive)' : ''}`;
    acc = 0;
    n = 0;
  }
  stats.frames++;
  const idle = performance.now() - lastInput > 6000;
  hud.style.opacity = hudHidden ? 0 : idle ? 0.0 : 0.9;
  requestAnimationFrame(frame);
}
document.getElementById('loading').remove();
requestAnimationFrame(frame);

// review hooks (used by the screenshot tooling): read fps, switch presets instantly, freeze time
window.__hd2d = {
  stats,
  pipeline,
  preset(name) {
    blendTarget = blend = name === 'night' ? 1 : 0;
  },
  rain(on) {
    toggles.rain = on;
    U.uWet.value = on ? 1 : 0;
  },
  hud(show) {
    hudHidden = !show;
  },
  pause(p) {
    paused = p;
  },
  advance(sec) {
    for (let t = 0; t < sec; t += 1 / 60) step(1 / 60);
  },
  get time() {
    return time;
  },
  scene,
  U,
  camera,
  rig,
  hero,
  PRESETS,
  renderOnly() {
    pipeline.render();
  },
};
