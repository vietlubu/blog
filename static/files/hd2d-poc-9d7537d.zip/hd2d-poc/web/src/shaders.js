// Full-screen passes. Written for WebGL2 (three adds the GLSL 3 compatibility defines).

export const FS_VERT = /* glsl */ `
varying vec2 vUv;
void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

const COMMON = /* glsl */ `
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
float linDepth(float d, float n, float f) { float z = d * 2.0 - 1.0; return (2.0 * n * f) / (f + n - z * (f - n)); }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
`;

export const COPY_FRAG = `uniform sampler2D tSrc; varying vec2 vUv; void main(){ gl_FragColor = texture2D(tSrc, vUv); }`;

export const BLUR_FRAG = /* glsl */ `
uniform sampler2D tSrc; uniform vec2 uDir; varying vec2 vUv;
void main() {
  vec4 a = vec4(0.0); float ws = 0.0;
  for (int k = -5; k <= 5; k++) { float w = exp(-float(k * k) / 12.0); a += texture2D(tSrc, vUv + uDir * float(k)) * w; ws += w; }
  gl_FragColor = a / ws;
}`;

// half-res linear depth (closest of the 2x2 footprint)
export const DEPTH_DOWN_FRAG = /* glsl */ `
${COMMON}
uniform sampler2D tDepth; uniform vec2 uTexel; uniform float uNear, uFar; varying vec2 vUv;
void main() {
  vec2 o = uTexel * 0.5;
  float d = min(min(texture2D(tDepth, vUv + vec2(-o.x, -o.y)).r, texture2D(tDepth, vUv + vec2(o.x, -o.y)).r),
                min(texture2D(tDepth, vUv + vec2(-o.x, o.y)).r, texture2D(tDepth, vUv + vec2(o.x, o.y)).r));
  gl_FragColor = vec4(d >= 0.999999 ? 1.0e4 : linDepth(d, uNear, uFar), 0.0, 0.0, 1.0);
}`;

// ---------------------------------------------------------------------------
// Volumetric fog: single scattering ray march at half resolution.
//  * exponential height fog, animated by the wind through a tiling 3D noise
//  * mist layer hugging the pond / stream (splat map)
//  * sun / moon in-scattering shadowed by the real shadow map -> god rays through the canopy
//  * analytic in-scattering for lanterns and windows (closed-form line integral)
//  * aerial perspective beyond the march range (far tiers fade into the haze colour)
// ---------------------------------------------------------------------------
export function fogFrag(NP, STEPS) {
  return /* glsl */ `
${COMMON}
precision highp sampler3D;
precision highp sampler2DShadow;
#define NP ${NP}
#define STEPS ${STEPS}
uniform sampler2D tDepth;
uniform sampler3D tNoise;
uniform sampler2D tSplat;
uniform vec4 uSplatBox;
uniform sampler2DShadow tSunShadow;
uniform mat4 uSunShadowMat;
uniform mat4 uProjInv, uViewInv;
uniform vec3 uCamPos;
uniform float uTime;
uniform vec3 uSunDir, uSunScat, uAmbLow, uAmbHigh, uHaze;
uniform vec4 uFogA; // density, falloff, base y, noise amount
uniform vec4 uFogB; // noise scale, march distance, mist, water y
uniform vec4 uFogC; // phase g, far haze density, shaft gain, start distance
uniform vec3 uWind;
uniform vec4 uVolC; // local haze volume around the oak and the village airspace: centre, density
uniform vec3 uVolR;
uniform vec3 uFade; // density fade-in along the ray (start, end, min): keeps the focal band clear of veil
uniform vec3 uPtPos[NP];
uniform vec4 uPtCol[NP];
varying vec2 vUv;

float hg(float c, float g) { float g2 = g * g; return (1.0 - g2) / (12.566 * pow(max(1.0 + g2 - 2.0 * g * c, 1e-4), 1.5)); }

float density(vec3 p, out float mistOut) {
  vec3 q = p * uFogB.x;
  float n = texture(tNoise, q + uWind * uTime).r * 0.65 + texture(tNoise, q * 2.7 + 0.37 - uWind * uTime * 1.6).r * 0.35;
  float d = uFogA.x * exp(-max(p.y - uFogA.z, 0.0) * uFogA.y);
  d *= max(mix(1.0, n * 2.3 - 0.25, uFogA.w), 0.0);
  vec4 sp = texture(tSplat, (p.xz - uSplatBox.xy) * uSplatBox.zw);
  float water = (sp.b > 0.0 ? 1.0 : 0.0) + sp.a * 0.35;
  float mist = uFogB.z * water * exp(-max(p.y - uFogB.w, 0.0) * 3.0) * smoothstep(0.35, 0.75, n);
  mistOut = mist;
  vec3 vq = (p - uVolC.xyz) / uVolR;
  float vf = clamp(1.0 - dot(vq, vq), 0.0, 1.0);
  d += uVolC.w * vf * (0.35 + n);
  return d + mist;
}

float sunShadow(vec3 p) {
  vec4 sc = uSunShadowMat * vec4(p, 1.0);
  if (sc.x <= 0.001 || sc.x >= 0.999 || sc.y <= 0.001 || sc.y >= 0.999 || sc.z >= 1.0) return 1.0;
  return texture(tSunShadow, vec3(sc.xy, sc.z - 0.0015));
}

void main() {
  float depth = texture2D(tDepth, vUv).r;
  vec4 v = uProjInv * vec4(vUv * 2.0 - 1.0, 1.0, 1.0);
  vec3 vr = v.xyz / v.w;
  vr /= -vr.z;
  vec3 wp = (uViewInv * vec4(vr * min(depth, 3000.0), 1.0)).xyz;
  vec3 rd = normalize(wp - uCamPos);
  float dist = length(wp - uCamPos);
  bool sky = depth > 5000.0;
  float t0 = uFogC.w;
  float tMax = max(min(dist, uFogB.y), t0 + 0.1);
  float cosT = dot(rd, uSunDir);
  // mostly forward scattering: light piles up toward the sun (shafts), the air between shafts stays dark
  float phase = mix(hg(cosT, uFogC.x), 0.0796, 0.08);
  float jit = ign(gl_FragCoord.xy);
  vec3 L = vec3(0.0);
  float T = 1.0;
  // cheap analytic haze for the empty air in front of the march start
  {
    vec3 pm = uCamPos + rd * t0 * 0.5;
    float m0;
    float d0 = density(pm, m0) * 0.6;
    float Ts = exp(-d0 * t0);
    L += mix(uAmbLow, uAmbHigh, clamp(pm.y / 14.0, 0.0, 1.0)) * (1.0 - Ts);
    T *= Ts;
  }
  float dt = (tMax - t0) / float(STEPS);
  for (int i = 0; i < STEPS; i++) {
    float t = t0 + (float(i) + jit) * dt;
    vec3 p = uCamPos + rd * t;
    float mist;
    float dens = density(p, mist);
    if (dens <= 1e-5) continue;
    dens = (dens - mist) * mix(uFade.z, 1.0, smoothstep(uFade.x, uFade.y, t)) + mist;
    vec3 amb = mix(uAmbLow, uAmbHigh, clamp(p.y / 14.0, 0.0, 1.0));
    float sh = sunShadow(p);
    vec3 inS = amb + uSunScat * (phase * sh * uFogC.z);
    float Ts = exp(-dens * dt);
    L += T * inS * (1.0 - Ts);
    T *= Ts;
  }
  // aerial perspective for the far tiers
  if (!sky && dist > tMax) {
    float Tf = exp(-uFogC.y * (min(dist, 900.0) - tMax));
    vec3 haze = uHaze + uSunScat * pow(max(cosT, 0.0), 6.0) * 0.08;
    L += T * haze * (1.0 - Tf);
    T *= Tf;
  }
  // lanterns + windows: closed-form in-scattering along the ray
  float tEnd = min(dist, 300.0);
  for (int i = 0; i < NP; i++) {
    vec4 c = uPtCol[i];
    if (c.r + c.g + c.b <= 0.0) continue;
    vec3 toL = uPtPos[i] - uCamPos;
    float tc = dot(toL, rd);
    float h = max(length(toL - rd * tc), 0.08);
    if (h > c.w) continue;
    float I = (atan((tEnd - tc) / h) - atan(-tc / h)) / h;
    float w = clamp(1.0 - pow(h / c.w, 3.0), 0.0, 1.0);
    vec3 pc = uCamPos + rd * clamp(tc, 0.0, tEnd);
    float m;
    float dc = max(density(pc, m), uFogA.x * 0.4);
    L += c.rgb * (I * w * w * dc * 0.0796);
  }
  gl_FragColor = vec4(L, T);
}`;
}

export const BILATERAL_FRAG = /* glsl */ `
uniform sampler2D tSrc; uniform sampler2D tDepth; uniform vec2 uDir; varying vec2 vUv;
void main() {
  float dc = texture2D(tDepth, vUv).r;
  vec4 acc = vec4(0.0); float ws = 0.0;
  for (int k = -4; k <= 4; k++) {
    vec2 uv = vUv + uDir * float(k);
    float d = texture2D(tDepth, uv).r;
    float w = exp(-float(k * k) / 8.0) * exp(-abs(d - dc) / (0.05 * min(dc, 400.0) + 0.05));
    acc += texture2D(tSrc, uv) * w; ws += w;
  }
  gl_FragColor = acc / max(ws, 1e-4);
}`;

export const FOG_COMPOSITE_FRAG = /* glsl */ `
${COMMON}
uniform sampler2D tScene, tDepth, tFog, tFogDepth;
uniform vec2 uFogRes; uniform float uNear, uFar, uFogOn;
varying vec2 vUv;
void main() {
  vec3 col = texture2D(tScene, vUv).rgb;
  if (uFogOn < 0.5) { gl_FragColor = vec4(col, 1.0); return; }
  float d = texture2D(tDepth, vUv).r;
  float lin = d >= 0.999999 ? 1.0e4 : linDepth(d, uNear, uFar);
  vec2 p = vUv * uFogRes - 0.5;
  vec2 f = fract(p);
  vec2 base = (floor(p) + 0.5) / uFogRes;
  vec4 acc = vec4(0.0); float ws = 0.0;
  for (int j = 0; j <= 1; j++)
    for (int i = 0; i <= 1; i++) {
      vec2 uv = base + vec2(float(i), float(j)) / uFogRes;
      float ld = texture2D(tFogDepth, uv).r;
      float bw = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
      float w = bw * exp(-abs(ld - lin) / (0.04 * min(lin, 400.0) + 0.03)) + 1e-5;
      acc += texture2D(tFog, uv) * w; ws += w;
    }
  vec4 fog = acc / ws;
  gl_FragColor = vec4(col * fog.a + fog.rgb, 1.0);
}`;

// ---------------------------------------------------------------------------
// Tilt-shift bokeh DOF: signed CoC from depth, scatter-as-gather on a golden-angle spiral
// (after Dennis Gustafsson's single-pass bokeh), half resolution.
// ---------------------------------------------------------------------------
// UE4 legacy-Bokeh-style focus model (Octopath shipped on it): a flat in-focus region from (focus - nearIn) to
// (focus + farIn), then smooth near / far transition ramps. Negative = foreground.
const COC = /* glsl */ `
uniform float uFocus, uNearIn, uNearRamp, uFarIn, uFarRamp, uNearK, uFarK, uMaxCoc;
float coc(float lin) {
  float n = (1.0 - smoothstep(uFocus - uNearIn - uNearRamp, uFocus - uNearIn, lin)) * uNearK;
  float f = smoothstep(uFocus + uFarIn, uFocus + uFarIn + uFarRamp, lin) * uFarK;
  return clamp(f - n, -1.0, 1.0) * uMaxCoc;
}`;

export const DOF_PRE_FRAG = /* glsl */ `
${COMMON}
${COC}
uniform sampler2D tColor, tDepth; uniform float uNear, uFar; uniform vec2 uTexel; varying vec2 vUv;
void main() {
  vec3 c = texture2D(tColor, vUv).rgb;
  vec2 o = uTexel * 0.5;
  float d = min(min(texture2D(tDepth, vUv + vec2(-o.x, -o.y)).r, texture2D(tDepth, vUv + vec2(o.x, -o.y)).r),
                min(texture2D(tDepth, vUv + vec2(-o.x, o.y)).r, texture2D(tDepth, vUv + vec2(o.x, o.y)).r));
  float lin = d >= 0.999999 ? 1.0e4 : linDepth(d, uNear, uFar);
  c = c / (1.0 + max(luma(c) - 16.0, 0.0) * 0.05);
  gl_FragColor = vec4(c, coc(lin));
}`;

// max |CoC| per 8x8 tile of the half-res pre-pass (in half-res pixels)
export const TILE_MAX_FRAG = /* glsl */ `
uniform sampler2D tPre; uniform vec2 uSrcTexel; varying vec2 vUv;
void main() {
  vec2 o = vUv - uSrcTexel * 3.5;
  float m = 0.0;
  for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) m = max(m, abs(texture2D(tPre, o + vec2(float(x), float(y)) * uSrcTexel).a));
  gl_FragColor = vec4(m, 0.0, 0.0, 1.0);
}`;
// dilate the tile maxima by two tiles (the largest blur radius) so foreground bokeh can bleed over sharp areas
export const TILE_DILATE_FRAG = /* glsl */ `
uniform sampler2D tSrc; uniform vec2 uTexel; varying vec2 vUv;
void main() {
  float m = 0.0;
  for (int y = -2; y <= 2; y++) for (int x = -2; x <= 2; x++) m = max(m, texture2D(tSrc, vUv + vec2(float(x), float(y)) * uTexel).r);
  gl_FragColor = vec4(m, 0.0, 0.0, 1.0);
}`;

export const DOF_GATHER_FRAG = /* glsl */ `
uniform sampler2D tPre, tTile; uniform vec2 uTexel; uniform float uMaxCoc; uniform float uRadScale; varying vec2 vUv;
void main() {
  vec4 center = texture2D(tPre, vUv);
  float cs = abs(center.a);
  vec3 color = center.rgb;
  float tot = 1.0;
  float fg = 0.0;
  float radius = uRadScale;
  float ang = 0.0;
  // the spiral only has to reach the largest CoC in this neighbourhood: in-focus tiles exit almost at once
  float lim = min(uMaxCoc, texture2D(tTile, vUv).r + 0.75);
  for (int i = 0; i < 300; i++) {
    if (radius >= lim) break;
    vec2 tc = vUv + vec2(cos(ang), sin(ang)) * uTexel * radius;
    vec4 s = texture2D(tPre, tc);
    float ss = abs(s.a);
    if (s.a > center.a) ss = clamp(ss, 0.0, cs * 2.0);
    float m = smoothstep(radius - 0.5, radius + 0.5, ss);
    color += mix(color / tot, s.rgb, m);
    if (s.a < center.a - 1.0) fg += m;
    tot += 1.0;
    ang += 2.39996323;
    radius += uRadScale / radius;
  }
  color /= tot;
  gl_FragColor = vec4(color, max(smoothstep(0.6, 2.0, cs), clamp(fg / tot * 2.2, 0.0, 1.0)));
}`;

export const DOF_COMPOSITE_FRAG = /* glsl */ `
${COMMON}
${COC}
uniform sampler2D tColor, tBlur, tDepth; uniform float uNear, uFar; varying vec2 vUv;
void main() {
  vec3 sharp = texture2D(tColor, vUv).rgb;
  vec4 blur = texture2D(tBlur, vUv);
  float d = texture2D(tDepth, vUv).r;
  float lin = d >= 0.999999 ? 1.0e4 : linDepth(d, uNear, uFar);
  float a = max(smoothstep(0.6, 2.0, abs(coc(lin))), blur.a);
  gl_FragColor = vec4(mix(sharp, blur.rgb, a), 1.0);
}`;

// ---------------------------------------------------------------------------
// Bloom mip chain: 13-tap down (Karis average + soft threshold on the first), tent up.
// ---------------------------------------------------------------------------
export const BLOOM_DOWN_FRAG = /* glsl */ `
${COMMON}
uniform sampler2D tSrc; uniform vec2 uTexel; uniform float uFirst; uniform float uThresh; varying vec2 vUv;
vec3 s(vec2 o) { return texture2D(tSrc, vUv + o * uTexel).rgb; }
vec3 thr(vec3 c) { float l = luma(c); float k = clamp((l - uThresh * 0.5) / (uThresh), 0.0, 1.0); return c * k * k * max(l - uThresh * 0.5, 0.0) / max(l, 1e-4); }
void main() {
  vec3 a = s(vec2(-2, 2)), b = s(vec2(0, 2)), c = s(vec2(2, 2));
  vec3 d = s(vec2(-2, 0)), e = s(vec2(0, 0)), f = s(vec2(2, 0));
  vec3 g = s(vec2(-2, -2)), h = s(vec2(0, -2)), i = s(vec2(2, -2));
  vec3 j = s(vec2(-1, 1)), k = s(vec2(1, 1)), l = s(vec2(-1, -1)), m = s(vec2(1, -1));
  vec3 res;
  if (uFirst > 0.5) {
    vec3 g0 = (a + b + d + e) * 0.25, g1 = (b + c + e + f) * 0.25, g2 = (d + e + g + h) * 0.25, g3 = (e + f + h + i) * 0.25, g4 = (j + k + l + m) * 0.25;
    float w0 = 1.0 / (1.0 + luma(g0)), w1 = 1.0 / (1.0 + luma(g1)), w2 = 1.0 / (1.0 + luma(g2)), w3 = 1.0 / (1.0 + luma(g3)), w4 = 1.0 / (1.0 + luma(g4));
    res = (g0 * w0 * 0.125 + g1 * w1 * 0.125 + g2 * w2 * 0.125 + g3 * w3 * 0.125 + g4 * w4 * 0.5) / (w0 * 0.125 + w1 * 0.125 + w2 * 0.125 + w3 * 0.125 + w4 * 0.5);
    res = thr(res);
  } else {
    res = e * 0.125 + (a + c + g + i) * 0.03125 + (b + d + f + h) * 0.0625 + (j + k + l + m) * 0.125;
  }
  gl_FragColor = vec4(max(res, 0.0), 1.0);
}`;

export const BLOOM_UP_FRAG = /* glsl */ `
uniform sampler2D tSrc; uniform vec2 uTexel; varying vec2 vUv;
void main() {
  vec2 r = uTexel;
  vec3 c = texture2D(tSrc, vUv).rgb * 4.0;
  c += (texture2D(tSrc, vUv + vec2(-r.x, 0.0)).rgb + texture2D(tSrc, vUv + vec2(r.x, 0.0)).rgb + texture2D(tSrc, vUv + vec2(0.0, -r.y)).rgb + texture2D(tSrc, vUv + vec2(0.0, r.y)).rgb) * 2.0;
  c += texture2D(tSrc, vUv - r).rgb + texture2D(tSrc, vUv + r).rgb + texture2D(tSrc, vUv + vec2(-r.x, r.y)).rgb + texture2D(tSrc, vUv + vec2(r.x, -r.y)).rgb;
  gl_FragColor = vec4(c / 16.0, 1.0);
}`;

// ---------------------------------------------------------------------------
// Final: CA, bloom, ACES filmic, warm-highlight / cool-shadow split grade, vignette, grain.
// ---------------------------------------------------------------------------
export const FINAL_FRAG = /* glsl */ `
${COMMON}
uniform sampler2D tColor, tBloom;
uniform float uExposure, uBloom, uCA, uGrain, uVignette, uTime, uSaturation, uContrast;
uniform vec3 uLift, uGain, uShadowTint, uHighTint;
varying vec2 vUv;
vec3 aces(vec3 x) {
  const mat3 I = mat3(0.59719, 0.07600, 0.02840, 0.35458, 0.90834, 0.13383, 0.04823, 0.01566, 0.83777);
  const mat3 O = mat3(1.60475, -0.10208, -0.00327, -0.53108, 1.10813, -0.07276, -0.07367, -0.00605, 1.07602);
  vec3 v = I * x;
  vec3 a = v * (v + 0.0245786) - 0.000090537;
  vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
  return clamp(O * (a / b), 0.0, 1.0);
}
vec3 hdr(vec2 uv) { return texture2D(tColor, uv).rgb + texture2D(tBloom, uv).rgb * uBloom; }
vec3 toSRGB(vec3 c) { return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }
void main() {
  vec2 dir = vUv - 0.5;
  float r2 = dot(dir, dir);
  vec2 ca = dir * r2 * uCA * smoothstep(0.3, 0.55, sqrt(r2));
  vec3 col = vec3(hdr(vUv - ca).r, hdr(vUv).g, hdr(vUv + ca).b);
  col = aces(col * uExposure);
  float l = luma(col);
  col = mix(vec3(l), col, uSaturation);
  // grade in display (sRGB) space like a LUT: contrast around mid-grey, lift/gain, then split tone —
  // cool violet shadows, warm butter highlights (tints are display-space offsets, so they never crush to black)
  vec3 o = toSRGB(clamp(col, 0.0, 1.0));
  float ld = luma(o);
  o = (o - 0.5) * uContrast + 0.5;
  o = o * uGain + uLift * (1.0 - o);
  o += uShadowTint * (1.0 - smoothstep(0.05, 0.5, ld)) + uHighTint * smoothstep(0.5, 1.0, ld);
  o = clamp(o, 0.0, 1.0);
  float vig = smoothstep(0.9, 0.25, length(dir * vec2(1.2, 1.0)));
  o *= mix(1.0 - uVignette, 1.0, vig);
  float n = fract(sin(dot(gl_FragCoord.xy + fract(uTime * 7.31) * 113.0, vec2(12.9898, 78.233))) * 43758.5453);
  float n2 = fract(sin(dot(gl_FragCoord.xy * 1.37 + fract(uTime * 3.11) * 71.0, vec2(39.346, 11.135))) * 24634.6345);
  o += (n + n2 - 1.0) * uGrain * (0.35 + 0.65 * (1.0 - luma(o)));
  gl_FragColor = vec4(o, 1.0);
}`;
