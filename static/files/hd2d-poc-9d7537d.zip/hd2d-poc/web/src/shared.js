import * as THREE from 'three';
import { wind } from './wind.js';

// Uniform objects shared by reference between world materials and the pipeline.
export const U = {
  ...wind,
  uSunDir: { value: new THREE.Vector3(-0.8, 0.42, -0.3).normalize() },
  uSunCol: { value: new THREE.Color(1, 0.8, 0.5) },
  uAmbCol: { value: new THREE.Color(0.3, 0.32, 0.42) },
  tReflSharp: { value: null },
  tReflBlur: { value: null },
  uReflMatrix: { value: new THREE.Matrix4() },
  tNoise3D: { value: null },
  tSplat: { value: null },
  uSplatBox: { value: new THREE.Vector4() }, // x0, z0, 1/w, 1/h
  tSunShadow: { value: null },
  uSunShadowMat: { value: new THREE.Matrix4() },
  uWet: { value: 0 },
  uNight: { value: 0 },
  uGlow: { value: 1 }, // fireflies / lantern particles strength
  uProjScale: { value: 1000 }, // pixels per world unit at distance 1 (for point sprites)
};

// Layer bits: world (everything), water (mirror surfaces: excluded from the reflection pass).
export const LAYER = { WORLD: 0, WATER: 1, MAIN: 2 }; // MAIN: main view only (skipped by the reflection pass)

export function makeNoise3D(N = 64, seed = 7) {
  const data = new Uint8Array(N * N * N);
  let s = seed;
  const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [p[i], p[j]] = [p[j], p[i]];
  }
  const perm = new Uint8Array(512);
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  const grad = (h, x, y, z) => {
    const g = h & 15;
    const u = g < 8 ? x : y;
    const v = g < 4 ? y : g === 12 || g === 14 ? x : z;
    return ((g & 1) === 0 ? u : -u) + ((g & 2) === 0 ? v : -v);
  };
  const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const lerp = (a, b, t) => a + (b - a) * t;
  // tileable perlin
  const noise = (x, y, z, P) => {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const zi = Math.floor(z);
    const xf = x - xi;
    const yf = y - yi;
    const zf = z - zi;
    const m = (a) => ((a % P) + P) % P;
    const h = (a, b, c) => perm[perm[perm[m(a)] + m(b)] + m(c)];
    const u = fade(xf);
    const v = fade(yf);
    const w = fade(zf);
    return lerp(
      lerp(lerp(grad(h(xi, yi, zi), xf, yf, zf), grad(h(xi + 1, yi, zi), xf - 1, yf, zf), u), lerp(grad(h(xi, yi + 1, zi), xf, yf - 1, zf), grad(h(xi + 1, yi + 1, zi), xf - 1, yf - 1, zf), u), v),
      lerp(lerp(grad(h(xi, yi, zi + 1), xf, yf, zf - 1), grad(h(xi + 1, yi, zi + 1), xf - 1, yf, zf - 1), u), lerp(grad(h(xi, yi + 1, zi + 1), xf, yf - 1, zf - 1), grad(h(xi + 1, yi + 1, zi + 1), xf - 1, yf - 1, zf - 1), u), v),
      w
    );
  };
  let i = 0;
  for (let z = 0; z < N; z++)
    for (let y = 0; y < N; y++)
      for (let x = 0; x < N; x++) {
        let v = 0;
        let a = 0.5;
        let f = 4;
        for (let o = 0; o < 3; o++) {
          v += noise((x / N) * f, (y / N) * f, (z / N) * f, f) * a;
          a *= 0.5;
          f *= 2;
        }
        data[i++] = Math.max(0, Math.min(255, Math.round((v * 0.9 + 0.5) * 255)));
      }
  const t = new THREE.Data3DTexture(data, N, N, N);
  t.format = THREE.RedFormat;
  t.minFilter = t.magFilter = THREE.LinearFilter;
  t.wrapS = t.wrapT = t.wrapR = THREE.RepeatWrapping;
  t.needsUpdate = true;
  return t;
}
U.tNoise3D.value = makeNoise3D();
