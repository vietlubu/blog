import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { TPU, RNG, pixMat, vnoise, smoothstep } from './core.js';
import * as T from './textures.js';
import { U, LAYER } from './shared.js';
import { WIND_GLSL } from './wind.js';
import { WATER_Y, BRIDGE, STAIRS, POND, HERO, FIRE, pathZ, wallZ, isT1, waterDist, channelDist, onPath, groundY } from './layout.js';

// ---------------------------------------------------------------------------
// Instanced foliage cards (grass tufts, wildflowers, reeds, ferns, foxtails) bent by the shared wind field.
// ---------------------------------------------------------------------------
export function buildGrass(scene, { houses, extra = [], density = 1, camPos }) {
  const atlas = T.tuftAtlas().toTextures({ name: 'tufts', normal: 0 });
  atlas.map.wrapS = atlas.map.wrapT = THREE.ClampToEdgeWrapping;
  const r = new RNG(5);
  const items = []; // x, y, z, scale, tile, yaw, tint, stiffness
  const footprint = houses.map((h) => {
    const s = h.userData.spec;
    const pad = s.plinth ? 0.7 : 0.35;
    return { x: s.x, z: s.z, c: Math.cos(-s.rot || 0), sn: Math.sin(-s.rot || 0), hw: s.w / 2 + pad, hd: s.d / 2 + pad + (s.plinth ? 1.0 : 0) };
  });
  const blocked = (x, z) => {
    for (const f of footprint) {
      const dx = x - f.x;
      const dz = z - f.z;
      const lx = dx * f.c - dz * f.sn;
      const lz = dx * f.sn + dz * f.c;
      if (Math.abs(lx) < f.hw && Math.abs(lz) < f.hd) return true;
    }
    const wz = wallZ(x);
    if (z > wz - 0.75 && z < wz + 0.08) return true;
    if (x > STAIRS.x0 - 0.2 && x < STAIRS.x1 + 0.2 && z > wz - 0.6 && z < wz + 1.6) return true;
    if (Math.abs(x - 0.9) < 0.6 || Math.abs(x - 4.1) < 0.6) if (z < -3.3 && z > -5.3) return true; // wall returns
    const bz = pathZ(BRIDGE.x);
    if (Math.abs(x - BRIDGE.x) < BRIDGE.L / 2 + 0.2 && Math.abs(z - bz) < BRIDGE.W / 2 + 0.25) return true;
    if (Math.hypot(x - 8.5, z + 27.5) < 1.8) return true; // windmill
    if (Math.hypot(x + 15.5, z + 20.5) < 3.2) return true; // hill cottage
    if (Math.hypot(x - FIRE.x, z - FIRE.z) < 1.5) return true; // campfire clearing
    if (Math.hypot(x - HERO.x, z - HERO.z) < 0.8) return true;
    return false;
  };
  const add = (x, z, tile, scale, stiff = 1) => {
    const y = groundY(x, z);
    const yaw = Math.atan2(camPos.z - z, camPos.x - x) - Math.PI / 2 + r.float(-0.45, 0.45);
    items.push(x, y - 0.03, z, scale, tile, yaw, vnoise(x * 0.15, z * 0.15) * 0.7 + r.next() * 0.3, stiff);
  };
  // one saturated hue per flower clump (low-frequency noise picks the species, not a per-card coin toss)
  const flowerAt = (x, z) => [4, 5, 6, 7, 4][Math.floor(vnoise(x * 0.42 + 11, z * 0.42 - 3) * 4.99)];
  const N = Math.round(48000 * density);
  for (let i = 0; i < N; i++) {
    const x = r.float(-40, 44);
    const z = r.float(-44, 16);
    // camera-visible wedge only (narrow FOV): widen with depth
    const halfW = 12 + (camPos.z - z) * 0.4;
    if (Math.abs(x - camPos.x - 4) > halfW) continue;
    const t1 = isT1(x, z);
    if (blocked(x, z)) continue;
    let wd = 9;
    if (t1) {
      wd = waterDist(x, z);
      if (wd < -0.2) continue;
      const p = onPath(x, z);
      if (p < -0.1) continue;
      if (p < 0.25 && r.chance(0.7)) continue;
    } else if (z > -14) {
      if (channelDist(x, z) < 0.25) continue;
      if (Math.abs(x + 10.4) < 1.6 && z > -5.6 && z < -3.9) continue; // yard A
      if (Math.abs(x - 2.5) < 0.9 && z > -8.6) continue; // walk to door B
    }
    // thin out with distance (back tiers get fewer, bigger cards)
    const far = smoothstep(-6, -40, z);
    if (r.next() < far * 0.55) continue;
    const meadow = vnoise(x * 0.22 + 3, z * 0.22);
    const nearWater = t1 && wd < 0.55;
    const pondBank = t1 && wd < 1.6 && Math.abs(x - POND.x) < POND.rx + 1 && Math.abs(z - POND.z) < POND.rz + 1.5;
    // a low strip in front of the focal path keeps the hero's feet and the cobbles readable
    const pathFront = t1 && x > -3.2 && x < 16 && z > pathZ(x) && onPath(x, z) < 2.6;
    let tile;
    let scale = r.float(0.6, 1.05) * (1 + far * 0.6);
    if (z > 7.5) {
      // T0: half density, varied heights with gaps of ground, a few flower clumps and backlit foxtails
      if (r.chance(0.55)) continue;
      const clump = vnoise(x * 0.6 + 5, z * 0.6);
      if (clump < 0.35) continue;
      tile = clump > 0.78 ? flowerAt(x, z) : vnoise(x * 0.3 - 7, z * 0.3) > 0.68 ? 10 : r.pick([3, 1, 0, 2, 9]);
      scale *= r.float(0.7, 1.5);
    } else if (pathFront) {
      if (r.chance(0.35)) continue;
      tile = meadow > 0.6 ? flowerAt(x, z) : r.pick([0, 2, 2, 0]);
      scale *= 0.5;
    } else if (pondBank) {
      const ends = Math.abs(x - POND.x) > POND.rx - 1.4;
      tile = nearWater && ends ? (r.chance(0.7) ? 8 : 3) : r.pick([0, 2, 2, 0, flowerAt(x, z)]);
      scale *= ends ? 1.1 : 0.55;
    } else if (nearWater) {
      tile = r.chance(0.65) ? 8 : r.pick([1, 3, 9]);
      scale *= 1.15;
    } else if (meadow > 0.62 && r.chance(0.6)) {
      tile = flowerAt(x, z);
    } else {
      tile = r.pick([0, 1, 2, 0, 1, 2, 9, 3]);
    }
    add(x, z, tile, scale, tile === 8 ? 0.6 : 1);
  }
  // flower beds along the terrace edge + window boxes
  for (let i = 0; i < 900; i++) {
    const x = r.float(-24, 22);
    const z = wallZ(x) - r.float(0.8, 1.9);
    if (blocked(x, z) || channelDist(x, z) < 0.3) continue;
    add(x, z, flowerAt(x, z), r.float(0.55, 0.85));
  }
  for (const p of extra) items.push(p.x, p.y, p.z, r.float(0.4, 0.55), flowerAt(p.x, p.z * 3), r.float(-0.4, 0.4), 0.5, 0.6);

  // only cards near the water are rendered into the planar reflection (perf)
  const nearW = [];
  const rest = [];
  for (let i = 0; i < items.length; i += 8) {
    const near = isT1(items[i], items[i + 2]) && waterDist(items[i], items[i + 2]) < 3.5;
    (near ? nearW : rest).push(...items.slice(i, i + 8));
  }
  const base = new THREE.PlaneGeometry(1, 1);
  base.translate(0, 0.5, 0);
  const geo = (list) => {
    const n = list.length / 8;
    const g = new THREE.InstancedBufferGeometry();
    g.index = base.index;
    g.setAttribute('position', base.attributes.position);
    g.setAttribute('uv', base.attributes.uv);
    g.setAttribute('normal', base.attributes.normal);
    const off = new Float32Array(n * 4);
    const dat = new Float32Array(n * 4);
    for (let i = 0; i < n; i++) {
      off.set(list.slice(i * 8, i * 8 + 4), i * 4);
      dat.set(list.slice(i * 8 + 4, i * 8 + 8), i * 4);
    }
    g.setAttribute('aOff', new THREE.InstancedBufferAttribute(off, 4));
    g.setAttribute('aData', new THREE.InstancedBufferAttribute(dat, 4));
    g.instanceCount = n;
    return g;
  };
  const count = items.length / 8;
  const m = new THREE.MeshStandardMaterial({ map: atlas.map, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.85 });
  m.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, { uTime: U.uTime, uWindDir: U.uWindDir, uWindStr: U.uWindStr, uSunDir: U.uSunDir, uSunCol: U.uSunCol });
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', `#include <common>\n${WIND_GLSL}\nattribute vec4 aOff; attribute vec4 aData; varying float vTint; varying float vV; varying float vFox; varying vec3 vVw;`)
      .replace('#include <uv_vertex>', `#include <uv_vertex>\nvMapUv = vec2((uv.x + aData.x) / ${T.TUFTS}.0, uv.y);`)
      .replace('#include <beginnormal_vertex>', 'vec3 objectNormal = normalize(vec3(0.0, 1.0, 0.45));')
      .replace(
        '#include <begin_vertex>',
        /* glsl */ `vec3 transformed;
        {
          float s = aOff.w;
          float cy = cos(aData.y), sy = sin(aData.y);
          vec3 p = vec3(position.x * cy, position.y, -position.x * sy) * s;
          float k = uv.y * uv.y;
          vec2 w = windAt(aOff.xz) * aData.w;
          p.xz += w * k * s * 0.5;
          p.y -= dot(w, w) * k * s * 0.12;
          transformed = p + aOff.xyz;
          vTint = aData.z; vV = uv.y; vFox = step(9.5, aData.x);
          vVw = normalize(transformed - cameraPosition);
        }`
      );
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying float vTint; varying float vV; varying float vFox; varying vec3 vVw; uniform vec3 uSunDir; uniform vec3 uSunCol;')
      .replace(
        '#include <map_fragment>',
        `#include <map_fragment>
        diffuseColor.rgb *= mix(vec3(0.8, 0.95, 0.9), vec3(1.15, 1.05, 0.8), vTint) * mix(0.42, 1.0, smoothstep(0.0, 0.55, vV));`
      )
      .replace(
        '#include <opaque_fragment>',
        // back-light through blade tips; foxtail seed heads blaze past the bloom threshold -> round bokeh highlights
        `outgoingLight += diffuseColor.rgb * uSunCol * (pow(max(dot(vVw, uSunDir) * 0.5 + 0.5, 0.0), 3.0) * vV * vV * (1.1 + vFox * 9.0 * step(0.8, vV)));
        #include <opaque_fragment>`
      );
  };
  m.customProgramCacheKey = () => 'grassCards';
  const meshes = [geo(nearW), geo(rest)].map((g, i) => {
    const mesh = new THREE.Mesh(g, m);
    mesh.frustumCulled = false;
    mesh.receiveShadow = true;
    if (i === 1) mesh.layers.set(LAYER.MAIN);
    scene.add(mesh);
    return mesh;
  });
  return { meshes, count };
}

// ---------------------------------------------------------------------------
// Voxel canopies: each crown is voxelised on a world-aligned grid (0.5 u = 16 texels for trees, 0.3125 u = 10 texels
// for bushes) from a union of noisy spheres; only the outer shell is kept and a low-frequency noise punches holes
// that let sun through (dappled shadows, god rays). Every cube face carries a 16/10-texel leaf tile; tone comes from
// a 4-step hue-shifted ramp driven by the crown normal (lit cap / mid band / dark underside) + clustered noise.
// Instanced; sways with the wind field (taller voxels lean further).
// ---------------------------------------------------------------------------
function h3(x, y, z) {
  let n = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(z | 0, 1442695041)) | 0;
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}
function vnoise3(x, y, z) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const zi = Math.floor(z);
  const s = (t) => t * t * (3 - 2 * t);
  const u = s(x - xi);
  const v = s(y - yi);
  const w = s(z - zi);
  const L = (a, b, t) => a + (b - a) * t;
  return L(
    L(L(h3(xi, yi, zi), h3(xi + 1, yi, zi), u), L(h3(xi, yi + 1, zi), h3(xi + 1, yi + 1, zi), u), v),
    L(L(h3(xi, yi, zi + 1), h3(xi + 1, yi, zi + 1), u), L(h3(xi, yi + 1, zi + 1), h3(xi + 1, yi + 1, zi + 1), u), v),
    w
  );
}

const VOX_VERT_HEAD = /* glsl */ `
${WIND_GLSL}
attribute vec4 aPos;   // centre xyz, size
attribute vec4 aN;     // crown normal xyz, clustered noise
attribute vec4 aTree;  // root x, root z, sway weight, palette
vec3 voxWind() {
  vec2 w = windAt(aTree.xy);
  float sw = aTree.z;
  return vec3(w.x, 0.0, w.y) * sw * (0.22 + 0.08 * sin(uTime * 1.7 + aTree.x * 3.1))
       + vec3(0.0, sin(uTime * 2.3 + aTree.y * 5.0 + aPos.y) * 0.02 * sw, 0.0);
}
`;

function voxMaterials(tile, tileSize) {
  const m = new THREE.MeshStandardMaterial({ map: tile.map, roughness: 0.85 });
  m.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, { uTime: U.uTime, uWindDir: U.uWindDir, uWindStr: U.uWindStr, uSunDir: U.uSunDir, uSunCol: U.uSunCol });
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', `#include <common>\n${VOX_VERT_HEAD}\nuniform vec3 uSunDir; varying vec3 vTone; varying float vOuter; varying vec3 vVw;`)
      .replace(
        '#include <uv_vertex>',
        `#include <uv_vertex>
        vMapUv = vec2((uv.x + floor(fract(sin(dot(aPos.xyz, vec3(12.9, 78.2, 37.7))) * 43758.5) * 4.0)) / 4.0, uv.y);`
      )
      .replace(
        '#include <begin_vertex>',
        /* glsl */ `vec3 transformed = position * aPos.w + aPos.xyz + voxWind();
        {
          // 4-step hue-shifted ramp: lit cap / two mid bands / dark underside, clustered by low-frequency noise
          float t = aN.y * 0.55 + dot(aN.xyz, uSunDir) * 0.2 + 0.42 + (aN.w - 0.5) * 0.6;
          int k = int(clamp(floor(t * 4.0), 0.0, 3.0));
          int id = int(aTree.w + 0.5);
          vec3 p0, p1, p2, p3;
          if (id == 0) { p0 = vec3(0.06, 0.14, 0.12); p1 = vec3(0.13, 0.27, 0.12); p2 = vec3(0.28, 0.44, 0.13); p3 = vec3(0.55, 0.64, 0.2); }
          else if (id == 1) { p0 = vec3(0.25, 0.14, 0.08); p1 = vec3(0.52, 0.3, 0.07); p2 = vec3(0.8, 0.52, 0.12); p3 = vec3(0.96, 0.76, 0.3); }
          else if (id == 2) { p0 = vec3(0.04, 0.09, 0.1); p1 = vec3(0.08, 0.17, 0.12); p2 = vec3(0.16, 0.29, 0.13); p3 = vec3(0.32, 0.43, 0.17); }
          else { p0 = vec3(0.09, 0.15, 0.09); p1 = vec3(0.22, 0.33, 0.1); p2 = vec3(0.45, 0.53, 0.14); p3 = vec3(0.7, 0.7, 0.27); }
          vTone = k == 0 ? p0 : k == 1 ? p1 : k == 2 ? p2 : p3;
          vOuter = clamp(dot(aN.xyz, normalize(cameraPosition - aPos.xyz)) * 0.5 + 0.5, 0.0, 1.0);
          vVw = normalize(aPos.xyz - cameraPosition);
        }`
      );
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vTone; varying float vOuter; varying vec3 vVw; uniform vec3 uSunDir; uniform vec3 uSunCol;')
      .replace('#include <map_fragment>', '#include <map_fragment>\ndiffuseColor.rgb = vTone * texture2D(map, vMapUv).rgb * 1.12;')
      .replace(
        '#include <opaque_fragment>',
        // leaves are thin: a little sun transmits through the outer shell toward the camera (backlit crowns glow at the rim)
        `outgoingLight += diffuseColor.rgb * uSunCol * pow(max(dot(vVw, uSunDir), 0.0), 2.0) * vOuter * 0.9;
        #include <opaque_fragment>`
      );
  };
  m.customProgramCacheKey = () => 'voxLeaf' + tileSize;
  const d = new THREE.MeshDepthMaterial();
  d.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, { uTime: U.uTime, uWindDir: U.uWindDir, uWindStr: U.uWindStr });
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', `#include <common>\n${VOX_VERT_HEAD}`)
      .replace('#include <begin_vertex>', 'vec3 transformed = position * aPos.w + aPos.xyz + voxWind();');
  };
  d.customProgramCacheKey = () => 'voxDepth';
  return { m, d };
}

// spec: { x, z, y?, trunkH, crown: [cx, cy, cz, rx, ry, rz], clumps | clumpList, rMin, rMax, palette, vs, seed, sway, limbs, trunkR }
export function buildTree(scene, spec, out) {
  const r = new RNG(spec.seed);
  const y0 = spec.y ?? groundY(spec.x, spec.z);
  const [cx, cy, cz, rx, ry, rz] = spec.crown;
  const clumps = spec.clumpList ? spec.clumpList.slice() : [];
  if (!spec.clumpList) {
    for (let i = 0; i < spec.clumps; i++) {
      // bias toward the outer shell and the top so the crown reads as a dome
      const a = r.float(0, Math.PI * 2);
      const u = r.float(-0.55, 1);
      const k = Math.sqrt(r.float(0.25, 1));
      const s = Math.sqrt(1 - u * u);
      clumps.push([cx + Math.cos(a) * s * rx * k, cy + u * ry * k, cz + Math.sin(a) * s * rz * k, r.float(spec.rMin, spec.rMax)]);
    }
  }
  // --- voxelise the crown -------------------------------------------------------
  const vs = spec.vs ?? 0.5;
  const seed = spec.seed * 1.37;
  let mn = [1e9, 1e9, 1e9];
  let mx = [-1e9, -1e9, -1e9];
  for (const [x, y, z, rad] of clumps) {
    mn = [Math.min(mn[0], x - rad * 1.3), Math.min(mn[1], y - rad * 1.3), Math.min(mn[2], z - rad * 1.3)];
    mx = [Math.max(mx[0], x + rad * 1.3), Math.max(mx[1], y + rad * 1.3), Math.max(mx[2], z + rad * 1.3)];
  }
  const i0 = mn.map((v) => Math.floor(v / vs));
  const i1 = mx.map((v) => Math.ceil(v / vs));
  const dims = [i1[0] - i0[0] + 1, i1[1] - i0[1] + 1, i1[2] - i0[2] + 1];
  const occ = new Uint8Array(dims[0] * dims[1] * dims[2]);
  const idx = (a, b, c) => (c * dims[1] + b) * dims[0] + a;
  const field = (p) => {
    let f = -1;
    let best = 0;
    for (let i = 0; i < clumps.length; i++) {
      const [x, y, z, rad] = clumps[i];
      const v = 1 - Math.hypot(p[0] - x, p[1] - y, p[2] - z) / rad;
      if (v > f) {
        f = v;
        best = i;
      }
    }
    return [f + (vnoise3(p[0] * 0.7 + seed, p[1] * 0.7, p[2] * 0.7) - 0.5) * 0.36, best];
  };
  const dom = new Int32Array(occ.length);
  for (let c = 0; c < dims[2]; c++)
    for (let b = 0; b < dims[1]; b++)
      for (let a = 0; a < dims[0]; a++) {
        const p = [(i0[0] + a + 0.5) * vs, (i0[1] + b + 0.5) * vs, (i0[2] + c + 0.5) * vs];
        const [f, best] = field(p);
        if (f > 0) {
          occ[idx(a, b, c)] = 1;
          dom[idx(a, b, c)] = best;
        }
      }
  const filled = (a, b, c) => a >= 0 && b >= 0 && c >= 0 && a < dims[0] && b < dims[1] && c < dims[2] && occ[idx(a, b, c)] === 1;
  const crownC = [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2];
  const crownR = Math.max(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 2;
  const H = Math.max(1, mx[1] - y0);
  for (let c = 0; c < dims[2]; c++)
    for (let b = 0; b < dims[1]; b++)
      for (let a = 0; a < dims[0]; a++) {
        if (!filled(a, b, c)) continue;
        if (filled(a - 1, b, c) && filled(a + 1, b, c) && filled(a, b - 1, c) && filled(a, b + 1, c) && filled(a, b, c - 1) && filled(a, b, c + 1)) continue;
        const p = [(i0[0] + a + 0.5) * vs, (i0[1] + b + 0.5) * vs, (i0[2] + c + 0.5) * vs];
        // gaps in the leaf shell (never on the top cap, so the silhouette stays solid against the sky)
        const hole = vnoise3(p[0] * 0.42 + seed * 3, p[1] * 0.42, p[2] * 0.42);
        if (hole > 0.7 && p[1] < crownC[1] + crownR * 0.35 && !spec.solid) continue;
        const cl = clumps[dom[idx(a, b, c)]];
        let nx = (p[0] - cl[0]) / cl[3] * 0.65 + (p[0] - crownC[0]) / crownR * 0.35;
        let ny = (p[1] - cl[1]) / cl[3] * 0.65 + (p[1] - crownC[1]) / crownR * 0.35;
        let nz = (p[2] - cl[2]) / cl[3] * 0.65 + (p[2] - crownC[2]) / crownR * 0.35;
        const nl = Math.hypot(nx, ny, nz) || 1;
        nx /= nl;
        ny /= nl;
        nz /= nl;
        const tn = vnoise3(p[0] * 0.55 - seed, p[1] * 0.55, p[2] * 0.55);
        const sway = (spec.sway ?? 1) * Math.min(1, Math.max(0.1, (p[1] - y0) / H));
        out.vox[vs === 0.5 ? 'big' : 'small'].push(p[0], p[1], p[2], vs, nx, ny, nz, tn, spec.x, spec.z, sway, spec.palette);
      }
  // --- trunk + limbs ---------------------------------------------------------------
  if (spec.trunkH) {
    const base = new THREE.Vector3(spec.x, y0 - 0.3, spec.z);
    const tr = spec.trunkR ?? 0.55;
    const mid = new THREE.Vector3(spec.x + r.float(-0.5, 0.5), y0 + spec.trunkH * 0.55, spec.z + r.float(-0.3, 0.3));
    const top = new THREE.Vector3(cx + r.float(-0.4, 0.4), y0 + spec.trunkH, cz);
    out.bark.push(limbGeo(base, mid, tr * 1.25, tr * 0.85), limbGeo(mid, top, tr * 0.85, tr * 0.6));
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + r.float(0, 1);
      const foot = new THREE.Vector3(spec.x + Math.cos(a) * tr * 2.4, y0 - 0.25, spec.z + Math.sin(a) * tr * 2.4);
      out.bark.push(limbGeo(foot, new THREE.Vector3(spec.x, y0 + tr * 1.6, spec.z), tr * 0.35, tr * 0.6));
    }
    for (let i = 0; i < (spec.limbs ?? 5); i++) {
      const c = clumps[r.int(0, clumps.length - 1)];
      const end = new THREE.Vector3(c[0], c[1] - c[3] * 0.3, c[2]);
      const from = mid.clone().lerp(top, r.float(0.2, 1));
      out.bark.push(limbGeo(from, end, tr * 0.42, tr * 0.14));
    }
  }
}

function limbGeo(a, b, r0, r1) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const len = dir.length();
  const g = new THREE.CylinderGeometry(r1, r0, len, 7, 2, true);
  const uv = g.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * ((2 * Math.PI * ((r0 + r1) / 2) * TPU) / 32), uv.getY(i) * ((len * TPU) / 64));
  g.translate(0, len / 2, 0);
  g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize()));
  g.translate(a.x, a.y, a.z);
  return g;
}

function voxMesh(scene, list, tileSize) {
  const n = list.length / 12;
  if (!n) return null;
  const tile = T.leafTile(tileSize).toTextures({ name: 'leafTile' + tileSize, normal: 1.2 });
  const { m, d } = voxMaterials(tile, tileSize);
  const box = new THREE.BoxGeometry(1, 1, 1);
  const g = new THREE.InstancedBufferGeometry();
  g.index = box.index;
  for (const k of ['position', 'normal', 'uv']) g.setAttribute(k, box.attributes[k]);
  const P = new Float32Array(n * 4);
  const Nn = new Float32Array(n * 4);
  const Tt = new Float32Array(n * 4);
  for (let i = 0; i < n; i++) {
    P.set(list.slice(i * 12, i * 12 + 4), i * 4);
    Nn.set(list.slice(i * 12 + 4, i * 12 + 8), i * 4);
    Tt.set(list.slice(i * 12 + 8, i * 12 + 12), i * 4);
  }
  g.setAttribute('aPos', new THREE.InstancedBufferAttribute(P, 4));
  g.setAttribute('aN', new THREE.InstancedBufferAttribute(Nn, 4));
  g.setAttribute('aTree', new THREE.InstancedBufferAttribute(Tt, 4));
  g.instanceCount = n;
  const mesh = new THREE.Mesh(g, m);
  mesh.customDepthMaterial = d;
  mesh.castShadow = mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  scene.add(mesh);
  return mesh;
}

export function finishTrees(scene, out) {
  const b = T.bark().toTextures({ name: 'bark', normal: 2.5 });
  const barkMat = new THREE.MeshStandardMaterial({ map: b.map, normalMap: b.normalMap, roughnessMap: b.roughnessMap, roughness: 1 });
  const big = voxMesh(scene, out.vox.big, 16);
  const small = voxMesh(scene, out.vox.small, 5); // 5 texels per half-size cube = the same 32 texels/unit as the big canopies
  if (out.bark.length) {
    const bm = new THREE.Mesh(mergeGeometries(out.bark), barkMat);
    bm.castShadow = bm.receiveShadow = true;
    scene.add(bm);
  }
  return { voxels: out.vox.big.length / 12 + out.vox.small.length / 12, big, small };
}

export const TREES = [
  // the big old oak on the T3 rise: the sun shines through its crown onto the village
  { x: -3.8, z: -15.2, trunkH: 4.4, trunkR: 0.62, crown: [-4.2, 8.3, -15.0, 6.6, 2.9, 3.9], clumps: 36, rMin: 1.2, rMax: 2.2, palette: 0, seed: 3, limbs: 7 },
  // a yellowing late-summer tree on the right
  { x: 17.6, z: -13.6, trunkH: 4.0, trunkR: 0.45, crown: [17.6, 6.9, -13.6, 3.9, 2.3, 3.0], clumps: 22, rMin: 1.0, rMax: 1.8, palette: 1, seed: 4 },
  { x: -20.5, z: -11.8, trunkH: 3.6, trunkR: 0.4, crown: [-20.5, 6.0, -11.8, 3.6, 2.4, 2.8], clumps: 18, rMin: 1.0, rMax: 1.7, palette: 3, seed: 5 },
  { x: 22.0, z: -5.0, trunkH: 3.4, trunkR: 0.4, crown: [22.0, 5.6, -5.0, 3.4, 2.4, 2.6], clumps: 16, rMin: 1.0, rMax: 1.7, palette: 0, seed: 6 },
];

export function buildTrees({ quality = 1 } = {}) {
  const out = { vox: { big: [], small: [] }, bark: [] };
  for (const t of TREES) buildTree(null, t, out);
  // forest edge on the hill crest (dense backdrop)
  const r = new RNG(91);
  for (let x = -50; x < 56; x += r.float(4, 6.5)) {
    const z = r.float(-46, -36);
    if (Math.abs(x - 8.5) < 5 && z > -33) continue;
    const s = r.float(0.6, 0.95);
    const y = groundY(x, z);
    buildTree(null, { x, z, trunkH: 3.2 * s, trunkR: 0.35 * s, crown: [x, y + 5.2 * s, z, 3.2 * s, 2.6 * s, 2.6 * s], clumps: Math.round(8 * quality + 4), rMin: 1.2 * s, rMax: 1.9 * s, palette: r.pick([2, 2, 0, 3, 1]), seed: 100 + Math.round(x * 7), limbs: 1, sway: 0.6 }, out);
  }
  // mid-hill copses
  for (const [x, z, s, p] of [[-11, -25, 0.9, 3], [20, -24, 1.0, 2], [-27, -19, 1.1, 2], [29, -17, 1.0, 0], [-4, -29, 0.75, 1]]) {
    const y = groundY(x, z);
    buildTree(null, { x, z, trunkH: 3 * s, trunkR: 0.35 * s, crown: [x, y + 4.8 * s, z, 3 * s, 2.3 * s, 2.4 * s], clumps: 12, rMin: 1.0 * s, rMax: 1.6 * s, palette: p, seed: 300 + x, limbs: 2, sway: 0.7 }, out);
  }
  // bushes (no trunk) hugging walls, houses and the pond; a big blocky shrub frames the lower-left foreground
  const bushes = [[-15.6, -4.4, 1.0, 0], [-6.9, -4.3, 0.8, 3], [6.2, -4.6, 0.9, 0], [14.6, -4.6, 1.1, 3], [-13.6, 2.4, 1.0, 0], [0.9, 4.6, 0.75, 3], [7.6, 3.6, 0.7, 0], [-14.5, 7.2, 1.2, 2], [13.8, 5.6, 0.9, 0], [-9.6, 10.2, 1.7, 0], [-7.4, 11.6, 1.2, 3]];
  for (const [x, z, s0, p] of bushes) {
    const y = groundY(x, z);
    const s = s0 * 0.62; // near-path bushes at 1:1 read as stacks of cubes; smaller masses read as shrubs
    const list = [];
    // voxel size stays 0.3125 u (32 texels/unit, matches the big canopies); the bush simply needs enough
    // clumps to resolve as one leafy mass instead of a scatter of cubes
    for (let i = 0; i < 14; i++) list.push([x + r.float(-0.95, 0.95) * s, y + r.float(0.2, 1.0) * s, z + r.float(-0.6, 0.6) * s, r.float(0.7, 1.0) * s]);
    buildTree(null, { x, z, y, clumpList: list, crown: [x, y, z, 1, 1, 1], palette: p, vs: 0.15625, seed: 500 + Math.round(x * 3), sway: 0.35, solid: true }, out);
  }
  return out;
}

// A leafy branch entering the top-left corner, ~13 u from the lens (heavy near bokeh), made of hand-pixel leaf cards
// so its blur reads as leaves, swaying with the wind field.
export function buildBranch(scene, camera) {
  const t = T.leafCards().toTextures({ name: 'leafCards', normal: 0.8 });
  t.map.wrapS = t.map.wrapT = THREE.ClampToEdgeWrapping;
  const mat = new THREE.MeshStandardMaterial({ map: t.map, normalMap: t.normalMap, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.8 });
  mat.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, { uTime: U.uTime, uWindDir: U.uWindDir, uWindStr: U.uWindStr });
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', `#include <common>\n${WIND_GLSL}`)
      .replace(
        '#include <begin_vertex>',
        `vec3 transformed = position;
        { vec3 wp = (modelMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz; vec2 w = windAt(wp.xz);
          transformed.xy += vec2(w.x, abs(w.y)) * 0.12 * (0.6 + uv.x) + vec2(sin(uTime * 2.1 + wp.x), cos(uTime * 1.7 + wp.y)) * 0.03; }`
      );
  };
  mat.customProgramCacheKey = () => 'branchCards';
  const r = new RNG(77);
  const pts = [[-1.0, 1.0, 13.5], [-0.9, 1.04, 13], [-0.8, 1.02, 14], [-0.97, 0.86, 13.8], [-0.72, 1.08, 13.2], [-1.04, 0.78, 12.6], [-0.86, 0.92, 12.4]];
  for (const [nx, ny, d] of pts) {
    const p = new THREE.Vector3(nx, ny, 0.5).unproject(camera).sub(camera.position).normalize().multiplyScalar(d).add(camera.position);
    const g = new THREE.PlaneGeometry(2, 1);
    const uv = g.attributes.uv;
    const v = r.chance(0.5) ? 0 : 0.5;
    for (let i = 0; i < uv.count; i++) uv.setX(i, v + uv.getX(i) * 0.5);
    const m = new THREE.Mesh(g, mat);
    m.position.copy(p);
    m.quaternion.copy(camera.quaternion);
    m.rotateZ(r.float(-0.6, 0.6));
    m.rotateY(r.float(-0.5, 0.5));
    m.scale.setScalar(r.float(0.9, 1.3));
    m.castShadow = true;
    m.layers.set(LAYER.MAIN);
    scene.add(m);
  }
}

// Lily pads floating on the pond (bobbing handled in life.js)
export function buildLilyPads(scene) {
  const r = new RNG(61);
  const pads = [];
  const mats = [pixMat(T.lilyPad(1), { alphaTest: 0.5, normal: 1 }), pixMat(T.lilyPad(2), { alphaTest: 0.5, normal: 1 })];
  for (let i = 0; i < 40 && pads.length < 18; i++) {
    const x = POND.x + r.float(-POND.rx, POND.rx);
    const z = POND.z + r.float(-POND.rz, POND.rz);
    if (waterDist(x, z) > -0.5) continue;
    if (Math.abs(x - POND.x) < 2.2 && Math.abs(z - POND.z) < 1.4) continue; // keep the mirror's centre open
    const s = r.float(0.55, 0.95);
    const g = new THREE.PlaneGeometry(s, s);
    g.rotateX(-Math.PI / 2);
    const m = new THREE.Mesh(g, r.chance(0.35) ? mats[0] : mats[1]);
    m.position.set(x, WATER_Y + 0.015, z);
    m.rotation.y = r.float(0, Math.PI * 2);
    m.receiveShadow = true;
    scene.add(m);
    pads.push({ m, ph: r.float(0, 6) });
  }
  return pads;
}
