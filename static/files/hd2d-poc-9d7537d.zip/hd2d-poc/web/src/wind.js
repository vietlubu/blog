import * as THREE from 'three';

// One wind field for everything: grass, flowers, reeds, canopies, cloth, smoke, leaves.
// Base breeze along uWindDir plus gust fronts that travel across the strip.
export const wind = {
  uTime: { value: 0 },
  uWindDir: { value: new THREE.Vector2(0.92, -0.38).normalize() },
  uWindStr: { value: 1.0 },
};

export const WIND_GLSL = /* glsl */ `
uniform float uTime;
uniform vec2 uWindDir;
uniform float uWindStr;
float gustAt(vec2 p) {
  float s = dot(p, uWindDir);
  float g = 0.5 + 0.5 * sin(s * 0.16 - uTime * 0.9);
  g = g * g * g * g;
  float n = sin(p.x * 0.31 + uTime * 0.63) * sin(p.y * 0.27 - uTime * 0.41);
  return g + n * 0.12;
}
vec2 windAt(vec2 p) {
  float g = gustAt(p);
  vec2 flutter = vec2(sin(uTime * 2.3 + p.x * 1.7 + p.y), cos(uTime * 1.9 + p.y * 1.3 - p.x * 0.4)) * 0.12;
  return (uWindDir * (0.3 + g * 0.9) + flutter) * uWindStr;
}
`;

export function gustAt(x, z, t) {
  const d = wind.uWindDir.value;
  const s = x * d.x + z * d.y;
  let g = 0.5 + 0.5 * Math.sin(s * 0.16 - t * 0.9);
  g = g * g * g * g;
  return g + Math.sin(x * 0.31 + t * 0.63) * Math.sin(z * 0.27 - t * 0.41) * 0.12;
}

export function windAt(x, z, t, out = new THREE.Vector2()) {
  const d = wind.uWindDir.value;
  const g = gustAt(x, z, t);
  const k = (0.3 + g * 0.9) * wind.uWindStr.value;
  return out.set(
    d.x * k + Math.sin(t * 2.3 + x * 1.7 + z) * 0.12 * wind.uWindStr.value,
    d.y * k + Math.cos(t * 1.9 + z * 1.3 - x * 0.4) * 0.12 * wind.uWindStr.value
  );
}
