# Windferry Hamlet — HD-2D round 1 (Web / three.js)

A living, tiered HD-2D diorama built with three.js (WebGL2) + Vite. Everything except the shared hero
sprite is generated in code at load time: pixel textures, normal maps, foliage, clouds, particles.

## Run

```bash
cd web
npm install
npm run dev      # http://127.0.0.1:5180/ (strictPort)
npm run build    # static build in web/dist/ (relative paths, serve with any static server)
npm run preview  # serves dist on 5180
```

Quality: `?q=low|med|high` (default `high`). Any quality field can be overridden from the URL,
e.g. `?q=high&msaa=0&fogSteps=24&shadow=2048`.

| Key | Action |
| --- | --- |
| `1` | Golden hour (default) |
| `2` | Blue hour / night (1.5 s blend) |
| `R` | Rain on/off (wet ground, puddles, rain rings on water, streaks) |
| `F` / `G` / `B` | Volumetrics / depth of field / bloom on/off |
| `H` | Hide HUD (it also fades out after 6 s idle) |
| drag / wheel | Limited pan along the strip / small zoom |

Review hook: `window.__hd2d` exposes `stats` (fps, frame ms, internal resolution), `preset('night'|'golden')`,
`rain(bool)`, `hud(bool)`, `pause(bool)`, `advance(sec)`.

## Measured performance

Chrome on this Apple Silicon Mac (M1 Pro), 1920×982 CSS @2x, GPU idle (`review/web/round-2/fps.json`):
`high` 2464×1260 internal → **~90 fps** (p95 frame 17.1 ms). Round-1's "~55 fps" was measured while the
Godot track held the GPU — the same tier swings 37–61 fps under contention, so treat any contended number as a floor.
`?q=med` / `?q=low` remain the fallbacks for older machines.

## Scene layout (front → back)

- **T0 (bokeh foreground)**: tall grass + wildflower cards, a fence, a leafy branch in the top-left corner placed
  12–15 units from the lens (heavy near-field bokeh).
- **T1 (focal, sharp)**: cobbled path with path lanterns, the hero, a cobbled arched stone bridge over a stream
  that drops off a waterfall and widens into a lily pond; bench, crates, barrels, signpost, butterflies, a hopping bird.
- **T2 (+0.9 u terrace behind a mossy retaining wall, stairs up)**: thatched cottage, two-storey clay-tile house on a plinth
  (Kites-Studio banner by its door), slate-roof house turned gable-first; chimneys with smoke, flower boxes, lit windows,
  hanging lanterns, laundry line, a water wheel in the feeder channel.
- **T3**: the big old oak (sun shines through its crown), yellowing late-summer tree, a cottage on the rise, windmill,
  forest edge, the studio kite on its string.
- **T4**: three hazy hill silhouettes, banded/dithered sky gradient, drifting pixel cumulus.

## Pipeline (`src/pipeline.js`, `src/shaders.js`)

1. **Planar reflection** (half res, 2× MSAA): mirrored camera + Lengyel oblique near-plane clip at the water plane; also
   renders the frame's sun shadow map. Only grass cards near water are drawn into it (layer mask). A linear haze stands in
   for the volumetric pass that the mirror image doesn't get.
2. **Main HDR pass** (2× MSAA): `MeshStandardMaterial` with injected shader code; nearest-sampled pixel textures with
   per-texel normal maps derived from painted height.
3. **Volumetric fog** (half res, 36–48 steps, IGN jitter, depth-aware bilateral blur + joint-bilateral upsample):
   height fog animated by wind through a tiling 3D Perlin texture, a local haze volume over the village/oak,
   splat-driven mist hugging the water, **sun in-scattering shadowed by the real shadow map** (god rays through the oak and
   between houses), closed-form point-light in-scattering for every lantern and lit window, aerial perspective beyond the march.
4. **Tilt-shift bokeh DOF**: signed CoC from depth around the hero's distance (auto-focus each frame), golden-angle
   scatter-as-gather at half res; foreground blur is stronger than background (miniature look).
5. **Bloom**: 6-level mip chain, Karis-weighted 13-tap down with a soft threshold, tent up (high threshold — only lamps,
   windows, sun glints bloom).
6. **Grade**: ACES fit, saturation/contrast, split-tone (violet shadows / butter highlights), lift/gain, vignette,
   radial chromatic aberration at the edges, luminance-weighted grain.

### Materials & life
- **Terrain**: one heightfield, world-space UVs (texels never rotate, no seams), splat map for path/cobbles/water/wet banks with
  per-texel dithered edges, low-frequency gradient tint to break 64-texel repetition, rain puddles that sample the reflection.
- **Water**: 2-texel-quantised ripple normals (flowing 3D noise) + ring ripples (more in rain), Fresnel mix with the planar
  reflection, shallow→deep colour from the splat, pixel foam at the banks, **sun glints**: sparse twinkling texel cells inside the
  sun's reflection lobe, gated by shadow-map visibility.
- **Foliage canopies**: each clump is an icosphere shell shaded per 3D texel cell (1/11 u): stepped dot-cluster silhouettes,
  noise holes that let sunlight through the shadow map, 4-step hue-shifted ramps, translucency + warm rim toward the sun.
  Clumps sway rigidly with the wind field; the shadow depth material uses the same cell test, so shafts move with the leaves.
- **Wind** (`src/wind.js`): one field — base breeze + travelling gust fronts + flutter, evaluated identically in GLSL and JS.
  Drives grass/flower/reed cards, canopies, laundry + banner cloth, smoke drift, falling leaves, dust, kite, windmill speed.
- **Hero** (`src/hero.js`): Y-billboard quad sized from the PNG's pixel size ÷ 32 texels/unit (works for any sprite size), pivot =
  centre of the last opaque row; volume normals from the blurred alpha; rim light from the sun (shadow-gated) and the 4 nearest
  lanterns; casts and receives shadows; soft contact shadow.
- **Particles**: point-sprite atlas at the same texel density — falling leaves, butterflies, a crossing bird flock, two hopping
  birds (ground + roof ridge), chimney smoke, dust motes that only glitter inside sun shafts (shadow-map test), fireflies
  (stronger at night), kite tail ribbons, rain streaks.

## Own HD-2D identity

- **"Late-summer dot diorama"**: one texel density everywhere (32 texels / unit; the hero is 1:1 dot-for-texel), but foliage is
  *volumetric dots* — 3D texel cells on clump shells instead of flat leaf cards — so canopies read as hand-placed pixel clusters
  from any angle while still casting dappled, moving shadows.
- **Hue-shifted ramps baked into every painter**: shadows step toward cool violet, lights toward butter yellow (`tone()` in
  `src/core.js`), and the grade repeats it (violet shadow split-tone, peach sun-scatter, lavender aerial haze) — dusk feels warm
  without going orange-brown.
- **Light is the protagonist**: low back-light from up-left, so the oak throws visible shafts across the village and the camera
  looks *into* the haze; windows and lanterns are already lit at golden hour so the night preset is a continuation, not a switch.
- **Tilt-shift lens, not a tilted camera**: a gentle 12° line of sight with an off-axis (lens-shifted) frustum fills the frame with
  tiers instead of sky, and the foreground is deliberately oversized wildflower bokeh — a "miniature in a flower bed" read.
- **Kites Studio signature**: a kite on a string over the hill and a kite-emblem banner at the centre house.

## References & research

- Octopath dev notes (brief): <https://business.4gamer.net/article/1810/18101801/>
- Tribute source studied (techniques re-implemented, not copied): `refs/the-last-night-tribute/`
- Bokeh DOF in a single pass — Dennis Gustafsson: <https://blog.voxagon.se/2018/05/04/bokeh-depth-of-field-in-single-pass.html>
- Oblique near-plane clipping — Eric Lengyel: <https://terathon.com/blog/oblique-clipping.html>
- Bloom mip chain — Jorge Jimenez, SIGGRAPH 2014: <https://www.iryoku.com/next-generation-post-processing-in-call-of-duty-advanced-warfare/>,
  three.js-oriented walkthrough: <https://learnopengl.com/Guest-Articles/2022/Phys.-Based-Bloom>
- Volumetric fog / shadowed in-scattering — Sébastien Hillaire, Frostbite:
  <https://www.ea.com/frostbite/news/physically-based-unified-volumetric-rendering-in-frostbite>

## Round-2 changes (after `review/web-review-1.md`)

The round-1 builder hit an account rate limit mid-pass; these edits are the orchestrator's, applied on top of its
round-2 work. Evidence: `review/web/round-2/`.

- Camera/composition, focus band, haze, night readability, canopies and life were reworked in the builder's round-2
  pass (see the captures): 22° line of sight, flat sharp band from 4 u in front of the hero to 14 u behind, warm
  surface ambient instead of fog-brightness, bigger lantern pools + window decals + campfire, voxel canopies.
- **Bushes fixed**: they were voxelised at 0.3125 u per cube over a ~0.6 u radius, so each shrub resolved into a
  scatter of 4–5 separate cubes. They now use 14 clumps at 0.7–1.0 u radius, 0.15625 u cubes and a 5-texel tile —
  half-size cubes with half the texels keeps 32 texels/unit, so the shrubs read as leaf clusters at the same
  texel density as the canopies.
- Performance re-measured with the GPU idle: `q=high` ~90 fps (round-1 numbers were contention-bound).

## Known limits

- `high` runs ~55 fps at 1440p internal on a shared GPU; use `?q=med` for a locked 60. Cost centres: volumetric march (~20%),
  DOF gather (~15%), canopy cell shader + 26k grass cards.
- Planar reflection only for the water plane (y = −0.32); the T2 channel uses the same mirror (slight parallax error there).
- Reflection pass has no volumetrics (linear haze approximation) and only near-water grass.
- Hero is a static single frame (no idle animation yet); no circular foreground cut-out around the hero.
- Fog lights are capped at 16 (lanterns + first windows); extra windows glow but don't scatter.
- Cloud cards are flat billboards; far hills are simple silhouettes.
