#!/usr/bin/env bash
# Scaffold an HD-2D Godot project from the godot-hd2d template, install Terrain3D 1.1.0, import, bake terrain.
# Usage: new_project.sh <target_dir> [--name "Project Name"]
# Env: GODOT (godot binary, default "godot"), T3D_ADDON (path to an existing addons/terrain_3d to copy
#      instead of downloading).
set -euo pipefail

SK="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T3D_URL="https://github.com/TokisanGames/Terrain3D/releases/download/v1.1.0-stable/Terrain3D_v1.1.0-stable.zip"
T3D_SHA="51b78bc758f5759cbc8eaaab14e5cf4e8661717e265fdd760f5abf945f15b243"
GODOT="${GODOT:-godot}"

[ $# -ge 1 ] || { echo "usage: $0 <target_dir> [--name \"Project Name\"]" >&2; exit 2; }
target="$1"; shift
name=""
while [ $# -gt 0 ]; do
	case "$1" in
		--name) name="$2"; shift 2 ;;
		*) echo "unknown argument: $1" >&2; exit 2 ;;
	esac
done

if [ -e "$target" ] && [ -n "$(ls -A "$target" 2>/dev/null)" ]; then
	echo "refusing: $target exists and is not empty" >&2
	exit 1
fi
mkdir -p "$target"
target="$(cd "$target" && pwd)"
cp -R "$SK/template/." "$target"
if [ -n "$name" ]; then
	esc="$(printf '%s' "$name" | sed 's/[\/&"]/\\&/g')"
	sed -i.bak "s/^config\/name=.*/config\/name=\"$esc\"/" "$target/project.godot"
	rm "$target/project.godot.bak"
fi

# Terrain3D
mkdir -p "$target/addons"
if [ -n "${T3D_ADDON:-}" ]; then
	cp -R "$T3D_ADDON" "$target/addons/terrain_3d"
else
	cache="${XDG_CACHE_HOME:-$HOME/.cache}/godot-hd2d"
	zip="$cache/$(basename "$T3D_URL")"
	mkdir -p "$cache"
	if [ ! -f "$zip" ]; then
		curl -fL -o "$zip.part" "$T3D_URL"
		mv "$zip.part" "$zip"
	fi
	got="$(shasum -a 256 "$zip" | cut -d' ' -f1)"
	if [ "$got" != "$T3D_SHA" ]; then
		echo "Terrain3D zip hash mismatch: $got (expected $T3D_SHA); delete $zip and retry" >&2
		exit 1
	fi
	tmp="$(mktemp -d)"
	trap 'rm -rf "$tmp"' EXIT
	unzip -q "$zip" -d "$tmp"
	src="$(find "$tmp" -type d -path '*addons/terrain_3d' | head -1)"
	[ -n "$src" ] || { echo "addons/terrain_3d not found in $zip" >&2; exit 1; }
	cp -R "$src" "$target/addons/terrain_3d"
fi

# first import registers the Terrain3D extension and imports textures; it exits non-zero on harmless warnings
"$GODOT" --headless --path "$target" --import >/dev/null 2>&1 || true
out="$("$GODOT" --headless --path "$target" --script res://hd2d/tools/bake_terrain.gd 2>&1)" || true
echo "$out" | grep -E "BAKE|ERROR" || true
if ! echo "$out" | grep -q "BAKE ok"; then
	echo "terrain bake failed:" >&2
	echo "$out" >&2
	exit 1
fi

cat <<MSG

HD-2D project ready: $target
  run:    $GODOT --path "$target"
  shot:   $GODOT --path "$target" --fixed-fps 60 -- --shot="$target/shot.png" --shot-delay=8 --nohud [--preset=night] [--rain]
  bench:  $GODOT --path "$target" -- --bench --nohud
  editor: $GODOT --path "$target" -e
MSG
