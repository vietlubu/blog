extends Node3D
## HD-2D rig (main.tscn root): camera, sun/moon, environment + volumetrics, planar water reflection,
## post pass, presets (golden hour <-> night, rain), controls, HUD, capture mode and FPS log.
## Scene objects are @tool prefabs found through groups (see SKILL.md group contract).

const Kit := preload("res://hd2d/core/kit.gd")
const Wind := preload("res://hd2d/core/wind.gd")
const Flora := preload("res://hd2d/core/flora.gd")
const SKY := preload("res://hd2d/shaders/sky.gdshader")
const POST := preload("res://hd2d/shaders/post.gdshader")
const FOG := preload("res://hd2d/shaders/fog.gdshader")
const TiltShift := preload("res://hd2d/core/tiltshift.gd")
const TEXEL := 32.0

@export var focus := Vector3(0.0, 2.9, -2.0)
@export var distance := 40.0
@export var fov := 21.0
## Sun at golden hour / moon at night: (azimuth, elevation) in degrees.
@export var sun_golden := Vector2(-40.0, 27.0)
@export var moon := Vector2(-6.0, 20.0)

var cam_base_pos: Vector3
var cam_fwd: Vector3
var cam: Camera3D
var env: Environment
var refl_env: Environment
var attrs: CameraAttributesPractical
var tilt: CompositorEffect
var sun: DirectionalLight3D
var sky_mat: ShaderMaterial
var water: Node3D
var refl_vp: SubViewport
var refl_cam: Camera3D
var post_mat: ShaderMaterial
var hud: Label
var toast: Label
var haze_mat: ShaderMaterial
var rain_fx: GPUParticles3D

var night := 0.0
var night_target := 0.0
var rain := 0.0
var rain_target := 0.0
var t := 0.0
var pan := 0.0
var zoom := 0.0
var dragging := false
var hud_t := 0.0
var hud_on := true
var toast_t := 0.0
var fog_on := true
var dof_on := true
var bloom_on := true
var high_q := false # default "balanced"; Q or --high switches to the screenshot tier
var shot_path := ""
var shot_delay := 4.0
var shot_taken := false
var bench := false
var fps_next := 10.0


func _parse_args() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shot="):
			shot_path = a.substr(7)
		elif a.begins_with("--shot-delay="):
			shot_delay = a.substr(13).to_float()
		elif a == "--preset=night":
			night = 1.0
			night_target = 1.0
		elif a == "--rain":
			rain = 1.0
			rain_target = 1.0
		elif a == "--high":
			high_q = true
		elif a == "--bench":
			bench = true


func _ready() -> void:
	_parse_args()
	RenderingServer.global_shader_parameter_set("wind_dir", Wind.DIR)
	cam_fwd = Kit.cam_fwd()
	cam_base_pos = focus - cam_fwd * distance
	_environment()
	_camera()
	_sun()
	_rain()
	_post_and_hud()
	_late_setup.call_deferred() # prefab builds were queued first, so they run before this


func _exit_tree() -> void:
	Kit.clear_caches()
	Flora.clear_caches()


func _late_setup() -> void:
	water = get_tree().get_first_node_in_group("hd2d_water")
	RenderingServer.global_shader_parameter_set("water_level", water.global_position.y if water else -1000.0)
	if water:
		_reflection()
	_apply()
	_set_quality(high_q)
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--scale="): # override the 3D render scale (MetalFX spatial), e.g. --scale=0.75
			get_viewport().scaling_3d_mode = Viewport.SCALING_3D_MODE_METALFX_SPATIAL
			get_viewport().scaling_3d_scale = a.substr(8).to_float()
		elif a.begins_with("--hide="): # diagnostics: hide nodes by name, e.g. --hide=GodRays,GrassT1
			for nm in a.substr(7).split(","):
				var n := find_child(nm, true, false) as Node3D
				if n:
					n.visible = false
				else:
					push_warning("--hide: no node named " + nm)
		elif a == "--nodof":
			tilt.dof_enabled = false
		elif a == "--novol":
			env.volumetric_fog_enabled = false


func _environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = SKY
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_128
	sky.process_mode = Sky.PROCESS_MODE_AUTOMATIC # static sky shader: radiance only rebuilt on preset change
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.ssao_enabled = true
	env.ssao_radius = 1.4
	env.ssao_intensity = 1.8
	env.ssao_power = 1.4
	env.glow_enabled = true
	env.glow_normalized = false
	env.glow_intensity = 0.55
	env.glow_strength = 1.0
	env.glow_bloom = 0.04
	env.glow_hdr_threshold = 1.0
	env.glow_hdr_scale = 1.8
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	for i in 7:
		env.set_glow_level(i, [0.0, 0.6, 1.0, 1.0, 0.8, 0.5, 0.3][i])
	env.volumetric_fog_enabled = true
	env.volumetric_fog_length = 70.0
	env.volumetric_fog_detail_spread = 1.6
	env.volumetric_fog_anisotropy = 0.45
	env.volumetric_fog_ambient_inject = 0.0 # only lit fog glows: shafts keep their contrast
	env.volumetric_fog_sky_affect = 0.15
	env.volumetric_fog_temporal_reprojection_enabled = true
	env.volumetric_fog_temporal_reprojection_amount = 0.9
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_DEPTH # aerial haze only beyond the focal band
	env.fog_depth_begin = 48.0
	env.fog_depth_end = 240.0
	env.fog_depth_curve = 1.4
	env.fog_aerial_perspective = 0.35
	env.fog_sky_affect = 0.25
	env.fog_sun_scatter = 0.25
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.06
	env.adjustment_saturation = 1.1
	attrs = CameraAttributesPractical.new() # exposure only; DOF is the custom half-res tilt-shift compositor
	tilt = TiltShift.new()
	var we := WorldEnvironment.new()
	we.environment = env
	we.camera_attributes = attrs
	add_child(we)
	# drifting ground haze over the whole diorama, graded by camera distance (pond mist lives in pond.gd)
	haze_mat = ShaderMaterial.new()
	haze_mat.shader = FOG
	haze_mat.set_shader_parameter("by_distance", true)
	haze_mat.set_shader_parameter("base_y", 0.0)
	haze_mat.set_shader_parameter("falloff", 0.25)
	haze_mat.set_shader_parameter("wisp", 0.45)
	haze_mat.set_shader_parameter("use_sdf", false)
	var haze := FogVolume.new()
	haze.shape = RenderingServer.FOG_VOLUME_SHAPE_WORLD
	haze.material = haze_mat
	add_child(haze)


func _camera() -> void:
	cam = Camera3D.new()
	cam.fov = fov
	cam.near = 0.5
	cam.far = 700.0
	cam.cull_mask = 0xFFFFF
	add_child(cam)
	cam.position = cam_base_pos
	cam.look_at(focus)
	cam.current = true
	var comp := Compositor.new()
	comp.compositor_effects = [tilt]
	cam.compositor = comp


func _sun() -> void:
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 130.0
	sun.directional_shadow_split_1 = 0.08
	sun.directional_shadow_split_2 = 0.2
	sun.directional_shadow_split_3 = 0.45
	sun.directional_shadow_blend_splits = true
	sun.light_angular_distance = 0.0
	sun.shadow_blur = 1.2
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.2
	add_child(sun)


## Rain (toggle R): streaks in a world-fixed volume around the focus.
func _rain() -> void:
	var rm := ParticleProcessMaterial.new()
	rm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	rm.emission_box_extents = Vector3(26, 0.5, 16)
	rm.direction = Vector3(0.15, -1, 0.05)
	rm.spread = 2.0
	rm.initial_velocity_min = 16.0
	rm.initial_velocity_max = 19.0
	rm.gravity = Vector3(0, -4, 0)
	var rq := QuadMesh.new()
	rq.size = Vector2(1.0 / TEXEL, 0.55)
	var rmt := StandardMaterial3D.new()
	rmt.albedo_color = Color(0.75, 0.8, 0.9, 0.35)
	rmt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmt.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	rmt.roughness = 0.1
	rmt.backlight_enabled = true
	rmt.backlight = Color(0.5, 0.5, 0.5)
	rq.material = rmt
	rain_fx = GPUParticles3D.new()
	# GPUParticles3D stay unnamed: a named one leaks its process shader at exit on Godot 4.7 ("ParticlesShaderRD never freed")
	rain_fx.amount = 9000
	rain_fx.lifetime = 1.3
	rain_fx.process_material = rm
	rain_fx.draw_pass_1 = rq
	rain_fx.position = Vector3(focus.x, 16, focus.z)
	rain_fx.visibility_aabb = AABB(Vector3(-30, -30, -20), Vector3(60, 34, 40))
	rain_fx.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	rain_fx.emitting = false
	add_child(rain_fx)


func _reflection() -> void:
	refl_vp = SubViewport.new()
	refl_vp.name = "Reflection"
	refl_vp.use_hdr_2d = true
	refl_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	refl_vp.positional_shadow_atlas_size = 0
	add_child(refl_vp)
	refl_env = env.duplicate()
	refl_env.volumetric_fog_enabled = false
	refl_env.ssao_enabled = false
	refl_env.glow_enabled = false
	refl_env.adjustment_enabled = false
	refl_env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	refl_env.fog_density = 0.012
	refl_cam = Camera3D.new()
	refl_cam.fov = fov
	refl_cam.near = 0.5
	refl_cam.far = 700.0
	refl_cam.cull_mask = 1 | 16 # world + sprites (sprite actors live on layer 16 so their contact decal skips them)
	refl_cam.environment = refl_env
	refl_cam.attributes = CameraAttributesPractical.new() # no DOF in the mirror
	refl_vp.add_child(refl_cam)
	refl_cam.current = true
	water.material.set_shader_parameter("reflection_tex", refl_vp.get_texture())
	_resize_reflection()
	get_viewport().size_changed.connect(_resize_reflection)


func _resize_reflection() -> void:
	if refl_vp == null:
		return
	var s := get_viewport().get_visible_rect().size
	var k := 0.5 if high_q else 0.45
	refl_vp.size = Vector2i(max(64, int(s.x * k)), max(64, int(s.y * k)))


func _post_and_hud() -> void:
	var cl := CanvasLayer.new()
	cl.layer = 1
	add_child(cl)
	var cr := ColorRect.new()
	cr.set_anchors_preset(Control.PRESET_FULL_RECT)
	cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	post_mat = ShaderMaterial.new()
	post_mat.shader = POST
	cr.material = post_mat
	cl.add_child(cr)
	var hl := CanvasLayer.new()
	hl.layer = 2
	add_child(hl)
	hud = Label.new()
	hud.text = "%s    1 golden  2 night  R rain  F fog  G DOF  B bloom  Q quality  H HUD  P shot" % ProjectSettings.get_setting("application/config/name")
	hud.position = Vector2(22, 16)
	hud.add_theme_font_size_override("font_size", 15)
	hud.add_theme_color_override("font_color", Color(1.0, 0.95, 0.85))
	hud.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	hud.add_theme_constant_override("shadow_offset_x", 1)
	hud.add_theme_constant_override("shadow_offset_y", 1)
	hl.add_child(hud)
	toast = Label.new()
	toast.position = Vector2(22, 46)
	toast.add_theme_font_size_override("font_size", 15)
	toast.add_theme_color_override("font_color", Color(1.0, 0.85, 0.55))
	toast.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	toast.modulate.a = 0.0
	hl.add_child(toast)
	if shot_path != "" or OS.get_cmdline_user_args().has("--nohud"):
		hl.visible = false


func _toast(s: String) -> void:
	toast.text = s
	toast_t = 2.0


func _sun_dir(az_deg: float, el_deg: float) -> Vector3:
	var az := deg_to_rad(az_deg)
	var el := deg_to_rad(el_deg)
	return Vector3(cos(el) * sin(az), sin(el), -cos(el) * cos(az))


func _c(a: String, b: String, k: float) -> Color:
	return Color.html(a).lerp(Color.html(b), k)


## All look parameters are a blend of two presets (golden hour / night) plus rain.
func _apply() -> void:
	var n := night
	var r := rain
	RenderingServer.global_shader_parameter_set("night", n)
	RenderingServer.global_shader_parameter_set("rain", r)
	RenderingServer.global_shader_parameter_set("wetness", r)
	RenderingServer.global_shader_parameter_set("wind_strength", 1.0 + r * 0.7)
	var to_light := _sun_dir(sun_golden.x, sun_golden.y).slerp(_sun_dir(moon.x, moon.y), n) # low moon behind the pond -> moon path
	sun.transform = Transform3D(Basis.looking_at(-to_light, Vector3.UP), Vector3.ZERO)
	Kit.night = n
	Kit.rain = r
	Kit.sun_dir = to_light
	if water:
		var wm: ShaderMaterial = water.material
		wm.set_shader_parameter("sun_dir", to_light)
		wm.set_shader_parameter("sun_col", _c("#ffc890", "#b8c8ff", n))
		wm.set_shader_parameter("glint", lerp(16.0, 5.0, n) * (1.0 - r * 0.8))
		# night keeps the moon glint to a few sparkles: a broad lobe turned the pond into one white blob that bloomed
		wm.set_shader_parameter("glint_lo", lerp(0.94, 0.995, n))
	sun.light_color = _c("#ffb46e", "#8fa8ff", n)
	sun.light_energy = lerp(4.4, 0.6, n) * (1.0 - r * 0.7)
	sun.light_volumetric_fog_energy = lerp(1.15, 1.6, n) # 2.0 blew the canopy gap into a shapeless amber smear
	env.ambient_light_energy = lerp(0.6, 0.6, n)
	env.ambient_light_sky_contribution = 0.45
	env.ambient_light_color = _c("#6f7fb8", "#2a3a78", n)
	sky_mat.set_shader_parameter("zenith", _c("#5f86c4", "#0a1430", n).lerp(Color.html("#5a6478"), r * 0.6))
	sky_mat.set_shader_parameter("horizon", _c("#ffc48c", "#30406e", n).lerp(Color.html("#8a8e98"), r * 0.6))
	sky_mat.set_shader_parameter("below", _c("#9a8a7a", "#141a30", n))
	sky_mat.set_shader_parameter("sun_glow", _c("#ff8a40", "#3a5aa0", n) * (1.0 - r * 0.7))
	sky_mat.set_shader_parameter("disc", lerp(0.99955, 0.99925, n))
	env.volumetric_fog_density = lerp(0.0, 0.0015, n) + r * 0.0015
	env.volumetric_fog_albedo = _c("#fff0dc", "#a8b8e8", n)
	env.volumetric_fog_emission = _c("#000000", "#06080f", n)
	env.fog_light_color = _c("#d4bfa6", "#1e2a50", n).lerp(Color.html("#7a808c"), r * 0.5)
	env.glow_hdr_threshold = lerp(1.0, 1.3, n)
	env.fog_density = lerp(0.8, 0.9, n)
	haze_mat.set_shader_parameter("albedo", _c("#ffe6c8", "#9cb0e0", n))
	haze_mat.set_shader_parameter("near_density", lerp(0.0015, 0.008, n) + r * 0.004)
	haze_mat.set_shader_parameter("density", lerp(0.022, 0.02, n) + r * 0.01)
	haze_mat.set_shader_parameter("near_d", 36.0)
	haze_mat.set_shader_parameter("far_d", 64.0)
	env.tonemap_exposure = lerp(1.0, 1.15, n)
	var m := Kit.materials()
	m["glass"].set_shader_parameter("emissive", lerp(0.45, 0.8, n)) # 1.05 blew the window cores to white at night
	m["lamp"].set_shader_parameter("emissive", lerp(2.2, 3.0, n))
	get_tree().call_group("hd2d_preset", "apply_preset", n, r)
	rain_fx.emitting = r > 0.02
	rain_fx.amount_ratio = r
	post_mat.set_shader_parameter("shadow_tint", _c("#c8d8ff", "#c8d4ff", n))
	post_mat.set_shader_parameter("high_tint", _c("#fff0dc", "#ffe8cc", n))


## balanced: no MSAA (SMAA), no SSAO, 96x64 froxels, 2 shadow splits, 0.45 mirror at 30 Hz, medium bokeh.
## high: MSAA 2x, 128x96 froxels, 4 splits, 0.5 mirror every frame, high bokeh.
func _set_quality(high: bool) -> void:
	high_q = high
	var vp := get_viewport()
	vp.msaa_3d = Viewport.MSAA_2X if high else Viewport.MSAA_DISABLED
	env.ssao_enabled = high
	vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED if high else Viewport.SCREEN_SPACE_AA_SMAA
	RenderingServer.environment_set_volumetric_fog_volume_size(128 if high else 96, 96 if high else 64)
	tilt.max_coc = 22.0 if high else 18.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if high else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 120.0 if high else 64.0
	RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM if high else RenderingServer.SHADOW_QUALITY_SOFT_VERY_LOW)
	# balanced renders 3D at 0.8 and upscales with MetalFX spatial (pixel edges stay sharp at this ratio)
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR if high else Viewport.SCALING_3D_MODE_METALFX_SPATIAL
	vp.scaling_3d_scale = 1.0 if high else 0.8
	_resize_reflection()


func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo:
		match e.keycode:
			KEY_1:
				night_target = 0.0
				_toast("Golden hour")
			KEY_2:
				night_target = 1.0
				_toast("Night")
			KEY_R:
				rain_target = 1.0 - rain_target
				_toast("Rain " + ("on" if rain_target > 0.5 else "off"))
			KEY_F:
				fog_on = not fog_on
				env.volumetric_fog_enabled = fog_on
				_toast("Volumetrics " + ("on" if fog_on else "off"))
			KEY_G:
				dof_on = not dof_on
				tilt.dof_enabled = dof_on
				_toast("Depth of field " + ("on" if dof_on else "off"))
			KEY_B:
				bloom_on = not bloom_on
				env.glow_enabled = bloom_on
				_toast("Bloom " + ("on" if bloom_on else "off"))
			KEY_Q:
				_set_quality(not high_q)
				_toast("Quality: " + ("high" if high_q else "balanced"))
			KEY_H:
				hud_on = not hud_on
			KEY_P:
				_save_shot()
			KEY_ESCAPE:
				get_tree().quit()
		hud_t = 0.0
	elif e is InputEventMouseButton:
		if e.button_index == MOUSE_BUTTON_LEFT:
			dragging = e.pressed
		elif e.button_index == MOUSE_BUTTON_WHEEL_UP and e.pressed:
			zoom = clamp(zoom - 1.5, -10.0, 8.0)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN and e.pressed:
			zoom = clamp(zoom + 1.5, -10.0, 8.0)
	elif e is InputEventMouseMotion and dragging:
		pan = clamp(pan - e.relative.x * 0.02, -9.0, 9.0)


func _save_shot() -> void:
	var dir := ProjectSettings.globalize_path("res://shots")
	DirAccess.make_dir_recursive_absolute(dir)
	var p := "%s/shot_%s.png" % [dir, Time.get_datetime_string_from_system().replace(":", "-")]
	get_viewport().get_texture().get_image().save_png(p)
	_toast("Saved " + p.get_file())
	print("screenshot: ", p)

## --bench: average real frame rate over seconds 6..16, printed with draw stats, then quit.
var bench_t := 0.0
var bench_n := 0
func _bench(delta: float) -> void:
	if t < 6.0:
		return
	bench_t += delta
	bench_n += 1
	if t >= 16.0:
		print("BENCH %s: %.1f fps avg (%.2f ms)  draws %d  prims %d  at %s" % [" ".join(OS.get_cmdline_user_args()), bench_n / bench_t, bench_t * 1000.0 / bench_n,
			Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME), str(get_viewport().get_visible_rect().size)])
		get_tree().quit()


func _process(delta: float) -> void:
	t += delta
	if bench:
		_bench(delta)
	var nn := move_toward(night, night_target, delta * 0.4)
	var rr := move_toward(rain, rain_target, delta * 0.5)
	if nn != night or rr != rain:
		night = nn
		rain = rr
		_apply()
	# slow breathing drift (parallax) + user pan/zoom; default framing is the money shot
	var right := cam_fwd.cross(Vector3.UP).normalized()
	var drift := right * (sin(t * 0.11) * 0.9 + pan) + Vector3.UP * sin(t * 0.17) * 0.3
	cam.position = cam_base_pos + drift - cam_fwd * zoom
	cam.look_at(focus + right * pan + Vector3(sin(t * 0.07) * 0.15, 0, 0))
	var fn := get_tree().get_first_node_in_group("hd2d_focus")
	var fp: Vector3 = fn.focus_point() if fn else focus
	tilt.focus_distance = (fp - cam.global_position).dot(-cam.global_basis.z)
	# planar mirror camera
	if water:
		var b := cam.global_basis
		var mirror := func(v: Vector3) -> Vector3: return Vector3(v.x, -v.y, v.z)
		var p := cam.global_position
		p.y = 2.0 * water.global_position.y - p.y
		refl_cam.global_transform = Transform3D(Basis(-mirror.call(b.x), mirror.call(b.y), mirror.call(b.z)), p)
		if high_q or Engine.get_process_frames() % 2 == 0:
			refl_vp.render_target_update_mode = SubViewport.UPDATE_ONCE # balanced: 30 Hz mirror is plenty under ripples
	haze_mat.set_shader_parameter("cam_pos", cam.global_position)
	# HUD fade
	hud_t += delta
	hud.modulate.a = (clamp(1.0 - (hud_t - 6.0) / 1.5, 0.0, 1.0) if hud_on else 0.0)
	toast_t -= delta
	toast.modulate.a = clamp(toast_t, 0.0, 1.0)
	# capture mode
	if shot_path != "" and not shot_taken and t >= shot_delay:
		shot_taken = true
		await RenderingServer.frame_post_draw
		var img := get_viewport().get_texture().get_image()
		img.save_png(shot_path)
		print("shot saved: ", shot_path, " ", img.get_size())
		get_tree().quit()
	# FPS log every 10 s in normal runs
	if t >= fps_next:
		fps_next += 10.0
		print("FPS %d at %s (%s quality)" % [Engine.get_frames_per_second(), str(get_viewport().get_visible_rect().size), "high" if high_q else "balanced"])
