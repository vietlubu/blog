@tool
extends RefCounted
## Foliage building blocks shared by tree, structure and grass prefabs: leaf-card canopies, trunks, ivy,
## grass tuft MultiMeshes, falling leaves. Units: 1 unit = 32 texels.

const Pix := preload("res://hd2d/core/pixtex.gd")
const Kit := preload("res://hd2d/core/kit.gd")
const FOLIAGE := preload("res://hd2d/shaders/foliage.gdshader")
const GRASS := preload("res://hd2d/shaders/grass.gdshader")
const LEAVES := preload("res://hd2d/shaders/leaves.gdshader")
const LEAFDRAW := preload("res://hd2d/shaders/leafdraw.gdshader")
const TEXEL := 32.0
const LEAF_KEY := Vector3(-0.35, 0.86, -0.36) # up-weighted golden-hour key used to bake lobe value masses

static var _foliage := {}
static var _grass_mat: ShaderMaterial
static var _tuft: QuadMesh
static var _leaf_tex: ImageTexture


static func clear_caches() -> void:
	_foliage = {}
	_grass_mat = null
	_tuft = null
	_leaf_tex = null


## "near" focal-tier trees, "bush" bushes / ivy / lens branch, "far" bluer backdrop forest.
static func foliage_mat(kind: String) -> ShaderMaterial:
	if _foliage.has(kind):
		return _foliage[kind]
	var atlas: Texture2D
	var tint := Color(1, 1, 1)
	var sway := 0.35
	match kind:
		"bush":
			atlas = Pix.leaf_atlas(1)
			tint = Color(1.02, 1.04, 0.95)
			sway = 0.5
		"far":
			atlas = Pix.leaf_atlas(2, ["#14262e", "#1d3a3a", "#2c5640", "#447646", "#6c9a52", "#a4bc6a"])
			tint = Color(0.95, 0.97, 1.0)
			sway = 0.25
		_:
			atlas = Pix.leaf_atlas(1)
	var mt := ShaderMaterial.new()
	mt.shader = FOLIAGE
	mt.set_shader_parameter("atlas", atlas)
	mt.set_shader_parameter("tint", tint)
	mt.set_shader_parameter("sway", sway)
	_foliage[kind] = mt
	return mt


## Cards face the camera with yaw/tilt jitter only: the right axis stays horizontal, so leaf pixels never
## turn into diamonds (Octopath rule: pixels never rotate diagonally).
static func card_basis(rng: RandomNumberGenerator) -> Basis:
	var f := (-Kit.cam_fwd() + Vector3(rng.randf_range(-0.45, 0.45), rng.randf_range(-0.15, 0.35), 0.0)).normalized()
	var r := Vector3.UP.cross(f).normalized()
	var u := f.cross(r).normalized()
	return Basis(r, u, f)


## Leaf-card canopy: cards on/inside ellipsoid lobes [[center, radii], ...], outward normals per vertex, AO by
## depth and a baked 3-step value mass per lobe (lit cap / mid band / dark core) so clumps read as big shapes.
static func canopy(fb, key: String, lobes: Array, cards: int, rng: RandomNumberGenerator, sway: float, card: float = 2.0) -> void:
	var total_v := 0.0
	for lb in lobes:
		total_v += lb[1].x * lb[1].y * lb[1].z
	for lb in lobes:
		var c: Vector3 = lb[0]
		var rad: Vector3 = lb[1]
		var n := int(cards * rad.x * rad.y * rad.z / total_v) + 3
		for i in n:
			var dir := Vector3(rng.randfn(), rng.randfn() * 0.8 + 0.25, rng.randfn() + 0.35).normalized()
			var depth := pow(rng.randf(), 0.5)
			var p := c + dir * rad * (0.55 + 0.45 * depth)
			var bas := card_basis(rng)
			var hs := card * 0.5
			var cell := rng.randi_range(0, 7)
			var corners := [Vector3(-hs, -hs, 0), Vector3(hs, -hs, 0), Vector3(hs, hs, 0), Vector3(-hs, hs, 0)]
			var uvs := [Vector2(cell / 8.0, 1.0), Vector2((cell + 1) / 8.0, 1.0), Vector2((cell + 1) / 8.0, 0.0), Vector2(cell / 8.0, 0.0)]
			var kd := dir.dot(LEAF_KEY)
			var mass := 1.1 if kd > 0.4 else (0.92 if kd > -0.15 else 0.7)
			var pts := []
			var nrm := []
			var col := []
			for k in 4:
				var q: Vector3 = p + bas * corners[k]
				pts.append(q)
				var on := ((q - c) / (rad * rad)).normalized()
				nrm.append((on * 0.85 + bas.z * 0.15).normalized())
				var ao: float = clamp(0.5 + 0.5 * depth + on.y * 0.15, 0.35, 1.0) * mass
				col.append(Color(ao, ao, ao))
			var uv2 := Vector2(sway * clamp(0.4 + (p.y - (c.y - rad.y)) / (rad.y * 2.0) * 0.6, 0.0, 1.0), rng.randf() * 6.28)
			fb.tri(key, [pts[0], pts[1], pts[2]], [nrm[0], nrm[1], nrm[2]], [uvs[0], uvs[1], uvs[2]], [col[0], col[1], col[2]], uv2)
			fb.tri(key, [pts[0], pts[2], pts[3]], [nrm[0], nrm[2], nrm[3]], [uvs[0], uvs[2], uvs[3]], [col[0], col[2], col[3]], uv2)


static func trunk(tb, base: Vector3, h: float, r: float, rng: RandomNumberGenerator, branches: Array) -> void:
	tb.prism("bark", Transform3D(Basis(), base), 11, r, r * 0.62, h, Color(0.6, 0.55, 0.6))
	for i in 5:
		var a := i * TAU / 5.0 + rng.randf()
		var bas := Basis(Vector3(cos(a + PI * 0.5), 0, sin(a + PI * 0.5)), 0.9)
		tb.box("bark", Transform3D(bas, base + Vector3(cos(a) * r * 0.9, 0.25, sin(a) * r * 0.9)), Vector3(r * 0.5, 1.0, r * 0.5), Color(0.55, 0.5, 0.55))
	for br in branches:
		var to: Vector3 = br
		var from := base + Vector3(0, h * 0.85, 0)
		var dv := to - from
		var up := dv.normalized()
		var side := up.cross(Vector3.FORWARD).normalized()
		if side.length() < 0.1:
			side = Vector3.RIGHT
		var bas := Basis(side, up, side.cross(up)).orthonormalized()
		tb.prism("bark", Transform3D(bas, from), 8, r * 0.4, r * 0.18, dv.length(), Color(0.6, 0.55, 0.6), Color.WHITE, false)


## One 2x2-unit ivy card hanging from `top` down the wall face (+z), darker toward its tip. Key "bush".
static func ivy(fb, top: Vector3, rng: RandomNumberGenerator) -> void:
	var cell := rng.randi_range(0, 7)
	var pts := [top + Vector3(-1, -2, 0), top + Vector3(1, -2, 0), top + Vector3(1, 0, 0), top + Vector3(-1, 0, 0)]
	var uvs := [Vector2(cell / 8.0, 1.0), Vector2((cell + 1) / 8.0, 1.0), Vector2((cell + 1) / 8.0, 0.0), Vector2(cell / 8.0, 0.0)]
	var nb := Vector3(0, 0.35, 1).normalized()
	var nt := Vector3(0, 0.7, 0.7).normalized()
	var lo := Color(0.62, 0.62, 0.62)
	var hi := Color(0.95, 0.95, 0.95)
	var uv2 := Vector2(0.12, rng.randf() * 6.28)
	fb.tri("bush", [pts[0], pts[1], pts[2]], [nb, nb, nt], [uvs[0], uvs[1], uvs[2]], [lo, lo, hi], uv2)
	fb.tri("bush", [pts[0], pts[2], pts[3]], [nb, nt, nt], [uvs[0], uvs[2], uvs[3]], [lo, hi, hi], uv2)


static func grass_material() -> ShaderMaterial:
	if _grass_mat == null:
		_grass_mat = ShaderMaterial.new()
		_grass_mat.shader = GRASS
		_grass_mat.set_shader_parameter("atlas", Pix.tuft_atlas())
	return _grass_mat


## 24x32 px tuft quad, pivot at the bottom centre (atlas cells: Pix.tuft_atlas).
static func tuft_mesh() -> QuadMesh:
	if _tuft == null:
		_tuft = QuadMesh.new()
		_tuft.size = Vector2(24.0, 32.0) / TEXEL
		_tuft.center_offset = Vector3(0, _tuft.size.y * 0.5, 0)
	return _tuft


## Tufts instanced at exactly 1 texel = 1/32 unit (integer scale only); colors tint, custom = (cell, phase).
static func multimesh(xf: Array, colors: Array, custom: Array, node_name: String, layer: int) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.use_custom_data = true
	mm.mesh = tuft_mesh()
	mm.instance_count = xf.size()
	for i in xf.size():
		mm.set_instance_transform(i, xf[i])
		mm.set_instance_color(i, colors[i])
		mm.set_instance_custom_data(i, custom[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.name = node_name
	mmi.multimesh = mm
	mmi.material_override = grass_material()
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.layers = layer
	return mmi


## Flower tufts spilling out of window boxes / niches: 4 per point, in the caller's local space.
static func flower_tufts(points: Array, rng: RandomNumberGenerator) -> MultiMeshInstance3D:
	var xf := []
	var co := []
	var cu := []
	for fs in points:
		for k in 4:
			var p: Vector3 = fs + Vector3(rng.randf_range(-0.4, 0.4), 0, rng.randf_range(-0.08, 0.08))
			var flip := -1.0 if rng.randf() < 0.5 else 1.0
			xf.append(Transform3D(Basis(Vector3.UP, rng.randf_range(-0.3, 0.3)).scaled(Vector3(flip, 1, 1)), p - Vector3(0, 0.04, 0)))
			cu.append(Color(4 + rng.randi_range(0, 2), rng.randf(), 0, 0))
			var t := rng.randf_range(0.88, 1.1)
			co.append(Color(t, t * rng.randf_range(0.97, 1.03), t * 0.95))
	return multimesh(xf, co, cu, "Flowers", 4)


## Falling leaves riding the wind field, spawned in a box of half-size `extent` around `center` (caller's local space).
static func leaves(center: Vector3, extent: Vector3, amount: int) -> GPUParticles3D:
	var pm := ShaderMaterial.new()
	pm.shader = LEAVES
	pm.set_shader_parameter("box_center", Vector3.ZERO)
	pm.set_shader_parameter("box_extent", extent)
	pm.set_shader_parameter("leaf_scale", 1.0)
	var q := QuadMesh.new()
	q.size = Vector2(6.0, 6.0) / TEXEL
	var dm := ShaderMaterial.new()
	dm.shader = LEAFDRAW
	if _leaf_tex == null:
		_leaf_tex = Pix.leaf_particles()
	dm.set_shader_parameter("tex", _leaf_tex)
	q.material = dm
	var gp := GPUParticles3D.new()
	gp.amount = amount
	gp.lifetime = 16.0
	gp.preprocess = 16.0
	gp.process_material = pm
	gp.draw_pass_1 = q
	gp.position = center
	gp.visibility_aabb = AABB(Vector3(-60, -20, -40), Vector3(120, 40, 80))
	return gp
