@tool
extends RefCounted
## Shared building blocks for prefabs: one cached set of surface materials (rig.gd animates glass/lamp
## emissive on these instances), window/lantern lights, chimney smoke, lit pixel sprites, and the
## current preset values the rig publishes for prefabs.

const SURF := preload("res://hd2d/shaders/surface.gdshader")
const Pix := preload("res://hd2d/core/pixtex.gd")
const SPRITE := preload("res://hd2d/shaders/sprite.gdshader")
const TEXEL := 32.0
const CAM_PITCH := 17.0 # camera pitch lives here: camera-facing leaf cards and god-ray slices are baked against it

# written by rig._apply, read by prefabs in apply_preset / _process
static var night := 0.0
static var rain := 0.0
static var sun_dir := Vector3.UP

static var _mats := {}
static var _puff: ImageTexture


## Static caches outlive the scene tree and are reported as leaks at exit; the rig calls this on exit.
static func clear_caches() -> void:
	_mats = {}
	_puff = null


static func _smat(pattern: int, cols: Array, opts: Dictionary = {}) -> ShaderMaterial:
	var mt := ShaderMaterial.new()
	mt.shader = SURF
	mt.set_shader_parameter("pattern", pattern)
	for i in 4:
		mt.set_shader_parameter("c%d" % i, Color.html(cols[i]))
	for k in opts:
		mt.set_shader_parameter(k, opts[k])
	return mt


static func materials() -> Dictionary:
	if not _mats.is_empty():
		return _mats
	var stone := ["#3d3440", "#736a6c", "#a39886", "#d0c4a8"]
	_mats = {
		"plaster": _smat(0, ["#7a6560", "#bfa58e", "#e6d2b2", "#f7ead0"]),
		"plaster_b": _smat(0, ["#7c5d5e", "#c9a294", "#efd3bf", "#fdeadb"]),
		"timber": _smat(6, ["#24161a", "#432a26", "#62402f", "#82593c"], {"rough": 0.8}),
		"stone": _smat(1, stone, {"moss": 0.3}),
		"stone_big": _smat(1, stone, {"moss": 0.35, "course": 9.0}),
		"clay": _smat(2, ["#4e1f22", "#93392b", "#c95e3a", "#ea9a5e"], {"rough": 0.65, "moss": 0.08}),
		"slate": _smat(3, ["#1f2440", "#37446c", "#506595", "#7d93bd"], {"rough": 0.45, "spec": 0.6}),
		"thatch": _smat(4, ["#4a3420", "#86622f", "#bc9448", "#e4c878"], {"moss": 0.12, "bump": 1.4}),
		"planks": _smat(5, ["#33221d", "#5f3f2d", "#8a5e3c", "#b08458"]),
		"shutter_g": _smat(5, ["#1f3a34", "#2f5e4e", "#47806a", "#6aa488"]),
		"shutter_b": _smat(5, ["#1c2a48", "#2e4878", "#4568a0", "#6f92c4"]),
		"shutter_r": _smat(5, ["#4a1c1e", "#7a2e2a", "#a8463a", "#cc6a50"]),
		"glass": _smat(9, ["#2a1a18", "#6a3c2a", "#b07440", "#e8b066"], {"rough": 0.12, "spec": 0.9, "emissive": 0.6}),
		"lamp": _smat(9, ["#6a3c20", "#c07a38", "#f0b860", "#fff0c0"], {"rough": 0.2, "emissive": 3.0, "emit_color": Color(1.0, 0.7, 0.35)}),
		"bark": _smat(7, ["#2a2026", "#4a3934", "#6c5646", "#8c775c"], {"moss": 0.2}),
		"cobble": _smat(8, stone, {"rough": 0.6}),
		"iron": _smat(10, ["#16161c", "#25252e", "#383842", "#52525e"], {"rough": 0.45, "spec": 0.7}),
		"cloth_red": _smat(10, ["#4a1c22", "#8a2e2e", "#b84a3a", "#d87050"]),
		"windmill": _smat(0, ["#6a5e5a", "#a89a8c", "#d6c8b0", "#efe4cc"]),
	}
	return _mats


static func omni(p: Vector3, col: Color, rng_: float) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = p
	l.light_color = col
	l.omni_range = rng_
	l.omni_attenuation = 1.6
	l.light_specular = 0.6
	l.shadow_enabled = false
	return l


static func smoke(p: Vector3) -> GPUParticles3D:
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.15
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 12.0
	pm.initial_velocity_min = 0.3
	pm.initial_velocity_max = 0.45
	pm.gravity = Vector3(0.6, 0.04, 0.25)
	pm.damping_min = 0.1
	pm.damping_max = 0.2
	pm.scale_min = 0.55
	pm.scale_max = 0.85
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.35))
	sc.add_point(Vector2(1, 2.6))
	var sct := CurveTexture.new()
	sct.curve = sc
	pm.scale_curve = sct
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0.0))
	g.set_color(1, Color(1, 1, 1, 0.0))
	g.add_point(0.08, Color(1, 1, 1, 0.9))
	g.add_point(0.5, Color(0.95, 0.95, 1.0, 0.6))
	var gt := GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	pm.angle_min = -180.0
	pm.angle_max = 180.0
	pm.angular_velocity_min = -15.0
	pm.angular_velocity_max = 15.0
	var q := QuadMesh.new()
	q.size = Vector2(1.2, 1.2)
	var mt := StandardMaterial3D.new()
	if _puff == null:
		_puff = Pix.puff_image()
	mt.albedo_texture = _puff
	mt.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.vertex_color_use_as_albedo = true
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mt.albedo_color = Color(0.92, 0.9, 0.92)
	mt.backlight_enabled = true
	mt.backlight = Color(0.5, 0.45, 0.4)
	mt.disable_receive_shadows = false
	q.material = mt
	var gp := GPUParticles3D.new()
	gp.amount = 32
	gp.lifetime = 7.0
	gp.preprocess = 7.0
	gp.process_material = pm
	gp.draw_pass_1 = q
	gp.position = p
	gp.visibility_aabb = AABB(Vector3(-8, -2, -8), Vector3(16, 14, 16))
	gp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return gp


static func cam_fwd() -> Vector3:
	return Basis(Vector3.RIGHT, deg_to_rad(-CAM_PITCH)) * Vector3.FORWARD


static func window_light(l: OmniLight3D, n: float) -> void:
	l.light_energy = lerp(0.5, 0.95, n)
	l.light_volumetric_fog_energy = lerp(1.0, 2.2, n)


static func lantern_light(l: OmniLight3D, n: float) -> void:
	l.light_energy = lerp(1.1, 4.0, n)
	l.light_volumetric_fog_energy = lerp(2.0, 4.5, n)


static func smoke_preset(s: GPUParticles3D, n: float) -> void:
	var sm: StandardMaterial3D = s.draw_pass_1.material
	sm.albedo_color = Color.html("#ebe6eb").lerp(Color.html("#3a4058"), n)
	sm.backlight = Color.html("#807366").lerp(Color.html("#000000"), n)


## Lit pixel sprite quad at 32 texels / unit, pivot bottom-centre; `frames` side-by-side cells.
static func sprite(img: Image, frames: int, shadows: bool) -> MeshInstance3D:
	var q := QuadMesh.new()
	q.size = Vector2(img.get_width() / float(frames), img.get_height()) / TEXEL
	q.center_offset = Vector3(0, q.size.y * 0.5, 0)
	var mt := ShaderMaterial.new()
	mt.shader = SPRITE
	mt.set_shader_parameter("tex", ImageTexture.create_from_image(img))
	mt.set_shader_parameter("ntex", Pix.silhouette_normals(img, 2 if img.get_height() < 20 else 3))
	mt.set_shader_parameter("frames", float(frames))
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = mt
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi
