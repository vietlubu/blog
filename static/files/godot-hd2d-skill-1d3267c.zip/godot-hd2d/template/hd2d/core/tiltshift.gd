extends CompositorEffect
## Half-resolution tilt-shift bokeh DOF (replaces Godot's built-in DOF, which cost ~5 ms at 1440p).
## 1) downsample to half res + signed circle of confusion (far > 0, near < 0) from linear depth,
## 2) single-pass scatter-as-gather on a golden-angle spiral (Gustafsson 2018), background samples are
##    clamped so they cannot bleed over sharper foreground; near samples spread over the focal band,
## 3) full-res composite that leaves in-focus pixels untouched, so the hero's pixels stay perfectly crisp.
## All three passes are compute shaders compiled from the GLSL strings below (no import step needed).

var dof_enabled := true
var focus_distance := 30.0
var near_start := 3.0 # 7.0 put the whole near field inside the sharp band and killed the miniature look
var near_range := 4.0
var far_start := 9.0 # sharp band behind the focus (units)
var far_range := 34.0
var max_coc := 20.0 # full-blur radius in pixels at 1440p (scaled with the internal height)
var z_near := 0.5
var z_far := 700.0
var reversed_z := true # Godot 4.3+ renders with reversed Z

var rd: RenderingDevice
var shaders: Array[RID] = []
var pipes: Array[RID] = []
var lin_sampler: RID
var near_sampler: RID
var half_a: RID
var half_b: RID
var half_size := Vector2i.ZERO

const COMMON := """
#version 450
layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;
layout(push_constant, std430) uniform Params {
	vec4 a; // focus (view depth), near_start, near_range, far_start
	vec4 b; // far_range, max_coc_px, full_w, full_h
	vec4 c; // znear, zfar, reversed-z flag, unused
} p;
float coc(vec2 uv, float z) {
	float n = p.c.x;
	float f = p.c.y;
	float d = p.c.z > 0.5 ? n * f / (n + z * (f - n)) : n * f / (f - z * (f - n));
	float far_c = clamp((d - (p.a.x + p.a.w)) / p.b.x, 0.0, 1.0);
	float near_c = clamp(((p.a.x - p.a.y) - d) / p.a.z, 0.0, 1.0);
	return far_c - near_c;
}
"""

const DOWN := """
layout(set = 0, binding = 0) uniform sampler2D color_tex;
layout(set = 0, binding = 1) uniform sampler2D depth_tex;
layout(rgba16f, set = 0, binding = 2) uniform restrict writeonly image2D out_img;
void main() {
	ivec2 fs = ivec2(p.b.zw);
	ivec2 hs = (fs + 1) / 2;
	ivec2 px = ivec2(gl_GlobalInvocationID.xy);
	if (any(greaterThanEqual(px, hs))) return;
	vec3 c = vec3(0.0);
	float cmin = 1.0;
	float cmax = -1.0;
	for (int j = 0; j < 2; j++) {
		for (int i = 0; i < 2; i++) {
			ivec2 q = min(px * 2 + ivec2(i, j), fs - 1);
			c += texelFetch(color_tex, q, 0).rgb;
			float k = coc((vec2(q) + 0.5) / vec2(fs), texelFetch(depth_tex, q, 0).r);
			cmin = min(cmin, k);
			cmax = max(cmax, k);
		}
	}
	c *= 0.25;
	float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
	c *= 1.0 / (1.0 + max(l - 6.0, 0.0) * 0.15); // energy clamp: lone hot texels must not sparkle
	imageStore(out_img, px, vec4(c, cmin < -0.01 ? cmin : cmax));
}
"""

const GATHER := """
layout(set = 0, binding = 0) uniform sampler2D half_tex;
layout(rgba16f, set = 0, binding = 1) uniform restrict writeonly image2D out_img;
const float GOLDEN = 2.39996323;
void main() {
	ivec2 hs = (ivec2(p.b.zw) + 1) / 2;
	ivec2 px = ivec2(gl_GlobalInvocationID.xy);
	if (any(greaterThanEqual(px, hs))) return;
	vec2 texel = 1.0 / vec2(hs);
	vec2 uv = (vec2(px) + 0.5) * texel;
	vec4 c0 = textureLod(half_tex, uv, 0.0);
	float maxr = p.b.y * 0.5;
	float csize = abs(c0.a) * maxr;
	vec3 acc = c0.rgb;
	float tot = 1.0;
	float nearcov = max(-c0.a, 0.0);
	float radius = 0.6;
	for (float ang = 0.0; radius < maxr; ang += GOLDEN) {
		vec4 s = textureLod(half_tex, uv + vec2(cos(ang), sin(ang)) * texel * radius, 0.0);
		float ssize = abs(s.a) * maxr;
		if (s.a > c0.a) {
			ssize = min(ssize, csize * 2.0); // farther (sharper or behind) samples cannot bleed forward
		}
		float m = smoothstep(radius - 0.5, radius + 0.5, ssize);
		acc += mix(acc / tot, s.rgb, m);
		tot += 1.0;
		if (s.a < 0.0) {
			nearcov = max(nearcov, -s.a * m);
		}
		radius += 0.8 / radius;
	}
	imageStore(out_img, px, vec4(acc / tot, nearcov));
}
"""

const COMPOSITE := """
layout(rgba16f, set = 0, binding = 0) uniform restrict image2D color_img;
layout(set = 0, binding = 1) uniform sampler2D depth_tex;
layout(set = 0, binding = 2) uniform sampler2D blur_tex;
void main() {
	ivec2 fs = ivec2(p.b.zw);
	ivec2 px = ivec2(gl_GlobalInvocationID.xy);
	if (any(greaterThanEqual(px, fs))) return;
	vec2 uv = (vec2(px) + 0.5) / vec2(fs);
	float k = abs(coc(uv, texelFetch(depth_tex, px, 0).r));
	vec4 b = textureLod(blur_tex, uv, 0.0);
	float w = smoothstep(0.06, 0.30, max(k, b.a));
	if (w <= 0.0) return; // focal band: untouched, pixel-exact
	vec4 c = imageLoad(color_img, px);
	imageStore(color_img, px, vec4(mix(c.rgb, b.rgb, w), c.a));
}
"""


func _init() -> void:
	effect_callback_type = EFFECT_CALLBACK_TYPE_POST_TRANSPARENT
	access_resolved_color = true
	access_resolved_depth = true
	rd = RenderingServer.get_rendering_device()
	RenderingServer.call_on_render_thread(_init_rd)


func _init_rd() -> void:
	if rd == null:
		return
	for src in [DOWN, GATHER, COMPOSITE]:
		var s := RDShaderSource.new()
		s.language = RenderingDevice.SHADER_LANGUAGE_GLSL
		s.source_compute = COMMON + src
		var spirv := rd.shader_compile_spirv_from_source(s)
		if spirv.compile_error_compute != "":
			push_error("tiltshift: " + spirv.compile_error_compute)
			return
		var sh := rd.shader_create_from_spirv(spirv)
		shaders.append(sh)
		pipes.append(rd.compute_pipeline_create(sh))
	var ss := RDSamplerState.new()
	ss.min_filter = RenderingDevice.SAMPLER_FILTER_LINEAR
	ss.mag_filter = RenderingDevice.SAMPLER_FILTER_LINEAR
	ss.repeat_u = RenderingDevice.SAMPLER_REPEAT_MODE_CLAMP_TO_EDGE
	ss.repeat_v = RenderingDevice.SAMPLER_REPEAT_MODE_CLAMP_TO_EDGE
	lin_sampler = rd.sampler_create(ss)
	ss.min_filter = RenderingDevice.SAMPLER_FILTER_NEAREST
	ss.mag_filter = RenderingDevice.SAMPLER_FILTER_NEAREST
	near_sampler = rd.sampler_create(ss)


func _notification(what: int) -> void:
	# methods can't be called on self during PREDELETE: free everything inline
	if what == NOTIFICATION_PREDELETE and rd != null:
		for r in [half_a, half_b, lin_sampler, near_sampler]:
			if r.is_valid():
				rd.free_rid(r)
		for sh in shaders:
			if sh.is_valid():
				rd.free_rid(sh) # frees its pipeline and cached uniform sets too


func _free_textures() -> void:
	for r in [half_a, half_b]:
		if r.is_valid():
			rd.free_rid(r)
	half_a = RID()
	half_b = RID()


func _make_textures(hs: Vector2i) -> void:
	_free_textures()
	var tf := RDTextureFormat.new()
	tf.format = RenderingDevice.DATA_FORMAT_R16G16B16A16_SFLOAT
	tf.width = hs.x
	tf.height = hs.y
	tf.usage_bits = RenderingDevice.TEXTURE_USAGE_SAMPLING_BIT | RenderingDevice.TEXTURE_USAGE_STORAGE_BIT
	half_a = rd.texture_create(tf, RDTextureView.new())
	half_b = rd.texture_create(tf, RDTextureView.new())
	half_size = hs


func _u(type: int, binding: int, ids: Array) -> RDUniform:
	var u := RDUniform.new()
	u.uniform_type = type
	u.binding = binding
	for id in ids:
		u.add_id(id)
	return u


func _render_callback(_type: int, render_data: RenderData) -> void:
	if not dof_enabled or pipes.size() < 3:
		return
	var rsb: RenderSceneBuffersRD = render_data.get_render_scene_buffers()
	var size := rsb.get_internal_size()
	if size.x == 0 or size.y == 0:
		return
	var hs := Vector2i((size.x + 1) / 2, (size.y + 1) / 2)
	if hs != half_size:
		_make_textures(hs)
	var pc := PackedFloat32Array([
		focus_distance, near_start, near_range, far_start,
		far_range, max_coc * size.y / 1440.0, size.x, size.y,
		z_near, z_far, 1.0 if reversed_z else 0.0, 0.0]).to_byte_array()
	var SWT := RenderingDevice.UNIFORM_TYPE_SAMPLER_WITH_TEXTURE
	var IMG := RenderingDevice.UNIFORM_TYPE_IMAGE
	for view in rsb.get_view_count():
		var color := rsb.get_color_layer(view)
		var depth := rsb.get_depth_layer(view)
		var s0 := UniformSetCacheRD.get_cache(shaders[0], 0, [_u(SWT, 0, [near_sampler, color]), _u(SWT, 1, [near_sampler, depth]), _u(IMG, 2, [half_a])])
		var s1 := UniformSetCacheRD.get_cache(shaders[1], 0, [_u(SWT, 0, [lin_sampler, half_a]), _u(IMG, 1, [half_b])])
		var s2 := UniformSetCacheRD.get_cache(shaders[2], 0, [_u(IMG, 0, [color]), _u(SWT, 1, [near_sampler, depth]), _u(SWT, 2, [lin_sampler, half_b])])
		var cl := rd.compute_list_begin()
		rd.compute_list_bind_compute_pipeline(cl, pipes[0])
		rd.compute_list_bind_uniform_set(cl, s0, 0)
		rd.compute_list_set_push_constant(cl, pc, pc.size())
		rd.compute_list_dispatch(cl, (hs.x + 7) / 8, (hs.y + 7) / 8, 1)
		rd.compute_list_add_barrier(cl)
		rd.compute_list_bind_compute_pipeline(cl, pipes[1])
		rd.compute_list_bind_uniform_set(cl, s1, 0)
		rd.compute_list_set_push_constant(cl, pc, pc.size())
		rd.compute_list_dispatch(cl, (hs.x + 7) / 8, (hs.y + 7) / 8, 1)
		rd.compute_list_add_barrier(cl)
		rd.compute_list_bind_compute_pipeline(cl, pipes[2])
		rd.compute_list_bind_uniform_set(cl, s2, 0)
		rd.compute_list_set_push_constant(cl, pc, pc.size())
		rd.compute_list_dispatch(cl, (size.x + 7) / 8, (size.y + 7) / 8, 1)
		rd.compute_list_end()
