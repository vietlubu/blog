@tool
extends RefCounted
## Script-side copy of the shader wind field (common.gdshaderinc wind_gust), for life that moves on the CPU.

const DIR := Vector2(0.92, 0.38) # must equal project.godot shader_globals/wind_dir (rig.gd sets the global from this)


static func gust(p: Vector2, t: float) -> float:
	var s := p.dot(DIR)
	var g := 0.5 + 0.5 * sin(s * 0.21 - t * 1.6 + 0.6 * sin(t * 0.23))
	g *= 0.55 + 0.45 * sin(s * 0.063 - t * 0.47 + 2.0)
	return g * g
