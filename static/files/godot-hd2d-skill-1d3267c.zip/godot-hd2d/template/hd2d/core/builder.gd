@tool
extends RefCounted
## Collects triangles per material. Surface materials project their own UVs (surface.gdshader face_uv), so box/prism emit none; tri() still carries UVs for atlas cards.

const NO_UV := [Vector2.ZERO, Vector2.ZERO, Vector2.ZERO]

var tools := {}
var mats := {}


func _st(key: String) -> SurfaceTool:
	if not tools.has(key):
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		tools[key] = st
	return tools[key]


## One vertex-complete triangle; reorders to Godot's clockwise front faces around `n`.
func tri(key: String, p: Array, n: Array, uv: Array, col: Array, uv2: Vector2 = Vector2.ZERO) -> void:
	var order := [0, 1, 2]
	var face_n: Vector3 = n[0] + n[1] + n[2]
	if (p[1] - p[0]).cross(p[2] - p[0]).dot(face_n) > 0.0:
		order = [0, 2, 1]
	var st := _st(key)
	for i in order:
		st.set_color(col[i])
		st.set_normal(n[i])
		st.set_uv(uv[i])
		st.set_uv2(uv2)
		st.add_vertex(p[i])


## Quad a,b,c,d (any winding) with flat normal.
func quad(key: String, a: Vector3, b: Vector3, c: Vector3, d: Vector3, n: Vector3, lo: Color = Color.WHITE, hi: Color = Color.WHITE) -> void:
	tri(key, [a, b, c], [n, n, n], NO_UV, [lo, lo, hi])
	tri(key, [a, c, d], [n, n, n], NO_UV, [lo, hi, hi])


const FACES := [
	[Vector3.RIGHT, Vector3.UP], [Vector3.LEFT, Vector3.UP],
	[Vector3.BACK, Vector3.UP], [Vector3.FORWARD, Vector3.UP],
	[Vector3.UP, Vector3.FORWARD], [Vector3.DOWN, Vector3.BACK]]


## Box centred at xf.origin; lo/hi vertex colours give a baked grime/AO gradient bottom->top.
func box(key: String, xf: Transform3D, size: Vector3, lo: Color = Color.WHITE, hi: Color = Color.WHITE, bottom: bool = false) -> void:
	var h := size * 0.5
	for f in FACES:
		var n: Vector3 = f[0]
		var up: Vector3 = f[1]
		if n == Vector3.DOWN and not bottom:
			continue
		var right := up.cross(n)
		var c := n * h
		var r := right * h
		var u := up * h
		var nw := (xf.basis * n).normalized()
		var side := n.y == 0.0
		quad(key, xf * (c - r - u), xf * (c + r - u), xf * (c + r + u), xf * (c - r + u), nw,
			lo if side else hi, hi)


func boxp(key: String, pos: Vector3, size: Vector3, lo: Color = Color.WHITE, hi: Color = Color.WHITE) -> void:
	box(key, Transform3D(Basis(), pos), size, lo, hi)


## N-sided prism (tapered), base at xf.origin.
func prism(key: String, xf: Transform3D, sides: int, r0: float, r1: float, height: float, lo: Color = Color.WHITE, hi: Color = Color.WHITE, cap: bool = true) -> void:
	for i in sides:
		var a0 := TAU * i / sides
		var a1 := TAU * (i + 1) / sides
		var am := (a0 + a1) * 0.5
		var p0 := Vector3(cos(a0) * r0, 0, sin(a0) * r0)
		var p1 := Vector3(cos(a1) * r0, 0, sin(a1) * r0)
		var p2 := Vector3(cos(a1) * r1, height, sin(a1) * r1)
		var p3 := Vector3(cos(a0) * r1, height, sin(a0) * r1)
		var n := (xf.basis * Vector3(cos(am), (r0 - r1) / height, sin(am))).normalized()
		tri(key, [xf * p0, xf * p1, xf * p2], [n, n, n], NO_UV, [lo, lo, hi])
		tri(key, [xf * p0, xf * p2, xf * p3], [n, n, n], NO_UV, [lo, hi, hi])
		if cap:
			var top := xf * Vector3(0, height, 0)
			var nu := (xf.basis * Vector3.UP).normalized()
			tri(key, [top, xf * p2, xf * p3], [nu, nu, nu], NO_UV, [hi, hi, hi])


func commit(node_name: String, shadows: bool = true) -> MeshInstance3D:
	var mesh := ArrayMesh.new()
	for key in tools:
		var st: SurfaceTool = tools[key]
		st.commit(mesh)
		mesh.surface_set_material(mesh.get_surface_count() - 1, mats[key])
	var mi := MeshInstance3D.new()
	mi.name = node_name
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	tools.clear()
	return mi
