@tool
extends RefCounted
## Ground queries on the Terrain3D node in group "hd2d_terrain": bilinear height, painted path/cobble/flower
## mask (same channels as terrain.gdshader mask_at), and the water plane height.

const SPACING := 0.5 # Terrain3D vertex_spacing in main.tscn


static func find(n: Node) -> Terrain3D:
	if not n.is_inside_tree():
		return null
	var t := n.get_tree().get_first_node_in_group("hd2d_terrain") as Terrain3D
	if t == null or t.data == null or t.data.get_region_count() == 0:
		return null
	return t


## Bilinear between the 4 surrounding vertices: Terrain3DData.get_height/get_control are floor lookups.
## The +0.25 keeps each sample inside its vertex cell despite float error.
static func height(t: Terrain3D, x: float, z: float) -> float:
	if t == null:
		return 0.0
	var fx := x / SPACING
	var fz := z / SPACING
	var ix := floorf(fx)
	var iz := floorf(fz)
	var d := t.data
	var h00 := d.get_height(Vector3((ix + 0.25) * SPACING, 0.0, (iz + 0.25) * SPACING))
	var h10 := d.get_height(Vector3((ix + 1.25) * SPACING, 0.0, (iz + 0.25) * SPACING))
	var h01 := d.get_height(Vector3((ix + 0.25) * SPACING, 0.0, (iz + 1.25) * SPACING))
	var h11 := d.get_height(Vector3((ix + 1.25) * SPACING, 0.0, (iz + 1.25) * SPACING))
	return lerpf(lerpf(h00, h10, fx - ix), lerpf(h01, h11, fx - ix), fz - iz)


## r path (dirt + cobbles), g cobbles, a flowers.
static func mask(t: Terrain3D, x: float, z: float) -> Color:
	if t == null:
		return Color(0, 0, 0, 0)
	var fx := x / SPACING
	var fz := z / SPACING
	var ix := floorf(fx)
	var iz := floorf(fz)
	var m00 := _id_mask(t, Vector3((ix + 0.25) * SPACING, 0.0, (iz + 0.25) * SPACING))
	var m10 := _id_mask(t, Vector3((ix + 1.25) * SPACING, 0.0, (iz + 0.25) * SPACING))
	var m01 := _id_mask(t, Vector3((ix + 0.25) * SPACING, 0.0, (iz + 1.25) * SPACING))
	var m11 := _id_mask(t, Vector3((ix + 1.25) * SPACING, 0.0, (iz + 1.25) * SPACING))
	var mm := m00.lerp(m10, fx - ix).lerp(m01.lerp(m11, fx - ix), fz - iz)
	return Color(mm.x + mm.y, mm.y, 0.0, mm.z)


## Painted ids: 0 grass, 1 dirt path, 2 cobbles, 3 meadow -> (dirt, cobble, flowers).
static func _id_mask(t: Terrain3D, p: Vector3) -> Vector3:
	var c := t.data.get_control(p)
	var bl := Terrain3DUtil.get_blend(c) / 255.0
	return _id_vec(Terrain3DUtil.get_base(c)) * (1.0 - bl) + _id_vec(Terrain3DUtil.get_overlay(c)) * bl


static func _id_vec(id: int) -> Vector3:
	match id:
		1: return Vector3(1, 0, 0)
		2: return Vector3(0, 1, 0)
		3: return Vector3(0, 0, 1)
	return Vector3.ZERO


static func water_y(n: Node) -> float:
	if not n.is_inside_tree():
		return -1e6
	var w := n.get_tree().get_first_node_in_group("hd2d_water") as Node3D
	return w.global_position.y if w else -1e6
