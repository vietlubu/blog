@tool
extends Node3D
## Base of every prefab: rebuilds generated children under "_gen" whenever an export changes (editor and
## runtime). "_gen" has no owner, so the .tscn stores only the exports. Subclasses override _build(root).

const Builder := preload("res://hd2d/core/builder.gd")
const Kit := preload("res://hd2d/core/kit.gd")
const Pix := preload("res://hd2d/core/pixtex.gd")
const Ground := preload("res://hd2d/core/ground.gd")
const Flora := preload("res://hd2d/core/flora.gd")
const Wind := preload("res://hd2d/core/wind.gd")

@export var snap_to_ground := false:
	set(v):
		snap_to_ground = v
		_queue()
@export var snap_offset := 0.0:
	set(v):
		snap_offset = v
		_queue()
@export_tool_button("Rebuild", "Reload") var rebuild_now: Callable = _queue

var _gen: Node3D
var _dirty := false
var _t: Terrain3D


func _ready() -> void:
	_queue() # deferred: terrain data and sibling prefabs are ready first


func _queue() -> void:
	if is_inside_tree() and not _dirty:
		_dirty = true
		_rebuild.call_deferred()


func _rebuild() -> void:
	_dirty = false
	if _gen:
		remove_child(_gen)
		_gen.queue_free()
	_gen = Node3D.new()
	_gen.name = "_gen"
	add_child(_gen)
	_t = Ground.find(self)
	_build(_gen)
	if snap_to_ground:
		var gp := global_position
		_gen.position.y = Ground.height(_t, gp.x, gp.z) + snap_offset - gp.y
	if has_method("apply_preset"):
		call("apply_preset", Kit.night, Kit.rain)


func _build(_root: Node3D) -> void:
	pass


## Multi-part prefabs: ground under a local point minus ground under the origin (0 when not snapping).
func _ground_rel(local: Vector3) -> float:
	if not snap_to_ground or _t == null:
		return 0.0
	var p := global_transform * local
	var o := global_position
	return Ground.height(_t, p.x, p.z) - Ground.height(_t, o.x, o.z)


## XZ rect enclosing a local footprint rect after the node transform.
func _xz_bounds(r: Rect2) -> Rect2:
	var xf := global_transform
	var out := Rect2()
	for i in 4:
		var c := r.position + r.size * Vector2(i & 1, i >> 1)
		var p := xf * Vector3(c.x, 0.0, c.y)
		out = Rect2(p.x, p.z, 0.0, 0.0) if i == 0 else out.expand(Vector2(p.x, p.z))
	return out
