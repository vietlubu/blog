extends SceneTree
## Prints baked ground height and paint at world points.
## godot --headless --path . --script res://hd2d/tools/probe.gd -- -12,0.15 7,-8

const Ground := preload("res://hd2d/core/ground.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var t := Terrain3D.new()
	t.vertex_spacing = Ground.SPACING
	t.data_directory = "res://terrain/data"
	var target := Node3D.new()
	root.add_child(target)
	t.set_clipmap_target(target)
	root.add_child(t)
	await process_frame
	for a in OS.get_cmdline_user_args():
		var xz := a.split(",")
		if xz.size() != 2:
			push_error("probe: expected x,z but got " + a)
			continue
		var x := xz[0].to_float()
		var z := xz[1].to_float()
		var m := Ground.mask(t, x, z)
		print("PROBE %s %s h=%.3f dirt=%.2f cobble=%.2f flowers=%.2f" % [xz[0], xz[1], Ground.height(t, x, z), m.r - m.g, m.g, m.a])
	quit()
