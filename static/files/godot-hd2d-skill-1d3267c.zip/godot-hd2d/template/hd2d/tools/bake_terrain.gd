extends SceneTree
## Bakes res://terrain/recipe.gd into Terrain3D data (res://terrain/data), using res://terrain/assets.tres.
## godot --headless --path . --script res://hd2d/tools/bake_terrain.gd

const Ground := preload("res://hd2d/core/ground.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var recipe = load("res://terrain/recipe.gd").new()
	var bounds: Rect2 = recipe.BOUNDS
	var origin: Vector2 = recipe.ORIGIN
	var n: int = recipe.SIZE
	var t := Terrain3D.new()
	t.vertex_spacing = Ground.SPACING
	t.assets = load("res://terrain/assets.tres")
	var target := Node3D.new()
	root.add_child(target)
	t.set_clipmap_target(target)
	root.add_child(t)
	await process_frame
	var hmap := Image.create(n, n, false, Image.FORMAT_RF)
	var cmap := Image.create(n, n, false, Image.FORMAT_RF)
	var lo := bounds.position
	var hi := bounds.end
	for pz in n:
		for px in n:
			var x := origin.x + px * Ground.SPACING
			var z := origin.y + pz * Ground.SPACING
			var bits: int
			var h: float
			if bounds.has_point(Vector2(x, z)):
				h = recipe.height(x, z)
				var p: Vector3 = recipe.paint(x, z)
				var over := 0
				var blend := 0.0
				if p.y >= 0.02:
					over = 2
					blend = p.y
				elif p.x >= 0.02:
					over = 1
					blend = p.x
				elif p.z >= 0.02:
					over = 3
					blend = p.z
				bits = Terrain3DUtil.enc_base(0) | Terrain3DUtil.enc_overlay(over) | Terrain3DUtil.enc_blend(roundi(clampf(blend, 0.0, 1.0) * 255.0))
			else:
				h = recipe.height(clampf(x, lo.x, hi.x - Ground.SPACING), clampf(z, lo.y, hi.y - Ground.SPACING))
				bits = Terrain3DUtil.enc_hole(true)
			hmap.set_pixel(px, pz, Color(h, 0, 0, 1))
			cmap.set_pixel(px, pz, Color(Terrain3DUtil.as_float(bits), 0, 0, 1))
	t.data.import_images([hmap, cmap, null], Vector3(origin.x, 0, origin.y), 0.0, 1.0)
	var dir := ProjectSettings.globalize_path("res://terrain/data")
	DirAccess.make_dir_recursive_absolute(dir)
	for f in DirAccess.get_files_at(dir):
		if f.ends_with(".res"):
			DirAccess.remove_absolute(dir.path_join(f))
	t.data.save_directory("res://terrain/data")
	print("BAKE ok regions=%d" % t.data.get_region_count())
	quit()
