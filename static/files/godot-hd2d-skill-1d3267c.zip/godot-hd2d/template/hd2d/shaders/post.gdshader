// Final lens/grade pass on the tonemapped image: split-tone grade, vignette, edge-weighted
// chromatic aberration, fine animated grain.
shader_type canvas_item;
#include "res://hd2d/shaders/common.gdshaderinc"

uniform sampler2D screen : hint_screen_texture, filter_linear, repeat_disable;
uniform float ca = 0.0012;
uniform float vignette = 0.42;
uniform float grain = 0.022;
uniform vec3 shadow_tint : source_color = vec3(0.86, 0.92, 1.08);
uniform vec3 high_tint : source_color = vec3(1.08, 1.0, 0.9);
uniform float lift = 0.015;

void fragment() {
	vec2 uv = SCREEN_UV;
	vec2 c = uv - 0.5;
	float r2 = dot(c, c);
	vec2 off = c * r2 * ca * 4.0;
	vec3 col = vec3(texture(screen, uv - off).r, texture(screen, uv).g, texture(screen, uv + off).b);
	float l = dot(col, vec3(0.299, 0.587, 0.114));
	col *= mix(shadow_tint, high_tint, smoothstep(0.08, 0.75, l));
	col += lift * shadow_tint * (1.0 - l);
	col *= 1.0 - vignette * smoothstep(0.08, 0.55, r2 * 1.6);
	float g = hash12(floor(FRAGCOORD.xy * 0.5) + fract(TIME * 7.13) * 431.0) - 0.5;
	col += g * grain * (1.0 - l * 0.6);
	COLOR = vec4(col, 1.0);
}
