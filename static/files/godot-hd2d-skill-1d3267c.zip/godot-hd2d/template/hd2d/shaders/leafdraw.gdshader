// Draw pass for falling leaves: 4-variant pixel leaf atlas picked by particle CUSTOM.z.
shader_type spatial;
render_mode cull_disabled;

uniform sampler2D tex : source_color, filter_nearest;
uniform float cells = 4.0;
varying float cell;

void vertex() {
	cell = floor(INSTANCE_CUSTOM.z * cells);
}

void fragment() {
	vec4 c = texture(tex, vec2((UV.x + cell) / cells, UV.y));
	ALBEDO = c.rgb;
	ALPHA = c.a;
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	BACKLIGHT = c.rgb * 0.6;
	ROUGHNESS = 0.8;
}
