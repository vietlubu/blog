// Every architectural surface: per-texel procedural pixel art on an object-space planar projection (32 texels / unit),
// quantised to a 4-tone hue-shifted ramp, with a per-texel normal from the pattern height.
shader_type spatial;
render_mode cull_back;
#include "res://hd2d/shaders/common.gdshaderinc"

uniform int pattern = 0;
uniform vec3 c0 : source_color = vec3(0.2);
uniform vec3 c1 : source_color = vec3(0.4);
uniform vec3 c2 : source_color = vec3(0.6);
uniform vec3 c3 : source_color = vec3(0.8);
uniform float texel = 32.0;
uniform float course = 7.0;
uniform float rough = 0.85;
uniform float bump = 1.0;
uniform float moss = 0.0;
uniform float emissive = 0.0;
uniform vec3 emit_color : source_color = vec3(1.0, 0.62, 0.3);
uniform float spec = 0.5;

varying vec3 wpos;
varying vec3 wnrm;
varying vec3 opos; // object-space position in world units (model scale applied): 32 texels / unit at any scale
varying vec3 onrm; // object-space normal, only used to orient the derived face normal

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wnrm = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	opos = VERTEX * vec3(length(MODEL_MATRIX[0].xyz), length(MODEL_MATRIX[1].xyz), length(MODEL_MATRIX[2].xyz));
	onrm = NORMAL;
}

// x: ramp value 0..1, y: height 0..1 (for the per-texel normal)
vec2 pat(vec2 t) {
	if (pattern == 0) { // lime plaster with stains
		float n = vnoise(t * 0.09) * 0.5 + vnoise(t * 0.31 + 5.0) * 0.25 + hash12(t) * 0.25;
		float stain = smoothstep(0.7, 0.8, vnoise(t * vec2(0.05, 0.11) + 11.0));
		return vec2(0.66 + (n - 0.5) * 0.42 - stain * 0.32, n * 0.35);
	}
	if (pattern == 1) { // rubble stone courses
		float row = floor(t.y / course);
		float ly = t.y - row * course;
		float w = course + 1.0 + floor(hash12(vec2(row, 3.0)) * course);
		float sx = t.x + hash12(vec2(row, 9.0)) * 40.0;
		float col = floor(sx / w);
		float lx = sx - col * w;
		if (ly < 1.0 || lx < 1.0) return vec2(0.04, 0.0);
		vec2 id = vec2(col, row);
		float v = 0.36 + hash12(id) * 0.3 + (hash12(t) - 0.5) * 0.14;
		if (ly < 2.0 || lx < 2.0) v += 0.2;
		if (ly > course - 2.0 || lx > w - 2.0) v -= 0.14;
		float e = min(min(ly, course - ly), min(lx, w - lx));
		return vec2(v, clamp(e / 2.5, 0.0, 1.0));
	}
	if (pattern == 2) { // barrel clay tiles
		float row = floor(t.y / 6.0);
		float ly = t.y - row * 6.0;
		float sx = t.x + mod(row, 2.0) * 2.0;
		float col = floor(sx / 5.0);
		float lx = sx - col * 5.0;
		float prof = 1.0 - abs(lx - 2.0) / 2.5;
		float v = 0.28 + prof * 0.52 + (hash12(vec2(col, row)) - 0.5) * 0.2;
		if (ly > 4.0) v -= 0.32;
		if (ly < 1.0) v += 0.08;
		return vec2(v, prof * (ly > 4.0 ? 0.25 : 1.0));
	}
	if (pattern == 3) { // slate
		float row = floor(t.y / 5.0);
		float ly = t.y - row * 5.0;
		float w = 7.0 + floor(hash12(vec2(row, 4.0)) * 4.0);
		float sx = t.x + hash12(vec2(row, 7.0)) * 30.0;
		float col = floor(sx / w);
		float lx = sx - col * w;
		if (ly > 3.0 || lx < 1.0) return vec2(0.04, 0.0);
		float v = 0.34 + hash12(vec2(col, row)) * 0.36 + (hash12(t) - 0.5) * 0.1;
		if (ly < 1.0) v += 0.2;
		return vec2(v, 1.0 - ly * 0.18);
	}
	if (pattern == 4) { // thatch bundles
		float row = floor(t.y / 8.0);
		float ly = t.y - row * 8.0;
		float streak = hash12(vec2(t.x, floor((t.y + hash12(vec2(t.x, row)) * 4.0) / 3.0)));
		float v = 0.45 + (streak - 0.5) * 0.5 + (vnoise(t * 0.07) - 0.5) * 0.3 + (1.0 - ly / 7.0) * 0.15;
		if (ly > 6.0) v -= 0.35;
		return vec2(v, 1.0 - ly / 8.0 * 0.8 + streak * 0.2);
	}
	if (pattern == 5) { // planks
		float row = floor(t.y / 6.0);
		float ly = t.y - row * 6.0;
		float len = 28.0 + floor(hash12(vec2(row, 2.0)) * 20.0);
		float sx = t.x + hash12(vec2(row, 5.0)) * 60.0;
		float col = floor(sx / len);
		float lx = sx - col * len;
		if (ly < 1.0 || lx < 1.0) return vec2(0.04, 0.0);
		float grain = sin(sx * 0.25 + ly * 1.7 + hash12(vec2(col, row)) * 20.0) * 0.5 + 0.5;
		float v = 0.4 + hash12(vec2(col, row)) * 0.2 + grain * 0.18 + (hash12(t) - 0.5) * 0.08;
		if (ly < 2.0) v += 0.1;
		if (ly > 4.0) v -= 0.08;
		if ((abs(lx - 2.0) < 0.5 || abs(lx - (len - 2.0)) < 0.5) && abs(ly - 3.0) < 0.5) v = 0.02;
		return vec2(v, 0.7 + grain * 0.3);
	}
	if (pattern == 6) { // timber beams, grain along u
		float g = vnoise(vec2(t.x * 0.08, t.y * 0.7));
		return vec2(0.3 + g * 0.45 + (hash12(t) - 0.5) * 0.12, g);
	}
	if (pattern == 7) { // bark ridges
		float ridge = vnoise(vec2(t.x * 0.45, t.y * 0.07));
		float v = 0.2 + ridge * 0.65 + (hash12(t) - 0.5) * 0.12;
		if (ridge < 0.28) v = 0.04;
		return vec2(v, ridge);
	}
	if (pattern == 8) { // cobbles (voronoi)
		vec2 c = t / 7.0;
		vec2 ci = floor(c);
		vec2 cf = fract(c);
		float f1 = 8.0;
		float f2 = 8.0;
		vec2 best = vec2(0.0);
		vec2 boff = vec2(0.0);
		for (int j = -1; j <= 1; j++) {
			for (int i = -1; i <= 1; i++) {
				vec2 g = vec2(float(i), float(j));
				vec2 r = g + hash22(ci + g) * 0.8 + 0.1 - cf;
				float d = dot(r, r);
				if (d < f1) { f2 = f1; f1 = d; best = ci + g; boff = r; } else if (d < f2) { f2 = d; }
			}
		}
		float edge = (sqrt(f2) - sqrt(f1)) * 7.0;
		if (edge < 1.1) return vec2(0.04, 0.0);
		float v = 0.34 + hash12(best) * 0.34 + clamp(dot(boff, vec2(0.7)), -1.0, 1.0) * 0.22;
		return vec2(v, clamp(edge / 3.0, 0.0, 1.0));
	}
	if (pattern == 9) { // glass: warm interior, faint curtain bands
		float band = step(0.5, fract(t.x / 6.0)) * 0.12;
		return vec2(0.45 + band + (hash12(floor(t / 2.0)) - 0.5) * 0.15, 0.5);
	}
	// 10: cloth / generic
	float n = vnoise(t * 0.2);
	return vec2(0.45 + (hash12(t) - 0.5) * 0.18 + (n - 0.5) * 0.3, n);
}


// Per-face planar UV in object space (world units): u along the face's horizontal edge, v down its up-slope.
// The face normal comes from position derivatives, so smooth-shaded imported meshes still project per triangle.
vec2 face_uv(vec3 p, vec3 ref_n) {
	vec3 c = cross(dFdx(p), dFdy(p));
	vec3 n = dot(c, c) > 1e-20 ? normalize(c) : normalize(ref_n);
	if (dot(n, ref_n) < 0.0) n = -n;
	vec3 up = abs(n.y) > 0.9 ? vec3(0.0, 0.0, -sign(n.y)) : vec3(0.0, 1.0, 0.0);
	up = normalize(up - n * dot(up, n));
	vec3 right = cross(up, n);
	return vec2(dot(p, right), -dot(p, up));
}

// Cotangent frame (no mesh tangents needed): view-space T/B along +u/+v.
void cotangent(vec3 N, vec3 p, vec2 uv, out vec3 T, out vec3 B) {
	vec3 dp1 = dFdx(p);
	vec3 dp2 = dFdy(p);
	vec2 duv1 = dFdx(uv);
	vec2 duv2 = dFdy(uv);
	vec3 dp2perp = cross(dp2, N);
	vec3 dp1perp = cross(N, dp1);
	T = dp2perp * duv1.x + dp1perp * duv2.x;
	B = dp2perp * duv1.y + dp1perp * duv2.y;
	float invmax = inversesqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
	T *= invmax;
	B *= invmax;
}
void fragment() {
	if (CAMERA_POSITION_WORLD.y < water_level && wpos.y < water_level) {
		discard; // planar reflection pass: drop what is below the mirror
	}
	vec2 uv = face_uv(opos, onrm);
	vec2 t = floor(uv * texel);
	vec2 p = pat(t);
	vec2 px = pat(t + vec2(1.0, 0.0));
	vec2 py = pat(t + vec2(0.0, 1.0));
	// big soft tint gradient (breaks tile repetition, Octopath-style)
	float big = vnoise(wpos.xz * 0.11 + wpos.y * 0.07);
	vec3 col = ramp4(p.x + (big - 0.5) * 0.12, c0, c1, c2, c3);
	if (moss > 0.0) {
		float m = vnoise(t * 0.06 + 3.0) * 0.7 + hash12(t) * 0.3;
		float up = clamp(wnrm.y, 0.0, 1.0);
		if (m > 1.0 - moss * (0.3 + up * 0.6)) {
			col = ramp4(p.x * 0.8 + 0.1, vec3(0.03, 0.06, 0.04), vec3(0.06, 0.12, 0.04), vec3(0.13, 0.22, 0.05), vec3(0.27, 0.36, 0.08));
		}
	}
	col *= COLOR.rgb;
	float wet = wetness * (0.5 + 0.5 * clamp(wnrm.y, 0.0, 1.0));
	ALBEDO = col * (1.0 - wet * 0.35);
	ROUGHNESS = mix(rough, 0.15, wet);
	SPECULAR = spec;
	vec3 T;
	vec3 B;
	cotangent(NORMAL, VERTEX, uv, T, B);
	NORMAL = normalize(NORMAL - (T * (px.y - p.y) + B * (py.y - p.y)) * bump * 0.6);
	if (emissive > 0.0) {
		EMISSION = emit_color * emissive * (0.7 + 0.6 * p.x);
	}
}
