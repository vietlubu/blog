// Copyright © 2023-2026 Cory Petkovsek, Roope Palmroos, and Contributors.
// This shader is the minimum needed to allow the terrain to function, without any texturing.
// HD-2D template: Terrain3D minimum.gdshader (v1.1.0) + HD-2D ground shading (per world texel, 32 / unit).

shader_type spatial;
render_mode blend_mix,depth_draw_opaque,cull_back,diffuse_burley,specular_schlick_ggx,skip_vertex_transform;

// Defined Constants
#define MAX_REGIONS 1024 // Match Terrain3DMaterial.max_regions. Set to 64-256 for mobile

// Inline Functions
#if CURRENT_RENDERER == RENDERER_COMPATIBILITY
    #define fma(a, b, c) ((a) * (b) + (c))
    #define dFdxCoarse(a) dFdx(a)
    #define dFdyCoarse(a) dFdy(a)
#endif

// Private uniforms
// Commented uniforms aren't needed for this shader, but are available for your own needs.
group_uniforms private;
uniform vec3 _target_pos = vec3(0.f);
uniform float _mesh_size = 48.f;
uniform float _subdiv = 1.f;
uniform uint _background_mode = 1u; // NONE = 0, FLAT = 1, NOISE = 2
uniform uint _mouse_layer = 0x80000000u; // Layer 32
uniform float _vertex_spacing = 1.0;
uniform float _vertex_density = 1.0; // = 1./_vertex_spacing
uniform float _region_size = 1024.0;
uniform float _region_texel_size = 0.0009765625; // = 1./region_size
uniform int _region_map_size = 32;
uniform int _region_map[1024];
//uniform vec2 _region_locations[MAX_REGIONS];
//uniform float _texture_normal_depth_array[32];
//uniform float _texture_ao_strength_array[32];
//uniform float _texture_ao_affect_array[32];
//uniform float _texture_roughness_mod_array[32];
//uniform float _texture_uv_scale_array[32];
//uniform vec2 _texture_detile_array[32];
//uniform vec4 _texture_color_array[32];
uniform highp sampler2DArray _height_maps : repeat_disable;
uniform highp sampler2DArray _control_maps : repeat_disable;
//uniform highp sampler2DArray _color_maps : source_color, filter_linear_mipmap_anisotropic, repeat_disable;
//uniform highp sampler2DArray _texture_array_albedo : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
//uniform highp sampler2DArray _texture_array_normal : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
group_uniforms;

// Public uniforms
#include "res://hd2d/shaders/common.gdshaderinc"
uniform float texel = 32.0;
uniform vec3 g0 : source_color = vec3(0.0902, 0.1882, 0.1843); // #17302f
uniform vec3 g1 : source_color = vec3(0.1412, 0.3137, 0.2275); // #24503a
uniform vec3 g2 : source_color = vec3(0.2471, 0.4588, 0.2118); // #3f7536
uniform vec3 g3 : source_color = vec3(0.4353, 0.6118, 0.2275); // #6f9c3a
uniform vec3 g4 : source_color = vec3(0.6902, 0.7765, 0.3373); // #b0c656
uniform vec3 d0 : source_color = vec3(0.2431, 0.1725, 0.1647); // #3e2c2a
uniform vec3 d1 : source_color = vec3(0.4314, 0.3137, 0.2510); // #6e5040
uniform vec3 d2 : source_color = vec3(0.6118, 0.4784, 0.3451); // #9c7a58
uniform vec3 d3 : source_color = vec3(0.7765, 0.6588, 0.4784); // #c6a87a
uniform vec3 s0 : source_color = vec3(0.2745, 0.2235, 0.2353); // #46393c
uniform vec3 s1 : source_color = vec3(0.5020, 0.4353, 0.4000); // #806f66
uniform vec3 s2 : source_color = vec3(0.6902, 0.6275, 0.5255); // #b0a086
uniform vec3 s3 : source_color = vec3(0.8627, 0.7961, 0.6588); // #dccba8
uniform vec3 mud : source_color = vec3(0.2275, 0.2275, 0.1490); // #3a3a26
uniform float wet_min_z = -7.0; // below water_level counts as pond bed / wet bank only where z > wet_min_z (keeps dry valleys behind the pond dry)

// Varyings & Types
// Some are required for editor functions
varying vec3 v_vertex;
varying float v_vertex_xz_dist;
varying vec3 v_camera_pos;

////////////////////////
// Vertex
////////////////////////

// Takes in world space XZ (UV) coordinates
// Returns ivec3 with:
// XY: (0 to _region_size - 1) coordinates within a region
// Z: layer index used for texturearrays, -1 if not in a region
ivec3 get_index_coord(const vec2 uv) {
	vec2 r_uv = round(uv);
	ivec2 pos = ivec2(floor(r_uv * _region_texel_size)) + (_region_map_size / 2);
	int bounds = int(uint(pos.x | pos.y) < uint(_region_map_size));
	int map_val = _region_map[pos.y * _region_map_size + pos.x];
	int raw_index = map_val - 1;
	// Real regions limited by max_regions
	int is_region = bounds * int(raw_index >= 0) * int(raw_index < MAX_REGIONS);
	// Editor dummies are negative; keep them != -1 so the shader still sees a region
	int is_dummy = bounds * int(map_val < 0);
	int layer_index = is_region * raw_index
	               + is_dummy * (map_val - 1)
	               - (1 - is_region - is_dummy);
	return ivec3(ivec2(mod(r_uv, _region_size)), layer_index);
}

// Takes in world space XZ (UV) and returns if the coordinate should be part of the NONE background.
bool is_none_bg(const vec2 uv) {
	ivec4 regions = ivec4(
		get_index_coord(uv - vec2(0.5, 0.0)).z,
		get_index_coord(uv - vec2(0.0, 0.5)).z,
		get_index_coord(uv + vec2(1.0, 0.0)).z,
		get_index_coord(uv + vec2(0.0, 1.0)).z);
	return any(equal(regions, ivec4(-1)));
}

float interpolated_height(vec2 pos) {
	const vec2 offsets = vec2(0, 1);
	vec2 index_id = floor(pos);
	ivec3 index[4];
	index[0] = get_index_coord(index_id + offsets.xy);
	index[1] = get_index_coord(index_id + offsets.yy);
	index[2] = get_index_coord(index_id + offsets.yx);
	index[3] = get_index_coord(index_id + offsets.xx);
	float h0 = texelFetch(_height_maps, index[0], 0).r;
	float h1 = texelFetch(_height_maps, index[1], 0).r;
	float h2 = texelFetch(_height_maps, index[2], 0).r;
	float h3 = texelFetch(_height_maps, index[3], 0).r;
	vec2 f = fract(pos);
	vec2 i = 1.0 - f;
	vec4 w = vec4(i.x * f.y, f.x * f.y, f.x * i.y, i.x * i.y);
	float h = h0 * w[0] + h1 * w[1] + h2 * w[2] + h3 * w[3];
	return h;
}

// Painted ids (Terrain3D asset dock): 0 grass, 1 dirt path, 2 cobbles, 3 meadow (flowers).
vec3 id_vec(int id) {
	return id == 1 ? vec3(1.0, 0.0, 0.0) : (id == 2 ? vec3(0.0, 1.0, 0.0) : (id == 3 ? vec3(0.0, 0.0, 1.0) : vec3(0.0)));
}
vec3 id_mask(uint c) { // (dirt, cobble, flowers) at one vertex
	float b = float(c >> 14u & 0xFFu) * (1.0 / 255.0);
	return id_vec(int(c >> 27u & 0x1Fu)) * (1.0 - b) + id_vec(int(c >> 22u & 0x1Fu)) * b;
}
uint ctl(vec2 vgrid) {
	return floatBitsToUint(texelFetch(_control_maps, get_index_coord(vgrid), 0).r);
}
// The old mask texture's channels at a world XZ, bilinear over the 4 surrounding vertices:
// r path (cobbles count as path, keeping the dirt fringe around them), g cobbles, a flower density.
vec4 mask_at(vec2 xz) {
	vec2 p = xz * _vertex_density;
	vec2 id = floor(p);
	vec2 f = p - id;
	vec3 m = mix(mix(id_mask(ctl(id)), id_mask(ctl(id + vec2(1.0, 0.0))), f.x),
			mix(id_mask(ctl(id + vec2(0.0, 1.0))), id_mask(ctl(id + vec2(1.0, 1.0))), f.x), f.y);
	return vec4(m.x + m.y, m.y, 0.0, m.z);
}

// Cobble: returns ramp value; g = height gradient (stone domes, mortar flat).
float cob(vec2 t, out vec2 g) {
	vec2 c = t / 7.0;
	vec2 ci = floor(c);
	vec2 cf = fract(c);
	float f1 = 8.0;
	float f2 = 8.0;
	vec2 best = vec2(0.0);
	vec2 boff = vec2(0.0);
	for (int j = -1; j <= 1; j++) {
		for (int i = -1; i <= 1; i++) {
			vec2 gg = vec2(float(i), float(j));
			vec2 r = gg + hash22(ci + gg) * 0.8 + 0.1 - cf;
			float d = dot(r, r);
			if (d < f1) { f2 = f1; f1 = d; best = ci + gg; boff = r; } else if (d < f2) { f2 = d; }
		}
	}
	float edge = (sqrt(f2) - sqrt(f1)) * 7.0;
	g = edge < 1.1 ? vec2(0.0) : normalize(boff + 1e-4) * (1.0 - clamp(edge / 3.0, 0.0, 1.0)) * 0.9;
	return edge < 1.1 ? 0.03 : 0.3 + hash12(best) * 0.35 + clamp(dot(boff, vec2(0.7)), -1.0, 1.0) * 0.22;
}

// One ground texel: colour, roughness and an analytic height gradient (per-texel normal).
vec3 ground(vec2 t, vec3 wpos, vec3 wnrm, out vec2 g, out float r) {
	vec2 tc = (t + 0.5) / texel;
	vec4 m = mask_at(tc);
	float d = hash12(t + 17.0) - 0.5;
	vec2 jit = hash22(t + 5.0) - 0.5;
	float dn = vnoise(tc * 2.7) - 0.5;
	float y = wpos.y + d * 0.06;
	r = 0.92;
	g = jit * 0.35;
	bool wet_zone = wpos.z > wet_min_z;
	if (wet_zone && y < water_level - 0.08) { // pond bed
		float v = 0.3 + vnoise(tc * 1.5) * 0.4 + d * 0.3;
		r = 0.4;
		if (hash12(t * 0.37 + 2.0) > 0.93) { g = jit * 1.4; return s1; }
		return mud * (0.6 + v * 0.8);
	}
	if (wet_zone && y < water_level + 0.22) { // wet bank
		float v = 0.35 + vnoise(tc * 2.0) * 0.4 + d * 0.3;
		r = 0.3;
		if (hash12(t * 0.53 + 9.0) > 0.86) { g = jit * 1.4; return ramp4(v + 0.15, s0, s1, s2, s3) * 0.8; }
		return ramp4(v - 0.1, d0 * 0.7, d1 * 0.7, d2 * 0.75, d3 * 0.8);
	}
	float path = m.r + d * 0.22 + dn * 0.38;
	float cb = m.g + d * 0.18 + dn * 0.2;
	float steep = 1.0 - smoothstep(0.72, 0.86, wnrm.y);
	if (cb > 0.5) {
		r = 0.7;
		return ramp4(cob(t, g) + dn * 0.15, s0, s1, s2, s3);
	}
	if (path > 0.5 || steep + d * 0.6 > 0.6) {
		float v = 0.42 + vnoise(tc * 1.7) * 0.3 + d * 0.32 - (path < 0.62 ? 0.12 : 0.0);
		g *= 0.6;
		if (hash12(t * 0.71 + 5.0) > 0.95) { v = 0.85; g = vec2(-0.3, -0.6); }
		if (hash12((t - vec2(0.0, 1.0)) * 0.71 + 5.0) > 0.95) { v = 0.08; }
		return ramp4(v, d0, d1, d2, d3);
	}
	// grass: soft patches + 1x2 blade strokes, 5-tone ramp, tiny flowers
	float n = vnoise(tc * 0.23) * 0.45 + vnoise(tc * 0.9 + 4.0) * 0.25;
	float blade = hash12(vec2(t.x, floor(t.y * 0.5)));
	float v = n + blade * 0.38 - 0.06 - (path > 0.36 ? 0.1 : 0.0);
	if (hash12(t * 1.7 + 3.0) > 0.994 - m.a * 0.05) {
		float k = hash12(t + 41.0);
		g = vec2(0.0, -0.5);
		return k < 0.35 ? vec3(0.95, 0.92, 0.85) : (k < 0.6 ? vec3(0.95, 0.75, 0.2) : (k < 0.8 ? vec3(0.9, 0.35, 0.45) : vec3(0.55, 0.45, 0.85)));
	}
	float i = clamp(floor(v * 5.0), 0.0, 4.0);
	return i < 0.5 ? g0 : (i < 1.5 ? g1 : (i < 2.5 ? g2 : (i < 3.5 ? g3 : g4)));
}

void vertex() {
	// Save Camera Position to varying for access in later functions
	v_camera_pos = MAIN_CAM_INV_VIEW_MATRIX[3].xyz;

	// Get vertex of flat plane in world coordinates and set world UV
	v_vertex = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;

	// Distance from target node to vertex on a flat plane
	v_vertex_xz_dist = length(v_vertex.xz - _target_pos.xz);

	// Geomorph vertex across clipmap LODs, set end and start for linear height interpolate
	float scale = MODEL_MATRIX[0][0];
	float inv_scale = 1.0 / scale;
	float max_xz = max(abs(v_vertex.x - _target_pos.x), abs(v_vertex.z - _target_pos.z));
	float vertex_lerp = smoothstep(0.0, 1.0, (max_xz * inv_scale - _mesh_size - 4.0) / (_mesh_size - 4.0));
	vec2 vertex_fract = fract(VERTEX.xz * 0.5) * 2.0;
	// For LOD0 morph from a regular grid to an alternating grid to align with LOD1+
	vec2 shift = (scale < _vertex_spacing / _subdiv + 1e-6) ? // LOD0 or not
		// Shift from regular to symmetric
		mix(vertex_fract, vec2(vertex_fract.x, -vertex_fract.y),
			round(fract(round(mod(v_vertex.z * inv_scale, 4.0)) *
			round(mod(v_vertex.x * inv_scale, 4.0)) * 0.25))) :
		// Symmetric shift
		vertex_fract * round((fract(v_vertex.xz * 0.25 * inv_scale) - 0.5) * 4.0);
	vec2 start_pos = v_vertex.xz * _vertex_density;
	vec2 end_pos = (v_vertex.xz - shift * scale) * _vertex_density;
	v_vertex.xz -= shift * scale * vertex_lerp;

	// UV coordinates in region space. 0-1 covers 1 region, 1-2 is the next region, etc.
	UV = v_vertex.xz * _vertex_density;

	// UV coordinates in region space + texel offset. Values are 0 to 1 within regions
	UV2 = fma(UV, vec2(_region_texel_size), vec2(0.5 * _region_texel_size));

	// Discard vertices for Holes. 1 lookup
	ivec3 v_region = get_index_coord(start_pos);
	uint control = floatBitsToUint(texelFetch(_control_maps, v_region, 0)).r;
	bool hole = bool(control >>2u & 0x1u);

	// Show holes to all cameras except mouse camera (on exactly 1 layer)
	if ( !(CAMERA_VISIBLE_LAYERS == _mouse_layer) &&
			(hole || (_background_mode == 0u && is_none_bg(UV)))) {
		v_vertex.x = 0. / 0.;
	} else {
		// Set final vertex height.
		float h;
		// This branch is static for each of the clipmap segments
		// Interpolated reads only occur where sub-texel values are required.
		if (scale < _vertex_spacing) {
			h = interpolated_height(UV);
		} else {
			ivec3 coord_a = get_index_coord(start_pos);
			ivec3 coord_b = get_index_coord(end_pos);
			h = mix(texelFetch(_height_maps, coord_a, 0).r,texelFetch(_height_maps, coord_b, 0).r,vertex_lerp);
		}
		v_vertex.y = h;
	}

	// Convert model space to view space w/ skip_vertex_transform render mode
	VERTEX = (VIEW_MATRIX * vec4(v_vertex, 1.0)).xyz;
	NORMAL = normalize((MODELVIEW_MATRIX * vec4(NORMAL, 0.0)).xyz);
	BINORMAL = normalize((MODELVIEW_MATRIX * vec4(BINORMAL, 0.0)).xyz);
	TANGENT = normalize((MODELVIEW_MATRIX * vec4(TANGENT, 0.0)).xyz);
}

////////////////////////
// Fragment
////////////////////////

void fragment() {
	if (CAMERA_POSITION_WORLD.y < water_level && v_vertex.y < water_level) {
		discard; // planar reflection pass: drop what is below the mirror
	}
	// Recover UVs
	vec2 uv = UV;
	//vec2 uv2 = UV2;

	// Lookup offsets, ID and blend weight
	const vec3 offsets = vec3(0, 1, 2);
	vec2 index_id = floor(uv);
	vec2 weight = min(fract(uv), 1.0 - 1e-7);
	vec2 invert = 1.0 - weight;
	vec4 weights = vec4(
		invert.x * weight.y, // 0
		weight.x * weight.y, // 1
		weight.x * invert.y, // 2
		invert.x * invert.y  // 3
	);

	vec3 base_ddx = dFdxCoarse(v_vertex);
	vec3 base_ddy = dFdyCoarse(v_vertex);
	//vec4 base_derivatives = vec4(base_ddx.xz, base_ddy.xz);
	// Calculate the effective mipmap for regionspace, and if less than 0,
	// skip all extra lookups required for bilinear blend.
	float region_mip = log2(max(length(base_ddx.xz), length(base_ddy.xz)) * _vertex_density);
	bool bilerp = region_mip < 4.0;

	ivec3 index[4];
	// control map lookups, used for some normal lookups as well
	index[0] = get_index_coord(index_id + offsets.xy);
	index[1] = get_index_coord(index_id + offsets.yy);
	index[2] = get_index_coord(index_id + offsets.yx);
	index[3] = get_index_coord(index_id + offsets.xx);

	// Terrain normals
	vec3 index_normal[4];
	float h[4];
	// allows additional derivatives, eg world noise, brush previews etc
	float u = 0.0;
	float v = 0.0;

	// Re-use index[] for the first lookups, skipping some math. 3 lookups
	h[3] = texelFetch(_height_maps, index[3], 0).r; // 0 (0,0)
	h[2] = texelFetch(_height_maps, index[2], 0).r; // 1 (1,0)
	h[0] = texelFetch(_height_maps, index[0], 0).r; // 2 (0,1)
	index_normal[3] = normalize(vec3(h[3] - h[2] + u, _vertex_spacing, h[3] - h[0] + v));

	// Set flat world normal - overriden if bilerp is true
	vec3 w_normal = index_normal[3];

	// Branching smooth normals must be done seperatley for correct normals at all 4 index ids
	if (bilerp) {
		// 5 lookups
		// Fetch the additional required height values for smooth normals
		h[1] = texelFetch(_height_maps, index[1], 0).r; // 3 (1,1)
		float h_4 = texelFetch(_height_maps, get_index_coord(index_id + offsets.yz), 0).r; // 4 (1,2)
		float h_5 = texelFetch(_height_maps, get_index_coord(index_id + offsets.zy), 0).r; // 5 (2,1)
		float h_6 = texelFetch(_height_maps, get_index_coord(index_id + offsets.zx), 0).r; // 6 (2,0)
		float h_7 = texelFetch(_height_maps, get_index_coord(index_id + offsets.xz), 0).r; // 7 (0,2)

		// Calculate the normal for the remaining index ids.
		index_normal[0] = normalize(vec3(h[0] - h[1] + u, _vertex_spacing, h[0] - h_7 + v));
		index_normal[1] = normalize(vec3(h[1] - h_5 + u, _vertex_spacing, h[1] - h_4 + v));
		index_normal[2] = normalize(vec3(h[2] - h_6 + u, _vertex_spacing, h[2] - h[1] + v));

		// Set interpolated world normal
		w_normal =
			index_normal[0] * weights[0] +
			index_normal[1] * weights[1] +
			index_normal[2] * weights[2] +
			index_normal[3] * weights[3] ;
	}

	// HD-2D ground, per world texel
	vec2 t = floor(v_vertex.xz * texel);
	vec2 g;
	float r;
	vec3 col = ground(t, v_vertex, w_normal, g, r);
	col *= 0.9 + vnoise(v_vertex.xz * 0.07) * 0.2;
	// sunlit caustics on the pond bed
	if (v_vertex.y < water_level - 0.05) {
		vec2 q = floor(v_vertex.xz * 16.0) / 16.0;
		float c = abs(sin(q.x * 3.1 + TIME * 0.9 + sin(q.y * 2.3 + TIME * 0.7) * 1.5) + sin(q.y * 3.7 - TIME * 0.8 + sin(q.x * 1.9) * 1.2));
		col *= 1.0 + smoothstep(1.55, 1.95, c) * 0.6 * (1.0 - night);
	}
	float wet = wetness * smoothstep(0.3, 0.9, w_normal.y);
	ALBEDO = col * (1.0 - wet * 0.3);
	ROUGHNESS = mix(r, 0.12, wet);
	SPECULAR = 0.4;
	vec3 nw = normalize(w_normal - vec3(g.x, 0.0, g.y) * 0.45);
	NORMAL = normalize((VIEW_MATRIX * vec4(nw, 0.0)).xyz);
	// Terrain3D injects its editor brush decal here (EDITOR_DECAL_RENDER); it reads `uv`.
}
