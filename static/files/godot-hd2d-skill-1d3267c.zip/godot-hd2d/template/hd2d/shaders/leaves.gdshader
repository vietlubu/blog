// Falling leaves: spawn in a box over the canopies, ride the shared wind field, tumble in 3D.
shader_type particles;
#include "res://hd2d/shaders/common.gdshaderinc"

uniform vec3 box_center = vec3(0.0, 8.0, -10.0);
uniform vec3 box_extent = vec3(14.0, 3.0, 6.0);
uniform float leaf_scale = 1.0;

float rnd(uint s) {
	s = (s ^ 61u) ^ (s >> 16u);
	s *= 9u;
	s = s ^ (s >> 4u);
	s *= 0x27d4eb2du;
	s = s ^ (s >> 15u);
	return float(s % 65536u) / 65535.0;
}

void start() {
	uint s = NUMBER * 1973u + RANDOM_SEED * 9277u;
	vec3 r = vec3(rnd(s), rnd(s + 1u), rnd(s + 2u));
	TRANSFORM = mat4(1.0);
	TRANSFORM[3].xyz = (EMISSION_TRANSFORM * vec4(box_center + (r * 2.0 - 1.0) * box_extent, 1.0)).xyz; // box is in emitter space
	VELOCITY = vec3(0.0, -0.5, 0.0);
	CUSTOM = vec4(rnd(s + 3u) * 6.28, rnd(s + 4u), rnd(s + 5u), 0.0);
	COLOR = vec4(1.0);
}

void process() {
	CUSTOM.w += DELTA;
	vec3 p = TRANSFORM[3].xyz;
	vec2 w = wind_offset(p.xz, TIME, CUSTOM.x) * 2.4;
	vec2 wob = vec2(sin(TIME * 1.7 + CUSTOM.x), cos(TIME * 1.3 + CUSTOM.x * 1.7)) * 0.4;
	VELOCITY.xz = mix(VELOCITY.xz, w + wob, clamp(DELTA * 1.5, 0.0, 1.0));
	VELOCITY.y = -0.5 - 0.3 * sin(TIME * 2.3 + CUSTOM.x) - rain * 1.5;
	float a = TIME * (1.0 + CUSTOM.y * 2.5) + CUSTOM.x;
	float b = TIME * (0.7 + CUSTOM.y) * 1.3 + CUSTOM.x * 2.0;
	mat3 rx = mat3(vec3(1.0, 0.0, 0.0), vec3(0.0, cos(a), sin(a)), vec3(0.0, -sin(a), cos(a)));
	mat3 ry = mat3(vec3(cos(b), 0.0, -sin(b)), vec3(0.0, 1.0, 0.0), vec3(sin(b), 0.0, cos(b)));
	float life = CUSTOM.w / LIFETIME;
	mat3 m = ry * rx * leaf_scale * smoothstep(0.0, 0.04, life) * smoothstep(1.0, 0.9, life);
	TRANSFORM[0].xyz = m[0];
	TRANSFORM[1].xyz = m[1];
	TRANSFORM[2].xyz = m[2];
}
