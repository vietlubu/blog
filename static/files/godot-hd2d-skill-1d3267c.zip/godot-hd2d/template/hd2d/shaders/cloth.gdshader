// Laundry, banner, bunting: hangs from its top edge (UV.y = 0) and billows with the wind field.
shader_type spatial;
render_mode cull_disabled, world_vertex_coords;
#include "res://hd2d/shaders/common.gdshaderinc"

uniform sampler2D tex : source_color, filter_nearest;
uniform float stiffness = 1.0;

void vertex() {
	float hang = UV.y;
	float g = wind_gust(VERTEX.xz, TIME);
	float s = wind_strength * (0.4 + g * 1.2);
	float ripple = sin(VERTEX.x * 6.0 + VERTEX.z * 3.0 - TIME * 6.0) * 0.06 + sin(VERTEX.x * 2.3 - TIME * 3.1) * 0.08;
	vec3 push = vec3(wind_dir.x, 0.0, wind_dir.y);
	VERTEX += (push * s * 0.35 + vec3(0.0, 0.0, ripple * s)) * hang * stiffness;
	VERTEX.y += hang * s * 0.08 * stiffness;
}

void fragment() {
	vec4 c = texture(tex, UV);
	ALBEDO = c.rgb * COLOR.rgb;
	ALPHA = c.a;
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	BACKLIGHT = c.rgb * 0.5;
	ROUGHNESS = 0.85;
}
