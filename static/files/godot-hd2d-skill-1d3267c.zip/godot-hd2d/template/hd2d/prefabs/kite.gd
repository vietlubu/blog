@tool
extends "res://hd2d/core/gen.gd"
## Diamond kite with a tail of bows, riding the gusts at the node, tied by a sagging string to
## `anchor_offset` (local). The kite never rolls: its pixel grid stays upright.

@export var anchor_offset := Vector3(-4.4, -3.3, 4.6):
	set(v):
		anchor_offset = v
		_queue()

var _kite: MeshInstance3D
var _tail: Array[MeshInstance3D] = []
var _line: MeshInstance3D
var _time := 0.0


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func _build(root: Node3D) -> void:
	_tail.clear()
	_kite = Kit.sprite(Pix.kite_image().get_image(), 1, false)
	root.add_child(_kite)
	var tail_img := Image.create(6, 5, false, Image.FORMAT_RGBA8)
	for o in [Vector2i(0, 0), Vector2i(0, 4), Vector2i(1, 1), Vector2i(1, 3), Vector2i(0, 1), Vector2i(0, 3), Vector2i(0, 2), Vector2i(1, 2),
			Vector2i(5, 0), Vector2i(5, 4), Vector2i(4, 1), Vector2i(4, 3), Vector2i(5, 1), Vector2i(5, 3), Vector2i(5, 2), Vector2i(4, 2)]:
		tail_img.set_pixel(o.x, o.y, Color.html("#f4d35e"))
	tail_img.set_pixel(2, 2, Color.html("#e24a3a"))
	tail_img.set_pixel(3, 2, Color.html("#e24a3a"))
	for i in 7:
		var k := Kit.sprite(tail_img, 1, false)
		root.add_child(k)
		_tail.append(k)
	_line = MeshInstance3D.new()
	_line.name = "String"
	_line.mesh = ImmediateMesh.new()
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(0.95, 0.9, 0.8, 0.6)
	lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_line.material_override = lm
	_line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(_line)
	_pose()


func _process(delta: float) -> void:
	_time += delta
	_pose()


func _pose() -> void:
	if _kite == null:
		return
	var t := _time
	var wind := 1.0 + Kit.rain * 0.7
	var ap := global_position + anchor_offset
	var g := Wind.gust(Vector2(ap.x, ap.z), t)
	var p := Vector3(sin(t * 0.37) * 0.6 + g * 0.8 * wind, sin(t * 0.53) * 0.3 + g * 0.3, 0.0)
	_kite.position = p
	var cam := get_viewport().get_camera_3d() if is_inside_tree() and not Engine.is_editor_hint() else null
	_face(_kite, cam)
	var prev := p
	for i in _tail.size():
		var k := _tail[i]
		var target := prev + Vector3(-0.2 - g * 0.15, -0.38, 0)
		target.x += sin(t * 3.0 - i * 0.7) * 0.12
		k.position = target
		_face(k, cam)
		prev = target
	var im: ImmediateMesh = _line.mesh
	im.clear_surfaces()
	im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
	for i in 13:
		var f := i / 12.0
		var q := anchor_offset.lerp(p, f)
		q.y -= sin(f * PI) * 1.4
		im.surface_add_vertex(q)
	im.surface_end()


func _face(n: Node3D, cam: Camera3D) -> void:
	if cam:
		var d := cam.global_position - n.global_position
		n.rotation.y = atan2(d.x, d.z)
