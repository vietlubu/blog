@tool
extends "res://hd2d/core/gen.gd"
## Small village props. Origin = base centre on the ground. `count`, `length` and `seed` mean:
## crate: stack height; fence: posts (1.6 apart along +X); laundry_line: cloths, pole distance along +X;
## rock and crate: seed picks size / tilt / yaw.

const Cloth := preload("res://hd2d/prefabs/cloth.gd")

@export_enum("lantern_post", "bench", "barrel", "crate", "rock", "fence", "laundry_line") var kind: String = "lantern_post":
	set(v):
		kind = v
		_queue()
@export var count := 1:
	set(v):
		count = v
		_queue()
@export var length := 2.7:
	set(v):
		length = v
		_queue()
@warning_ignore("shadowed_global_identifier")
@export var seed := 0:
	set(v):
		seed = v
		_queue()

var _light: OmniLight3D


func _init() -> void:
	add_to_group("hd2d_preset")
	add_to_group("hd2d_footprint")


func footprint_world() -> Rect2:
	match kind:
		"lantern_post":
			return _xz_bounds(Rect2(-0.4, -0.4, 0.8, 0.8))
		"bench":
			return _xz_bounds(Rect2(-1.1, -0.4, 2.2, 0.8))
		"barrel", "crate":
			return _xz_bounds(Rect2(-0.45, -0.45, 0.9, 0.9))
	return Rect2()


func apply_preset(n: float, _r: float) -> void:
	if _light:
		Kit.lantern_light(_light, n)


func _build(root: Node3D) -> void:
	_light = null
	var b := Builder.new()
	b.mats = Kit.materials()
	var lo := Color(0.7, 0.66, 0.68)
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	match kind:
		"lantern_post":
			b.boxp("stone_big", Vector3(0, 0.1, 0), Vector3(0.5, 0.3, 0.5), lo)
			b.boxp("timber", Vector3(0, 1.3, 0), Vector3(0.18, 2.4, 0.18), lo)
			b.boxp("timber", Vector3(0.22, 2.42, 0), Vector3(0.6, 0.1, 0.1))
			var hp := Vector3(0.42, 2.08, 0)
			b.boxp("iron", hp + Vector3(0, 0.24, 0), Vector3(0.36, 0.08, 0.36))
			b.boxp("iron", hp + Vector3(0, 0.34, 0), Vector3(0.16, 0.12, 0.16))
			b.boxp("lamp", hp, Vector3(0.24, 0.36, 0.24))
			b.boxp("iron", hp + Vector3(0, -0.21, 0), Vector3(0.3, 0.06, 0.3))
			_light = Kit.omni(hp + Vector3(0, 0, 0.1), Color(1.0, 0.64, 0.32), 6.0)
			root.add_child(_light)
		"bench":
			b.boxp("planks", Vector3(0, 0.48, 0), Vector3(1.9, 0.08, 0.5))
			b.boxp("planks", Vector3(0, 0.85, -0.24), Vector3(1.9, 0.32, 0.07))
			for sx in [-0.8, 0.8]:
				b.boxp("timber", Vector3(sx, 0.24, 0), Vector3(0.1, 0.48, 0.44))
				b.boxp("timber", Vector3(sx, 0.6, -0.24), Vector3(0.08, 0.6, 0.08))
		"barrel":
			b.prism("planks", Transform3D(), 10, 0.36, 0.36, 0.95, lo)
			for hy in [0.18, 0.77]:
				b.prism("iron", Transform3D(Basis(), Vector3(0, hy, 0)), 10, 0.375, 0.375, 0.06, Color.WHITE, Color.WHITE, false)
		"crate":
			for i in count:
				var off := Vector3(0.1, 0.7, -0.1) * float(i)
				var xf := Transform3D(Basis(Vector3.UP, seed * 0.7 + i * 0.4), off + Vector3(0, 0.34, 0))
				b.box("planks", xf, Vector3(0.7, 0.68, 0.7), lo)
				b.box("timber", xf, Vector3(0.74, 0.12, 0.74))
		"rock":
			var s := rng.randf_range(0.5, 0.9)
			var xf := Transform3D(Basis.from_euler(Vector3(rng.randf_range(-0.2, 0.2), rng.randf() * TAU, rng.randf_range(-0.2, 0.2))), Vector3(0, s * 0.2, 0))
			b.box("stone_big", xf, Vector3(s * 1.3, s * 0.7, s), lo, Color.WHITE, true)
		"fence":
			for i in count:
				var p := Vector3(i * 1.6, 0, sin(i * 0.9) * 0.25 - i * 0.12)
				p.y = _ground_rel(p)
				b.boxp("timber", p + Vector3(0, 0.6, 0), Vector3(0.18, 1.2 + (0.25 if i == 0 else 0.0), 0.18), lo)
				if i < count - 1:
					b.box("timber", Transform3D(Basis(Vector3.UP, 0.08), p + Vector3(0.8, 0.85, -0.06)), Vector3(1.7, 0.1, 0.07))
					b.box("timber", Transform3D(Basis(Vector3.UP, 0.08), p + Vector3(0.8, 0.42, -0.06)), Vector3(1.7, 0.1, 0.07))
		"laundry_line":
			var l1 := Vector3(length, 0, 0)
			for lp in [Vector3.ZERO, l1]:
				b.boxp("timber", lp + Vector3(0, 1.2, 0), Vector3(0.12, 2.4, 0.12))
			b.boxp("timber", l1 * 0.5 + Vector3(0, 2.32, 0), Vector3(length, 0.03, 0.03))
			for i in count:
				var t := 0.2 + i * 0.3
				root.add_child(Cloth.make(l1 * t + Vector3(0, 2.33, 0.02), Vector2(0.55, 0.7), i % 3, 1.0))
	root.add_child(b.commit("Mesh"))
