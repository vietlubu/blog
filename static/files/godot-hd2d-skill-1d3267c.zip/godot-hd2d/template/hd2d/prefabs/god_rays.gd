@tool
extends "res://hd2d/core/gen.gd"
## Crisp god rays: `slices` camera-facing additive quads stacked along the view through a box around the node.
## Every fragment samples the real sun shadow map (shafts.gdshader), so canopy holes and house gaps become
## dappled blades. Dust motes in the same box glitter only where lit. Centre it in a tree's shadow volume.

const SHAFTS := preload("res://hd2d/shaders/shafts.gdshader")
const TEXEL := 32.0

## Half extents of the lit volume (x right, y up, z depth).
@export var half := Vector3(5.5, 4.5, 5.0):
	set(v):
		half = v
		_queue()
## Pure overdraw: blend_add + a shadow lookup per fragment; 20 slices cost ~9 ms at 1440p.
@export var slices := 10:
	set(v):
		slices = v
		_queue()
@export var density := 0.005:
	set(v):
		density = v
		_queue()
@export var tint := Color(1.0, 0.93, 0.8): # paler than 1.0/0.85/0.62, which read as fire
	set(v):
		tint = v
		_queue()
@export var dust := 280:
	set(v):
		dust = v
		_queue()

var _mat: ShaderMaterial
var _dust: GPUParticles3D


func _init() -> void:
	add_to_group("hd2d_preset")


func apply_preset(n: float, r: float) -> void:
	if _mat:
		_mat.set_shader_parameter("strength", (1.0 - n) * (1.0 - 0.75 * r))
	if _dust:
		_dust.amount_ratio = lerp(1.0, 0.25, n) * (1.0 - r * 0.8)


func _build(root: Node3D) -> void:
	_dust = null
	var fwd := Kit.cam_fwd()
	var right := Vector3.UP.cross(-fwd).normalized()
	var upv := (-fwd).cross(right).normalized()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in slices:
		var c := fwd * lerpf(-half.z * 1.8, half.z * 1.8, (i + 0.5) / slices)
		var rx := right * half.x * 2.0
		var uy := upv * half.y * 1.56
		var a := c - rx - uy
		var b := c + rx - uy
		var cc := c + rx + uy
		var d := c - rx + uy
		for v in [a, b, cc, a, cc, d]:
			st.set_normal(-fwd)
			st.add_vertex(v)
	var center := global_position
	_mat = ShaderMaterial.new()
	_mat.shader = SHAFTS
	_mat.set_shader_parameter("box_center", center)
	_mat.set_shader_parameter("box_half", half)
	_mat.set_shader_parameter("y_lo", center.y - half.y - 0.5)
	_mat.set_shader_parameter("y_hi", center.y + half.y - 0.5)
	_mat.set_shader_parameter("density", density)
	_mat.set_shader_parameter("tint", tint)
	var mi := MeshInstance3D.new()
	mi.name = "Shafts"
	mi.mesh = st.commit()
	mi.material_override = _mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.layers = 2 # not in the mirror
	root.add_child(mi)
	if dust <= 0:
		return
	# dust motes / pollen: lit only, so they glitter in the shafts and vanish in shade
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(half.x * 2.0, half.y * 0.9, half.z * 1.3)
	pm.gravity = Vector3(0.05, 0.02, 0)
	pm.initial_velocity_min = 0.02
	pm.initial_velocity_max = 0.1
	pm.direction = Vector3(1, 0.2, 0)
	pm.spread = 180.0
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.4
	pm.turbulence_noise_speed_random = 0.2
	pm.turbulence_noise_scale = 3.0
	pm.scale_min = 0.6
	pm.scale_max = 1.4
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0))
	g.set_color(1, Color(1, 1, 1, 0))
	g.add_point(0.2, Color(1, 1, 1, 1))
	g.add_point(0.8, Color(1, 1, 1, 1))
	var gt := GradientTexture1D.new()
	gt.gradient = g
	pm.color_ramp = gt
	var q := QuadMesh.new()
	q.size = Vector2(2.0, 2.0) / TEXEL
	var mt := StandardMaterial3D.new()
	mt.albedo_color = Color(1.0, 0.9, 0.7)
	mt.vertex_color_use_as_albedo = true
	mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	mt.backlight_enabled = true
	mt.backlight = Color(1.0, 0.85, 0.6)
	q.material = mt
	_dust = GPUParticles3D.new()
	_dust.amount = dust
	_dust.lifetime = 12.0
	_dust.preprocess = 12.0
	_dust.process_material = pm
	_dust.draw_pass_1 = q
	_dust.position = Vector3(-1.0, -1.0, 0.5)
	_dust.visibility_aabb = AABB(Vector3(-20, -6, -12), Vector3(40, 14, 24))
	_dust.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(_dust)
