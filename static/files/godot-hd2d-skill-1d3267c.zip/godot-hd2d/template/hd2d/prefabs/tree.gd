@tool
extends "res://hd2d/core/gen.gd"
## Leaf-card tree, bush (trunk_height 0) or a row of trees (count > 1). One main lobe on top of the trunk,
## side lobes around it, branches from the trunk top into the side lobes. Never rotate: cards face the camera.

@export var trunk_height := 4.6:
	set(v):
		trunk_height = v
		_queue()
@export var trunk_radius := 0.95:
	set(v):
		trunk_radius = v
		_queue()
## Radii of the main lobe.
@export var canopy := Vector3(5.6, 3.4, 4.2):
	set(v):
		canopy = v
		_queue()
@export_range(1, 8) var lobes := 4:
	set(v):
		lobes = v
		_queue()
@export var cards := 300:
	set(v):
		cards = v
		_queue()
@export_enum("near", "far", "bush") var leaf: String = "near":
	set(v):
		leaf = v
		_queue()
@export var sway := 0.8:
	set(v):
		sway = v
		_queue()
@export var shadows := true:
	set(v):
		shadows = v
		_queue()
@export var falling_leaves := 0:
	set(v):
		falling_leaves = v
		_queue()
## Row mode: trees step spread.x along +X and scatter up to spread.y toward -Z.
@export var count := 1:
	set(v):
		count = v
		_queue()
@export var spread := Vector2(4.9, 9.0):
	set(v):
		spread = v
		_queue()
@export_range(0.0, 0.9) var size_jitter := 0.0:
	set(v):
		size_jitter = v
		_queue()
@warning_ignore("shadowed_global_identifier")
@export var seed := 1:
	set(v):
		seed = v
		_queue()


func _init() -> void:
	add_to_group("hd2d_footprint")


func footprint_world() -> Rect2:
	if trunk_height <= 0.0 or count != 1:
		return Rect2()
	var s := trunk_radius * 2.0 + 0.4
	return _xz_bounds(Rect2(-s * 0.5, -s * 0.5, s, s))


func _build(root: Node3D) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var tb := Builder.new()
	tb.mats = Kit.materials()
	var fb := Builder.new()
	fb.mats = {leaf: Flora.foliage_mat(leaf)}
	var first_main := Vector3.ZERO
	for i in count:
		var base := Vector3.ZERO
		if count > 1:
			base.x = i * spread.x + rng.randf_range(-1.5, 1.5)
			base.z = -rng.randf_range(0.0, spread.y)
		base.y = _ground_rel(base)
		var k := rng.randf_range(1.0 - size_jitter, 1.0 + size_jitter)
		var rad := canopy * k
		var main := base + Vector3(0, trunk_height * 0.87 * k + rad.y * (1.3 if trunk_height > 0.0 else 0.7), 0)
		if i == 0:
			first_main = main
		var lb := [[main, rad]]
		var branches := []
		for j in range(1, lobes):
			var a := (j - 1) * TAU / (lobes - 1) + rng.randf_range(-0.4, 0.4)
			var c := main + Vector3(cos(a) * rad.x * 0.75, rng.randf_range(-0.6, 0.2) * rad.y, sin(a) * rad.z * 0.35)
			var r := rad * rng.randf_range(0.55, 0.7)
			lb.append([c, r])
			branches.append(c - Vector3(0, r.y * 0.3, 0))
		if trunk_height > 0.0:
			Flora.trunk(tb, base, trunk_height * k, trunk_radius * k, rng, branches)
		Flora.canopy(fb, leaf, lb, cards, rng, sway)
	if trunk_height > 0.0:
		root.add_child(tb.commit("Trunk"))
	root.add_child(fb.commit("Canopy", shadows))
	if falling_leaves > 0:
		root.add_child(Flora.leaves(first_main + Vector3(0, 1.6, 0), canopy * Vector3(1.25, 0.9, 0.95), falling_leaves))
