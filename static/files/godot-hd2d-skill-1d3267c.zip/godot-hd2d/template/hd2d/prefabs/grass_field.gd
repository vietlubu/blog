@tool
extends "res://hd2d/core/gen.gd"
## Grass / flower / reed tufts scattered over a rect centred on the node (XZ), on the terrain. Skips painted
## path and cobbles, hd2d_footprint rects, and the water; banks inside the pond rect go to a second MultiMesh on
## layer 1 so the mirror reflects them. Tufts stay at 1 texel = 1/32 unit, scale_px 2 only in blurred tiers.

@export var size := Vector2(20.0, 10.0):
	set(v):
		size = v
		_queue()
## Tufts per square unit.
@export var density := 3.2:
	set(v):
		density = v
		_queue()
## Integer texel scale: 1 in focus, 2 only where the tier is always blurred.
@export_range(1.0, 2.0, 1.0) var scale_px := 1.0:
	set(v):
		scale_px = v
		_queue()
@export var brightness := 1.0:
	set(v):
		brightness = v
		_queue()
## 0 neutral, 1 cool (blue-shifted) for the dark near foreground.
@export var coolness := 0.0:
	set(v):
		coolness = v
		_queue()
## Base flower chance on top of the painted meadow channel.
@export var flowers := 0.04:
	set(v):
		flowers = v
		_queue()
@warning_ignore("shadowed_global_identifier")
@export var seed := 33:
	set(v):
		seed = v
		_queue()


func _build(root: Node3D) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var gp := global_position
	var wy := Ground.water_y(self)
	var wet_rect := Rect2()
	var water := get_tree().get_first_node_in_group("hd2d_water") as Node3D
	if water:
		var ws: Vector2 = water.get("size")
		wet_rect = Rect2(water.global_position.x - ws.x * 0.5, water.global_position.z - ws.y * 0.5, ws.x, ws.y)
	var fps: Array[Rect2] = []
	for n in get_tree().get_nodes_in_group("hd2d_footprint"):
		var r: Rect2 = n.footprint_world()
		if r.has_area():
			fps.append(r)
	var sets := [{"xf": [], "cu": [], "co": []}, {"xf": [], "cu": [], "co": []}] # 0 = main, 1 = water bank
	var count := int(size.x * size.y * density)
	for i in count:
		var x := gp.x - size.x * 0.5 + rng.randf() * size.x
		var z := gp.z - size.y * 0.5 + rng.randf() * size.y
		var y := Ground.height(_t, x, z)
		var mk := Ground.mask(_t, x, z)
		if mk.r > 0.42 or mk.g > 0.4:
			continue
		var blocked := false
		for fp in fps:
			if fp.has_point(Vector2(x, z)):
				blocked = true
				break
		if blocked:
			continue
		var wet := wet_rect.has_point(Vector2(x, z))
		var s := scale_px
		var cell := 0
		if wet and y < wy + 0.02:
			if y > wy - 0.35 and rng.randf() < 0.16:
				cell = 7
				s = 1.0
			else:
				continue
		else:
			cell = rng.randi_range(0, 2)
			if rng.randf() < 0.12:
				cell = 3
			if rng.randf() < mk.a * 0.6 + flowers:
				cell = 4 + rng.randi_range(0, 2)
			if wet and y < wy + 0.25 and s < 1.5 and rng.randf() < 0.3:
				cell = 7
		var flip := -1.0 if rng.randf() < 0.5 else 1.0
		var bas := Basis(Vector3.UP, rng.randf_range(-0.3, 0.3)).scaled(Vector3(s * flip, s, s))
		var st: Dictionary = sets[1 if wet and y < wy + 0.7 else 0]
		st.xf.append(Transform3D(bas, Vector3(x, y - 0.04, z) - gp))
		st.cu.append(Color(cell, rng.randf(), 0, 0))
		# brightness / coolness per tier: a near foreground as bright as the lit houses loses the value hierarchy
		var t := rng.randf_range(0.88, 1.1) * brightness
		st.co.append(Color(t * (1.0 - 0.06 * coolness), t * rng.randf_range(0.97, 1.03), t * (0.95 + 0.10 * coolness)))
	root.add_child(Flora.multimesh(sets[0].xf, sets[0].co, sets[0].cu, "Grass", 4))
	if not sets[1].xf.is_empty():
		root.add_child(Flora.multimesh(sets[1].xf, sets[1].co, sets[1].cu, "BankGrass", 1))
