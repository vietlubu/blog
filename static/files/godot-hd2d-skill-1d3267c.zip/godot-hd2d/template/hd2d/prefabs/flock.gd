@tool
extends "res://hd2d/core/gen.gd"
## V-formation of pixel birds crossing the sky: a pass every `period` seconds, flying `travel` (local) in
## `cross_time`. Shown frozen at the start of the pass in the editor.

@export var birds := 7:
	set(v):
		birds = v
		_queue()
@export var travel := Vector3(54.0, 0.0, 0.0):
	set(v):
		travel = v
		_queue()
@export var cross_time := 12.0
@export var period := 15.0
@export var first_delay := 1.5

var _birds: Array[MeshInstance3D] = []
var _time := 0.0


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func _build(root: Node3D) -> void:
	_birds.clear()
	var img := Pix.bird_frames()
	for i in birds:
		var b := Kit.sprite(img, 2, false)
		root.add_child(b)
		_birds.append(b)
	_pose(0.0, true)


func _pose(lt: float, cross: bool) -> void:
	var lead := travel * (lt / cross_time) + Vector3(0, sin(lt * 0.5) * 0.4, 0)
	var cam := get_viewport().get_camera_3d() if is_inside_tree() else null
	for i in _birds.size():
		var b := _birds[i]
		b.visible = cross
		if not cross:
			continue
		var row := (i + 1) / 2
		var side := -1.0 if i % 2 == 1 else 1.0
		b.position = lead + Vector3(-row * 1.3, side * row * 0.45 + sin(_time * 1.7 + i) * 0.15, side * row * 0.9)
		var flap := fmod(_time * 7.0 + i * 0.37, 2.0)
		var glide := sin(_time * 0.9 + i) > 0.6
		b.set_instance_shader_parameter("frame", 0.0 if glide else floor(flap))
		if cam:
			var d := cam.global_position - b.global_position
			b.rotation.y = atan2(d.x, d.z)


func _process(delta: float) -> void:
	_time += delta
	var lt := fmod(_time - first_delay, period)
	_pose(lt, _time > first_delay and lt < cross_time)
