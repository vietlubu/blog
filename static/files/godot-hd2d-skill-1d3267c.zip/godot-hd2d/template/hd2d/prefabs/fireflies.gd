@tool
extends "res://hd2d/core/gen.gd"
## Night fireflies: unshaded additive dots that blink via the colour ramp; they fade in with the night preset.

@export var extents := Vector3(17.0, 1.4, 9.0):
	set(v):
		extents = v
		_queue()
@export var amount := 140:
	set(v):
		amount = v
		_queue()

var _fx: GPUParticles3D


func _init() -> void:
	add_to_group("hd2d_preset")


func apply_preset(n: float, r: float) -> void:
	if _fx:
		_fx.amount_ratio = clampf((n - 0.3) / 0.7, 0.0, 1.0) * 0.7 * (1.0 - r * 0.8)


func _build(root: Node3D) -> void:
	var fm := ParticleProcessMaterial.new()
	fm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	fm.emission_box_extents = extents
	fm.gravity = Vector3.ZERO
	fm.initial_velocity_min = 0.05
	fm.initial_velocity_max = 0.25
	fm.spread = 180.0
	fm.turbulence_enabled = true
	fm.turbulence_noise_strength = 1.2
	fm.turbulence_noise_scale = 4.0
	var fg := Gradient.new()
	fg.set_color(0, Color(0, 0, 0, 0))
	fg.set_color(1, Color(0, 0, 0, 0))
	fg.add_point(0.3, Color(1, 1, 1, 1))
	fg.add_point(0.45, Color(0.2, 0.2, 0.2, 0.2))
	fg.add_point(0.6, Color(1, 1, 1, 1))
	var fgt := GradientTexture1D.new()
	fgt.gradient = fg
	fm.color_ramp = fgt
	var fq := QuadMesh.new()
	fq.size = Vector2(0.07, 0.07)
	var fmt := StandardMaterial3D.new()
	fmt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmt.albedo_texture = Pix.dot_image()
	fmt.albedo_color = Color(0.85, 1.0, 0.45) * 4.0
	fmt.vertex_color_use_as_albedo = true
	fmt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fmt.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fmt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	fq.material = fmt
	_fx = GPUParticles3D.new()
	_fx.amount = amount
	_fx.lifetime = 6.0
	_fx.preprocess = 6.0
	_fx.process_material = fm
	_fx.draw_pass_1 = fq
	_fx.visibility_aabb = AABB(Vector3(-20, -4, -12), Vector3(40, 10, 24))
	_fx.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(_fx)
