@tool
extends "res://hd2d/core/gen.gd"
## Parametric timber-frame house: stone plinth, plaster walls, timber frame, roof (thatch/clay/slate),
## chimney with smoke, shuttered windows with flower boxes, door with a wall lamp. Origin = plinth centre.

@export var width := 6.0:
	set(v):
		width = v
		_queue()
@export var depth := 4.6:
	set(v):
		depth = v
		_queue()
@export var wall_height := 2.5:
	set(v):
		wall_height = v
		_queue()
@export_enum("thatch", "clay", "slate") var roof: String = "thatch":
	set(v):
		roof = v
		_queue()
@export var pitch_deg := 48.0:
	set(v):
		pitch_deg = v
		_queue()
@export_enum("shutter_g", "shutter_b", "shutter_r") var shutter: String = "shutter_g":
	set(v):
		shutter = v
		_queue()
@export_enum("plaster", "plaster_b") var wall: String = "plaster":
	set(v):
		wall = v
		_queue()
## Front-wall windows: x offset from the centre, y above the wall base.
@export var windows := PackedVector2Array([Vector2(-1.75, 1.15), Vector2(1.7, 1.15)]):
	set(v):
		windows = v
		_queue()
@export var door_x := 0.0:
	set(v):
		door_x = v
		_queue()
@export var chimney_x := 1.6:
	set(v):
		chimney_x = v
		_queue()

var window_lights: Array[OmniLight3D] = []
var lantern_lights: Array[OmniLight3D] = []
var smoke: GPUParticles3D
var _flower_spots: Array[Vector3] = []
var _time := 0.0


func _init() -> void:
	add_to_group("hd2d_preset")
	add_to_group("hd2d_footprint")


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func footprint_world() -> Rect2:
	return _xz_bounds(Rect2(-width * 0.5 - 0.5, -depth * 0.5 - 0.5, width + 1.0, depth + 1.6))


func apply_preset(n: float, _r: float) -> void:
	for l in window_lights:
		Kit.window_light(l, n)
	for l in lantern_lights:
		Kit.lantern_light(l, n)
	if smoke:
		Kit.smoke_preset(smoke, n)


## Chimney smoke follows the shared wind field.
func _process(delta: float) -> void:
	_time += delta
	if smoke == null:
		return
	var sp := smoke.global_position
	var g := Wind.gust(Vector2(sp.x, sp.z), _time)
	var pm: ParticleProcessMaterial = smoke.process_material
	pm.gravity = Vector3(Wind.DIR.x, 0, Wind.DIR.y) * (0.6 + g * 1.3) * (1.0 + Kit.rain * 0.7) + Vector3(0, 0.04, 0)


func _build(root: Node3D) -> void:
	window_lights.clear()
	lantern_lights.clear()
	_flower_spots.clear()
	smoke = null
	var b := Builder.new()
	b.mats = Kit.materials()
	var w := width
	var d := depth
	var wh := wall_height
	var lo := Color(0.62, 0.58, 0.62)
	b.boxp("stone", Vector3(0, 0.2, 0), Vector3(w + 0.3, 1.0, d + 0.3), lo)
	var wb := 0.7
	var top := wb + wh
	b.boxp(wall, Vector3(0, wb + wh * 0.5, 0), Vector3(w, wh, d), Color(0.8, 0.76, 0.78))
	# timber frame
	var fz := d * 0.5 + 0.03
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			b.boxp("timber", Vector3(sx * w * 0.5, wb + wh * 0.5, sz * d * 0.5), Vector3(0.26, wh, 0.26))
	for yy in [wb + 0.08, wb + wh * 0.5, top - 0.1]:
		b.boxp("timber", Vector3(0, yy, fz), Vector3(w + 0.08, 0.17, 0.12))
		for sx in [-1.0, 1.0]:
			b.boxp("timber", Vector3(sx * (w * 0.5 + 0.03), yy, 0), Vector3(0.12, 0.17, d + 0.08))
	var studs := int(w / 1.4)
	for i in range(1, studs):
		var x := -w * 0.5 + i * w / studs
		var clear := true
		for wnd in windows:
			if abs(x - wnd.x) < 0.75:
				clear = false
		if abs(x - door_x) < 0.8:
			clear = false
		if clear:
			b.boxp("timber", Vector3(x, wb + wh * 0.5, fz), Vector3(0.14, wh, 0.1))
			# diagonal brace in the lower panel
			var br := Transform3D(Basis(Vector3.BACK, deg_to_rad(38.0 if i % 2 == 0 else -38.0)), Vector3(x + 0.35 * (1 if i % 2 == 0 else -1), wb + wh * 0.27, fz))
			b.box("timber", br, Vector3(0.12, wh * 0.55, 0.09))
	# gables + roof
	var p := deg_to_rad(pitch_deg)
	var ov := 0.55 if roof == "thatch" else 0.45
	var th := 0.42 if roof == "thatch" else 0.16
	var rise := (d * 0.5) * tan(p)
	for sx in [-1.0, 1.0]:
		var gx: float = sx * w * 0.5
		var a := Vector3(gx, top, -d * 0.5)
		var bb := Vector3(gx, top, d * 0.5)
		var r := Vector3(gx, top + rise, 0)
		var nn := Vector3(sx, 0, 0)
		b.tri(wall, [a, bb, r], [nn, nn, nn], Builder.NO_UV, [Color.WHITE, Color.WHITE, Color.WHITE])
		b.boxp("timber", Vector3(gx + sx * 0.03, top + rise * 0.5, 0), Vector3(0.12, rise, 0.14))
	var half := d * 0.5 + ov
	var slope := half / cos(p)
	var ridge_y := top + rise
	for side in [1.0, -1.0]:
		var basis := Basis(Vector3.RIGHT, p * side)
		var mid := Vector3(0, ridge_y - half * tan(p) * 0.5, side * half * 0.5)
		mid += basis.y * (th * 0.5 + 0.02)
		b.box(roof, Transform3D(basis, mid), Vector3(w + ov * 2.0, th, slope), Color(0.75, 0.72, 0.75), Color.WHITE, true)
	b.boxp(roof, Vector3(0, ridge_y + th * 0.9, 0), Vector3(w + ov * 2.0 + 0.05, th * 0.9, th * 2.2), Color(0.85, 0.85, 0.85))
	# chimney
	var ch := Vector3(chimney_x, 0, -d * 0.18)
	var ch_top := ridge_y + 0.7
	b.boxp("stone", Vector3(ch.x, (top + ch_top) * 0.5, ch.z), Vector3(0.7, ch_top - top, 0.7), lo)
	b.boxp("stone_big", Vector3(ch.x, ch_top + 0.08, ch.z), Vector3(0.86, 0.16, 0.86))
	smoke = Kit.smoke(Vector3(ch.x, ch_top + 0.25, ch.z))
	root.add_child(smoke)
	# windows
	for wnd in windows:
		_window(b, root, Vector3(wnd.x, wb + wnd.y, fz))
	# side window (right gable wall)
	_window_side(b, root, Vector3(w * 0.5 + 0.03, wb + wh * 0.45, 0))
	# door
	var dx := door_x
	b.boxp("planks", Vector3(dx, wb + 0.95, fz - 0.02), Vector3(0.95, 1.9, 0.08), Color(0.7, 0.66, 0.66))
	b.boxp("timber", Vector3(dx, wb + 1.95, fz + 0.03), Vector3(1.25, 0.16, 0.14))
	for sx in [-1.0, 1.0]:
		b.boxp("timber", Vector3(dx + sx * 0.56, wb + 0.95, fz + 0.03), Vector3(0.14, 1.9, 0.14))
	b.boxp("stone_big", Vector3(dx, wb - 0.12, fz + 0.35), Vector3(1.3, 0.24, 0.7))
	b.boxp("iron", Vector3(dx + 0.3, wb + 0.95, fz + 0.04), Vector3(0.06, 0.06, 0.05))
	# wall lamp by the door
	var lp := Vector3(dx + 0.95, wb + 1.75, fz + 0.18)
	b.boxp("iron", lp + Vector3(0, 0.25, -0.1), Vector3(0.06, 0.06, 0.3))
	b.boxp("iron", lp + Vector3(0, 0.17, 0), Vector3(0.26, 0.05, 0.26))
	b.boxp("lamp", lp, Vector3(0.18, 0.26, 0.18))
	var ll := Kit.omni(lp + Vector3(0, -0.05, 0.25), Color(1.0, 0.62, 0.3), 3.2)
	root.add_child(ll)
	lantern_lights.append(ll)
	root.add_child(b.commit("Mesh"))
	var rng := RandomNumberGenerator.new()
	rng.seed = 33
	root.add_child(Flora.flower_tufts(_flower_spots, rng))


func _window(b, root: Node3D, p: Vector3) -> void:
	b.boxp("glass", p + Vector3(0, 0, -0.03), Vector3(0.72, 0.9, 0.04))
	for sx in [-1.0, 1.0]:
		b.boxp("timber", p + Vector3(sx * 0.42, 0, 0.02), Vector3(0.12, 1.06, 0.1))
		b.boxp(shutter, p + Vector3(sx * 0.72, 0, 0.04), Vector3(0.4, 1.0, 0.06), Color(0.8, 0.8, 0.8))
	for sy in [-1.0, 1.0]:
		b.boxp("timber", p + Vector3(0, sy * 0.5, 0.02), Vector3(0.96, 0.12, 0.1))
	b.boxp("timber", p + Vector3(0, 0, 0.0), Vector3(0.06, 0.9, 0.06))
	b.boxp("timber", p + Vector3(0, 0.08, 0.0), Vector3(0.72, 0.06, 0.06))
	b.boxp("planks", p + Vector3(0, -0.66, 0.16), Vector3(1.0, 0.24, 0.32), Color(0.75, 0.72, 0.72))
	_flower_spots.append(p + Vector3(0, -0.54, 0.16))
	var l := Kit.omni(p + Vector3(0, -0.1, 0.55), Color(1.0, 0.6, 0.28), 4.0)
	root.add_child(l)
	window_lights.append(l)


func _window_side(b, root: Node3D, p: Vector3) -> void:
	b.boxp("glass", p + Vector3(-0.02, 0, 0), Vector3(0.04, 0.85, 0.7))
	for sz in [-1.0, 1.0]:
		b.boxp("timber", p + Vector3(0.02, 0, sz * 0.4), Vector3(0.1, 1.0, 0.12))
		b.boxp("timber", p + Vector3(0.02, sz * 0.47, 0), Vector3(0.1, 0.12, 0.92))
	var l := Kit.omni(p + Vector3(0.5, -0.1, 0), Color(1.0, 0.6, 0.28), 3.0)
	root.add_child(l)
	window_lights.append(l)
