@tool
extends "res://hd2d/core/gen.gd"
## Places a pixel-art character PNG in 3D light: 32 texels / unit, pivot bottom-centre, always facing the
## camera. Lives on layer 16 so its contact-shadow decal skips it; a sun-facing proxy casts its shadow.
## With `focus`, the tilt-shift DOF focuses on it (group hd2d_focus).

@export_file("*.png") var texture_path := "res://assets/hero.png":
	set(v):
		texture_path = v
		_queue()
## Side-by-side animation cells in the PNG (frame picked with the "frame" instance uniform).
@export var frames := 1:
	set(v):
		frames = v
		_queue()
@export var focus := true:
	set(v):
		focus = v
		if focus:
			add_to_group("hd2d_focus")
		elif is_in_group("hd2d_focus"):
			remove_from_group("hd2d_focus")

var sprite: MeshInstance3D
var _shadow: MeshInstance3D


func _init() -> void:
	add_to_group("hd2d_preset")
	add_to_group("hd2d_focus")


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func focus_point() -> Vector3:
	return (_gen.global_position if _gen else global_position) + Vector3(0, 1, 0)


func apply_preset(n: float, _r: float) -> void:
	if sprite:
		sprite.material_override.set_shader_parameter("rim_strength", lerp(0.9, 2.0, n))
		sprite.material_override.set_shader_parameter("wrap", lerp(0.5, 0.8, n))


func _build(root: Node3D) -> void:
	sprite = null
	var img := Image.load_from_file(ProjectSettings.globalize_path(texture_path))
	if img == null or img.is_empty():
		push_error("sprite_actor: cannot load " + texture_path)
		return
	# the visible quad never casts (a camera-facing billboard would shadow itself); a sun-facing proxy casts instead
	sprite = Kit.sprite(img, frames, false)
	sprite.name = "Sprite"
	sprite.layers = 16
	root.add_child(sprite)
	_shadow = Kit.sprite(img, frames, true)
	_shadow.name = "ShadowProxy"
	_shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY
	_shadow.layers = 16
	root.add_child(_shadow)
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 1))
	g.set_color(1, Color(1, 1, 1, 0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(0.5, 0.0)
	gt.width = 64
	gt.height = 64
	var w := img.get_width() / float(frames) / Kit.TEXEL
	var dec := Decal.new()
	dec.name = "Contact"
	dec.texture_albedo = gt
	dec.size = Vector3(w * 1.1, 0.6, w * 0.55)
	dec.modulate = Color(0.05, 0.04, 0.08, 0.75)
	dec.position = Vector3(0, 0.1, 0)
	dec.cull_mask = 0xFFFFF & ~16 # do not darken the sprite's own feet
	root.add_child(dec)


func _process(_delta: float) -> void:
	if sprite == null:
		return
	var cam := get_viewport().get_camera_3d()
	if cam:
		var d := cam.global_position - sprite.global_position
		sprite.rotation.y = atan2(d.x, d.z)
	var sd := Kit.sun_dir
	var ld := Vector3(sd.x, 0.0, sd.z)
	if ld.length() > 0.01:
		ld = ld.normalized()
		_shadow.position = sprite.position - ld * 0.25
		_shadow.rotation.y = atan2(ld.x, ld.z)
