@tool
extends "res://hd2d/core/gen.gd"
## One butterfly flying a figure-eight around its home (the node), pushed by gusts, settling on the
## flowers every few seconds with slow wing beats. Snap offset ~0.7 keeps it above the tufts.

@export var tint := Color(1.0, 0.55, 0.12):
	set(v):
		tint = v
		_queue()
@warning_ignore("shadowed_global_identifier")
@export var seed := 0:
	set(v):
		seed = v
		_queue()

var _fly: MeshInstance3D
var _ph := 0.0
var _rate := 12.0
var _cycle := 9.0
var _time := 0.0


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func _build(root: Node3D) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	_ph = rng.randf() * TAU
	_rate = rng.randf_range(10.0, 14.0)
	_cycle = rng.randf_range(8.0, 11.0)
	_fly = Kit.sprite(Pix.butterfly_frames(), 2, false)
	_fly.set_instance_shader_parameter("tint", tint)
	root.add_child(_fly)


func _process(delta: float) -> void:
	if _fly == null:
		return
	_time += delta
	var t := _time
	var gp := global_position
	var g := Wind.gust(Vector2(gp.x, gp.z), t)
	# figure-eight flight (1:2 Lissajous), then settle on the flowers with slow wing beats
	var a := t * 0.9 + _ph
	var fly := Vector3(sin(a) * 1.1, sin(t * 1.3 + _ph) * 0.25 + sin(t * 3.1 + _ph) * 0.06, sin(2.0 * a) * 0.45)
	fly += Vector3(Wind.DIR.x, 0, Wind.DIR.y) * g * 0.5 * (1.0 + Kit.rain * 0.7)
	var lt := fmod(t + _ph * 2.0, _cycle)
	var rest_w := smoothstep(_cycle - 3.2, _cycle - 2.6, lt) * (1.0 - smoothstep(_cycle - 0.4, _cycle, lt))
	var rest := Vector3(sin(_ph) * 0.4, -0.5, 0.0)
	_fly.position = fly.lerp(rest, rest_w)
	var beat: float = floor(fmod(t * 1.6, 2.0)) if rest_w > 0.9 else floor(fmod(t * _rate, 2.0))
	_fly.set_instance_shader_parameter("frame", beat)
	var cam := get_viewport().get_camera_3d()
	if cam:
		var d := cam.global_position - _fly.global_position
		_fly.rotation.y = atan2(d.x, d.z)
