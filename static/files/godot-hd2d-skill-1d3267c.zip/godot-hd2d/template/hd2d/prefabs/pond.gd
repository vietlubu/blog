@tool
extends "res://hd2d/core/gen.gd"
## Water plane (planar mirror, refraction, glints, ripples) at the node's height, lily pads and a pond mist.
## The node y is the water level: keep project.godot shader_globals/water_level equal to it for the
## editor preview (the rig sets the global at runtime). One pond per scene: there is one mirror camera.

const WATER := preload("res://hd2d/shaders/water.gdshader")
const FOG := preload("res://hd2d/shaders/fog.gdshader")
const TEXEL := 32.0

@export var size := Vector2(17.0, 17.0):
	set(v):
		size = v
		_queue()
@export var shallow := Color("#3f6f6a"):
	set(v):
		shallow = v
		_queue()
@export var deep := Color("#0b1d22"):
	set(v):
		deep = v
		_queue()
@export var lilies := 11:
	set(v):
		lilies = v
		_queue()
## Lily ellipse centre (local XZ) and radii.
@export var lily_center := Vector2(-0.6, 0.5):
	set(v):
		lily_center = v
		_queue()
@export var lily_radii := Vector2(2.85, 1.5):
	set(v):
		lily_radii = v
		_queue()
@export var mist := true:
	set(v):
		mist = v
		_queue()
@export var mist_offset := Vector3(-1.0, 0.05, 1.2):
	set(v):
		mist_offset = v
		_queue()
@export var mist_size := Vector3(9.0, 1.6, 6.0):
	set(v):
		mist_size = v
		_queue()

var material: ShaderMaterial
var _mist_mat: ShaderMaterial
var _lily_nodes: Array[Node3D] = []
var _time := 0.0


func _init() -> void:
	add_to_group("hd2d_water")
	add_to_group("hd2d_preset")


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func apply_preset(n: float, r: float) -> void:
	if _mist_mat:
		_mist_mat.set_shader_parameter("albedo", Color.html("#fff4e8").lerp(Color.html("#b4c4f0"), n))
		_mist_mat.set_shader_parameter("density", lerp(0.018, 0.12, n) + r * 0.05) # pond mist was greying the water


func _process(delta: float) -> void:
	_time += delta
	for i in _lily_nodes.size():
		_lily_nodes[i].position.y = 0.012 + sin(_time * 1.3 + i) * 0.006


func _build(root: Node3D) -> void:
	_lily_nodes.clear()
	_mist_mat = null
	var pm := PlaneMesh.new()
	pm.size = size
	pm.subdivide_width = 1
	if material == null:
		material = ShaderMaterial.new() # kept across rebuilds: the rig holds the reflection texture on it
		material.shader = WATER
	material.set_shader_parameter("shallow", shallow)
	material.set_shader_parameter("deep", deep)
	var cs := get_tree().get_first_node_in_group("hd2d_cascade") as Node3D
	material.set_shader_parameter("cascade_pos", Vector2(cs.global_position.x, cs.global_position.z + 0.15) if cs else Vector2(1e6, 1e6))
	var mi := MeshInstance3D.new()
	mi.name = "Water"
	mi.mesh = pm
	mi.material_override = material
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.layers = 2 # not seen by the reflection camera
	root.add_child(mi)
	# lily pads
	var lily_tex := Pix.lily_atlas()
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var gp := global_position
	for i in lilies:
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf())
		var p := Vector3(lily_center.x + cos(a) * r * lily_radii.x, 0.01, lily_center.y + sin(a) * r * lily_radii.y)
		var rot := rng.randf_range(-0.4, 0.4)
		if _t and Ground.height(_t, gp.x + p.x, gp.z + p.z) > gp.y - 0.1:
			continue
		var q := QuadMesh.new()
		q.size = Vector2(20.0, 14.0) / TEXEL
		q.orientation = PlaneMesh.FACE_Y
		var lm := StandardMaterial3D.new()
		lm.albedo_texture = lily_tex
		lm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		lm.uv1_scale = Vector3(0.5, 1, 1)
		lm.uv1_offset = Vector3(0.5 if i % 4 == 0 else 0.0, 0, 0)
		lm.roughness = 0.35
		var li := MeshInstance3D.new()
		li.mesh = q
		li.material_override = lm
		li.position = p
		li.rotation.y = rot
		li.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(li)
		_lily_nodes.append(li)
	if mist:
		_mist_mat = ShaderMaterial.new()
		_mist_mat.shader = FOG
		_mist_mat.set_shader_parameter("density", 0.1)
		_mist_mat.set_shader_parameter("base_y", gp.y - 0.05)
		_mist_mat.set_shader_parameter("falloff", 2.2)
		_mist_mat.set_shader_parameter("wisp", 0.8)
		_mist_mat.set_shader_parameter("scale", 0.45)
		var fv := FogVolume.new()
		fv.name = "Mist"
		fv.shape = RenderingServer.FOG_VOLUME_SHAPE_ELLIPSOID
		fv.size = mist_size
		fv.position = mist_offset
		fv.material = _mist_mat
		root.add_child(fv)
