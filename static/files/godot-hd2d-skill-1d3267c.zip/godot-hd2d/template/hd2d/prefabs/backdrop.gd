@tool
extends "res://hd2d/core/gen.gd"
## Far backdrop: three flat unshaded ridge silhouettes (aerial perspective by value) and drifting pixel clouds.
## Place at the origin; ridge depths and the cloud box are in local space.

const CLOUD := preload("res://hd2d/shaders/cloud.gdshader")
# [z, low y, high y, golden colour, night colour]; ridges sit low so they show through valley windows
const RIDGES := [[-70.0, -10.0, -4.5, "#5d7088", "#1c2a4a"], [-100.0, -8.5, -2.5, "#7b8aa4", "#253456"], [-140.0, -8.0, -0.5, "#9aa6bc", "#2e3e62"]]
const RIDGE_GOLD := ["#6f86a0", "#8c9ab4", "#aab4c8"] # preset colour at golden hour (build colour is only the editor look)

@export var cloud_count := 7:
	set(v):
		cloud_count = v
		_queue()
## Clouds spawn inside this box and drift along +X, wrapping around it.
@export var cloud_box := AABB(Vector3(-10, -10, -120), Vector3(90, 5, 38)):
	set(v):
		cloud_box = v
		_queue()
@warning_ignore("shadowed_global_identifier")
@export var seed := 3:
	set(v):
		seed = v
		_queue()

var _cloud_mat: ShaderMaterial
var _hill_mats: Array[StandardMaterial3D] = []
var _clouds: Array[Node3D] = []


func _init() -> void:
	add_to_group("hd2d_preset")


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func apply_preset(n: float, r: float) -> void:
	if _cloud_mat:
		_cloud_mat.set_shader_parameter("lit", Color.html("#ffe2bc").lerp(Color.html("#56689a"), n).lerp(Color.html("#b8bcc4"), r * 0.6))
		_cloud_mat.set_shader_parameter("shade", Color.html("#b9a0b8").lerp(Color.html("#222a48"), n).lerp(Color.html("#6a7080"), r * 0.6))
	for i in _hill_mats.size():
		_hill_mats[i].albedo_color = Color.html(RIDGE_GOLD[i]).lerp(Color.html(RIDGES[i][4]), n).lerp(Color.html("#9098a8"), r * 0.5)


func _process(delta: float) -> void:
	var lo := cloud_box.position.x - 30.0
	var span := cloud_box.size.x + 50.0
	for c in _clouds:
		c.position.x = fposmod(c.position.x - lo + delta * 0.5 * (1.0 + Kit.rain * 0.7), span) + lo


func _build(root: Node3D) -> void:
	_hill_mats.clear()
	_clouds.clear()
	var noise := FastNoiseLite.new()
	noise.seed = 7
	noise.frequency = 0.045
	noise.fractal_octaves = 3
	var li := 0
	for L in RIDGES:
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		var z: float = L[0]
		var lo: float = L[1]
		var hi: float = L[2]
		var n := 120
		for i in n:
			var xa := -260.0 + i * 520.0 / n
			var xb := xa + 520.0 / n
			var ya := lerpf(lo, hi, noise.get_noise_1d(xa * 0.35 + li * 50.0) * 0.5 + 0.5)
			var yb := lerpf(lo, hi, noise.get_noise_1d(xb * 0.35 + li * 50.0) * 0.5 + 0.5)
			for v in [Vector3(xa, -60, z), Vector3(xa, ya, z), Vector3(xb, yb, z), Vector3(xa, -60, z), Vector3(xb, yb, z), Vector3(xb, -60, z)]:
				st.set_normal(Vector3.BACK)
				st.set_uv(Vector2(0.5, 0.5))
				st.add_vertex(v)
		var mt := StandardMaterial3D.new()
		mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mt.albedo_color = Color.html(L[3])
		mt.disable_receive_shadows = true
		_hill_mats.append(mt)
		var mi := MeshInstance3D.new()
		mi.name = "Ridge%d" % li
		mi.mesh = st.commit()
		mi.material_override = mt
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(mi)
		li += 1
	_cloud_mat = ShaderMaterial.new()
	_cloud_mat.shader = CLOUD
	_cloud_mat.set_shader_parameter("tex", Pix.cloud_atlas())
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var b0 := cloud_box.position
	var b1 := cloud_box.end
	for i in cloud_count:
		var q := QuadMesh.new()
		var s := rng.randf_range(0.18, 0.3)
		q.size = Vector2(128.0, 64.0) * s
		var arr := q.get_mesh_arrays()
		var uvs: PackedVector2Array = arr[Mesh.ARRAY_TEX_UV]
		var cell := i % 3
		for k in uvs.size():
			uvs[k].x = (uvs[k].x + cell) / 3.0
		arr[Mesh.ARRAY_TEX_UV] = uvs
		var am := ArrayMesh.new()
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		var mi := MeshInstance3D.new()
		mi.mesh = am
		mi.material_override = _cloud_mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.position = Vector3(rng.randf_range(b0.x, b1.x), rng.randf_range(b0.y, b1.y), rng.randf_range(b0.z, b1.z))
		root.add_child(mi)
		_clouds.append(mi)
