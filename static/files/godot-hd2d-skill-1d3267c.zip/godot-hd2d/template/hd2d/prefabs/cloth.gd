@tool
extends "res://hd2d/core/gen.gd"
## Hanging cloth (laundry, towel, sheet, banner) that billows with the wind field. Origin = top centre.

const CLOTH := preload("res://hd2d/shaders/cloth.gdshader")

@export var size := Vector2(0.55, 0.7):
	set(v):
		size = v
		_queue()
## Atlas cell: 0 shirt, 1 towel, 2 sheet, 3 banner.
@export_range(0, 3) var cell := 0:
	set(v):
		cell = v
		_queue()
@export var stiffness := 1.0:
	set(v):
		stiffness = v
		_queue()
## Adds a timber rod along the top edge.
@export var rod := false:
	set(v):
		rod = v
		_queue()


## Cloth quad hanging from `top_center` (UV.y = 0 at the top edge), atlas cell baked into the UVs.
static func make(top_center: Vector3, sz: Vector2, atlas_cell: int, stiff: float) -> MeshInstance3D:
	var atlas := Pix.cloth_atlas()
	var q := QuadMesh.new()
	q.size = sz
	q.center_offset = Vector3(0, -sz.y * 0.5, 0)
	var arr := q.get_mesh_arrays()
	var uvs: PackedVector2Array = arr[Mesh.ARRAY_TEX_UV]
	for i in uvs.size():
		uvs[i].x = (uvs[i].x + atlas_cell) / 4.0
	arr[Mesh.ARRAY_TEX_UV] = uvs
	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	var mt := ShaderMaterial.new()
	mt.shader = CLOTH
	mt.set_shader_parameter("tex", atlas)
	mt.set_shader_parameter("stiffness", stiff)
	var mi := MeshInstance3D.new()
	mi.mesh = am
	mi.material_override = mt
	mi.position = top_center
	return mi


func _build(root: Node3D) -> void:
	root.add_child(make(Vector3.ZERO, size, cell, stiffness))
	if rod:
		var b := Builder.new()
		b.mats = Kit.materials()
		b.boxp("timber", Vector3(0, 0.02, 0), Vector3(size.x + 0.2, 0.06, 0.06))
		root.add_child(b.commit("Rod"))
