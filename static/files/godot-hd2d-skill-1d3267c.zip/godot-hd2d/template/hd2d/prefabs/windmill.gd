@tool
extends "res://hd2d/core/gen.gd"
## Hill windmill: tapered octagonal tower, thatched cap, door, window and four red-cloth sails that turn
## with the gusts. Origin = tower base.

var _sails: Node3D
var _time := 0.0


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func _build(root: Node3D) -> void:
	var m := Kit.materials()
	var b := Builder.new()
	b.mats = m
	b.prism("windmill", Transform3D(), 8, 1.5, 1.05, 6.0, Color(0.7, 0.66, 0.68))
	b.prism("thatch", Transform3D(Basis(), Vector3(0, 6.0, 0)), 8, 1.35, 0.1, 1.8, Color(0.8, 0.8, 0.8))
	b.boxp("planks", Vector3(0, 0.9, 1.4), Vector3(0.8, 1.6, 0.2))
	b.boxp("glass", Vector3(0, 3.6, 1.2), Vector3(0.5, 0.6, 0.12))
	root.add_child(b.commit("Tower"))
	_sails = Node3D.new()
	_sails.name = "Sails"
	_sails.position = Vector3(0, 6.0, 1.45)
	root.add_child(_sails)
	var sb := Builder.new()
	sb.mats = m
	sb.boxp("timber", Vector3.ZERO, Vector3(0.4, 0.4, 0.4))
	for i in 4:
		var bas := Basis(Vector3.BACK, i * PI * 0.5)
		sb.box("timber", Transform3D(bas, bas * Vector3(0, 2.4, 0)), Vector3(0.14, 4.8, 0.1))
		sb.box("cloth_red", Transform3D(bas, bas * Vector3(0.42, 2.9, 0.02)), Vector3(0.7, 3.4, 0.04))
	_sails.add_child(sb.commit("Blades"))


func _process(delta: float) -> void:
	_time += delta
	if _sails:
		var gp := global_position
		_sails.rotate_z(-delta * (0.35 + Wind.gust(Vector2(gp.x, gp.z), _time) * 0.6) * (1.0 + Kit.rain * 0.7))
