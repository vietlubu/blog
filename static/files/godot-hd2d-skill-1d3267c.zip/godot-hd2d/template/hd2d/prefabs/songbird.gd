@tool
extends "res://hd2d/core/gen.gd"
## One songbird hopping around its home (the node), pecking between hops. on_roof: hops along X only, keeps
## its height and never pecks (place it on a ridge with snap off).

@export var hop_radius := Vector2(0.9, 0.5):
	set(v):
		hop_radius = v
		_queue()
@export var on_roof := false:
	set(v):
		on_roof = v
		_queue()
@warning_ignore("shadowed_global_identifier")
@export var seed := 77:
	set(v):
		seed = v
		_queue()

var _bird: MeshInstance3D
var _rng := RandomNumberGenerator.new()
var _from := Vector3.ZERO
var _to := Vector3.ZERO
var _hop := 1.0
var _wait := 1.0
var _face := 1.0
var _time := 0.0


func _ready() -> void:
	super()
	set_process(not Engine.is_editor_hint())


func _build(root: Node3D) -> void:
	_rng.seed = seed
	_bird = Kit.sprite(Pix.songbird_frames(), 2, true)
	root.add_child(_bird)
	_from = Vector3.ZERO
	_to = Vector3.ZERO
	_hop = 1.0
	_wait = _rng.randf_range(0.5, 2.0)


func _process(delta: float) -> void:
	if _bird == null:
		return
	_time += delta
	if _hop < 1.0:
		_hop = minf(1.0, _hop + delta / 0.32)
		var p := _from.lerp(_to, _hop)
		p.y += sin(_hop * PI) * 0.28
		_bird.position = p
		_bird.set_instance_shader_parameter("frame", 0.0)
	else:
		_wait -= delta
		var peck := fmod(_time * 3.0 + global_position.x, 4.0) > 3.4 and not on_roof
		_bird.set_instance_shader_parameter("frame", 1.0 if peck else 0.0)
		if _wait <= 0.0:
			_from = _bird.position
			var to := Vector3(_rng.randf_range(-hop_radius.x, hop_radius.x), 0, 0.0 if on_roof else _rng.randf_range(-hop_radius.y, hop_radius.y))
			if not on_roof:
				to.y = _ground_rel(to)
			_to = to
			_face = 1.0 if to.x > _from.x else -1.0
			_hop = 0.0
			_wait = _rng.randf_range(0.4, 2.6)
	var cam := get_viewport().get_camera_3d()
	if cam:
		var d := cam.global_position - _bird.global_position
		_bird.rotation.y = atan2(d.x, d.z)
	_bird.scale.x = _face
