@tool
extends "res://hd2d/core/gen.gd"
## Stone structures along local X, origin = centre of the base line, placed at an explicit height (no snap).
## wall: retaining wall facing +Z with broken coping, buttresses and ivy. stairs: climbs toward -Z.
## bridge: arched stone bridge spanning `length` along X, deck `width` wide.

@export_enum("wall", "stairs", "bridge") var kind: String = "wall":
	set(v):
		kind = v
		_queue()
@export var length := 10.0:
	set(v):
		length = v
		_queue()
@export var height := 2.1:
	set(v):
		height = v
		_queue()
@export var width := 1.8:
	set(v):
		width = v
		_queue()
@export var steps := 6:
	set(v):
		steps = v
		_queue()
## Bridge deck rise at mid-span.
@export var rise := 0.62:
	set(v):
		rise = v
		_queue()
@export var ivy := true:
	set(v):
		ivy = v
		_queue()
@warning_ignore("shadowed_global_identifier")
@export var seed := 0:
	set(v):
		seed = v
		_queue()


func _init() -> void:
	add_to_group("hd2d_footprint")


func footprint_world() -> Rect2:
	match kind:
		"stairs":
			return _xz_bounds(Rect2(-width * 0.5 - 0.3, -length, width + 0.6, length))
		"bridge":
			return _xz_bounds(Rect2(-length * 0.5 - 0.3, -width * 0.5 - 0.15, length + 0.6, width + 0.3))
	return _xz_bounds(Rect2(-length * 0.5, -0.4, length, 0.8))


func _build(root: Node3D) -> void:
	var b := Builder.new()
	b.mats = Kit.materials()
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	match kind:
		"wall":
			_wall(b, root, rng)
		"stairs":
			_stairs(b)
		"bridge":
			_bridge(b)
	root.add_child(b.commit("Mesh"))


func _wall(b, root: Node3D, rng: RandomNumberGenerator) -> void:
	var lo := Color(0.72, 0.7, 0.74)
	var x0 := -length * 0.5
	var x1 := length * 0.5
	b.boxp("stone", Vector3(0, height * 0.5, 0), Vector3(length, height, 0.5), lo)
	# coping broken into runs of different heights, so the wall is not one flat band
	var x := x0
	while x < x1 - 0.01:
		var run := minf(rng.randf_range(3.5, 6.0), x1 - x)
		var cx := x + run * 0.5
		var cy := height + 0.07
		if rng.randf() < 0.3:
			b.boxp("stone", Vector3(cx, height + 0.29, 0), Vector3(run, 0.5, 0.45), lo)
			cy = height + 0.59
		b.boxp("stone_big", Vector3(cx, cy, 0.03), Vector3(run + 0.04, 0.18, 0.62), Color(0.9, 0.9, 0.9))
		x += run
	var bx := x0 + 4.25
	while bx < x1 - 0.5:
		b.boxp("stone_big", Vector3(bx, 0.95, 0.36), Vector3(0.55, 2.2, 0.36), lo)
		bx += 8.5
	if not ivy:
		return
	# ivy curtains draping over the coping (camera-facing, unrotated cards so the leaf pixels stay on-grid)
	var fb := Builder.new()
	fb.mats = {"bush": Flora.foliage_mat("bush")}
	var ix := x0 + 2.5
	while ix < x1 - 0.5:
		var drop := rng.randf_range(0.0, 0.5)
		Flora.ivy(fb, Vector3(ix, 1.88 - drop, 0.32), rng)
		if rng.randf() < 0.6:
			Flora.ivy(fb, Vector3(ix + rng.randf_range(0.6, 1.1), 1.53 - drop, 0.30), rng)
		ix += 5.0
	root.add_child(fb.commit("Ivy"))


func _stairs(b) -> void:
	var lo := Color(0.72, 0.7, 0.74)
	for i in steps:
		var top := height * (i + 1) / steps
		var zf := -i * length / steps
		b.boxp("stone_big", Vector3(0, (top - 0.2) * 0.5, (zf - length) * 0.5), Vector3(width, top + 0.2, zf + length), lo)
	for sx in [-1.0, 1.0]:
		b.boxp("stone", Vector3(sx * (width * 0.5 + 0.1), (height + 0.58) * 0.5 - 0.1, -length * 0.5), Vector3(0.25, height + 0.58, length + 0.05), lo)


func _bridge(b) -> void:
	var n := 14
	var sw := length / n
	var lo := Color(0.7, 0.68, 0.72)
	for i in n:
		var x := -length * 0.5 + (i + 0.5) * sw
		var k := x / (length * 0.5)
		var deck: float = 0.12 + rise * (1.0 - k * k)
		var ko := x / (length * 0.279)
		var under := -0.9
		if abs(ko) < 1.0:
			under = -0.3 + 0.95 * sqrt(1.0 - ko * ko)
		b.boxp("stone_big", Vector3(x, (deck + under) * 0.5, 0), Vector3(sw + 0.01, deck - under, width), lo)
		b.boxp("cobble", Vector3(x, deck + 0.04, 0), Vector3(sw + 0.01, 0.08, width - 0.3))
		for side in [-1.0, 1.0]:
			b.boxp("stone", Vector3(x, deck + 0.28, side * (width * 0.5 - 0.07)), Vector3(sw + 0.01, 0.5, 0.26), lo)
			b.boxp("stone_big", Vector3(x, deck + 0.56, side * (width * 0.5 - 0.07)), Vector3(sw + 0.02, 0.08, 0.34))
