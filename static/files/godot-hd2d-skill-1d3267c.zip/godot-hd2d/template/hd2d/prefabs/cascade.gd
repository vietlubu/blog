@tool
extends "res://hd2d/core/gen.gd"
## Small cascade: scrolling pixel streaks on a tilted quad, splash particles at its foot. The pond reads
## this node's position for its ripple rings.

const CASCADE := preload("res://hd2d/shaders/cascade.gdshader")
const TEXEL := 32.0

@export var size := Vector2(1.9, 0.75):
	set(v):
		size = v
		_queue()
@export var tilt_deg := -38.0:
	set(v):
		tilt_deg = v
		_queue()


func _init() -> void:
	add_to_group("hd2d_cascade")


func _build(root: Node3D) -> void:
	var cq := QuadMesh.new()
	cq.size = size
	var cm := ShaderMaterial.new()
	cm.shader = CASCADE
	var ci := MeshInstance3D.new()
	ci.name = "Fall"
	ci.mesh = cq
	ci.material_override = cm
	ci.rotation.x = deg_to_rad(tilt_deg)
	ci.layers = 2
	ci.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(ci)
	var sm := ParticleProcessMaterial.new()
	sm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	sm.emission_box_extents = Vector3(0.8, 0.05, 0.1)
	sm.direction = Vector3(0, 1, 0.6)
	sm.spread = 35.0
	sm.initial_velocity_min = 0.6
	sm.initial_velocity_max = 1.4
	sm.gravity = Vector3(0, -6, 0)
	var sq := QuadMesh.new()
	sq.size = Vector2(2.0, 2.0) / TEXEL
	var smt := StandardMaterial3D.new()
	smt.albedo_color = Color(0.9, 0.95, 1.0)
	smt.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	smt.roughness = 0.2
	sq.material = smt
	var sp := GPUParticles3D.new()
	sp.amount = 60
	sp.lifetime = 0.6
	sp.process_material = sm
	sp.draw_pass_1 = sq
	sp.position = Vector3(0, -0.21, 0.45)
	sp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(sp)
