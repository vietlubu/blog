@tool
extends RefCounted
## Terrain source of truth: heights and painted ids per world point. hd2d/tools/bake_terrain.gd writes them
## into res://terrain/data. Edit here and rebake (a rebake overwrites sculpting/painting done in the editor).
## Demo layout: T1 focal strip (y 0) with a path, pond and stream; a 1.6 u step up to T2 at z -5;
## T3 hill behind that climbs on the left and falls into a valley window on the right.

const BOUNDS := Rect2(-64, -78, 128, 106) # outside: terrain hole
const ORIGIN := Vector2(-128, -128) # world XZ of vertex (0, 0)
const SIZE := 512 # vertices per side at Ground.SPACING (0.5)
const POND := Vector4(-6.6, 3.5, 3.8, 2.0) # cx, cz, rx, rz
const STREAM := [Vector2(-4.0, -5.0), Vector2(-4.0, -1.0), Vector2(-4.2, 1.6), Vector2(-5.6, 3.2)]
# flower meadows: x, z, radius
const MEADOWS := [Vector3(-8.5, -3.2, 2.2), Vector3(4.5, -3.6, 2.6), Vector3(-14.0, 2.5, 2.5), Vector3(11.0, 3.5, 3.0),
	Vector3(-1.0, 4.5, 2.0), Vector3(14.0, -12.5, 3.0), Vector3(-6.0, -12.0, 2.5), Vector3(5.0, 8.5, 3.0), Vector3(-17.0, -2.0, 3.0)]

var noise := FastNoiseLite.new()


func _init() -> void:
	noise.seed = 7
	noise.frequency = 0.045
	noise.fractal_octaves = 3


func _ss(a: float, b: float, x: float) -> float:
	var t: float = clamp((x - a) / (b - a), 0.0, 1.0)
	return t * t * (3.0 - 2.0 * t)


func _seg_dist(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var t: float = clamp((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
	return p.distance_to(a + ab * t)


func stream_dist(x: float, z: float) -> float:
	var p := Vector2(x, z)
	var d := 1e9
	for i in STREAM.size() - 1:
		d = min(d, _seg_dist(p, STREAM[i], STREAM[i + 1]))
	return d


func pond_e(x: float, z: float) -> float:
	return Vector2((x - POND.x) / POND.z, (z - POND.y) / POND.w).length() + noise.get_noise_2d(x * 3.0, z * 3.0) * 0.08


func path_z(x: float) -> float:
	return 0.7 + 0.55 * sin(x * 0.16 + 0.4)


func height(x: float, z: float) -> float:
	var n := noise.get_noise_2d(x, z)
	var h := 1.6 * _ss(-4.8, -5.15, z)
	# T3: the hill keeps climbing on the left (big tree, windmill) but falls away into a valley on the right,
	# opening a window onto layered hazy ridges for the kite and the flock.
	var rv := _ss(3.0, 12.0, x)
	h += _ss(-15.0, -20.0, z) * 1.3 * (1.0 - rv * 0.5) + max(0.0, -z - 19.0) * lerpf(0.42, -0.6, rv)
	h += n * (0.12 + 0.9 * _ss(-14.0, -32.0, z))
	h += _ss(12.0, 22.0, z) * 0.6 # front lip rises a bit toward the lens
	# left and right ends of T1 rise gently so the strip reads as a diorama
	h += _ss(-22.0, -36.0, x) * 1.2 * _ss(-6.0, 4.0, z) + _ss(24.0, 36.0, x) * 1.0
	if z > -4.8:
		var c := 1.0 - _ss(1.05, 1.9, stream_dist(x, z))
		h = lerp(h, -0.8, c)
	var pc := 1.0 - _ss(0.72, 1.12, pond_e(x, z))
	h = lerp(h, -0.95, pc)
	return h


## (path, cobble, flowers) weights 0..1. Path includes the cobbled stretch; only one overlay survives per
## vertex in Terrain3D, so cobble beats path beats flowers.
func paint(x: float, z: float) -> Vector3:
	var r := 0.0
	var g := 0.0
	var a := 0.0
	if z > -4.7:
		var dz: float = abs(z - path_z(x))
		r = 1.0 - _ss(1.0, 1.6, dz + noise.get_noise_2d(x * 4.0, 0.0) * 0.3)
		if x > 6.0 and x < 8.0 and z < 0.5:
			r = max(r, 1.0 - _ss(0.7, 1.2, abs(x - 7.0))) # spur to the stairs
		var cob := 1.0 - _ss(2.0, 2.8, Vector2((x - 7.0) / 1.3, z + 1.6).length()) # plaza at the stair foot
		if x > -1.6 and x < 12.0:
			g = r
		g = max(g, cob)
		if x > -6.5 and x < -1.5:
			r = 0.0 # bridge deck covers it
			g = 0.0
	if z > -4.75 and z < -3.6:
		a = 0.9 # flower strip along the wall foot
	for s in MEADOWS:
		a = max(a, 1.0 - _ss(s.z * 0.5, s.z, Vector2(x - s.x, z - s.y).length()))
	return Vector3(r, g, a)
