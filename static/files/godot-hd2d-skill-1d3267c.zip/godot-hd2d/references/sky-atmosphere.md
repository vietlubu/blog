# Sky and atmosphere

## Sky (`sky.gdshader`, built by the rig)

- Gradient: `horizon` → `zenith` over elevation 0…0.6, `below` under the horizon.
- Sun/moon: glow `sun_glow` with a tight 9th-power lobe plus a 90th-power core (a 5th-power lobe washed the upper frame amber), and a disc (`disc` cosine threshold) in the light colour.
- Night: twinkling stars above the horizon, scaled by the `night` global; not in the radiance cubemap, so they never tint ambient light.
- Colours per preset: [lighting.md](lighting.md). The sky is only seen through the sky window between T3 silhouettes; the window should stay a saturated painted gradient.

## Backdrop (`backdrop.gd`, scene `backdrop.tscn`)

Place at the origin.
- **Ridges**: three flat unshaded silhouettes 520 u wide at z −70 / −100 / −140, noise-shaped tops between `RIDGES` low/high (−10…−4.5, −8.5…−2.5, −8…−0.5), so they peek through a low valley window at the 17° pitch. Value separation does the aerial perspective: nearer is darker and bluer. Preset colours: golden `#6f86a0 #8c9ab4 #aab4c8` → night `#1c2a4a #253456 #2e3e62`, rain lerps toward `#9098a8`. Edit `RIDGES` in the script to change shapes.
- **Clouds**: `cloud_count` pixel clouds (`Pix.cloud_atlas`, 3 cells, 128×64 px × 0.18–0.3) placed in `cloud_box`, drifting +X at 0.5 u/s (×1.7 in rain) and wrapping 30 u beyond the box. `cloud.gdshader` is unshaded: `mix(shade, lit, texel)`; preset `lit` `#ffe2bc` → `#56689a`, `shade` `#b9a0b8` → `#222a48`, rain toward greys.

## Haze, depth fog, mist

Three layers, each with one job:

| Layer | Where | Job |
|---|---|---|
| Distance-graded haze (`FogVolume` world, rig) | everywhere | thin near the camera (`near_density` within 36 u), full `density` past 64 u, fading out past 90 u: the focal band stays clear and deep-valued while T3 carries haze and shaft-lit air |
| Depth fog (Environment) | beyond 48 u | aerial perspective on T3/T4 and the ridges; sky affect 0.25 |
| Pond mist (`FogVolume` ellipsoid, pond prefab) | low over the water | morning/night mist; thin at golden hour so the mirror stays bright |

Global volumetric density is 0 at golden hour (only lit FogVolume fog glows, `ambient_inject 0`), rising at night and in rain, which is when lantern halos appear. A FogVolume for a new local effect: `fog.gdshader` with `use_sdf` true (shape falloff), `density`, `albedo`, `base_y` + `falloff` (height), `wisp` + `scale` (fbm breakup).

## God rays and dust (`god_rays.gd`, scene `god_rays.tscn`)

- `slices` camera-facing quads (±`half.x`·2 by ±`half.y`·1.56) spread ±`half.z`·1.8 along the view through the node; the shader fades them outside the `half` box and between `y_lo`/`y_hi` (box ±`half.y`, shifted 0.5 down), soft-intersects opaque geometry, and adds sun light × shadow map × HG phase × `density` × `tint`.
- Centre the node in a big canopy's shadow volume, under and around the crown (demo (−1, 6.5, −12.5) behind houses A/B with `half (5.5, 4.5, 5)`). Open sunlit air inside the box only adds amber haze.
- `dust` motes (2 px, backlit, turbulent) fill the same box and glitter only where lit.
- Preset: strength `(1 − night)(1 − 0.75 rain)`; dust `lerp(1, 0.25, night)(1 − 0.8 rain)`. Layer 2 (not mirrored).

## Fireflies (`fireflies.gd`, scene `fireflies.tscn`)

`amount` additive unshaded dots (glow 4× `(0.85, 1, 0.45)`) wandering with turbulence in a box of half-size `extents`, blinking through a colour ramp. They fade in from night 0.3 to 70 % at full night, ×0.2 in rain. Centre the box low over the focal tier and the pond (demo (−3, 1.2, 2), extents (17, 1.4, 9)).

## Rain and wetness

The rig owns rain: 9000 streaks (1 px × 0.55 u, slanted 0.15 along X) falling 16–19 u/s in a 52×1×32 box 16 u above the focus, emitting when `rain > 0.02` with `amount_ratio = rain`.

Shader globals set by the rig each preset change, read by:

| Global | Readers |
|---|---|
| `wetness` (= rain) | `surface.gdshader` (darker, glossier, more on up faces), `terrain.gdshader`, `grass.gdshader` (roughness) |
| `rain` | `water.gdshader` rain rings, `leaves.gdshader` faster fall |
| `wind_strength` (1 + 0.7 rain) | every wind reader ([life.md](life.md)) |
| `night` | `sky.gdshader` stars, `water.gdshader` darker deep tint |
| `water_level` | mirror-pass discards, terrain bed/bank zones |
