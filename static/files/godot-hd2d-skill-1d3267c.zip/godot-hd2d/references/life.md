# Life: wind, sprites, critters

## One wind field

Everything that moves reads one field: `wind_gust(p, t)` in `common.gdshaderinc` (gust fronts travelling along the `wind_dir` global, 0…1) and `wind_offset()` built on it. `hd2d/core/wind.gd` mirrors `wind_gust` as `Wind.gust(p, t)` for script-driven motion; `Wind.DIR` must equal `project.godot` `shader_globals/wind_dir` (the rig sets the global from it at startup). `wind_strength` scales it (rain 1.7).

Readers: `foliage.gdshader` (canopies, bushes, ivy), `grass.gdshader` (tufts, flowers, reeds), `cloth.gdshader` (laundry, banner), `leaves.gdshader` (falling leaves), `water.gdshader` (cat's paws, ripple amplitude), `shafts.gdshader` (ray flicker), house smoke gravity, windmill sails, butterflies, kite.

A new wind reader in a shader: `#include "res://hd2d/shaders/common.gdshaderinc"` and offset by `wind_offset(world_xz, TIME, phase) * weight`; in a script: `Wind.gust(Vector2(x, z), t)` times `(1.0 + Kit.rain * 0.7)`.

## Pixel sprites in 3D light (`Kit.sprite` + `sprite.gdshader`)

`Kit.sprite(img, frames, shadows)` returns a quad sized `img` px / 32 (one frame wide when `frames > 1`), pivot bottom-centre, with:
- `tex` nearest-filtered; `ntex` = **volume normals** from the blurred alpha silhouette (`Pix.silhouette_normals`, radius 2 for tiny sprites, 3 otherwise), so a flat sprite shades like a rounded form.
- **Wrap diffuse** (`wrap` 0.5 golden → 0.8 night) so the shadow side never goes black.
- **Capped rim**: lights behind the sprite outline its outer 1–2 texels, `rim_strength`, capped at 0.6 so it never turns into a lamp.
- Instance uniforms: `frame` (which side-by-side cell) and `tint`. Animate by setting `set_instance_shader_parameter("frame", n)`; one material serves many sprites.
- Frames sit side by side in one PNG at 1×: an 8-frame 32 px walk is a 256×32 strip.

Sprites face the camera by yaw only: `rotation.y = atan2(d.x, d.z)` with `d` = camera − sprite.

## Character (`sprite_actor.gd`, scene `sprite_actor.tscn`)

Places a character PNG; the template ships `assets/hero.png` (47×65 px, 2 heads tall ≈ 2 u).
- PNG rules: transparent background, 32 px per unit, feet on the last opaque row, pivot bottom-centre, drawn in front 3/4 view. Size comes from the PNG; never scale it.
- `texture_path` (loaded with `Image.load_from_file`, so any PNG in the project works), `frames`, `focus`.
- Layer 16: the visible quad (no shadow casting; a camera-facing card would shadow itself) and a **shadow proxy** (shadows only) turned to face the sun/moon (`Kit.sun_dir`) and nudged 0.25 u away from it, so the cast shadow keeps the silhouette.
- A radial contact-shadow `Decal` under the feet, cull mask excluding layer 16 so it darkens the ground, not the feet.
- `focus = true` joins `hd2d_focus`: the tilt-shift focuses 1 u above its feet. Keep exactly one focus actor.
- Snaps to the ground; place it on the lit path in the focal tier, clear of tall tufts (they sit in front of it in depth).
- Night: rim 2.0 and wrap 0.8 keep it readable; a dim warm omni beside it helps if lanterns are far.

## Critters

| Scene | Behaviour | Exports |
|---|---|---|
| `flock.tscn` | `birds` in a V (rows 1.3 u back, ±0.9 u deep) crossing `travel` (local) in `cross_time` s every `period` s after `first_delay`; flap/glide frames; hidden between passes; shown frozen in the editor | `birds travel cross_time period first_delay` |
| `songbird.tscn` | hops (0.32 s arcs) to random points within `hop_radius` of home, pecks between hops; `on_roof` keeps its height, hops along X only, no pecking | `hop_radius on_roof seed` |
| `butterfly.tscn` | figure-eight (1:2 Lissajous) around home, pushed by gusts, settles on the flowers 0.5 u below home every 8–11 s with slow wing beats | `tint seed` (vary seeds so wings don't sync) |
| `kite.tscn` | diamond kite riding gusts at the node, 7 bows on a tail, sagging string to `anchor_offset`; never rolls | `anchor_offset` |

Place the flock across the sky window above T2/T3 roofs; songbirds on the path (snap) or on a ridge (`on_roof = true`, snap off, y = ridge); butterflies over flower beds (snap, offset 0.7); the kite in open sky with the anchor on a hill or pole, clear of the flock lane.

## Smoke, windmill, cloth

- **Chimney smoke** (`Kit.smoke`, built by houses): puff particles rising and widening; each frame the house sets particle gravity to `wind_dir × (0.6 + 1.3 gust) × wind + (0, 0.04, 0)`, so plumes lean together in gusts. Preset: pale `#ebe6eb` with warm backlight by day, dark `#3a4058` at night.
- **Windmill** sails turn at `0.35 + 0.6 · gust` rad/s, ×1.7 in rain.
- **Cloth** billows in world space along `wind_dir` from its top edge; `stiffness` scales the motion (banner 0.4, laundry 1.0).

## New critter art

- Procedural: add a `static func` to `hd2d/core/pixtex.gd` returning an `Image` with frames side by side (see `bird_frames`, `songbird_frames`, `butterfly_frames`), feed it to `Kit.sprite`.
- Hand-drawn: author it with the `pixel-maker` or `pxl-pixel-art` skills at 32 px/unit, export a frame strip PNG, load it with `Image.load_from_file` or a `sprite_actor`.
- Script: copy `butterfly.gd` (build in `_build`, move in `_process`, runtime only), keep motion on `Wind.gust` and the 1/32 grid.
