# Architecture and props

## Builder (`hd2d/core/builder.gd`)

Collects triangles per material key, then commits one `MeshInstance3D` with one surface per key. Set `b.mats = Kit.materials()` (or your own `{key: Material}`) before `commit`.

| Call | Makes |
|---|---|
| `box(key, xf: Transform3D, size, lo, hi, bottom := false)` | box centred at `xf.origin`; no bottom face unless asked |
| `boxp(key, pos, size, lo, hi)` | axis-aligned `box` |
| `prism(key, xf, sides, r0, r1, height, lo, hi, cap := true)` | tapered N-sided prism, base at `xf.origin` (barrels, trunks, windmill) |
| `tri(key, pts, normals, uvs, colors, uv2)` | one triangle, rewound to Godot's front face; carries UVs for atlas cards |
| `quad(key, a, b, c, d, n, lo, hi)` | flat quad |
| `commit(name, shadows := true)` | the mesh node; clears the builder |

- `lo` / `hi` are vertex colours bottom → top on side faces: a baked grime/AO gradient (`Color(0.62, 0.58, 0.62)` at a plinth foot, `Color(0.9, 0.9, 0.9)` on coping). Top faces take `hi`.
- Tilted slabs and overhangs the camera can see from below (roof slopes, eaves, awnings) need `bottom = true`: surfaces are `cull_back`, and from a low camera the far roof slope's underside is the only face toward the camera. Without it the roof reads as see-through from one side.
- `Builder.NO_UV` is for surfaces that project their own UVs (all `surface.gdshader` materials); atlas cards pass real UVs.

## Surface model (`hd2d/shaders/surface.gdshader`)

- **Object-space face UV**: each triangle projects from object space in world units (u along the face's horizontal edge, v up its slope), 32 texels/unit. The face normal comes from position derivatives, so imported smooth-shaded meshes still project per face and a moved house keeps its pattern.
- **Pattern** returns a ramp value and a height per texel; `ramp4` quantises the value onto `c0..c3`; the height gives a **per-texel normal** (cotangent frame, no mesh tangents), scaled by `bump`.
- **Big tint**: a low-frequency noise shifts the ramp index ±0.06 to break repetition (Octopath gradient tint).
- **Moss** on up-facing texels, amount `moss`.
- **Wetness**: global `wetness` darkens albedo up to 35 % and drops roughness toward 0.15, more on up faces.
- **Mirror pass**: fragments below `water_level` are discarded when the camera is below it.
- Uniforms: `pattern`, `c0..c3`, `texel 32`, `course 7` (stone course height in texels), `rough`, `bump`, `moss`, `emissive`, `emit_color`, `spec`.

| Id | Pattern | Kit keys | Opts in `Kit.materials()` |
|---|---|---|---|
| 0 | lime plaster with stains | `plaster`, `plaster_b`, `windmill` | |
| 1 | rubble stone courses | `stone`, `stone_big` | moss 0.3 / 0.35, `course 9` on `stone_big` |
| 2 | barrel clay tiles | `clay` | rough 0.65, moss 0.08 |
| 3 | slate | `slate` | rough 0.45, spec 0.6 |
| 4 | thatch bundles | `thatch` | moss 0.12, bump 1.4 |
| 5 | planks | `planks`, `shutter_g/b/r` | |
| 6 | timber beams, grain along u | `timber` | rough 0.8 |
| 7 | bark ridges | `bark` | moss 0.2 |
| 8 | cobbles (voronoi) | `cobble` | rough 0.6 |
| 9 | glass: warm interior, curtain bands | `glass`, `lamp` | emissive 0.6 / 3.0 (rig drives both) |
| 10 | cloth / generic | `iron`, `cloth_red` | |

`Kit.materials()` is one shared cached set: every prefab using `"glass"` shares one material, which is how the rig animates all windows at once. A new key goes into that dictionary with a 4-tone ramp ([style.md](style.md)).

## House (`house.gd`, scenes `house_thatch|clay|slate.tscn`)

Origin = plinth centre on the ground; the front (door, windows) faces +Z; the plinth top is at y 0.7 above the origin. Place with an explicit y: the probed ground height (demo T2 houses at y 1.6).

| Export | Meaning |
|---|---|
| `width`, `depth`, `wall_height` | wall box; studs every ~1.4 u with diagonal braces where no window or door is |
| `roof` | `thatch` (overhang 0.55, thickness 0.42) / `clay` / `slate` (0.45 / 0.16) |
| `pitch_deg` | roof pitch; ridge = 0.7 + wall_height + depth/2 · tan(pitch) |
| `shutter`, `wall` | shutter ramp, plaster ramp |
| `windows` | front windows: (x from centre, y above wall base); each gets a flower box, flower tufts and a warm omni |
| `door_x`, `chimney_x` | door with a wall lamp beside it; chimney with smoke steered by the wind |

Groups: `hd2d_preset` (window/lantern lights, smoke colour), `hd2d_footprint` (rect 0.5 u around the plinth, 1.1 u in front). Rotation is fine.

## Structures (`structure.gd`, scenes `wall|stairs|bridge.tscn`)

Origin = centre of the base line; the structure runs along local X; place at an explicit y (no snap); rotation is fine.

- **wall**: retaining wall facing +Z, `length` × `height` × 0.5 u. Coping in runs of 3.5–6 u, 30 % raised by 0.5 u; buttresses every 8.5 u; with `ivy`, ivy cards every 5 u hanging over the face. Sink the base below the ground (demo y −0.33 for a 2.1 u wall holding a 1.6 u terrace). `seed` re-rolls runs and ivy.
- **stairs**: `steps` blocks climbing `height` over `length` toward −Z, `width` wide, side walls 0.58 u above the top. Put the foot on the lower ground and match `height` to the terrace step.
- **bridge**: arched deck spanning `length` along X, `width` wide, deck rising `rise` at mid-span, arch opening 0.279 · length half-width, cobble deck and parapets. Centre it on the path over a stream.

Footprints: wall `(−length/2, −0.4, length, 0.8)`; stairs `(−width/2 − 0.3, −length, width + 0.6, length)`; bridge `(−length/2 − 0.3, −width/2 − 0.15, length + 0.6, width + 0.3)`, all through the node transform.

## Props (`prop.gd`, scene `prop.tscn`, snaps)

| `kind` | Build | Uses |
|---|---|---|
| `lantern_post` | stone foot, post, arm, iron lantern with a `lamp` core and a warm omni (range 6) | `hd2d_preset` lantern light, footprint 0.8² |
| `bench` | planks seat and back on timber legs | footprint 2.2 × 0.8 |
| `barrel` | 10-sided planks prism with two iron hoops | footprint 0.9² |
| `crate` | `count` crates stacked (+0.1, +0.7, −0.1), yaw from `seed` | footprint 0.9² |
| `rock` | tilted `stone_big` box, size 0.5–0.9 from `seed` | none |
| `fence` | `count` posts 1.6 u apart along +X with two rails, each post on its own ground height | none |
| `laundry_line` | two poles `length` apart along +X, rope, `count` cloths (cells 0–2) | set `snap_to_ground = false` and an explicit y; rotate to aim |

## Windmill and cloth

- `windmill.tscn`: tapered octagonal `windmill` tower 6 u, thatch cap, door, window; four timber + `cloth_red` sails at (0, 6, 1.45) turning at `0.35 + 0.6 · gust` rad/s (faster in rain). Snaps with offset −0.3. Signature prop: place it against the sky window.
- `cloth.tscn`: a quad hanging from the node (top centre), `size`, atlas `cell` (0 shirt, 1 towel, 2 sheet, 3 banner), `stiffness` (billow amount), `rod` adds a timber rod. Unrotated: the shader billows along `wind_dir` in world space.

## New architectural prefab

1. Script: `@tool`, `extends "res://hd2d/core/gen.gd"`, exports with `set(v): name = v; _queue()`.
2. `_build(root)`: `var b := Builder.new(); b.mats = Kit.materials()`, emit boxes/prisms in local space with `lo`/`hi` grime, `root.add_child(b.commit("Mesh"))`. Lights: `Kit.omni(...)` added under `root` and kept in a member array.
3. `_init()`: join `hd2d_footprint` (+ `hd2d_preset` with lights). `footprint_world()` returns `_xz_bounds(local_rect)`; `apply_preset(n, r)` calls `Kit.window_light` / `Kit.lantern_light`.
4. Multi-part pieces that follow uneven ground: offset each part by `_ground_rel(local)` and set `snap_to_ground`.
5. Scene: copy `prefabs/prop.tscn`, change the script path and node name, set the default exports.
6. Done when it rebuilds on every export change in the editor, shows in a golden and a night shot, and grass stops at its footprint.
