# Vegetation

## Tree (`tree.gd`, scenes `tree|bush|forest_row.tscn`)

One script makes trees, bushes and rows. Origin = trunk base; snaps to the ground.

| Export | Meaning |
|---|---|
| `trunk_height`, `trunk_radius` | tapered 11-sided bark prism with 5 root flares; `trunk_height 0` makes a bush |
| `canopy` | radii of the main lobe |
| `lobes` | 1 main lobe + `lobes − 1` side lobes |
| `cards` | leaf cards over all lobes (each lobe also gets +3) |
| `leaf` | `near` focal-tier trees, `bush` bushes/ivy/lens branch, `far` bluer backdrop forest |
| `sway` | wind sway weight at the canopy top |
| `shadows` | canopy casts sun shadows (trunks always cast) |
| `falling_leaves` | particle count of leaves drifting from the canopy |
| `count`, `spread`, `size_jitter` | row mode: trees step `spread.x` along +X (±1.5), scatter up to `spread.y` toward −Z, scale ×(1 ± jitter) |
| `seed` | re-rolls everything |

Lobe algorithm per tree (k = size scale):
- Main lobe centre = base + (0, `trunk_height`·0.87·k + `canopy.y`·k·(1.3 with a trunk, 0.7 for a bush), 0), radii `canopy`·k.
- Side lobe j: angle (j−1)·2π/(lobes−1) ± 0.4; centre = main + (cos a · 0.75 · canopy.x, −0.6…0.2 · canopy.y, sin a · 0.35 · canopy.z)·k; radii ×0.55–0.7. The small z spread keeps the crown wide and shallow toward the camera.
- Branches run from 85 % of the trunk height into each side lobe, a little below its centre.

Demo presets: big focal tree `trunk 4.6, radius 0.95, canopy (5.6, 3.4, 4.2), lobes 4, cards 300`; hill trees `3.6 / 0.4 / (3.4, 2.8, 2.8) / 1 / 50`; `bush.tscn` `canopy (1.5, 0.9, 1.15), cards 16`; `forest_row.tscn` 22 far trees, `cards 34`, no canopy shadows.

## Leaf cards (`Flora.canopy`)

- **Camera-facing cards**: each 2×2 u card (64 px) faces the camera (`Kit.cam_fwd()`) with yaw/tilt jitter only; its right axis stays horizontal, so leaf pixels never become diamonds. The parent must stay unrotated and the camera pitch is `Kit.CAM_PITCH`; a different camera angle needs a rebuild.
- **Lobe value mass**: each card's direction from its lobe centre is dotted with `LEAF_KEY` (an up-weighted golden-hour key): lit cap ×1.1, mid band ×0.92, dark core ×0.7, so clumps read as big shapes, not fish scales.
- **AO**: deeper cards darken (vertex colour 0.35–1.0); normals point out of the ellipsoid (85 %) blended with the card normal, so the canopy shades like a volume.
- **Sway via UV2**: `uv2.x` = sway weight growing toward the lobe top, `uv2.y` = phase. `foliage.gdshader` displaces vertices by the shared wind field × `sway` × `uv2.x`, plus flutter.
- Atlases: `near` and `bush` use `Pix.leaf_atlas(1)` (`bush` tinted (1.02, 1.04, 0.95), sway 0.5; `near` sway 0.35); `far` uses `leaf_atlas(2)` with a bluer 6-tone ramp `#14262e … #a4bc6a`, tint (0.95, 0.97, 1.0), sway 0.25. Far trees skip canopy shadows: they are blurred and the shadows cost.
- Foliage shader: alpha scissor 0.5, translucency `(0.35, 0.45, 0.12)` so backlit leaves glow at golden hour.

## Falling leaves (`Flora.leaves`)

Particles spawn in a box of half-size `canopy × (1.25, 0.9, 0.95)` 1.6 u above the main lobe, ride `wind_offset` (×2.4) with a wobble, tumble in 3D, fall faster in rain. 6×6 px atlas cells (`Pix.leaf_particles`), lifetime 16 s. Demo: 70 on the big tree, 40 on the right tree.

## Lens branch (foreground frame)

A leafy branch entering a top corner sells the miniature: it sits ~12 u in front of the camera, deep in the near bokeh. Place a `bush.tscn` with `snap_to_ground = false`, `shadows = false`, flat canopy, at

    lobe = cam_pos + cam_fwd · 12 − right · 4.9 + up · 2.55
    node y = lobe.y − 0.7 · canopy.y            (a bush lobe sits 0.7 · canopy.y above its node)

with `cam_pos = focus − cam_fwd · distance`, `cam_fwd = Kit.cam_fwd()`, `right = (1, 0, 0)`, `up = (0, 0.956, −0.292)` at pitch 17°. Demo (focus (0, 2.9, −2), distance 40): `LensBranchA` (−4.9, 13.036, 24.03) canopy (1.8, 0.7, 0.8), `LensBranchB` one lobe further right (+1.7 right, +0.25 up). Recompute when the rig focus, distance or pitch changes.

## Ivy

`Flora.ivy(fb, top, rng)` hangs one 2×2 u `bush` card down a +Z face from `top`, darker toward its tip and barely swaying. The wall prefab hangs one every 5 u over the coping, with a second card 60 % of the time. Reuse it on any wall face that looks bare.

## Grass field (`grass_field.gd`, scene `grass_field.tscn`)

Tufts scattered over `size` (XZ, centred on the node) at `density` per u², on the terrain, as 1–2 MultiMeshes under the node. Node y stays 0 (instance heights come from the ground).

- Skips: painted path > 0.42 or cobble > 0.4; every `hd2d_footprint` rect; points under water inside the pond rect (16 % become reeds in the shallows, down to 0.35 below the surface).
- Cells (`Pix.tuft_atlas`, 24×32 px): 0–1 grass, 2 tall grass, 3 seed heads, 4 daisies, 5 poppies, 6 lavender, 7 reeds. Flower chance = painted meadow × 0.6 + `flowers`; 30 % reeds just above the waterline.
- **Bank tufts**: inside the pond rect and below water + 0.7 they go to `BankGrass` on layer 1, which the mirror camera sees; the rest go to `Grass` on layer 4 (not mirrored; too many).
- Tint per tier: `brightness` scales value, `coolness` shifts toward blue; random ±10 % per tuft.
- Fields don't overlap: an overlapping focal field puts untinted tufts into the dark foreground and breaks the value hierarchy.

| Tier | Demo node | size | density | scale_px | brightness | coolness |
|---|---|---|---|---|---|---|
| T0 foreground | `GrassT0` (0, 0, 10.1) | 60 × 5 | 1.2 | 2 | 0.76 | 1.0 |
| T1 focal | `GrassT1` (0, 0, 1.5) | 60 × 12.2 | 3.2 | 1 | 1.0 | 0 |
| T2 terrace | `GrassT2` (0, 0, −9.9) | 60 × 10.2 | 2.0 | 1 | 1.0 | 0 |
| T3 hill | `GrassT3` (0, 0, −30.5) | 90 × 31 | 0.45 | 2 | 0.92 | 0.5 |

Grass shader: alpha scissor; sway grows with tuft height squared and the wind field; normals bent upward so tufts light like the ground; backlight `(0.3, 0.38, 0.12)`; wet roughness in rain; discards below the water in the mirror pass.

## Window-box flowers

Houses add `Flora.flower_tufts(points, rng)` to every front window box: 4 flower tufts (cells 4–6) per box, jittered ±0.4 x, ±0.08 z, layer 4. Call it from any prefab that needs a planter.
