# Terrain and water

## Terrain3D node

`main.tscn` holds the ground as a Terrain3D 1.1.0 node with the HD-2D shader override:

```
[sub_resource type="Terrain3DMaterial" id="Terrain3DMaterial_1"]
world_background = 0
shader_override_enabled = true
shader_override = ExtResource("terrain_shader")   ; res://hd2d/shaders/terrain.gdshader

[node name="ClipmapTarget" type="Node3D" parent="."]
position = Vector3(0, 0, -25)

[node name="Terrain" type="Terrain3D" parent="." groups=["hd2d_terrain"]]
vertex_spacing = 0.5
mesh_size = 64
data_directory = "res://terrain/data"
material = SubResource("Terrain3DMaterial_1")
assets = ExtResource("terrain_assets")             ; res://terrain/assets.tres
clipmap_target = NodePath("../ClipmapTarget")
collision_mode = 0
```

- Put `Terrain` before the prefab parents: prefabs query it in their first build.
- `collision_mode = 0` stays last: `set_data_directory` recreates the collision object and drops a mode set earlier, and the editor collision modes also build collision in game, where all-hole chunks spam `min_height > max_height`.
- `ClipmapTarget` centres the LOD clipmap on the diorama, not on the far camera.
- `world_background = 0`: no endless background mesh; outside the baked bounds is a hole.

## Painted ids

| Id | Asset name | Shader meaning |
|---|---|---|
| 0 | Grass | base everywhere |
| 1 | Dirt path | path weight |
| 2 | Cobbles | cobbles (also count as path, keeping a dirt fringe) |
| 3 | Meadow (flowers) | flower density for terrain dots and grass tufts |

Terrain3D keeps one base + one overlay + a blend per vertex. The bake writes base 0 and the strongest overlay: **cobble beats dirt beats flowers**, blend = weight × 255. Where cobbles meet dirt, cobbles win; paint by hand in the editor with the same ids.

`Ground.mask()` and the shader's `mask_at` decode the same channels: r path (dirt + cobble), g cobble, a flowers, bilinear over the 4 surrounding vertices.

## Recipe → bake → probe

`terrain/recipe.gd` is the ground's source of truth (instance methods, it owns a `FastNoiseLite`):

| Member | Contract |
|---|---|
| `BOUNDS: Rect2` | XZ kept; outside becomes a terrain hole |
| `ORIGIN`, `SIZE` | world XZ of vertex (0, 0) and vertices per side (512 at spacing 0.5 → 256 u) |
| `height(x, z) -> float` | world height |
| `paint(x, z) -> Vector3` | (path, cobble, flowers) weights 0..1 |

```
godot --headless --path . --script res://hd2d/tools/bake_terrain.gd          # BAKE ok regions=4
godot --headless --path . --script res://hd2d/tools/probe.gd -- 7,-8 -6.6,3.5 # PROBE 7 -8 h=1.661 ...
```

- The bake deletes `terrain/data/*.res`, writes the regions, and keeps `terrain/assets.tres` as is.
- Probe before placing anything that takes an explicit y (houses, walls, stairs) and to confirm paint where grass must stay off.
- Demo recipe: T1 strip at y≈0 with a winding path (`path_z`), a cobbled stretch for x −1.6…12 and a plaza at the stair foot; the terrace step to 1.6 at z −5; the T3 hill climbing on the left and dropping into a valley window on the right; a stream channel (`STREAM`) into an elliptical pond (`POND`) carved to −0.95; a front lip rising toward the lens; meadows (`MEADOWS`).
- **Editor workflow**: the Terrain3D dock sculpts and paints the same data. Editor edits and the recipe diverge, and the next bake overwrites the edits. Choose recipe-driven (agents) or editor-driven (artists) per project; when switching to editor-driven, stop baking.

## Ground API (`hd2d/core/ground.gd`)

| Call | Returns |
|---|---|
| `Ground.find(node)` | the `hd2d_terrain` Terrain3D with data, else null |
| `Ground.height(t, x, z)` | bilinear height (0 when `t` is null) |
| `Ground.mask(t, x, z)` | `Color(path, cobble, 0, flowers)` |
| `Ground.water_y(node)` | global y of the first `hd2d_water` node, else −1e6 |

Prefabs get `_t` from `gen.gd` and use `_ground_rel(local)` for parts that follow the ground.

## Terrain shader (`hd2d/shaders/terrain.gdshader`)

Terrain3D's `minimum.gdshader` plus HD-2D ground shading per world texel (`texel 32`): a colour, roughness and analytic height gradient per texel.
- Palettes: grass `g0..g4` (5 tones, `Pix.GRASS`), dirt `d0..d3`, stone/cobble `s0..s3`, `mud`.
- Grass: soft patches, 1×2 blade strokes and tiny flowers where the meadow channel is painted.
- Path: dirt where path > 0.5 or the slope is steep; cobbles where painted.
- **Pond bed** where `y < water_level − 0.08`, **wet bank** up to `water_level + 0.22`, sunlit **caustics** on the bed. Both only where `z > wet_min_z` (uniform, default −7), so a dry valley that dips below the water level elsewhere stays dry. Move `wet_min_z` with the pond.
- Global `wetness` darkens and glosses the ground in rain.

## Pond (`pond.gd`, scene `pond.tscn`)

- The node y **is** the water level. `project.godot` `shader_globals/water_level` must equal it for the editor preview; the rig sets the global from the first `hd2d_water` node at runtime. Carve the pond bed below it in the recipe (demo: water −0.25, bed −0.95).
- One pond per scene: one mirror camera reflects through one plane. A second water surface at another height reflects wrongly.
- The plane `size` (demo 17×17) covers the pond and its stream; grass inside this rect follows the bank rules (bank tufts mirrored, reeds in shallows).
- `water.gdshader`: planar reflection distorted by texel-snapped ripple normals, depth-tinted refraction (`shallow`, `deep`, absorb rate 2.6), Fresnel, foam at the edges, wind cat's paws, rain rings, ripple rings around `cascade_pos`.
  - `distort 0.008` (0.018 smeared the mirror into a grey sheet), `refl_strength 0.92`.
  - `glint` / `glint_lo`: sun or moon sparkles on steepened texel normals; the rig sets golden 16 / 0.94, night 5 / 0.995 (a broad night lobe turned the pond into one bloomed white blob).
  - `sun_dir`, `sun_col` come from the rig preset.
- Lilies: `lilies` pads (20×14 px) in an ellipse at `lily_center` ± `lily_radii`, skipped where the ground is within 0.1 of the surface, bobbing at runtime.
- Mist: an ellipsoid `FogVolume` (`mist_size` at `mist_offset`, base at the water, falloff 2.2, wisp 0.8). Golden density 0.018: thicker mist greys the mirror. Night 0.12 for moonlit haze.
- Material survives rebuilds (the rig holds its reflection texture on it).

## Streams and cascade

- Streams are terrain channels carved by the recipe (`STREAM` polyline, carved to −0.8) under the pond plane: one water surface covers pond and stream, no extra prefab.
- `cascade.tscn`: a tilted quad (`size`, `tilt_deg` −38) of scrolling pixel streaks with foam at the lip, plus splash particles at its foot. Place it where the stream leaves a wall or step; the pond centres its ripple rings 0.15 u in front of it. Layer 2, not mirrored.
