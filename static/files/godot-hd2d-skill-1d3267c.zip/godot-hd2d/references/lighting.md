# Lighting, atmosphere and post

Everything here is built by `res://hd2d/rig.gd`; numbers below are the shipped values. Change one value, A/B it with two `--fixed-fps 60` shots, view both.

## What the rig builds

**Environment** (`_environment`)
- Sky background from `sky.gdshader` (radiance 128, rebuilt only on preset change); ambient and reflections from the sky, `ambient_light_sky_contribution 0.45`.
- ACES tonemap; adjustment contrast 1.06, saturation 1.1; exposure 1.0 golden → 1.15 night.
- SSAO (radius 1.4, intensity 1.8, power 1.4), high tier only.
- Glow: screen blend, not normalised, intensity 0.55, bloom 0.04, HDR threshold 1.0 → 1.3 night, HDR scale 1.8, levels `[0, 0.6, 1, 1, 0.8, 0.5, 0.3]`. Only emissive windows, lamps, glints and fireflies cross the threshold.

**Volumetric fog**: length 70, detail spread 1.6, anisotropy 0.45, `ambient_inject 0` (only lit fog glows, so shafts keep contrast), sky affect 0.15, temporal reprojection 0.9. Global density 0 golden → 0.0015 night (+0.0015 rain); local density comes from FogVolumes.

**Depth fog / aerial perspective**: `FOG_MODE_DEPTH` begins at 48 and ends at 240 (curve 1.4), so the focal band stays clear and T3/T4 fade; aerial perspective 0.35, sky affect 0.25, sun scatter 0.25.

**Distance-graded haze**: a world `FogVolume` with `fog.gdshader` (`by_distance`): density climbs from `near_density` to `density` between camera distance `near_d 36` and `far_d 64` and fades out past `end_d` (90) so far ridges stay readable; base y 0, height falloff 0.25, fbm wisps 0.45. The rig feeds it `cam_pos` every frame.

**Sun / moon** (`_sun`): one `DirectionalLight3D`, PSSM 4 splits (0.08 / 0.2 / 0.45, blended) to 130 u on the high tier, 2 splits to 64 u on balanced; blur 1.2, bias 0.04, normal bias 1.2, angular distance 0 (crisp pixel shadows). Direction = `sun_golden` slerped to `moon` by night (rig exports, azimuth/elevation degrees).

**Sky** (`sky.gdshader`): zenith/horizon/below gradient, sun glow with a tight 9th-power + 90th-power lobe (a 5th-power lobe washed the frame amber), sun disc, twinkling stars at night above the horizon.

**Post** (`post.gdshader` on a full-screen `ColorRect`): split tone (`shadow_tint`, `high_tint`, lift 0.015), vignette 0.42, edge-weighted chromatic aberration `ca 0.0012`, animated grain 0.022.

**Tilt-shift DOF** (`core/tiltshift.gd`, a half-res `CompositorEffect` replacing Godot's DOF, which cost ~5 ms at 1440p): signed circle of confusion from linear depth, golden-angle gather, full-res composite that leaves in-focus pixels untouched so the character stays crisp.
- `focus_distance` = view depth of the first `hd2d_focus` node's `focus_point()`, else the rig `focus`.
- Sharp band: `near_start 3` in front of the focus (blur ramps over `near_range 4`), `far_start 9` behind (ramps over `far_range 34`). `max_coc` 18 px balanced / 22 high at 1440p.
- `near_start` against camera geometry: at pitch 17°, distance 40, FOV 21° the bottom frame ray meets the ground ~6.5 u in front of the focus, so `near_start ≥ 6.5` puts all of T0 inside the sharp band. Recompute this when changing pitch, distance or FOV.

**Camera** (`_camera`): FOV 21°, pitch `Kit.CAM_PITCH` 17°, distance 40 from `focus (0, 2.9, −2)`, near 0.5, far 700. Slow breathing drift (sin 0.11 Hz sideways ±0.9, 0.17 Hz vertical ±0.3), drag to pan ±9, wheel zoom −10…8. Leaf cards and god-ray slices are baked against `CAM_PITCH`: change it in `kit.gd` and every prefab rebuilds to match.

## Presets

`_apply()` blends golden (n = 0) and night (n = 1), then rain (r) on top, every frame while `night`/`rain` move toward their targets.

| Value | Golden | Night | Rain delta |
|---|---|---|---|
| sun colour / energy | `#ffb46e` / 4.4 | `#8fa8ff` / 0.6 | energy × (1 − 0.7r) |
| sun volumetric energy | 1.15 | 1.6 | |
| ambient colour / energy | `#6f7fb8` / 0.6 | `#2a3a78` / 0.6 | |
| sky zenith / horizon | `#5f86c4` / `#ffc48c` | `#0a1430` / `#30406e` | → `#5a6478` / `#8a8e98` × 0.6r |
| sky below / sun glow | `#9a8a7a` / `#ff8a40` | `#141a30` / `#3a5aa0` | glow × (1 − 0.7r) |
| sun disc | 0.99955 | 0.99925 | |
| vol. fog density / albedo / emission | 0 / `#fff0dc` / black | 0.0015 / `#a8b8e8` / `#06080f` | +0.0015r |
| depth fog light colour / density | `#d4bfa6` / 0.8 | `#1e2a50` / 0.9 | → `#7a808c` × 0.5r |
| haze albedo / near / far density | `#ffe6c8` / 0.0015 / 0.022 | `#9cb0e0` / 0.008 / 0.02 | +0.004r / +0.01r |
| glow threshold / exposure | 1.0 / 1.0 | 1.3 / 1.15 | |
| post shadow / high tint | `#c8d8ff` / `#fff0dc` | `#c8d4ff` / `#ffe8cc` | |
| glass / lamp emissive (`Kit.materials()`) | 0.45 / 2.2 | 0.8 / 3.0 | |
| window lights energy / vol. | 0.5 / 1.0 | 0.95 / 2.2 | |
| lantern lights energy / vol. | 1.1 / 2.0 | 4.0 / 4.5 | |
| water sun colour / glint / glint_lo | `#ffc890` / 16 / 0.94 | `#b8c8ff` / 5 / 0.995 | glint × (1 − 0.8r) |
| god rays strength | 1 | 0 | × (1 − 0.75r) |
| dust motes ratio | 1 | 0.25 | × (1 − 0.8r) |
| fireflies ratio | 0 (until n 0.3) | 0.7 | × (1 − 0.8r) |
| pond mist albedo / density | `#fff4e8` / 0.018 | `#b4c4f0` / 0.12 | +0.05r |
| sprite rim / wrap | 0.9 / 0.5 | 2.0 / 0.8 | |
| smoke albedo / backlight | `#ebe6eb` / `#807366` | `#3a4058` / black | |
| globals `night rain wetness wind_strength` | 0 0 0 1 | 1 · · · | r, r, 1 + 0.7r |

Rain also starts the rig's rain particles (9000 streaks in a 52×32 box over the focus) and turns on rain rings in `water.gdshader`.

## Quality tiers

`Q` toggles; `--high` starts on high. Balanced is the default and the bench target.

| | Balanced | High |
|---|---|---|
| AA | SMAA | MSAA 2× |
| SSAO | off | on |
| froxels | 96×64 | 128×96 |
| sun shadows | 2 splits, 64 u, soft very low | 4 splits, 120 u, soft medium |
| 3D scale | 0.8 MetalFX spatial | 1.0 bilinear |
| mirror | 0.45× res, every 2nd frame | 0.5×, every frame |
| bokeh `max_coc` | 18 | 22 |

## Adding lights

- Local lights are `Kit.omni(pos, colour, range)`: attenuation 1.6, specular 0.6, **no shadows** (omni shadows are the expensive part; the sun carries shadow).
- Register the light in the prefab's `apply_preset`: `Kit.window_light(l, n)` for windows, `Kit.lantern_light(l, n)` for lanterns, or your own lerp.
- `light_volumetric_fog_energy` gives local scattering: a lantern halo appears where haze or mist has density.
- Emissive surfaces use the `glass` or `lamp` material; the rig drives their emissive with the preset, so every window and lamp follows.

## God rays

`god_rays` stacks `slices` camera-facing additive quads along the view through a box around the node. Every fragment samples the real sun shadow map in `light()` (`shafts.gdshader`, Henyey-Greenstein g 0.55, gust flicker), so leaf-card holes and gaps between houses become crisp blades ([David Holland](https://www.davidhol.land/articles/3d-pixel-art-rendering)). Cost is overdraw: 20 slices cost ~9 ms at 1440p, 10 slices in the demo box ~1–2 ms. Keep the box inside a canopy's shadow volume, behind content; see the amber-soup pitfall in [style.md](style.md).

## Mirror layers

The water mirror is a second camera reflected through the pond plane (`2 * water_y − y`), rendering into a SubViewport the water shader samples.
- Main camera cull mask covers layers 1–20; the mirror camera sees layers `1 | 16`.
- Layer 2: water, god-ray slices, cascade (never mirrored).
- Layer 4: main grass (not mirrored; too many instances). Layer 1: bank grass and reeds near water (mirrored).
- Layer 16: sprite actors, so their contact decal (cull mask excludes 16) never darkens their feet.
- `surface.gdshader` and `grass.gdshader` discard fragments below `water_level` when the camera is under it (the mirror pass).

## Tuning workflow

1. Change one value (rig `_apply`, a prefab export, or a shader uniform).
2. Shoot A and B with `--fixed-fps 60 --shot-delay=8 --nohud`, golden and night.
3. View both at 1× and crop the region the change targets. Keep it if the target reads better and the focal band stays crisp.
4. Bench when the change adds geometry, slices, particles or lights.

## Performance

- Windferry: 70.3 fps balanced at 2560×1440 on an M1 Pro (451 draws). Template demo: 69.3 fps (700 draws, 0.52 M prims) on the same machine.
- God-ray slices ≈ 1–2 ms; `--hide=GodRays` measures them.
- Cheap levers in order: grass `density` in blurred tiers, far tree `cards`, god-ray `slices`, mirror resolution.
