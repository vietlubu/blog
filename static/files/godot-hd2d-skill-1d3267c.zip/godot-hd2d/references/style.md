# HD-2D style

## What HD-2D is (Octopath Traveler developer notes)

From Acquire's UNREAL FEST EAST 2018 talk ([4Gamer report](https://business.4gamer.net/article/1810/18101801/), [Unreal spotlight](https://www.unrealengine.com/spotlights/octopath-traveler-s-hd-2d-art-style-and-story-make-for-a-jrpg-dream-come-true)):

- **Concept**: late-SNES dot art that kept evolving as dot art instead of turning into 3DCG.
- **Memory-corrected look**: builds with everything crisp and evenly lit felt "old-gen". People remember air, depth, DOF and beautiful effects, *but not overdone*.
- **Dot-art textures with normal + specular response**: dynamic lights and shadows change the pixels in real time.
- **Narrow FOV, gentle perspective**: a normal 3D FOV feels too wide next to 2D games.
- **Chibi scale**: houses shrink to fit 2-head characters; characters at true house scale stop reading as 2D.
- **Tiered (hina-dan) layout**: the back of the map is higher, so the tilted camera sees dense content instead of sky.
- **World-space texels**: pixels never rotate diagonally and seams vanish.
- **Gradient tinting** over tiles breaks repetition; a **wind shader** with gusts moves foliage.
- **Restrained post**: colour grading, bloom, bokeh DOF, vignette, lens flares only on the brightest spots, chromatic aberration only for drama.

## Texel density and scale

One density everywhere: **1 unit = 32 texels**, nearest sampling, no mips.

| Thing | Size | Where it is set |
|---|---|---|
| character | 64 px tall ≈ 2 u; head ≈ half the height | `sprite_actor` derives size from the PNG |
| door | 1.9 u high | `house.gd` |
| house | 5–7 u to the ridge | `house_*.tscn` exports |
| grass tuft | 24×32 px | `Flora.tuft_mesh()` |
| leaf card | 64 px = 2 u | `Flora.canopy(card = 2.0)` |
| lily pad | 20×14 px | `pond.gd` |
| procedural surfaces | `texel = 32.0` | `surface.gdshader`, `terrain.gdshader` |

Rules that keep the grid honest:

- **Integer scale only.** Tufts use `scale_px` 1 in focus and 2 only in tiers that are always blurred (T0, T3). Variety comes from atlas cells, yaw and X-flips, never from non-uniform scale.
- **Axis-aligned pixels.** Cards and sprites yaw toward the camera (`Flora.card_basis` keeps the right axis horizontal); they never roll. The kite flies upright for the same reason.
- **Object-space texels on architecture.** `surface.gdshader` projects 32 texels/unit per face from object space, so a moved or rotated house keeps its pattern.

## Hue-shifted ramps

Every architectural material is a 4-tone ramp (`Kit.materials()`): the dark end shifts toward violet/blue, the light end toward warm cream, so light reads as colour and not only value. `ramp4()` in `common.gdshaderinc` quantises the pattern value; lighting stays continuous on top.

| Key | Pattern | Ramp (dark → light) |
|---|---|---|
| `plaster` / `plaster_b` | 0 plaster | `#7a6560 #bfa58e #e6d2b2 #f7ead0` / `#7c5d5e #c9a294 #efd3bf #fdeadb` |
| `stone`, `stone_big`, `cobble` | 1 rubble / 8 cobbles | `#3d3440 #736a6c #a39886 #d0c4a8` |
| `timber` | 6 beams | `#24161a #432a26 #62402f #82593c` |
| `clay` | 2 tiles | `#4e1f22 #93392b #c95e3a #ea9a5e` |
| `slate` | 3 slate | `#1f2440 #37446c #506595 #7d93bd` |
| `thatch` | 4 thatch | `#4a3420 #86622f #bc9448 #e4c878` |
| `planks`, `shutter_g/b/r` | 5 planks | `#33221d …` / green, blue, red ramps |
| `glass`, `lamp` | 9 glass | warm interiors, emissive |
| `bark` | 7 bark | `#2a2026 #4a3934 #6c5646 #8c775c` |
| `iron`, `cloth_red` | 10 generic | dark neutrals / reds |
| `windmill` | 0 plaster | `#6a5e5a #a89a8c #d6c8b0 #efe4cc` |

Grass uses a 5-tone ramp (`Pix.GRASS`: `#17302f #24503a #3f7536 #6f9c3a #b0c656`, mirrored in `terrain.gdshader` `g0..g4`); leaves a 6-tone one (`Pix.LEAF`). New materials: copy the pattern of an existing ramp, shift hue toward cool in the darks and warm in the lights, keep 4 tones.

## Composition tiers

| Tier | Content | Focus | Demo |
|---|---|---|---|
| T0 foreground | tall tufts, fence, a leafy lens branch in a top corner | strong bokeh, darker and cooler | `GrassT0` (`brightness 0.76`, `coolness 1`), `Fence`, `LensBranchA/B` |
| T1 focal stage | path, bridge, pond, character, lanterns, bench, barrels | sharp | `GrassT1`, `Hero`, `Props` |
| T2 | houses on a 1.6 u terrace behind a retaining wall | sharp to slightly soft | `Houses`, `Wall*`, `Stairs` |
| T3 | big tree, hill, windmill, cottages, forest edge | soft blur | `BigTree`, `HillTree*`, `Forest`, `GrassT3` |
| T4 far | ridge silhouettes in aerial haze, clouds, sky | heavy blur + depth fog | `Backdrop` |

The terrain recipe builds the rise: T1 at y≈0, T2 +1.6, T3 climbing on the left and falling into a valley window on the right, so the sky band shows ridges, flock and kite.

## Value hierarchy

- T0 is the darkest, coolest band and sits in bokeh; it frames, it never competes.
- The focal stage is lit: path, character and signature props carry the brightest warm values after the windows.
- Signature props (windmill, kite, banner) read at 1× against a clean background; check them at 1× in the shot.
- The sky window stays a saturated painted gradient behind value-separated silhouettes.

## Moods

- **Golden hour** (default): low warm sun from behind-left (az −40°, el 27°), long shadows, shafts through the canopy, dust glittering in them, cool blue-violet ambient in shade, windows and lanterns just starting to glow.
- **Night**: moon low behind the pond (az −6°, el 20°) laying a sparkle path on the water, lit windows and lanterns with volumetric glow, fireflies, stars, stronger haze.
- **Rain** layers on either: wet roughness on every surface, grey sky and fog, rain rings on water, dimmer sun.

Values for each: [lighting.md](lighting.md).

## Pitfalls learned (cause → fix)

From the Windferry reviews (`hd2d/review/godot-review-2-opus.md`):

- **Amber god-ray soup.** A slice box in open sunlit air facing a forward-scattering sun adds amber everywhere and veils roofs → confine `god_rays` to a canopy's shadow volume (demo `half (5.5, 4.5, 5)`), `density 0.005`, pale `tint (1, 0.93, 0.8)`.
- **No foreground bokeh.** At pitch 17° / distance 40 the bottom frame edge is only ~6.5 u in front of the focus, so `near_start ≥ 6.5` makes all of T0 sharp → `near_start 3`, `near_range 4` (`tiltshift.gd`).
- **Grey pond.** Strong ripple distortion, thick mist and CA smear the mirror into a sheet → `distort 0.008`, golden mist density `0.018`; the review also asks for post `ca 0.0004` and absorb rate 4.0 (not applied in the template).
- **Night glint blob.** A broad moon-glint lobe turns the pond into one bloomed white blob → `glint_lo 0.995` and `glint 5` at night.
- **Overcast sky window.** `fog_sky_affect 0.25` greys the warm horizon → try `~0.05` (review suggestion, not applied).
- **Rain as white scratches.** Even, vertical, 1-px white streaks over an unchanged sunny grade → slant along `wind_dir`, tint `#c8d4e8` ≤ 0.4 alpha, dim the sun further, add puddles (review suggestion, not applied).
- **Hidden signature props.** A windmill behind a house reads as a stray stick; a kite in the flock lane reads as a bird → place them against the sky window, clear of other silhouettes (demo windmill at (12, 0, −28)).
- **Golden lamps at night strength.** Lanterns as bright at dusk as at night flatten the mood → the review suggests golden lamp emissive ~0.9 and lantern energy ~0.5 (template keeps 2.2 / 1.1).

## Identity

Write 3–6 identity bullets per project in its README: palette and ramp choices, how foliage is built, how light is graded, the signature props, what makes it yours. Keep the fundamentals: crisp pixel art at the focal plane, real 3D light, shadow, fog and reflection on it, tilt-shift depth.
