---
name: godot-hd2d
description: HD-2D dioramas in Godot 4 - Octopath-style pixel art under real 3D light, from a template of editor-editable @tool prefabs (Terrain3D ground, houses, props, trees, grass, water, sky, birds, butterflies). Use when creating or editing an HD-2D scene or project, placing those objects, or tuning its lighting, fog, god rays, tilt-shift DOF, grading or day/night presets.
---

# Godot HD-2D

## The kit in one paragraph

A project has three parts. `res://hd2d/rig.gd` is the `main.tscn` root: camera, sun/moon, environment, volumetric fog, planar water mirror, tilt-shift DOF, post grade, golden/night/rain presets, HUD, capture and bench modes. `res://hd2d/prefabs/*.tscn` are `@tool` prefabs: each rebuilds its meshes under an unowned `_gen` child whenever an export changes, so `main.tscn` stores only exports and the editor shows the real result. The ground is a Terrain3D node baked from `res://terrain/recipe.gd`. Projects built from this template carry `res://hd2d/rig.gd`; detect it before scaffolding.

```
project.godot  main.tscn  assets/hero.png
terrain/recipe.gd  assets.tres  textures/  data/       ground source of truth + baked data
hd2d/rig.gd  core/{gen,kit,builder,pixtex,flora,ground,wind,tiltshift}.gd
hd2d/shaders/  hd2d/prefabs/  hd2d/tools/{bake_terrain,probe}.gd
```

The rig and prefabs find each other only through groups:

| Group | Members | Contract |
|---|---|---|
| `hd2d_terrain` | the Terrain3D node (set in `main.tscn`) | `Ground.find` |
| `hd2d_preset` | prefabs whose lights, materials or particles change with time of day | `apply_preset(night: float, rain: float)` |
| `hd2d_water` | pond (first one wins; one mirror plane) | `var material: ShaderMaterial`, `var size: Vector2` |
| `hd2d_cascade` | cascade | the pond reads its xz for ripple rings |
| `hd2d_focus` | sprite actor | `focus_point() -> Vector3` |
| `hd2d_footprint` | house, structure, prop, tree | `footprint_world() -> Rect2` (XZ) from exports only; grass skips it |

## Start

New project: `bash <skill dir>/scripts/new_project.sh <dir> [--name "Project Name"]`. Done when it prints `BAKE ok regions=4`. It copies `template/`, installs Terrain3D 1.1.0 (downloaded once to `~/.cache/godot-hd2d`, sha256-checked), imports and bakes. Env: `GODOT` (binary, default `godot`), `T3D_ADDON` (copy an existing `addons/terrain_3d` instead of downloading).

Existing project: copy `template/hd2d/` and `template/terrain/`, merge the `[shader_globals]`, `[rendering]` and `[editor_plugins]` sections of `template/project.godot`, install `addons/terrain_3d`, copy the `Terrain` + `ClipmapTarget` node blocks and the `Terrain3DMaterial` sub-resource from `template/main.tscn`, set the root script to `res://hd2d/rig.gd`, then run the bake command below.

## Authoring loop

1. **Compose** the tiers T0 (blurred dark foreground) to T4 (far ridges) per [references/style.md](references/style.md). Done when every tier has named content and the focal tier holds the character and the signature props.
2. **Ground.** Edit `terrain/recipe.gd` (`height()`, `paint()`, `BOUNDS`), bake, then probe the spots you will build on. Done when every probe prints the intended height and paint. Sculpting or painting in the editor diverges from the recipe, and the next bake overwrites it: pick one source per project. Details: [references/terrain-water.md](references/terrain-water.md).
3. **Place prefabs** by editing `main.tscn` text. Reuse the `ext_resource` id when the scene already references the prefab; otherwise add the line next to the other `ext_resource` lines (`load_steps` is only a progress hint). Then add the node under one of the group parents (`Houses`, `Structures`, `Props`, `Trees`, `Grass`, `Water`, `Sky`, `Life`):
   ```
   [ext_resource type="PackedScene" path="res://hd2d/prefabs/tree.tscn" id="tree"]

   [node name="OakEast" parent="Trees" instance=ExtResource("tree")]
   position = Vector3(9.5, 0, 4)
   seed = 9
   canopy = Vector3(3, 2.2, 2.4)
   ```
   - Prefabs with `snap_to_ground = true` in their `.tscn` (trees, bushes, props, windmill, songbird, butterfly, sprite actor) take y 0 and snap; `snap_offset` sinks or lifts them.
   - Houses, structures, pond and anything off the ground take an explicit y: the probed height (house plinth, wall base) or the water level.
   - Rotate only houses, structures and `prop` laundry lines. Snapped and camera-facing prefabs stay unrotated: their leaf cards and sprites are baked against the camera.
   - The default camera frames about x ±11.5 at z 4, ±13 at the focus (z −2) and wider further back; the bottom edge meets the ground near z 8.
   - Done when every new node names an existing prefab, sits on the intended probed spot, and keeps clear of other footprints.
4. **Capture** golden and night shots (commands below), then **view the PNGs**. Done when the change is visible in both and `grep -E "SCRIPT ERROR|Parse Error|^ERROR" *.log` prints nothing.
5. **Tune light** one value at a time with A/B shots: [references/lighting.md](references/lighting.md).

## Prefab catalogue

Scenes live in `res://hd2d/prefabs/`; exports are documented in each script header and `@export` line.

| Scene | Makes | Key exports | Reference |
|---|---|---|---|
| `house_thatch` / `house_clay` / `house_slate` | timber-frame house, lit windows, wall lamp, chimney smoke, window-box flowers | `width depth wall_height roof pitch_deg shutter wall windows door_x chimney_x` | architecture |
| `wall` / `stairs` / `bridge` | retaining wall with coping, buttresses, ivy; stone stairs toward -Z; arched bridge along X | `kind length height width steps rise ivy seed` | architecture |
| `prop` | lantern post, bench, barrel, crate stack, rock, fence, laundry line | `kind count length seed` | architecture |
| `windmill` | tower, cap, sails turning with gusts | snap only | architecture, life |
| `cloth` | hanging cloth / banner billowing in the wind | `size cell stiffness rod` | life |
| `tree` / `bush` / `forest_row` | leaf-card tree, bush (`trunk_height 0`), row of far trees (`count > 1`) | `trunk_height trunk_radius canopy lobes cards leaf sway shadows falling_leaves count spread size_jitter seed` | vegetation |
| `grass_field` | grass, flower and reed tufts over a rect | `size density scale_px brightness coolness flowers seed` | vegetation |
| `pond` | mirror water plane, lilies, mist | `size shallow deep lilies lily_center lily_radii mist mist_offset mist_size` | terrain-water |
| `cascade` | small waterfall + splash | `size tilt_deg` | terrain-water |
| `backdrop` | far ridge silhouettes + drifting clouds | `cloud_count cloud_box seed` | sky-atmosphere |
| `god_rays` | shadow-mapped light-shaft slices + dust motes | `half slices density tint dust` | lighting, sky-atmosphere |
| `fireflies` | night fireflies | `extents amount` | sky-atmosphere |
| `flock` / `songbird` / `butterfly` / `kite` | bird V-formation, hopping bird, butterfly, kite with tail | see script | life |
| `sprite_actor` | a character PNG lit in 3D, contact shadow, DOF focus | `texture_path frames focus` | life |

References: [style](references/style.md) · [lighting](references/lighting.md) · [architecture](references/architecture.md) · [terrain-water](references/terrain-water.md) · [vegetation](references/vegetation.md) · [sky-atmosphere](references/sky-atmosphere.md) · [life](references/life.md).

## HD-2D rules

1. **32 texels per unit** for every surface, card, tuft and sprite; a 64 px character is 2 units tall.
2. **Nearest filtering**, no mips on pixel art; every pixel lands on the 1/32 grid.
3. **Integer scale only** (1× in focus, 2× only in always-blurred tiers), and **pixels stay axis-aligned**: cards yaw toward the camera, never roll.
4. **4-tone hue-shifted ramps** for materials: palettes are quantised, light stays continuous on top of them.
5. **Narrow FOV** (21°), 17° pitch, distance 40: a gentle diorama perspective.
6. **Tiers** T0–T4 rise toward the back so the tilted camera sees content, not sky.
7. **Value hierarchy**: dark, cool, blurred T0; a lit focal stage; signature props readable at 1×.
8. **Restraint**: bloom, fog, CA and god rays support the read; the focal band stays crisp and clear.

Why and how: [references/style.md](references/style.md).

## Commands

Run from the project root. Capture paths must be absolute.

```
godot --path .                                                    # run; 1 golden 2 night R rain F fog G DOF B bloom Q quality H HUD P shot
godot --path . --fixed-fps 60 -- --shot=$PWD/gold.png --shot-delay=8 --nohud > gold.log 2>&1
godot --path . --fixed-fps 60 -- --shot=$PWD/night.png --shot-delay=8 --nohud --preset=night > night.log 2>&1
godot --path . -- --bench --nohud | grep ^BENCH                    # avg fps over seconds 6-16; target >= 60
godot --path . -- --hide=GodRays,GrassT0 --nodof --novol --high   # diagnostics: hide nodes by name, drop DOF / volumetrics, high tier
godot --path . -e                                                 # editor
godot --headless --path . --import                                # re-import after adding textures
godot --headless --path . --script res://hd2d/tools/bake_terrain.gd                 # prints BAKE ok regions=<n>
godot --headless --path . --script res://hd2d/tools/probe.gd -- -12,0.15 7,-8       # PROBE x z h= dirt= cobble= flowers=
```

`--fixed-fps 60` makes captures deterministic in time; `--rain` adds rain; `--scale=0.75` overrides the 3D render scale.

## Gotchas

- In `main.tscn` the Terrain node writes `collision_mode = 0` after `data_directory`: `set_data_directory` recreates the collision object and drops a mode set before it, and the editor collision modes also build collision in game, where all-hole chunks spam `min_height > max_height`.
- Opening the editor rewrites `project.godot` and drops default-valued keys. Check `[shader_globals]` and `[rendering]` survive.
- `project.godot` `shader_globals/water_level` must equal the pond's y for the editor preview; the rig sets it at runtime. One pond per scene: there is one mirror camera, at the first `hd2d_water` node.
- "Albedo texture … has no mipmaps" warnings from Terrain3D are expected: pixel textures stay mip-free.
- Leave code-created `GPUParticles3D` unnamed: on Godot 4.7 a named one leaks its process shader at exit (`ParticlesShaderRD never freed`).
- New static caches in `@tool` scripts get released in `Kit.clear_caches` / `Flora.clear_caches` (the rig calls them on exit), or the exit log reports leaked materials.
- **New prefab**: `@tool` + `extends "res://hd2d/core/gen.gd"`; every export setter assigns then calls `_queue()`; build everything under `root` in `_build(root)`; join groups in `_init()`; add `footprint_world()` if grass must avoid it, `apply_preset(n, r)` if it reacts to time of day, and runtime motion in `_process` behind `set_process(not Engine.is_editor_hint())`; save a `.tscn` shaped like `prefabs/prop.tscn`.
